import { type User, type InsertUser, type Project, type InsertProject, type UseCase, type InsertUseCase } from "@shared/schema";
import { promises as fs } from "fs";
import path from "path";
import type { IStorage } from "./storage";

export class FileStorage implements IStorage {
  private dataDir: string;
  private currentUserId: number = 3;
  private currentProjectId: number = 4;
  private currentUseCaseId: number = 7;

  constructor() {
    this.dataDir = path.join(process.cwd(), 'data');
    this.ensureDataDir();
  }

  private async ensureDataDir() {
    try {
      await fs.access(this.dataDir);
    } catch {
      await fs.mkdir(this.dataDir, { recursive: true });
    }
  }

  private async readJsonFile<T>(filename: string): Promise<T[]> {
    try {
      const filePath = path.join(this.dataDir, filename);
      const data = await fs.readFile(filePath, 'utf-8');
      return JSON.parse(data);
    } catch (error) {
      return [];
    }
  }

  private async writeJsonFile<T>(filename: string, data: T[]): Promise<void> {
    const filePath = path.join(this.dataDir, filename);
    await fs.writeFile(filePath, JSON.stringify(data, null, 2));
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const users = await this.readJsonFile<User>('users.json');
    return users.find(user => user.id === id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await this.readJsonFile<User>('users.json');
    return users.find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const users = await this.readJsonFile<User>('users.json');
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    users.push(user);
    await this.writeJsonFile('users.json', users);
    return user;
  }

  async updateUserRole(userId: number, role: string): Promise<User | undefined> {
    const users = await this.readJsonFile<User>('users.json');
    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex === -1) return undefined;
    
    users[userIndex].currentRole = role;
    await this.writeJsonFile('users.json', users);
    return users[userIndex];
  }

  // Project methods
  async getProjects(): Promise<Project[]> {
    return this.readJsonFile<Project>('projects.json');
  }

  async getProject(id: number): Promise<Project | undefined> {
    const projects = await this.readJsonFile<Project>('projects.json');
    return projects.find(project => project.id === id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const projects = await this.readJsonFile<Project>('projects.json');
    const id = this.currentProjectId++;
    const project: Project = { 
      ...insertProject, 
      id,
      ownerId: insertProject.ownerId || null,
      approvalStatus: insertProject.approvalStatus || "pending",
      approvedById: insertProject.approvedById || null,
      approvedAt: insertProject.approvedAt || null
    };
    projects.push(project);
    await this.writeJsonFile('projects.json', projects);
    return project;
  }

  async updateProject(id: number, updateData: Partial<InsertProject>): Promise<Project | undefined> {
    const projects = await this.readJsonFile<Project>('projects.json');
    const projectIndex = projects.findIndex(p => p.id === id);
    if (projectIndex === -1) return undefined;
    
    projects[projectIndex] = { ...projects[projectIndex], ...updateData };
    await this.writeJsonFile('projects.json', projects);
    return projects[projectIndex];
  }

  async getProjectsByOwner(ownerId: number): Promise<Project[]> {
    const projects = await this.readJsonFile<Project>('projects.json');
    return projects.filter(project => project.ownerId === ownerId);
  }

  // Use case methods
  async getUseCasesByProject(projectId: number): Promise<UseCase[]> {
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    return useCases.filter(useCase => useCase.projectId === projectId);
  }

  async getUseCase(id: number): Promise<UseCase | undefined> {
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    return useCases.find(useCase => useCase.id === id);
  }

  async createUseCase(insertUseCase: InsertUseCase): Promise<UseCase> {
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    const id = this.currentUseCaseId++;
    const useCase: UseCase = { 
      ...insertUseCase, 
      id,
      actor: insertUseCase.actor || null,
      category: insertUseCase.category || null
    };
    useCases.push(useCase);
    await this.writeJsonFile('use-cases.json', useCases);
    return useCase;
  }

  async updateUseCase(id: number, updateData: Partial<InsertUseCase>): Promise<UseCase | undefined> {
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    const useCaseIndex = useCases.findIndex(uc => uc.id === id);
    if (useCaseIndex === -1) return undefined;
    
    useCases[useCaseIndex] = { ...useCases[useCaseIndex], ...updateData };
    await this.writeJsonFile('use-cases.json', useCases);
    return useCases[useCaseIndex];
  }

  async deleteUseCase(id: number): Promise<boolean> {
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    const initialLength = useCases.length;
    const filteredUseCases = useCases.filter(uc => uc.id !== id);
    
    if (filteredUseCases.length === initialLength) return false;
    
    await this.writeJsonFile('use-cases.json', filteredUseCases);
    return true;
  }

  async deleteProject(id: number): Promise<boolean> {
    const projects = await this.readJsonFile<Project>('projects.json');
    const initialLength = projects.length;
    const filteredProjects = projects.filter(p => p.id !== id);
    
    if (filteredProjects.length === initialLength) return false;
    
    await this.writeJsonFile('projects.json', filteredProjects);
    
    // Also delete associated use cases
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    const filteredUseCases = useCases.filter(uc => uc.projectId !== id);
    await this.writeJsonFile('use-cases.json', filteredUseCases);
    
    return true;
  }
}