import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, BarChart3, Users, Check } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { updateUserRole } from "@/lib/auth";
import type { User } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

interface ProfileSwitcherProps {
  user: User;
}

const roleConfig = {
  "business-analyst": {
    label: "Business Analyst",
    description: "Requirements & Analysis",
    icon: BarChart3,
    bgColor: "bg-blue-500",
  },
  "product-owner": {
    label: "Product Owner",
    description: "Strategy & Planning",
    icon: Users,
    bgColor: "bg-green-500",
  },
  "scrum-master": {
    label: "Scrum Master",
    description: "Agile Facilitation",
    icon: Users,
    bgColor: "bg-purple-500",
  },
  "architect": {
    label: "Architect",
    description: "System Design",
    icon: BarChart3,
    bgColor: "bg-indigo-500",
  },
  "ui-designer": {
    label: "UI Designer",
    description: "User Experience",
    icon: BarChart3,
    bgColor: "bg-pink-500",
  },
  "developer": {
    label: "Developer",
    description: "Implementation",
    icon: BarChart3,
    bgColor: "bg-yellow-500",
  },
  "production-management": {
    label: "Production Management",
    description: "Operations & Deployment",
    icon: BarChart3,
    bgColor: "bg-red-500",
  },
  "devops": {
    label: "DevOps",
    description: "Infrastructure & CI/CD",
    icon: BarChart3,
    bgColor: "bg-gray-500",
  },
  "approver": {
    label: "Approver",
    description: "Project Approval",
    icon: Check,
    bgColor: "bg-emerald-500",
  },
};

export function ProfileSwitcher({ user }: ProfileSwitcherProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const switchRoleMutation = useMutation({
    mutationFn: (role: string) => updateUserRole(user.id, role),
    onSuccess: (data) => {
      queryClient.setQueryData(['/api/auth/user'], data.user);
      toast({
        title: "Profile switched",
        description: `Switched to ${roleConfig[data.user.currentRole as keyof typeof roleConfig].label}`,
      });
      setIsOpen(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to switch profile",
        variant: "destructive",
      });
    },
  });

  const currentRoleConfig = roleConfig[user.currentRole as keyof typeof roleConfig];
  const CurrentIcon = currentRoleConfig.icon;

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          className="flex items-center space-x-2 px-4 py-2 bg-primary-50 border-primary-200 hover:bg-primary-100"
        >
          <div className={`w-6 h-6 ${currentRoleConfig.bgColor} rounded-full flex items-center justify-center`}>
            <CurrentIcon className="h-3 w-3 text-white" />
          </div>
          <span className="text-sm font-medium text-primary-700">
            {currentRoleConfig.label}
          </span>
          <ChevronDown className="h-3 w-3 text-primary-500" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64" align="end">
        <DropdownMenuLabel>
          <div>
            <p className="text-sm font-medium text-gray-800">Switch Profile</p>
            <p className="text-xs text-gray-600 mt-1">You have access to multiple roles</p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {user.roles.map((role) => {
          const config = roleConfig[role as keyof typeof roleConfig];
          const RoleIcon = config.icon;
          const isActive = role === user.currentRole;
          
          return (
            <DropdownMenuItem
              key={role}
              className={`flex items-center px-4 py-3 cursor-pointer ${
                isActive ? "bg-primary-50" : ""
              }`}
              onClick={() => {
                if (!isActive && !switchRoleMutation.isPending) {
                  switchRoleMutation.mutate(role);
                }
              }}
            >
              <div className={`w-8 h-8 ${config.bgColor} rounded-full flex items-center justify-center mr-3`}>
                <RoleIcon className="h-4 w-4 text-white" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-medium text-gray-800">{config.label}</p>
                <p className="text-xs text-gray-600">{config.description}</p>
              </div>
              {isActive && <Check className="h-4 w-4 text-primary-500" />}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
