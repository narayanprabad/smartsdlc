import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Users, Eye, Trash2, CheckCircle, XCircle, Clock, Play } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useState } from "react";

interface Project {
  id: number;
  name: string;
  description: string;
  status: string;
  startDate: string;
  teamSize: number;
  functionalUseCases: number;
  nonFunctionalUseCases: number;
  approvalStatus?: string;
  approvedAt?: string;
}

interface ProjectCardProps {
  project: Project;
  onViewUseCases: (projectId: number) => void;
  onDeleteProject?: (projectId: number) => void;
  onApproveProject?: (projectId: number) => void;
  onRejectProject?: (projectId: number) => void;
  onSubmitForApproval?: (projectId: number) => void;
  onCreateTasks?: (projectId: number) => void;
  currentRole: string;
}

const statusColors = {
  Active: "bg-green-50 text-green-700 border-green-200",
  Planning: "bg-yellow-50 text-yellow-700 border-yellow-200", 
  Development: "bg-blue-50 text-blue-700 border-blue-200",
  "On Hold": "bg-gray-50 text-gray-700 border-gray-200",
  Completed: "bg-purple-50 text-purple-700 border-purple-200",
  draft: "bg-orange-50 text-orange-700 border-orange-200",
  in_review: "bg-yellow-50 text-yellow-700 border-yellow-200",
};

export function ProjectCard({ 
  project, 
  onViewUseCases, 
  onDeleteProject, 
  onApproveProject,
  onRejectProject,
  onSubmitForApproval,
  onCreateTasks,
  currentRole 
}: ProjectCardProps) {
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  
  const getApprovalStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleDeleteConfirm = () => {
    if (onDeleteProject) {
      onDeleteProject(project.id);
    }
    setDeleteDialogOpen(false);
  };
  return (
    <Card className="bg-white border border-gray-200 hover:shadow-lg transition-all duration-200 h-[400px] flex flex-col">
      <CardContent className="p-6 flex-1 flex flex-col">
        {/* Header */}
        <div className="mb-4">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            {project.name}
          </h3>
          <div className="flex gap-2 mb-2">
            <Badge
              variant="outline"
              className={`text-xs px-2 py-1 rounded border ${
                project.approvalStatus === 'pending' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' :
                project.approvalStatus === 'approved' ? 'bg-green-100 text-green-800 border-green-200' :
                project.approvalStatus === 'rejected' ? 'bg-red-100 text-red-800 border-red-200' :
                'bg-orange-100 text-orange-800 border-orange-200'
              }`}
            >
              {project.approvalStatus === 'pending' ? 'Pending Review' : 
               project.approvalStatus === 'approved' ? 'Approved' : 
               project.approvalStatus === 'rejected' ? 'Rejected' : 'Draft'}
            </Badge>
          </div>
        </div>

        {/* Description */}
        <div className="flex-1">
          <p className="text-gray-600 text-xs leading-tight mb-4 line-clamp-3">
            {project.description}
          </p>

          {/* Metadata */}
          <div className="flex items-center gap-4 mb-3 text-xs text-gray-500">
            <div className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              <span>{project.startDate}</span>
            </div>
            <div className="flex items-center gap-1">
              <Users className="h-3 w-3" />
              <span>Owner</span>
            </div>
          </div>

          {/* Progress */}
          <div className="mb-4">
            <div className="flex justify-between items-center mb-1">
              <span className="text-xs text-gray-700 font-medium">Progress</span>
              <span className="text-xs text-gray-500">0%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5">
              <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: "0%" }}></div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-2 mt-auto">
          <div className="flex gap-2">
            <Button
              onClick={(e) => {
                e.stopPropagation();
                onViewUseCases(project.id);
              }}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Eye className="h-4 w-4 mr-2" />
              View Details
            </Button>
            {onDeleteProject && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    className="text-red-500 hover:text-red-600 hover:bg-red-50"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="max-w-md">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="flex items-center gap-2">
                      <Trash2 className="h-5 w-5 text-red-500" />
                      Delete Project
                    </AlertDialogTitle>
                    <AlertDialogDescription className="text-gray-600">
                      Are you sure you want to delete "{project.name}"? This action cannot be undone and will permanently remove all project data including use cases and requirements.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="border-gray-200 hover:bg-gray-50">
                      Cancel
                    </AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={handleDeleteConfirm}
                      className="bg-red-600 hover:bg-red-700 text-white"
                    >
                      Delete Project
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>

          {/* Role-based Workflow Actions */}
          
          {/* Business Analyst: Can submit draft projects for approval */}
          {currentRole === 'business-analyst' && project.approvalStatus === 'draft' && onSubmitForApproval && (
            <Button
              variant="outline"
              className="w-full text-green-600 border-green-200 hover:bg-green-50"
              onClick={(e) => {
                e.stopPropagation();
                onSubmitForApproval(project.id);
              }}
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Submit for Approval
            </Button>
          )}

          {/* Business Analyst: Read-only for pending projects */}
          {currentRole === 'business-analyst' && project.approvalStatus === 'pending' && (
            <div className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-md">
              <div className="flex items-center gap-2 text-yellow-700 text-sm">
                <Clock className="h-4 w-4" />
                <span className="font-medium">Pending Approval</span>
              </div>
              <p className="text-xs text-yellow-600 mt-1">Project is under review by Product Owner</p>
            </div>
          )}

          {/* Product Owner: Can approve or reject pending projects */}
          {currentRole === 'product-owner' && project.approvalStatus === 'pending' && (
            <div className="grid grid-cols-2 gap-2">
              {onApproveProject && (
                <Button
                  variant="outline"
                  size="sm"
                  className="text-green-600 border-green-200 hover:bg-green-50 text-xs"
                  onClick={(e) => {
                    e.stopPropagation();
                    onApproveProject(project.id);
                  }}
                >
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Approve
                </Button>
              )}
              {onRejectProject && (
                <Button
                  variant="outline"
                  size="sm"
                  className="text-red-600 border-red-200 hover:bg-red-50 text-xs"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRejectProject(project.id);
                  }}
                >
                  <XCircle className="h-3 w-3 mr-1" />
                  Needs Work
                </Button>
              )}
            </div>
          )}

          {/* Other roles: Show work in progress indicator */}
          {!['business-analyst', 'product-owner'].includes(currentRole) && (
            <div className="w-full p-3 bg-blue-50 border border-blue-200 rounded-md">
              <div className="flex items-center gap-2 text-blue-700 text-sm">
                <Play className="h-4 w-4" />
                <span className="font-medium">Work in Progress</span>
              </div>
              <p className="text-xs text-blue-600 mt-1">Project is being processed by the team</p>
            </div>
          )}

          {currentRole === 'product-owner' && project.approvalStatus === 'approved' && onCreateTasks && (
            <Button
              variant="outline"
              className="w-full text-blue-600 border-blue-200 hover:bg-blue-50"
              onClick={(e) => {
                e.stopPropagation();
                if (confirm('Create development tasks for this project?')) {
                  onCreateTasks(project.id);
                }
              }}
            >
              <Play className="h-4 w-4 mr-2" />
              Create Tasks
            </Button>
          )}

          {project.status === 'Development' && currentRole !== 'business-analyst' && currentRole !== 'product-owner' && (
            <div className="text-center py-2">
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                <Clock className="h-3 w-3 mr-1" />
                Development in Progress
              </Badge>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
