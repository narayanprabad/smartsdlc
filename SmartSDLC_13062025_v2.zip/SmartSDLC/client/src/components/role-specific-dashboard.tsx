import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search } from "lucide-react";

interface RoleSpecificDashboardProps {
  currentRole: string;
  onCreateProject: () => void;
}

export function RoleSpecificDashboard({ currentRole, onCreateProject }: RoleSpecificDashboardProps) {
  return (
    <div className="flex items-center gap-4 mb-6">
      <Button 
        onClick={onCreateProject} 
        className="bg-blue-500 hover:bg-blue-600 text-white"
      >
        <Plus className="h-4 w-4 mr-2" />
        Create Project
      </Button>
      
      <div className="flex items-center gap-2 flex-1">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search projects..."
            className="pl-10"
          />
        </div>
        
        <Select defaultValue="all-status">
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all-status">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="planning">Planning</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
        
        <Select defaultValue="all-types">
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all-types">All Types</SelectItem>
            <SelectItem value="web">Web</SelectItem>
            <SelectItem value="mobile">Mobile</SelectItem>
            <SelectItem value="api">API</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}