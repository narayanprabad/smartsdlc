import { generateArtifacts } from './server/bedrock';

(async () => {
  try {
    const result = await generateArtifacts('Create a project Payment gateway');
    console.log(JSON.stringify(result, null, 2));
  } catch (error: any) {
    console.error('ERROR:', error.message);
  }
})();
