import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";

function getBedrockClient() {
  const AWS_REGION = process.env.AWS_REGION || "us-east-1";
  const AWS_ACCESS_KEY_ID = process.env.AWS_ACCESS_KEY_ID;
  const AWS_SECRET_ACCESS_KEY = process.env.AWS_SECRET_ACCESS_KEY;

  if (!AWS_ACCESS_KEY_ID || !AWS_SECRET_ACCESS_KEY) {
    throw new Error("AWS credentials are not configured.");
  }

  return new BedrockRuntimeClient({
    region: AWS_REGION,
    credentials: {
      accessKeyId: AWS_ACCESS_KEY_ID,
      secretAccessKey: AWS_SECRET_ACCESS_KEY,
    },
  });
}

interface BedrockContentBlock {
  type: "text" | "image";
  text?: string;
  source?: {
    type: "base64";
    media_type: string;
    data: string;
  };
}

interface BedrockMessage {
  role: "user" | "assistant";
  content: BedrockContentBlock[];
}

interface UploadedFile {
  name: string;
  type: string;
  size: number;
  base64: string;
}

interface BedrockRequest {
  messages: BedrockMessage[];
  max_tokens: number;
  anthropic_version: string;
}

interface BedrockResponse {
  content: Array<{
    type: string;
    text: string;
  }>;
}

function buildMessageContent(prompt: string, files?: UploadedFile[]): BedrockContentBlock[] {
  const content: BedrockContentBlock[] = [];
  
  // Add text content
  content.push({
    type: "text",
    text: prompt,
  });
  
  // Add file attachments if present
  if (files && files.length > 0) {
    console.log(`[buildMessageContent] Processing ${files.length} file(s) for Bedrock`);
    for (const file of files) {
      // Handle images (PNG, JPG, GIF, WebP)
      if (file.type.startsWith('image/')) {
        console.log(`[buildMessageContent] Adding image: ${file.name} (${file.type})`);
        content.push({
          type: "image",
          source: {
            type: "base64",
            media_type: file.type,
            data: file.base64, // Using base64 field from UploadedFile interface
          },
        });
      }
      // Handle text documents (TXT, MD, JSON) - add as text context
      else if (file.type === 'text/plain' || file.type === 'text/markdown' || file.type === 'application/json') {
        try {
          console.log(`[buildMessageContent] Adding text document: ${file.name} (${file.type})`);
          const decodedText = Buffer.from(file.base64, 'base64').toString('utf-8');
          
          // Safeguard: Truncate very large text files to prevent token limit issues
          const MAX_TEXT_LENGTH = 50000; // ~50KB of text (roughly 12-15k tokens)
          let finalText = decodedText;
          if (decodedText.length > MAX_TEXT_LENGTH) {
            console.warn(`[buildMessageContent] Text file ${file.name} is large (${decodedText.length} chars), truncating to ${MAX_TEXT_LENGTH} chars`);
            finalText = decodedText.substring(0, MAX_TEXT_LENGTH) + '\n...[truncated]';
          }
          
          content.push({
            type: "text",
            text: `\n\n--- Attached file: ${file.name} ---\n${finalText}\n--- End of ${file.name} ---\n`,
          });
        } catch (error) {
          console.error(`[buildMessageContent] Failed to decode text file ${file.name}:`, error);
        }
      }
    }
  }
  
  return content;
}

export async function callBedrock(prompt: string, files?: UploadedFile[]): Promise<string> {
  try {
    const bedrockClient = getBedrockClient();
    const payload: BedrockRequest = {
      anthropic_version: "bedrock-2023-05-31",
      max_tokens: 8192,
      messages: [
        {
          role: "user",
          content: buildMessageContent(prompt, files),
        },
      ],
    };

    const modelId = "us.anthropic.claude-3-7-sonnet-20250219-v1:0";
    
    const command = new InvokeModelCommand({
      modelId,
      contentType: "application/json",
      accept: "application/json",
      body: JSON.stringify(payload),
    });

    const response = await bedrockClient.send(command);
    
    if (!response.body) {
      throw new Error("No response body from Bedrock");
    }

    let bodyString: string;
    if (response.body instanceof Uint8Array) {
      bodyString = new TextDecoder().decode(response.body);
    } else {
      const chunks: Uint8Array[] = [];
      for await (const chunk of response.body as AsyncIterable<Uint8Array>) {
        chunks.push(chunk);
      }
      const fullBody = Buffer.concat(chunks);
      bodyString = fullBody.toString('utf-8');
    }
    const responseBody = JSON.parse(bodyString) as BedrockResponse;

    if (!responseBody.content || responseBody.content.length === 0) {
      throw new Error("No content in Bedrock response");
    }

    const textBlocks = responseBody.content.filter((block) => block.type === "text");
    if (textBlocks.length === 0) {
      throw new Error("No text content found in Bedrock response");
    }

    return textBlocks.map((block) => block.text).join("\n");
  } catch (error: any) {
    console.error("Bedrock API Error:", error.message);
    throw new Error(`AI service error: ${error.message}`);
  }
}

function extractAndParseJSON(response: string, context: string): any {
  console.log(`[extractAndParseJSON] Context: ${context}, Response length: ${response.length}`);
  
  let cleanedResponse = response;
  if (cleanedResponse.includes('```json')) {
    cleanedResponse = cleanedResponse.replace(/```json\s*/g, '').replace(/```\s*/g, '');
  } else if (cleanedResponse.includes('```')) {
    cleanedResponse = cleanedResponse.replace(/```\s*/g, '');
  }
  
  const startIndex = cleanedResponse.indexOf('{');
  let endIndex = cleanedResponse.lastIndexOf('}');
  
  if (startIndex === -1 || endIndex === -1) {
    throw new Error(`Failed to find valid JSON in AI response for ${context}.`);
  }

  const jsonString = cleanedResponse.substring(startIndex, endIndex + 1);
  
  try {
    const parsed = JSON.parse(jsonString);
    console.log(`[extractAndParseJSON] Successfully parsed JSON for ${context}`);
    return parsed;
  } catch (error: any) {
    console.error(`[extractAndParseJSON] JSON Parse Error:`, error.message);
    throw new Error(`Failed to parse AI response as valid JSON: ${error.message}`);
  }
}

export async function generateProjectTitle(requirements: string): Promise<string> {
  const prompt = `Generate a professional, concise project title from these requirements.

REQUIREMENTS: ${requirements.substring(0, 500)}

Create a noun-based title that describes what the system IS, not what it does.
Format: "[System Type] to [facilitate/enable/provide] [key capability]"

Examples:
- "Design a payment gateway" → "Payment Gateway to facilitate secure online transactions"
- "Build an inventory system" → "Inventory Management System to enable real-time stock tracking"
- "Create a CRM" → "Customer Relationship Management Platform to streamline sales operations"

Rules:
- Keep it under 80 characters
- Return ONLY the title, no quotes, no extra text, no JSON
- Do NOT include file paths or technical implementation details`;

  const response = await callBedrock(prompt);
  // Extract and clean the title
  let title = response.trim()
    .replace(/^["'`]|["'`]$/g, '') // Remove surrounding quotes
    .replace(/^(Title:|Project:)\s*/i, '') // Remove common prefixes
    .split('\n')[0] // Take first line only
    .trim();
  
  // Validate title (shouldn't contain paths or be too long)
  if (title.includes('/') || title.includes('\\') || title.length > 100) {
    throw new Error('Generated title contains invalid characters');
  }
  
  return title;
}

// Separate focused Bedrock calls for each section to stay within token limits

async function generateBusinessContext(requirements: string, userContext?: any, files?: UploadedFile[]): Promise<any> {
  const filesContext = files && files.length > 0 
    ? `\n\nNOTE: User has attached ${files.length} file(s) for additional context. Analyze any images, diagrams, or documents to enhance your business analysis.`
    : '';
  
  const prompt = `Analyze these requirements and generate ONLY business context in valid JSON.

REQUIREMENTS: ${requirements}${filesContext}

Generate a professional business analysis with:
- Executive summary: 2-3 sentences on strategic value and business outcomes
- Domain analysis: 2-3 sentences on industry context and business processes
- Key stakeholders: 3-4 roles with brief descriptions
- Business goals: 3-4 measurable objectives
- Risk assessment: Top 3 risks with severity (high/medium/low) and mitigation strategies

Return ONLY this JSON (no markdown, no explanations):
{
  "executiveSummary": "2-3 sentence strategic overview",
  "domainAnalysis": "2-3 sentence industry context",
  "keyStakeholders": ["CFO: Requires compliance reporting", "Trading Desk: Daily users", "Risk Manager: Oversight"],
  "businessGoals": ["goal1", "goal2", "goal3"],
  "riskAssessment": [
    {"risk": "Data accuracy issues", "severity": "high", "mitigation": "Implement validation rules"},
    {"risk": "Performance degradation", "severity": "medium", "mitigation": "Load testing and optimization"}
  ]
}`;

  const response = await callBedrock(prompt, files);
  return extractAndParseJSON(response, "generateBusinessContext");
}

async function generateArchitecture(requirements: string, businessContext: any, files?: UploadedFile[]): Promise<any> {
  const filesContext = files && files.length > 0 
    ? `\n\nNOTE: User has attached ${files.length} file(s). Analyze any architecture diagrams, wireframes, or documents to inform your design.`
    : '';
  
  const prompt = `Generate ONLY architecture artifacts for this system in valid JSON.

REQUIREMENTS: ${requirements}
BUSINESS CONTEXT: ${businessContext.executiveSummary}${filesContext}

Generate professional architecture with:
- 4-5 components with responsibilities and technologies
- 2 detailed Mermaid diagrams: System Context (12-15 lines) and Component Architecture (15-18 lines)
- 3-4 infrastructure components
- Security architecture: 2-3 items per category

Return ONLY this JSON:
{
  "architectureOutline": [
    {"component": "Frontend", "description": "User interface", "responsibilities": ["Display data", "User input"], "technologies": ["React 18", "TypeScript"], "dependencies": ["Backend API"]}
  ],
  "architectureDiagrams": [
    {"title": "System Context", "type": "c4-context", "mermaidCode": "graph TB\\n  User[End User]\\n  System[Application]\\n  DB[(Database)]\\n  User-->System\\n  System-->DB"},
    {"title": "Component Architecture", "type": "components", "mermaidCode": "graph TB\\n  subgraph Frontend\\n    UI[UI Components]\\n    State[State Management]\\n  end\\n  subgraph Backend\\n    API[REST API]\\n    BL[Business Logic]\\n    Data[Data Layer]\\n  end"}
  ],
  "infrastructureComponents": [
    {"name": "PostgreSQL", "type": "database", "provider": "AWS RDS", "specifications": "db.t3.medium", "purpose": "Primary data store"}
  ],
  "securityArchitecture": {
    "authentication": ["OAuth 2.0", "JWT tokens"],
    "authorization": ["RBAC", "Permission checks"],
    "dataEncryption": ["TLS 1.3", "AES-256 at rest"],
    "compliance": ["SOC 2", "GDPR"]
  },
  "wellArchitectedPillars": {
    "operationalExcellence": ["CloudWatch monitoring", "Automated deployments"],
    "security": ["Encryption", "MFA"],
    "reliability": ["Multi-AZ", "Automated backups"],
    "performanceEfficiency": ["CDN", "Caching"],
    "costOptimization": ["Auto-scaling", "Reserved instances"],
    "sustainability": ["Efficient queries"]
  }
}`;

  const response = await callBedrock(prompt, files);
  return extractAndParseJSON(response, "generateArchitecture");
}

async function generateDevelopment(requirements: string, files?: UploadedFile[]): Promise<any> {
  const filesContext = files && files.length > 0 
    ? `\n\nNOTE: User has attached ${files.length} file(s). Review any code examples, tech stack preferences, or implementation details.`
    : '';
  
  const prompt = `Generate ONLY development artifacts for this system in valid JSON.

REQUIREMENTS: ${requirements}${filesContext}

Generate comprehensive development guide with:
- 3-4 code files with complete implementations (15-20 lines each - full functions, not snippets)
- 6-8 dependencies with versions
- 5-6 environment variables with descriptions and examples
- Repository structure
- Setup instructions

Return ONLY this JSON:
{
  "codeFiles": [
    {"filename": "server.js", "language": "javascript", "path": "src/backend/", "purpose": "Main server", "description": "Express server setup", "code": "const express = require('express');\\nconst app = express();\\nconst port = process.env.PORT || 3000;\\n\\napp.use(express.json());\\n\\napp.get('/api/health', (req, res) => {\\n  res.json({ status: 'healthy' });\\n});\\n\\napp.listen(port, () => {\\n  console.log(\`Server running on port \${port}\`);\\n});"}
  ],
  "developmentGuide": {
    "setupInstructions": ["git clone repo", "npm install", "cp .env.example .env", "npm run dev"],
    "technologyStack": ["Node.js 20", "Express 4.18", "PostgreSQL 15"],
    "codeConventions": ["ES6+", "Async/await", "Camelcase"],
    "dependencies": {"runtime": ["express: ^4.18.0", "pg: ^8.11.0"], "development": ["jest: ^29.0.0"]},
    "environmentVariables": [
      {"name": "DATABASE_URL", "description": "PostgreSQL connection", "example": "postgresql://user:pass@localhost:5432/db", "required": true}
    ],
    "repositoryStructure": [
      {"path": "/src/backend", "purpose": "Server code"},
      {"path": "/src/frontend", "purpose": "React app"}
    ]
  },
  "codeReviewGuidelines": [
    {"category": "Security", "guidelines": ["No hardcoded secrets"], "checklist": ["Env vars used"]}
  ]
}`;

  const response = await callBedrock(prompt, files);
  return extractAndParseJSON(response, "generateDevelopment");
}

async function generateQAAndRequirements(requirements: string, files?: UploadedFile[]): Promise<any> {
  const filesContext = files && files.length > 0 
    ? `\n\nNOTE: User has attached ${files.length} file(s). Use any requirements documents, test cases, or acceptance criteria provided.`
    : '';
  
  const prompt = `Generate ONLY requirements and QA artifacts for this system in valid JSON.

REQUIREMENTS: ${requirements}${filesContext}

Generate:
- 5-6 user stories with acceptance criteria (Given-When-Then format)
- 6-8 functional requirements
- Non-functional requirements (2-3 per category)
- 5-6 test cases with traceability to requirements (10-12 lines of test code each)
- Tasks for Sprint 0

Return ONLY this JSON:
{
  "userStories": [
    {"id": "US-1", "title": "User login", "description": "As a user, I want to login so that I can access the system", "acceptanceCriteria": ["Given valid credentials, When I login, Then I am redirected to dashboard"], "effort": "small", "priority": "high", "linkedRequirements": ["FR-1"]}
  ],
  "functionalRequirements": [
    {"id": "FR-1", "requirement": "System must authenticate users", "priority": "high"}
  ],
  "nonFunctionalRequirements": {
    "performance": ["Response time < 200ms", "Support 1000 concurrent users"],
    "security": ["Encrypt data at rest", "TLS 1.3"],
    "scalability": ["Horizontal scaling", "Auto-scaling"],
    "reliability": ["99.9% uptime", "Automated failover"],
    "maintainability": ["Code coverage > 80%", "Documented APIs"]
  },
  "testCases": [
    {"id": "TC-1", "linkedRequirements": ["FR-1", "US-1"], "testName": "User authentication", "testType": "integration", "description": "Verify login flow", "preconditions": "User exists", "testSteps": ["Navigate to login", "Enter credentials", "Click login"], "expectedResult": "User logged in", "language": "javascript", "testCode": "describe('Auth', () => {\\n  it('should login user', async () => {\\n    const response = await request(app)\\n      .post('/api/auth/login')\\n      .send({ email: 'test@example.com', password: 'pass' });\\n    expect(response.status).toBe(200);\\n    expect(response.body.token).toBeDefined();\\n  });\\n});"}
  ],
  "tasks": [
    {"id": "T-1", "role": "Scrum Master", "task": "Create Sprint 0 planning", "effort": "4h", "status": "pending"},
    {"id": "T-2", "role": "Architect", "task": "Review architecture", "effort": "6h", "status": "pending"}
  ]
}`;

  const response = await callBedrock(prompt, files);
  return extractAndParseJSON(response, "generateQAAndRequirements");
}

export async function generateArtifacts(
  requirements: string, 
  userContext?: any, 
  persona?: string,
  files?: UploadedFile[]
) {
  console.log('[generateArtifacts] Starting multi-pass generation...');
  console.log(`[generateArtifacts] Files attached: ${files?.length || 0}`);
  
  try {
    // Phase 1: Business Context
    console.log('[generateArtifacts] Phase 1: Generating business context...');
    const businessContext = await generateBusinessContext(requirements, userContext, files);
    
    // Phase 2: Architecture
    console.log('[generateArtifacts] Phase 2: Generating architecture...');
    const architecture = await generateArchitecture(requirements, businessContext, files);
    
    // Phase 3: Development
    console.log('[generateArtifacts] Phase 3: Generating development artifacts...');
    const development = await generateDevelopment(requirements, files);
    
    // Phase 4: QA and Requirements
    console.log('[generateArtifacts] Phase 4: Generating QA and requirements...');
    const qaAndRequirements = await generateQAAndRequirements(requirements, files);
    
    // Aggregate all sections
    const aggregatedArtifacts = {
      businessContext,
      ...qaAndRequirements,
      ...architecture,
      ...development,
    };
    
    console.log('[generateArtifacts] Multi-pass generation complete!');
    console.log(`- Business Context: ${businessContext ? 'Generated' : 'Missing'}`);
    console.log(`- User Stories: ${qaAndRequirements.userStories?.length || 0}`);
    console.log(`- Architecture Diagrams: ${architecture.architectureDiagrams?.length || 0}`);
    console.log(`- Code Files: ${development.codeFiles?.length || 0}`);
    console.log(`- Test Cases: ${qaAndRequirements.testCases?.length || 0}`);
    
    return aggregatedArtifacts;
  } catch (error: any) {
    console.error('[generateArtifacts] Multi-pass generation failed:', error.message);
    throw error;
  }
}

// Legacy single-pass function (keeping for reference, not used)
async function generateArtifactsSinglePass(
  requirements: string, 
  userContext?: any, 
  persona?: string
) {
  const userInfo = userContext ? `
PROJECT CREATOR: ${userContext.userName} (${userContext.userRole})
` : '';

  const prompt = `You are an elite enterprise architect and development lead. Generate professional-grade SDLC artifacts in valid JSON format.

REQUIREMENTS: ${requirements}
${userInfo}

Generate professional yet concise artifacts following these TOKEN-OPTIMIZED LIMITS (8192 token max):

BUSINESS CONTEXT (keep brief - 150 words total):
- Executive summary: 2 sentences on strategic value
- Domain analysis: 2 sentences on industry context
- 2-3 key stakeholders
- 2-3 main business goals
- Top 2 risks with mitigation

REQUIREMENTS:
- 4-6 user stories with clear acceptance criteria
- 5-7 functional requirements
- 2-3 non-functional requirements per category

ARCHITECTURE:
- 3-5 main components with responsibilities and 2-3 tech items each
- 2 Mermaid diagrams ONLY: (1) System Context 10-12 lines, (2) Component Architecture 12-15 lines
- 3-4 infrastructure components
- Security: 2 items per category (auth, authorization, encryption)

DEVELOPMENT:
- 2-3 code files with complete implementations (12-18 lines each)
- Dependencies: 6-8 key packages with versions
- Environment variables: 4-6 critical vars with descriptions
- Repository structure: 4-6 key folders
- Setup: 5-7 clear steps

QA:
- 4-6 test cases covering critical paths
- Link each test to 1-2 requirements for traceability
- Test code: 8-12 lines per test

TASKS:
- 5-7 tasks assigned to roles (Scrum Master, Architect, Developer, QA)
- Include effort and priority

Return THIS JSON structure:
{
  "businessContext": {
    "executiveSummary": "Strategic overview (2-3 sentences)",
    "domainAnalysis": "Industry context and business processes",
    "keyStakeholders": ["role: description"],
    "businessGoals": ["goal1", "goal2"],
    "riskAssessment": [{"risk": "description", "severity": "high|medium|low", "mitigation": "strategy"}]
  },
  "userStories": [{"id":"US-1","title":"title","description":"as a... I want... so that...","acceptanceCriteria":["Given..When..Then"],"effort":"small|medium|large","priority":"high|medium|low","linkedRequirements":["FR-1"]}],
  "functionalRequirements": [{"id":"FR-1","requirement":"description","priority":"high|medium|low"}],
  "nonFunctionalRequirements": {"performance":["requirement"],"security":["requirement"],"scalability":["requirement"],"reliability":["requirement"],"maintainability":["requirement"],"usability":["requirement"]},
  "architectureOutline": [{"component":"name","description":"detailed description","responsibilities":["resp1"],"technologies":["tech: version"],"dependencies":["component-name"]}],
  "architectureDiagrams": [
    {"title":"C4 Context Diagram","type":"c4-context","mermaidCode":"graph TB\\nsubgraph System\\nApp[Application]\\nend\\nUser-->App\\nApp-->DB[Database]\\nApp-->API[External API]"},
    {"title":"Component Architecture","type":"components","mermaidCode":"graph TB\\nsubgraph Frontend\\nUI\\nState\\nend\\nsubgraph Backend\\nAPI\\nBL[Business Logic]\\nData\\nend"},
    {"title":"Deployment Architecture","type":"deployment","mermaidCode":"graph LR\\nCDN-->LB[Load Balancer]\\nLB-->App1\\nLB-->App2\\nApp1-->DB\\nApp2-->DB"}
  ],
  "infrastructureComponents": [{"name":"service","type":"compute|database|cache|queue","provider":"AWS|Azure|GCP","specifications":"details","purpose":"why needed"}],
  "securityArchitecture": {"authentication":["strategy"],"authorization":["RBAC details"],"dataEncryption":["at-rest and in-transit"],"compliance":["standards"]},
  "wellArchitectedPillars": {"operationalExcellence":["monitoring","logging","CI/CD"],"security":["auth","encryption"],"reliability":["backups","failover"],"performanceEfficiency":["caching","CDN"],"costOptimization":["auto-scaling"],"sustainability":["efficient code"]},
  "codeFiles": [{"filename":"server.js","language":"javascript","path":"src/backend/","purpose":"Main server","description":"Express server setup","code":"// Full implementation (20-40 lines)\\nconst express = require('express');\\nconst app = express();\\n// ... complete code"}],
  "testCases": [{"id":"TC-1","linkedRequirements":["FR-1","US-1"],"testName":"User authentication","testType":"integration","description":"Verify user can login","preconditions":"User exists","testSteps":["Navigate to login","Enter credentials","Click login"],"expectedResult":"User redirected to dashboard","language":"javascript","testCode":"describe('Auth', () => {\\n  it('should login user', async () => {\\n    // Full test implementation\\n  });\\n});"}],
  "codeReviewGuidelines": [{"category":"Security","guidelines":["No hardcoded secrets","Input validation","SQL injection prevention"],"checklist":["Environment variables used","Inputs sanitized","Parameterized queries"]}],
  "developmentGuide": {
    "setupInstructions":["git clone repo","npm install","cp .env.example .env","Configure DATABASE_URL","npm run db:migrate","npm run dev"],
    "technologyStack":["Node.js 20.x","Express 4.x","PostgreSQL 15","Redis 7.x","React 18"],
    "codeConventions":["ES6+ syntax","Async/await","2-space indentation","Camelcase naming"],
    "dependencies":{"runtime":["express: ^4.18.0","pg: ^8.11.0"],"development":["jest: ^29.0.0","eslint: ^8.0.0"]},
    "environmentVariables":[{"name":"DATABASE_URL","description":"PostgreSQL connection string","example":"postgresql://user:pass@localhost:5432/db","required":true}],
    "repositoryStructure":[{"path":"/src/backend","purpose":"Server-side code"},{"path":"/src/frontend","purpose":"React application"},{"path":"/tests","purpose":"Test suites"}]
  },
  "tasks": [{"id":"T-1","role":"Scrum Master","task":"Create Sprint 0 planning","effort":"4h","status":"pending","priority":"high"},{"id":"T-2","role":"Architect","task":"Review architecture","effort":"6h","status":"pending","priority":"high"}]
}

IMPORTANT: Generate COMPLETE code files (20-40 lines each), not 3-5 line snippets. Include ALL dependencies. Return ONLY valid JSON, no markdown.`;

  const maxRetries = 3;
  let lastError: Error | null = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`[generateArtifacts] Attempt ${attempt}/${maxRetries}`);
      const response = await callBedrock(prompt);
      
      const result = extractAndParseJSON(response, "generateArtifacts");
      
      console.log(`[generateArtifacts] Success on attempt ${attempt}`);
      console.log(`- User Stories: ${result.userStories?.length || 0}`);
      console.log(`- Code Files: ${result.codeFiles?.length || 0}`);
      console.log(`- Test Cases: ${result.testCases?.length || 0}`);
      
      return result;
    } catch (error: any) {
      lastError = error;
      console.error(`[generateArtifacts] Attempt ${attempt} failed:`, error.message);
      
      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
  }
  
  throw lastError || new Error('Failed to generate artifacts after all retries');
}

export async function refineArtifacts(
  currentArtifacts: any,
  refinementPrompt: string,
  requirements: string
) {
  const prompt = `Refine these SDLC artifacts based on feedback.
  
Requirements: ${requirements}
Feedback: ${refinementPrompt}

Return the complete updated JSON with all sections.`;

  const result = extractAndParseJSON(await callBedrock(prompt), "refineArtifacts");
  return result;
}
