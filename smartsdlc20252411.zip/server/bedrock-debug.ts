// DEBUG: Save prompt and response to files for inspection
import fs from 'fs';
import path from 'path';

const debugDir = '/tmp/bedrock-debug';

export function initDebugDir() {
  if (!fs.existsSync(debugDir)) {
    fs.mkdirSync(debugDir, { recursive: true });
  }
}

export function savePrompt(prompt: string, timestamp: string) {
  initDebugDir();
  const filename = path.join(debugDir, `prompt-${timestamp}.txt`);
  fs.writeFileSync(filename, prompt, 'utf-8');
  console.log(`[DEBUG] Prompt saved to: ${filename}`);
  console.log(`[DEBUG] FULL PROMPT:\n${prompt}\n`);
  return filename;
}

export function saveResponse(response: string, timestamp: string) {
  initDebugDir();
  const filename = path.join(debugDir, `response-${timestamp}.json`);
  fs.writeFileSync(filename, response, 'utf-8');
  console.log(`[DEBUG] Response saved to: ${filename}`);
  console.log(`[DEBUG] FULL RESPONSE (first 2000 chars):\n${response.substring(0, 2000)}\n`);
  return filename;
}
