// API Routes for SmartSDLC with Authentication and Multi-Project Support
// Reference: blueprint:javascript_log_in_with_replit

import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";
import { setupSimulatedAuth, isAuthenticated } from "./simulatedAuth";
import { generateArtifacts, generateProjectTitle, refineArtifacts } from "./bedrock";
import { processAgentMessage } from "./agent";
import {
  translateRequestSchema,
  refineRequestSchema,
  type TranslateResponse,
  type RefineResponse,
  type CollaboratorRole,
} from "@shared/schema";
import { db } from "./db";
import { projects } from "@shared/schema";

// Role-based permission helpers
type Permission = "view" | "edit_requirements" | "edit_architecture" | "edit_tasks" | "manage_collaborators" | "manage_project";

const rolePermissions: Record<CollaboratorRole, Permission[]> = {
  "Owner": ["view", "edit_requirements", "edit_architecture", "edit_tasks", "manage_collaborators", "manage_project"],
  "Architect": ["view", "edit_requirements", "edit_architecture"],
  "Business Analyst": ["view", "edit_requirements"],
  "Developer": ["view", "edit_tasks"],
  "QA/SDET": ["view"],
  "DevOps/Platform": ["view"],
  "Product Owner": ["view", "edit_requirements"],
  "Support/SRE": ["view"],
  "Scrum Master": ["view"],
};

function hasPermission(role: CollaboratorRole | null, permission: Permission): boolean {
  if (!role) return false;
  return rolePermissions[role]?.includes(permission) || false;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup simulated SSO authentication (MVP)
  await setupSimulatedAuth(app);

  // Note: Auth routes are handled in simulatedAuth.ts
  // Available routes: GET /api/auth/users, POST /api/auth/login-simulated, GET /api/auth/me, POST /api/auth/logout

  // ============================================
  // PROJECT ROUTES
  // ============================================
  
  // Get all projects for current user
  app.get("/api/projects", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const projects = await storage.getUserProjects(userId);
      res.json(projects);
    } catch (error: any) {
      console.error("Failed to get projects:", error);
      res.status(500).json({ error: "Failed to load projects" });
    }
  });

  // DEBUG: Show last prompt and response
  app.get("/api/debug/last-bedrock", isAuthenticated, async (req: any, res) => {
    try {
      const debugDir = '/tmp/bedrock-debug';
      const fs = require('fs');
      const path = require('path');
      
      if (!fs.existsSync(debugDir)) {
        res.json({ error: "No debug logs yet" });
        return;
      }
      
      const files = fs.readdirSync(debugDir).sort().reverse();
      const promptFile = files.find((f: string) => f.startsWith('prompt-'));
      const responseFile = files.find((f: string) => f.startsWith('response-'));
      
      const data: any = {};
      
      if (promptFile) {
        data.promptFile = promptFile;
        data.prompt = fs.readFileSync(path.join(debugDir, promptFile), 'utf-8');
      }
      
      if (responseFile) {
        data.responseFile = responseFile;
        const responseContent = fs.readFileSync(path.join(debugDir, responseFile), 'utf-8');
        try {
          data.response = JSON.parse(responseContent);
          data.responseStats = {
            userStories: data.response.userStories?.length || 0,
            tasks: data.response.tasks?.length || 0,
            architectureDiagrams: data.response.architectureDiagrams?.length || 0,
            architectureOutline: data.response.architectureOutline?.length || 0,
            functionalRequirements: data.response.functionalRequirements?.length || 0,
            wellArchitectedPillars: Object.keys(data.response.wellArchitectedPillars || {}),
          };
        } catch (e) {
          data.response = responseContent;
        }
      }
      
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get specific project
  app.get("/api/projects/:projectId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      const project = await storage.getProject(projectId);
      if (!project) {
        res.status(404).json({ error: "Project not found" });
        return;
      }
      
      // Check user has access to project (owner always has access)
      const role = await storage.getUserRole(projectId, userId);
      if (!role && project.ownerId !== userId) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      // Get iterations for this project
      const iterations = await storage.getProjectIterations(projectId);
      
      // Determine user role (owner if they own it, otherwise their collaborator role)
      const userRole = project.ownerId === userId ? 'Owner' : (role || 'Viewer');
      
      res.json({
        project,
        iterations,
        userRole,
      });
    } catch (error: any) {
      console.error("Failed to get project:", error);
      res.status(500).json({ error: "Failed to load project" });
    }
  });

  // Create new project
  app.post("/api/projects", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const schema = z.object({
        name: z.string().min(1, "Project name is required"),
        description: z.string().optional(),
      });
      
      const validatedData = schema.parse(req.body);
      const project = await storage.createProject(
        validatedData.name,
        validatedData.description || null,
        userId
      );
      
      res.json(project);
    } catch (error: any) {
      console.error("Failed to create project:", error);
      
      if (error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create project" });
      }
    }
  });

  // Create new project with AI-generated artifacts
  app.post("/api/projects/generate", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      console.log(`[/api/projects/generate] Starting AI project generation for user ${userId}`);
      
      const schema = z.object({
        requirements: z.string().min(1, "Requirements are required"),
        persona: z.string().optional(),
        userContext: z.object({
          userId: z.string().optional(),
          userName: z.string().optional(),
          userRole: z.string().optional(),
          userEmail: z.string().optional(),
        }).optional(),
        files: z.array(z.object({
          name: z.string(),
          type: z.string(),
          size: z.number(),
          base64: z.string(),
        })).optional(),
      });
      
      const validatedData = schema.parse(req.body);
      
      // Server-side validation for file uploads (security)
      const ALLOWED_FILE_TYPES = [
        'image/png', 'image/jpeg', 'image/gif', 'image/webp',
        'text/plain', 'text/markdown', 'application/json'
      ];
      const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB in bytes
      const MAX_FILES = 5;
      
      if (validatedData.files && validatedData.files.length > 0) {
        // Validate file count
        if (validatedData.files.length > MAX_FILES) {
          res.status(400).json({ error: `Maximum ${MAX_FILES} files allowed` });
          return;
        }
        
        // Validate each file
        for (const file of validatedData.files) {
          // Validate file type first
          if (!ALLOWED_FILE_TYPES.includes(file.type)) {
            res.status(400).json({ 
              error: `File type "${file.type}" is not supported. Allowed types: images (PNG, JPG, GIF, WebP), text files (TXT, MD, JSON)` 
            });
            return;
          }
          
          // SECURITY: Calculate actual decoded size from base64 (don't trust client-provided size)
          const actualSize = Buffer.from(file.base64, 'base64').length;
          if (actualSize > MAX_FILE_SIZE) {
            res.status(400).json({ 
              error: `File "${file.name}" exceeds maximum size of 5MB (actual size: ${Math.round(actualSize / 1024)}KB)` 
            });
            return;
          }
        }
        
        console.log(`[/api/projects/generate] ${validatedData.files.length} file(s) attached:`, 
          validatedData.files.map(f => `${f.name} (${f.type}, ${Math.round(f.size / 1024)}KB)`).join(', '));
      }
      
      // Generate intelligent project title using Claude
      console.log(`[/api/projects/generate] Generating intelligent project title...`);
      let projectName: string;
      try {
        projectName = await generateProjectTitle(validatedData.requirements);
        console.log(`[/api/projects/generate] Generated title: ${projectName}`);
      } catch (error: any) {
        // Fallback to simple title if AI generation fails
        console.warn(`[/api/projects/generate] Title generation failed, using fallback: ${error.message}`);
        const firstLine = validatedData.requirements.split('\n')[0];
        projectName = firstLine.length > 50 ? firstLine.substring(0, 47) + '...' : firstLine;
      }
      console.log(`[/api/projects/generate] Created by: ${validatedData.userContext?.userName} (${validatedData.userContext?.userRole})`);
      
      // Step 1: Generate AI artifacts with user context and files
      console.log(`[/api/projects/generate] Calling Bedrock for artifact generation...`);
      const artifacts = await generateArtifacts(
        validatedData.requirements,
        validatedData.userContext,
        validatedData.persona,
        validatedData.files
      );
      console.log(`[/api/projects/generate] Bedrock generation complete`);
      
      // Step 2: Create the project with requirements
      const project = await storage.createProject(
        projectName,
        `AI-generated project from requirements: ${validatedData.requirements}`,
        userId
      );
      
      // Step 3: Construct comprehensive business overview from Claude's semantic analysis
      let businessOverview = validatedData.requirements;
      
      if (artifacts.businessContext) {
        const ctx = artifacts.businessContext;
        const sections = [];
        
        // Executive Summary
        if (ctx.executiveSummary) {
          sections.push(`EXECUTIVE SUMMARY\n${ctx.executiveSummary}`);
        }
        
        // Domain Analysis
        if (ctx.domainAnalysis) {
          sections.push(`DOMAIN ANALYSIS\n${ctx.domainAnalysis}`);
        }
        
        // Key Stakeholders
        if (ctx.keyStakeholders?.length) {
          sections.push(`KEY STAKEHOLDERS\n${ctx.keyStakeholders.map((s: string, i: number) => `${i + 1}. ${s}`).join('\n')}`);
        }
        
        // Business Goals
        if (ctx.businessGoals?.length) {
          sections.push(`BUSINESS GOALS\n${ctx.businessGoals.map((g: string, i: number) => `${i + 1}. ${g}`).join('\n')}`);
        }
        
        // Risk Assessment
        if (ctx.riskAssessment?.length) {
          const risks = ctx.riskAssessment.map((r: any, i: number) => 
            `${i + 1}. ${r.risk} (${r.severity?.toUpperCase() || 'MEDIUM'})\n   Mitigation: ${r.mitigation}`
          ).join('\n');
          sections.push(`RISK ASSESSMENT\n${risks}`);
        }
        
        businessOverview = sections.join('\n\n');
        console.log(`[/api/projects/generate] Constructed business overview from Claude analysis (${businessOverview.length} chars)`);
      }
      
      await storage.updateProject(project.id, {
        functionalRequirements: validatedData.requirements,
        businessOverview,
      });
      
      // Step 4: Create iteration with AI-generated artifacts
      const iteration = await storage.addIteration(project.id, validatedData.requirements, artifacts);
      console.log(`[/api/projects/generate] Created iteration ${iteration.id} for project ${project.id}`);
      
      res.json({
        project: await storage.getProject(project.id),
        iteration,
      });
    } catch (error: any) {
      console.error(`[/api/projects/generate] FAILED:`, error.message);
      
      if (error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: error.message || "Failed to generate project with AI" });
      }
    }
  });

  // Update project (supports both metadata and role-based sections)
  app.patch("/api/projects/:projectId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Check user has access to project (owner or collaborator)
      const existingProject = await storage.getProject(projectId);
      if (!existingProject) {
        res.status(404).json({ error: "Project not found" });
        return;
      }
      
      const isOwner = existingProject.ownerId === userId;
      const role = await storage.getUserRole(projectId, userId);
      
      if (!isOwner && !role) {
        res.status(403).json({ error: "Access denied" });
        return;
      }
      
      // Use effectiveRole from session for section permissions
      const effectiveRole = req.session.user.effectiveRole;
      
      // Define role-based permissions for sections
      const sectionPermissions: Record<string, string[]> = {
        businessOverview: ['Business Analyst'],
        functionalRequirements: ['Business Analyst'],
        nonFunctionalRequirements: ['Business Analyst'],
        architectureDocs: ['Architect'],
        figmaLinks: ['Architect'],
        flowDiagrams: ['Architect'],
        developmentDocs: ['Developer'],
        testingDocs: ['Developer'],
        deploymentDocs: ['Developer'],
      };
      
      const schema = z.object({
        name: z.string().min(1).optional(),
        description: z.string().optional(),
        businessOverview: z.string().optional(),
        functionalRequirements: z.string().optional(),
        nonFunctionalRequirements: z.string().optional(),
        architectureDocs: z.string().optional(),
        figmaLinks: z.string().optional(),
        flowDiagrams: z.string().optional(),
        developmentDocs: z.string().optional(),
        testingDocs: z.string().optional(),
        deploymentDocs: z.string().optional(),
      });
      
      const validatedData = schema.parse(req.body);
      
      // Check permissions for each field being updated
      for (const [field, value] of Object.entries(validatedData)) {
        if (field === 'name' || field === 'description') {
          // Only owner can update metadata
          if (!isOwner && !hasPermission(role, "manage_project")) {
            res.status(403).json({ error: "Only project owner can update project metadata" });
            return;
          }
        } else if (field in sectionPermissions) {
          // Check role-based section permissions using effectiveRole
          const allowedRoles = sectionPermissions[field];
          if (!allowedRoles.includes(effectiveRole)) {
            res.status(403).json({ 
              error: `Only ${allowedRoles.join(' or ')} can edit ${field}` 
            });
            return;
          }
        }
      }
      
      const project = await storage.updateProject(projectId, validatedData);
      res.json(project);
    } catch (error: any) {
      console.error("Failed to update project:", error);
      
      if (error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update project" });
      }
    }
  });

  // Delete project
  app.delete("/api/projects/:projectId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Only owner can delete project
      const role = await storage.getUserRole(projectId, userId);
      if (!hasPermission(role, "manage_project")) {
        res.status(403).json({ error: "Only project owner can delete project" });
        return;
      }
      
      await storage.deleteProject(projectId);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Failed to delete project:", error);
      res.status(500).json({ error: "Failed to delete project" });
    }
  });

  // ============================================
  // COLLABORATOR ROUTES
  // ============================================
  
  // Get project collaborators
  app.get("/api/projects/:projectId/collaborators", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Check user has access to project
      const role = await storage.getUserRole(projectId, userId);
      if (!role) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      const collaborators = await storage.getProjectCollaborators(projectId);
      res.json(collaborators);
    } catch (error: any) {
      console.error("Failed to get collaborators:", error);
      res.status(500).json({ error: "Failed to load collaborators" });
    }
  });

  // Add collaborator to project
  app.post("/api/projects/:projectId/collaborators", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Only owner can add collaborators
      const role = await storage.getUserRole(projectId, userId);
      if (!hasPermission(role, "manage_collaborators")) {
        res.status(403).json({ error: "Only project owner can add collaborators" });
        return;
      }
      
      const schema = z.object({
        userId: z.string(),
        role: z.enum(["Owner", "Architect", "Developer", "Business Analyst", "Scrum Master"]),
      });
      
      const validatedData = schema.parse(req.body);
      const collaborator = await storage.addCollaborator(
        projectId,
        validatedData.userId,
        validatedData.role as CollaboratorRole
      );
      
      res.json(collaborator);
    } catch (error: any) {
      console.error("Failed to add collaborator:", error);
      
      if (error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to add collaborator" });
      }
    }
  });

  // Remove collaborator from project
  app.delete("/api/projects/:projectId/collaborators/:collaboratorUserId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId, collaboratorUserId } = req.params;
      
      // Only owner can remove collaborators
      const role = await storage.getUserRole(projectId, userId);
      if (!hasPermission(role, "manage_collaborators")) {
        res.status(403).json({ error: "Only project owner can remove collaborators" });
        return;
      }
      
      await storage.removeCollaborator(projectId, collaboratorUserId);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Failed to remove collaborator:", error);
      res.status(500).json({ error: "Failed to remove collaborator" });
    }
  });

  // ============================================
  // ARTIFACT GENERATION ROUTES
  // ============================================
  
  // Translate requirements to artifacts (now requires projectId)
  app.post("/api/projects/:projectId/translate", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Check user has permission to edit requirements/architecture
      const role = await storage.getUserRole(projectId, userId);
      if (!hasPermission(role, "edit_requirements")) {
        res.status(403).json({ error: "You don't have permission to generate artifacts for this project" });
        return;
      }
      
      const validatedData = translateRequestSchema.parse(req.body);
      
      // Generate artifacts using Bedrock
      const artifacts = await generateArtifacts(validatedData.requirements);
      
      // Save iteration
      const iteration = await storage.addIteration(
        projectId,
        validatedData.requirements,
        artifacts
      );

      const response: TranslateResponse = {
        artifacts: iteration.artifacts,
        iterationId: iteration.id,
      };

      res.json(response);
    } catch (error: any) {
      console.error("Translation error:", error);
      
      if (error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: error.message || "Failed to generate artifacts" });
      }
    }
  });

  // Refine artifacts
  app.post("/api/projects/:projectId/refine", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Check user has permission to edit requirements/architecture
      const role = await storage.getUserRole(projectId, userId);
      if (!hasPermission(role, "edit_requirements")) {
        res.status(403).json({ error: "You don't have permission to refine artifacts for this project" });
        return;
      }
      
      const validatedData = refineRequestSchema.parse(req.body);
      
      // Refine artifacts using Bedrock
      const result = await refineArtifacts(
        validatedData.currentArtifacts,
        validatedData.refinementPrompt,
        validatedData.previousRequirements
      );

      // Create new requirements text
      const updatedRequirements = `${validatedData.previousRequirements}\n\nRefinement: ${validatedData.refinementPrompt}`;

      // Save new iteration with diff
      const iteration = await storage.addIteration(
        projectId,
        updatedRequirements,
        result.artifacts,
        result.diff
      );

      const response: RefineResponse = {
        artifacts: iteration.artifacts,
        diff: iteration.diff || [],
        iterationId: iteration.id,
      };

      res.json(response);
    } catch (error: any) {
      console.error("Refinement error:", error);
      
      if (error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: error.message || "Failed to refine artifacts" });
      }
    }
  });

  // AI Agent chat endpoint
  app.post("/api/projects/:projectId/agent/chat", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Check user has access to project
      const project = await storage.getProject(projectId);
      if (!project) {
        res.status(404).json({ error: "Project not found" });
        return;
      }
      
      // SECURITY: Strictly verify ownership and collaborator status
      const isOwner = project.ownerId === userId;
      const collaboratorRole = await storage.getUserRole(projectId, userId);
      
      // Deny access if user is neither owner nor collaborator
      if (!isOwner && !collaboratorRole) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      // SECURITY: Determine effective role with strict precedence
      let effectiveRole: CollaboratorRole | null = null;
      
      // 1. Admin override takes highest precedence (if set)
      if (req.session.user.effectiveRole) {
        effectiveRole = req.session.user.effectiveRole;
      }
      // 2. Confirmed project owner gets Owner role
      else if (isOwner) {
        effectiveRole = 'Owner';
      }
      // 3. Confirmed collaborator gets their assigned role
      else if (collaboratorRole) {
        effectiveRole = collaboratorRole;
      }
      
      // Reject if role derivation failed
      if (!effectiveRole) {
        console.error(`Role derivation failed for user ${userId} in project ${projectId}`);
        res.status(403).json({ error: "Failed to determine user role" });
        return;
      }
      
      // Final validation: effectiveRole must be a valid CollaboratorRole
      const validRoles: CollaboratorRole[] = ['Owner', 'Architect', 'Business Analyst', 'Developer', 'Scrum Master'];
      if (!validRoles.includes(effectiveRole)) {
        console.error(`Invalid effective role: ${effectiveRole}`);
        res.status(403).json({ error: "Invalid role" });
        return;
      }
      
      const schema = z.object({
        message: z.string().min(1, "Message is required"),
        files: z.array(z.object({
          name: z.string(),
          type: z.string(),
          size: z.number(),
          base64: z.string(),
        })).optional(),
      });
      
      const validatedData = schema.parse(req.body);
      
      // Server-side validation for file uploads (security)
      const ALLOWED_FILE_TYPES = [
        'image/png', 'image/jpeg', 'image/gif', 'image/webp',
        'text/plain', 'text/markdown', 'application/json'
      ];
      const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB in bytes
      const MAX_FILES = 3; // Fewer for chat
      
      if (validatedData.files && validatedData.files.length > 0) {
        // Validate file count
        if (validatedData.files.length > MAX_FILES) {
          res.status(400).json({ error: `Maximum ${MAX_FILES} files allowed in chat` });
          return;
        }
        
        // Validate each file
        for (const file of validatedData.files) {
          // Validate file type first
          if (!ALLOWED_FILE_TYPES.includes(file.type)) {
            res.status(400).json({ 
              error: `File type "${file.type}" is not supported. Allowed types: images (PNG, JPG, GIF, WebP), text files (TXT, MD, JSON)` 
            });
            return;
          }
          
          // SECURITY: Calculate actual decoded size from base64 (don't trust client-provided size)
          const actualSize = Buffer.from(file.base64, 'base64').length;
          if (actualSize > MAX_FILE_SIZE) {
            res.status(400).json({ 
              error: `File "${file.name}" exceeds maximum size of 5MB (actual size: ${Math.round(actualSize / 1024)}KB)` 
            });
            return;
          }
        }
        
        console.log(`[/api/projects/${projectId}/agent/chat] ${validatedData.files.length} file(s) attached:`, 
          validatedData.files.map(f => `${f.name} (${f.type}, ${Math.round(f.size / 1024)}KB)`).join(', '));
      }
      
      // Process message with AI agent using SERVER-DERIVED role only
      const agentResponse = await processAgentMessage(
        projectId,
        validatedData.message,
        effectiveRole,
        validatedData.files
      );
      
      res.json(agentResponse);
    } catch (error: any) {
      console.error("Agent chat error:", error);
      
      if (error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: error.message || "Failed to process message" });
      }
    }
  });

  // ============================================
  // SPRINT ROUTES
  // ============================================
  
  // Get all sprints for a project
  app.get("/api/projects/:projectId/sprints", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Check user has access to project
      const role = await storage.getUserRole(projectId, userId);
      const project = await storage.getProject(projectId);
      if (!role && project?.ownerId !== userId) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      const sprints = await storage.getProjectSprints(projectId);
      res.json(sprints);
    } catch (error: any) {
      console.error("Failed to get sprints:", error);
      res.status(500).json({ error: "Failed to load sprints" });
    }
  });
  
  // Get active sprint for a project
  app.get("/api/projects/:projectId/sprints/active", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Check user has access to project
      const role = await storage.getUserRole(projectId, userId);
      const project = await storage.getProject(projectId);
      if (!role && project?.ownerId !== userId) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      const activeSprint = await storage.getActiveSprint(projectId);
      if (!activeSprint) {
        res.status(404).json({ error: "No active sprint found" });
        return;
      }
      
      res.json(activeSprint);
    } catch (error: any) {
      console.error("Failed to get active sprint:", error);
      res.status(500).json({ error: "Failed to load active sprint" });
    }
  });
  
  // Update sprint (Scrum Master can update sprint details and retrospectives)
  app.patch("/api/sprints/:sprintId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { sprintId } = req.params;
      
      // Get sprint to check project access
      const sprints = await storage.getProjectSprints(req.body.projectId || "");
      const sprint = sprints.find(s => s.id === sprintId);
      if (!sprint) {
        res.status(404).json({ error: "Sprint not found" });
        return;
      }
      
      // Check user has access to project
      const role = await storage.getUserRole(sprint.projectId, userId);
      const project = await storage.getProject(sprint.projectId);
      if (!role && project?.ownerId !== userId) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      const schema = z.object({
        name: z.string().optional(),
        startDate: z.string().transform(s => new Date(s)).optional(),
        endDate: z.string().transform(s => new Date(s)).optional(),
        sprintLengthDays: z.number().optional(),
        status: z.enum(["planning", "active", "completed", "archived"]).optional(),
        goal: z.string().nullable().optional(),
        retrospective: z.any().optional(),
      });
      
      const validatedData = schema.parse(req.body);
      const updatedSprint = await storage.updateSprint(sprintId, validatedData);
      
      res.json(updatedSprint);
    } catch (error: any) {
      console.error("Failed to update sprint:", error);
      
      if (error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: error.message || "Failed to update sprint" });
      }
    }
  });

  // ============================================
  // STORY ROUTES
  // ============================================
  
  // Get all stories for a project
  app.get("/api/projects/:projectId/stories", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Check user has access to project
      const role = await storage.getUserRole(projectId, userId);
      const project = await storage.getProject(projectId);
      if (!role && project?.ownerId !== userId) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      const stories = await storage.getProjectStories(projectId);
      res.json(stories);
    } catch (error: any) {
      console.error("Failed to get stories:", error);
      res.status(500).json({ error: "Failed to load stories" });
    }
  });
  
  // Get stories for a specific sprint
  app.get("/api/sprints/:sprintId/stories", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { sprintId } = req.params;
      
      // Get sprint to check project access
      const stories = await storage.getSprintStories(sprintId);
      if (stories.length === 0) {
        res.json([]);
        return;
      }
      
      const projectId = stories[0].projectId;
      const role = await storage.getUserRole(projectId, userId);
      const project = await storage.getProject(projectId);
      if (!role && project?.ownerId !== userId) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      res.json(stories);
    } catch (error: any) {
      console.error("Failed to get sprint stories:", error);
      res.status(500).json({ error: "Failed to load sprint stories" });
    }
  });
  
  // Create a new story
  app.post("/api/projects/:projectId/stories", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId } = req.params;
      
      // Check user has access to project
      const role = await storage.getUserRole(projectId, userId);
      const project = await storage.getProject(projectId);
      if (!role && project?.ownerId !== userId) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      const schema = z.object({
        sprintId: z.string().nullable(),
        title: z.string().min(1, "Title is required"),
        description: z.string().nullable().optional(),
        status: z.enum(["backlog", "todo", "in_progress", "in_review", "done", "blocked"]).default("backlog"),
        priority: z.string().default("medium"),
        storyPoints: z.number().nullable().optional(),
        assignedTo: z.string().nullable().optional(),
        linkedStories: z.array(z.string()).default([]),
        acceptanceCriteria: z.array(z.string()).default([]),
      });
      
      const validatedData = schema.parse(req.body);
      const story = await storage.createStory({
        projectId,
        createdBy: userId,
        ...validatedData,
      });
      
      res.json(story);
    } catch (error: any) {
      console.error("Failed to create story:", error);
      
      if (error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: error.message || "Failed to create story" });
      }
    }
  });
  
  // Update a story
  app.patch("/api/stories/:storyId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { storyId } = req.params;
      
      // Get story to check project access
      const stories = await storage.getProjectStories(req.body.projectId || "");
      const story = stories.find(s => s.id === storyId);
      if (!story) {
        res.status(404).json({ error: "Story not found" });
        return;
      }
      
      // Check user has access to project
      const role = await storage.getUserRole(story.projectId, userId);
      const project = await storage.getProject(story.projectId);
      if (!role && project?.ownerId !== userId) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      const schema = z.object({
        sprintId: z.string().nullable().optional(),
        title: z.string().optional(),
        description: z.string().nullable().optional(),
        status: z.enum(["backlog", "todo", "in_progress", "in_review", "done", "blocked"]).optional(),
        priority: z.string().optional(),
        storyPoints: z.number().nullable().optional(),
        assignedTo: z.string().nullable().optional(),
        linkedStories: z.array(z.string()).optional(),
        acceptanceCriteria: z.array(z.string()).optional(),
      });
      
      const validatedData = schema.parse(req.body);
      const updatedStory = await storage.updateStory(storyId, validatedData);
      
      res.json(updatedStory);
    } catch (error: any) {
      console.error("Failed to update story:", error);
      
      if (error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: error.message || "Failed to update story" });
      }
    }
  });
  
  // Delete a story
  app.delete("/api/stories/:storyId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { storyId } = req.params;
      const { projectId } = req.query;
      
      // Check user has access to project
      const role = await storage.getUserRole(projectId as string, userId);
      const project = await storage.getProject(projectId as string);
      if (!role && project?.ownerId !== userId) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      await storage.deleteStory(storyId);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Failed to delete story:", error);
      res.status(500).json({ error: "Failed to delete story" });
    }
  });

  // ============================================
  // SERVICENOW INTEGRATION
  // ============================================

  // Create ServiceNow change request from selected stories
  app.post("/api/servicenow/change-requests", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const schema = z.object({
        projectId: z.string(),
        storyIds: z.array(z.string()).min(1),
        summary: z.string().min(1),
        description: z.string().optional(),
        priority: z.string(),
        riskImpact: z.string(),
      });

      const validatedData = schema.parse(req.body);
      
      // Check user has access to project
      const role = await storage.getUserRole(validatedData.projectId, userId);
      const project = await storage.getProject(validatedData.projectId);
      if (!role && project?.ownerId !== userId) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }

      // Get ServiceNow credentials from environment
      const snowInstance = process.env.SERVICENOW_INSTANCE;
      const snowUsername = process.env.SERVICENOW_USERNAME;
      const snowPassword = process.env.SERVICENOW_PASSWORD;

      // Fetch the selected stories to get their details
      const allStories = await storage.getProjectStories(validatedData.projectId);
      const selectedStories = allStories.filter(s => validatedData.storyIds.includes(s.id));

      // Build change request description with story details
      let fullDescription = validatedData.description || '';
      fullDescription += '\n\nAssociated User Stories:\n';
      selectedStories.forEach(story => {
        fullDescription += `\n- ${story.title}`;
        if (story.description) {
          fullDescription += `\n  Description: ${story.description}`;
        }
        if (story.storyPoints) {
          fullDescription += `\n  Story Points: ${story.storyPoints}`;
        }
      });

      // Mock mode if credentials not configured
      const isMockMode = !snowInstance || !snowUsername || !snowPassword;

      if (isMockMode) {
        // Return mock response
        const mockChangeNumber = `CHG${Math.floor(Math.random() * 9000000) + 1000000}`;
        const mockSysId = `mock-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        
        res.json({
          success: true,
          mock: true,
          changeRequest: {
            number: mockChangeNumber,
            sys_id: mockSysId,
            short_description: validatedData.summary,
            description: fullDescription,
            priority: validatedData.priority,
            risk: validatedData.riskImpact,
            impact: validatedData.riskImpact,
            type: 'Normal',
            state: 'New',
          },
          message: `Mock change request ${mockChangeNumber} created successfully (ServiceNow not configured)`,
        });
        return;
      }

      // Prepare ServiceNow change request payload
      const changeRequestPayload = {
        short_description: validatedData.summary,
        description: fullDescription,
        priority: validatedData.priority,
        risk: validatedData.riskImpact,
        impact: validatedData.riskImpact,
        type: 'Normal',
        state: 'New',
      };

      // Make API call to ServiceNow
      const snowUrl = `https://${snowInstance}.service-now.com/api/now/table/change_request`;
      const authHeader = 'Basic ' + Buffer.from(`${snowUsername}:${snowPassword}`).toString('base64');

      const response = await fetch(snowUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': authHeader,
        },
        body: JSON.stringify(changeRequestPayload),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('ServiceNow API error:', errorText);
        res.status(response.status).json({ 
          error: 'Failed to create ServiceNow change request',
          details: errorText 
        });
        return;
      }

      const result = await response.json();
      
      res.json({
        success: true,
        mock: false,
        changeRequest: result.result,
        message: `Change request ${result.result.number} created successfully`,
      });
    } catch (error: any) {
      console.error('Failed to create ServiceNow change request:', error);
      
      if (error.name === 'ZodError') {
        res.status(400).json({ error: 'Invalid request data', details: error.errors });
      } else {
        res.status(500).json({ error: error.message || 'Failed to create change request' });
      }
    }
  });

  // ============================================
  // EXPORT ROUTES
  // ============================================
  
  // Export artifacts as JSON
  app.get("/api/projects/:projectId/export/json/:iterationId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId, iterationId } = req.params;
      
      // Check user has access to project
      const role = await storage.getUserRole(projectId, userId);
      if (!role) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      const iteration = await storage.getIteration(iterationId);

      if (!iteration) {
        res.status(404).json({ error: "Iteration not found" });
        return;
      }

      const exportData = {
        version: iteration.version,
        timestamp: iteration.timestamp,
        requirements: iteration.requirements,
        artifacts: iteration.artifacts,
      };

      res.setHeader("Content-Type", "application/json");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="smartsdlc-v${iteration.version}.json"`
      );
      res.send(JSON.stringify(exportData, null, 2));
    } catch (error: any) {
      console.error("Export JSON error:", error);
      res.status(500).json({ error: "Failed to export as JSON" });
    }
  });

  // Export artifacts as Markdown
  app.get("/api/projects/:projectId/export/markdown/:iterationId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { projectId, iterationId } = req.params;
      
      // Check user has access to project
      const role = await storage.getUserRole(projectId, userId);
      if (!role) {
        res.status(403).json({ error: "Access denied to this project" });
        return;
      }
      
      const iteration = await storage.getIteration(iterationId);

      if (!iteration) {
        res.status(404).json({ error: "Iteration not found" });
        return;
      }

      const { artifacts, requirements, version, timestamp } = iteration;
      let md = `# SmartSDLC Artifacts - Version ${version}\n\n`;
      md += `**Generated:** ${new Date(timestamp).toLocaleString()}\n\n`;
      md += `## Business Requirements\n\n${requirements}\n\n`;
      md += `---\n\n`;

      // User Stories
      md += `## User Stories\n\n`;
      artifacts.userStories.forEach((story, i) => {
        md += `### ${i + 1}. ${story.title}\n\n`;
        md += `${story.description}\n\n`;
        md += `**Effort:** ${story.effort}\n\n`;
        md += `**Acceptance Criteria:**\n`;
        story.acceptanceCriteria.forEach((ac) => {
          md += `- ${ac}\n`;
        });
        md += `\n`;
      });

      // Architecture
      md += `## Architecture Outline\n\n`;
      const renderArchitecture = (components: typeof artifacts.architectureOutline, level = 0) => {
        components.forEach((comp) => {
          const indent = "  ".repeat(level);
          md += `${indent}- **${comp.name}** (${comp.type})\n`;
          md += `${indent}  ${comp.description}\n`;
          if (comp.codeSnippet) {
            md += `${indent}  \`\`\`\n${comp.codeSnippet}\n${indent}  \`\`\`\n`;
          }
          if (comp.children && comp.children.length > 0) {
            renderArchitecture(comp.children, level + 1);
          }
        });
      };
      renderArchitecture(artifacts.architectureOutline);

      // Tasks
      md += `\n## Task Breakdown\n\n`;
      md += `| Role | Task | Effort | Status |\n`;
      md += `|------|------|--------|--------|\n`;
      artifacts.tasks.forEach((task) => {
        md += `| ${task.role} | ${task.task} | ${task.effort} | ${task.status.replace("_", " ")} |\n`;
      });

      res.setHeader("Content-Type", "text/markdown");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="smartsdlc-v${iteration.version}.md"`
      );
      res.send(md);
    } catch (error: any) {
      console.error("Export Markdown error:", error);
      res.status(500).json({ error: "Failed to export as Markdown" });
    }
  });

  // ============================================
  // SEED DEMO DATA (Development Only)
  // ============================================
  
  app.post("/api/seed-demo", isAuthenticated, async (req: any, res) => {
    try {
      // Only allow admin to seed demo data
      if (!req.session.user.isAdmin) {
        res.status(403).json({ error: "Admin access required" });
        return;
      }

      // Import and call comprehensive demo generator
      const { createComprehensiveDemoProject } = await import('./seed-demo');
      const result = await createComprehensiveDemoProject(storage, req.session.user.id);
      
      res.json(result);
    } catch (error: any) {
      console.error("[/api/seed-demo] Error:", error);
      res.status(500).json({ error: error.message || "Failed to create demo project" });
    }
  });

  // ============================================
  // ADMIN: CLOSE PROJECT
  // ============================================
  
  app.patch("/api/projects/:projectId/close", isAuthenticated, async (req: any, res) => {
    try {
      const { projectId } = req.params;
      const userId = req.session.user.id;

      // Only allow admin or project owner to close project
      const project = await storage.getProject(projectId);
      if (!project) {
        res.status(404).json({ error: "Project not found" });
        return;
      }

      const isAdmin = req.session.user.isAdmin;
      const isOwner = project.ownerId === userId;

      if (!isAdmin && !isOwner) {
        res.status(403).json({ error: "Only admins or project owners can close projects" });
        return;
      }

      // Update project to add a "closed" marker in description or a status field
      // Since we don't have a status field in the schema, we'll add a note to the description
      const closedNote = `\n\n---\n**PROJECT CLOSED** on ${new Date().toISOString().split('T')[0]} by ${req.session.user.name || userId}\n---`;
      
      await storage.updateProject(projectId, {
        description: (project.description || '') + closedNote,
      });

      res.json({ 
        success: true, 
        message: "Project closed successfully",
        projectId 
      });
    } catch (error: any) {
      console.error("[/api/projects/:projectId/close] Error:", error);
      res.status(500).json({ error: error.message || "Failed to close project" });
    }
  });

  // ============================================
  // ADMIN: DELETE PROJECT
  // ============================================
  
  app.delete("/api/projects/:projectId", isAuthenticated, async (req: any, res) => {
    try {
      const { projectId } = req.params;
      const userId = req.session.user.id;

      // Only allow admin or project owner to delete project
      const project = await storage.getProject(projectId);
      if (!project) {
        res.status(404).json({ error: "Project not found" });
        return;
      }

      const isAdmin = req.session.user.isAdmin;
      const isOwner = project.ownerId === userId;

      if (!isAdmin && !isOwner) {
        res.status(403).json({ error: "Only admins or project owners can delete projects" });
        return;
      }

      // Delete project (cascade will handle related records)
      await storage.deleteProject(projectId);

      res.json({ 
        success: true, 
        message: "Project deleted successfully",
        projectId 
      });
    } catch (error: any) {
      console.error("[/api/projects/:projectId] DELETE Error:", error);
      res.status(500).json({ error: error.message || "Failed to delete project" });
    }
  });
  // ============================================
  // ADMIN: REPAIR SPRINTS (Backfill Sprint 0)
  // ============================================
  
  app.post("/api/admin/sprints/repair", isAuthenticated, async (req: any, res) => {
    try {
      // Only allow admin to run repair
      if (!req.session.user.isAdmin) {
        res.status(403).json({ error: "Admin access required" });
        return;
      }

      // Get all projects directly from database
      const allProjects = await db.select({ id: projects.id }).from(projects);

      const repairResults = {
        totalProjects: allProjects.length,
        sprintsCreated: 0,
        sprintsExisted: 0,
        storiesCreated: 0,
        errors: [] as string[],
      };

      // Repair each project
      for (const project of allProjects) {
        try {
          // Ensure Sprint 0 exists
          const { sprint, created } = await storage.ensureSprintZero(project.id);
          
          if (created) {
            repairResults.sprintsCreated++;
            // Seed sample stories for newly created Sprint 0
            const stories = await storage.seedSampleStories(project.id, sprint.id);
            repairResults.storiesCreated += stories.length;
          } else {
            repairResults.sprintsExisted++;
            // Check if stories already exist, if not, seed them
            const existingStories = await storage.getSprintStories(sprint.id);
            if (existingStories.length === 0) {
              const stories = await storage.seedSampleStories(project.id, sprint.id);
              repairResults.storiesCreated += stories.length;
            }
          }
        } catch (error: any) {
          repairResults.errors.push(`Project ${project.id}: ${error.message}`);
        }
      }

      res.json({
        success: true,
        message: "Sprint repair completed",
        results: repairResults,
      });
    } catch (error: any) {
      console.error("Failed to repair sprints:", error);
      res.status(500).json({ error: "Failed to repair sprints" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
