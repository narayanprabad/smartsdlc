import type { Repository, RepositoryFile } from '@shared/schema';

// ============================================================================
// REPOSITORY 1: Frontend - Next.js 14 + React + TypeScript
// ============================================================================
export function generateCFTCFrontendRepo(): Repository {
  const files: RepositoryFile[] = [
    {
      path: 'package.json',
      type: 'file',
      language: 'json',
      size: 0,
      content: `{
  "name": "cftc-clearing-frontend",
  "version": "1.0.0",
  "description": "CFTC Clearing Platform - Frontend Application",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "eslint . --ext .ts,.tsx",
    "type-check": "tsc --noEmit",
    "format": "prettier --write \\"src/**/*.{ts,tsx,json,css}\\"",
    "format:check": "prettier --check \\"src/**/*.{ts,tsx,json,css}\\"",
    "test": "jest",
    "test:ci": "jest --ci --coverage --reporters=default --reporters=jest-junit",
    "test:e2e": "cypress open",
    "test:e2e:headless": "cypress run"
  },
  "dependencies": {
    "next": "14.1.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "axios": "^1.6.5",
    "date-fns": "^3.3.1",
    "recharts": "^2.10.4",
    "@tanstack/react-query": "^5.17.19",
    "@radix-ui/react-tabs": "^1.0.4",
    "@radix-ui/react-dialog": "^1.0.5",
    "@radix-ui/react-dropdown-menu": "^2.0.6",
    "@radix-ui/react-toast": "^1.1.5",
    "zod": "^3.22.4",
    "react-hook-form": "^7.49.3",
    "@hookform/resolvers": "^3.3.4",
    "ws": "^8.16.0",
    "clsx": "^2.1.0",
    "tailwind-merge": "^2.2.1"
  },
  "devDependencies": {
    "@types/node": "^20.11.5",
    "@types/react": "^18.2.48",
    "@types/react-dom": "^18.2.18",
    "@types/ws": "^8.5.10",
    "typescript": "^5.3.3",
    "eslint": "^8.56.0",
    "eslint-config-next": "14.1.0",
    "prettier": "^3.2.4",
    "@testing-library/react": "^14.1.2",
    "@testing-library/jest-dom": "^6.2.0",
    "jest": "^29.7.0",
    "jest-environment-jsdom": "^29.7.0",
    "jest-junit": "^16.0.0",
    "cypress": "^13.6.3",
    "tailwindcss": "^3.4.1",
    "postcss": "^8.4.33",
    "autoprefixer": "^10.4.17"
  }
}`
    },
    {
      path: 'tsconfig.json',
      type: 'file',
      language: 'json',
      size: 0,
      content: `{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "paths": {
      "@/*": ["./src/*"],
      "@/components/*": ["./src/components/*"],
      "@/lib/*": ["./src/lib/*"],
      "@/hooks/*": ["./src/hooks/*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}`
    },
    {
      path: '.env.example',
      type: 'file',
      language: 'bash',
      size: 0,
      content: `# API Configuration
NEXT_PUBLIC_API_URL=http://localhost:4000/api
NEXT_PUBLIC_WS_URL=ws://localhost:4000

# Environment
NEXT_PUBLIC_ENVIRONMENT=development

# Feature Flags
NEXT_PUBLIC_ENABLE_REALTIME=true
NEXT_PUBLIC_ENABLE_ANALYTICS=false`
    },
    {
      path: 'src/app/page.tsx',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { PositionDashboard } from '@/components/PositionDashboard';
import { ComplianceAlerts } from '@/components/ComplianceAlerts';
import { RecentSubmissions } from '@/components/RecentSubmissions';

export default function HomePage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">CFTC Compliance Dashboard</h1>
          <p className="text-muted-foreground">
            Large Trader Reporting & Position Monitoring
          </p>
        </div>
        
        <PositionDashboard />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ComplianceAlerts />
          <RecentSubmissions />
        </div>
      </div>
    </DashboardLayout>
  );
}`
    },
    {
      path: 'src/components/PositionDashboard.tsx',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `'use client';

import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { apiClient } from '@/lib/api-client';
import type { PositionSummary } from '@/types/positions';

export function PositionDashboard() {
  const { data: summary, isLoading } = useQuery<PositionSummary>({
    queryKey: ['/positions/summary'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-4 w-32" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-24 mb-2" />
              <Skeleton className="h-4 w-16" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!summary) return null;

  const cards = [
    {
      title: 'Total Open Positions',
      value: summary.totalPositions.toLocaleString(),
      change: summary.positionChange,
      status: 'normal' as const,
    },
    {
      title: 'Pending Reports',
      value: summary.pendingReports.toString(),
      change: summary.reportChange,
      status: summary.pendingReports > 5 ? 'warning' : 'normal' as const,
    },
    {
      title: 'Compliance Score',
      value: \`\${summary.complianceScore}%\`,
      change: summary.scoreChange,
      status: summary.complianceScore >= 95 ? 'good' : 'warning' as const,
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {cards.map((card) => (
        <Card key={card.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {card.title}
            </CardTitle>
            {card.status === 'warning' && (
              <div className="h-2 w-2 rounded-full bg-yellow-500" />
            )}
            {card.status === 'good' && (
              <div className="h-2 w-2 rounded-full bg-green-500" />
            )}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{card.value}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              {card.change > 0 ? (
                <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
              ) : (
                <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
              )}
              <span className={card.change > 0 ? 'text-green-500' : 'text-red-500'}>
                {card.change > 0 ? '+' : ''}{card.change}%
              </span>
              <span className="ml-1">from last week</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}`
    },
    {
      path: 'src/lib/api-client.ts',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';

class APIClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api',
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Request interceptor for authentication
    this.client.interceptors.request.use(
      (config) => {
        const token = this.getAuthToken();
        if (token) {
          config.headers.Authorization = \`Bearer \${token}\`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          // Handle unauthorized - redirect to login
          if (typeof window !== 'undefined') {
            window.location.href = '/login';
          }
        }
        return Promise.reject(error);
      }
    );
  }

  private getAuthToken(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem('auth_token');
  }

  async get<T>(url: string, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.get<T>(url, config);
    return response.data;
  }

  async post<T>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.post<T>(url, data, config);
    return response.data;
  }

  async put<T>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.put<T>(url, data, config);
    return response.data;
  }

  async delete<T>(url: string, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.delete<T>(url, config);
    return response.data;
  }

  async patch<T>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.patch<T>(url, data, config);
    return response.data;
  }
}

export const apiClient = new APIClient();`
    },
    {
      path: 'src/hooks/useWebSocket.ts',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `import { useEffect, useRef, useState, useCallback } from 'react';

export interface WebSocketOptions {
  onMessage?: (data: any) => void;
  onOpen?: () => void;
  onClose?: () => void;
  onError?: (error: Event) => void;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
}

export function useWebSocket(url: string, options: WebSocketOptions = {}) {
  const {
    onMessage,
    onOpen,
    onClose,
    onError,
    reconnectInterval = 3000,
    maxReconnectAttempts = 5,
  } = options;

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<any>(null);

  const connect = useCallback(() => {
    try {
      const ws = new WebSocket(url);

      ws.onopen = () => {
        console.log('WebSocket connected');
        setIsConnected(true);
        reconnectAttemptsRef.current = 0;
        onOpen?.();
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          setLastMessage(data);
          onMessage?.(data);
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      ws.onclose = () => {
        console.log('WebSocket disconnected');
        setIsConnected(false);
        wsRef.current = null;
        onClose?.();

        // Attempt to reconnect
        if (reconnectAttemptsRef.current < maxReconnectAttempts) {
          reconnectAttemptsRef.current += 1;
          console.log(\`Reconnecting... Attempt \${reconnectAttemptsRef.current}/\${maxReconnectAttempts}\`);
          reconnectTimeoutRef.current = setTimeout(() => {
            connect();
          }, reconnectInterval);
        } else {
          console.error('Max reconnection attempts reached');
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        onError?.(error);
      };

      wsRef.current = ws;
    } catch (error) {
      console.error('Failed to create WebSocket connection:', error);
    }
  }, [url, onMessage, onOpen, onClose, onError, reconnectInterval, maxReconnectAttempts]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setIsConnected(false);
  }, []);

  const sendMessage = useCallback((data: any) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(data));
    } else {
      console.warn('WebSocket is not connected. Message not sent.');
    }
  }, []);

  useEffect(() => {
    connect();
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  return {
    isConnected,
    lastMessage,
    sendMessage,
    disconnect,
    reconnect: connect,
  };
}`
    },
    {
      path: 'src/types/positions.ts',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `export interface Position {
  id: string;
  traderId: string;
  commodity: string;
  contractMonth: string;
  positionType: 'long' | 'short';
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  unrealizedPnL: number;
  reportingDate: string;
  createdAt: string;
  updatedAt: string;
}

export interface PositionSummary {
  totalPositions: number;
  positionChange: number;
  pendingReports: number;
  reportChange: number;
  complianceScore: number;
  scoreChange: number;
}

export interface ComplianceAlert {
  id: string;
  severity: 'critical' | 'warning' | 'info';
  message: string;
  relatedPositions: string[];
  createdAt: string;
  acknowledged: boolean;
}

export interface ReportSubmission {
  id: string;
  reportType: 'daily' | 'weekly' | 'monthly';
  status: 'pending' | 'submitted' | 'accepted' | 'rejected';
  submittedAt: string | null;
  submittedBy: string | null;
  validationErrors: string[];
  positionCount: number;
}`
    },
    {
      path: 'src/app/positions/page.tsx',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { DataTable } from '@/components/ui/data-table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Download, Filter, Search } from 'lucide-react';
import type { Position } from '@/types/positions';

export default function PositionsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'long' | 'short'>('all');

  const { data: positions, isLoading } = useQuery<Position[]>({
    queryKey: ['/positions', { search: searchTerm, type: filterType }],
  });

  const columns = [
    {
      key: 'traderId',
      label: 'Trader ID',
    },
    {
      key: 'commodity',
      label: 'Commodity',
    },
    {
      key: 'contractMonth',
      label: 'Contract Month',
    },
    {
      key: 'positionType',
      label: 'Type',
      render: (value: string) => (
        <span className={\`px-2 py-1 rounded text-xs \${
          value === 'long' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }\`}>
          {value.toUpperCase()}
        </span>
      ),
    },
    {
      key: 'quantity',
      label: 'Quantity',
      render: (value: number) => value.toLocaleString(),
    },
    {
      key: 'unrealizedPnL',
      label: 'Unrealized P&L',
      render: (value: number) => (
        <span className={value >= 0 ? 'text-green-600' : 'text-red-600'}>
          {value >= 0 ? '+' : ''}\${value.toLocaleString()}
        </span>
      ),
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Position Management</h1>
            <p className="text-muted-foreground">
              View and manage all trading positions
            </p>
          </div>
          <Button>
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by trader ID, commodity..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>

        <DataTable
          data={positions || []}
          columns={columns}
          isLoading={isLoading}
        />
      </div>
    </DashboardLayout>
  );
}`
    },
    {
      path: 'README.md',
      type: 'file',
      language: 'markdown',
      size: 0,
      content: `# CFTC Clearing Platform - Frontend

Next.js 14 application for CFTC Large Trader Reporting compliance and position monitoring.

## Features

- 📊 Real-time position monitoring dashboard
- 📋 CFTC compliance reporting workflows
- 🔐 Role-based access control (Trader, Compliance Officer, Administrator)
- 📱 Responsive design for mobile and desktop
- 🎨 Modern UI with Radix UI components
- ⚡ Server-side rendering with Next.js 14
- 🔄 Real-time updates with WebSocket and React Query

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **UI Library**: React 18
- **State Management**: TanStack Query (React Query)
- **Forms**: React Hook Form + Zod validation
- **Styling**: Tailwind CSS
- **Components**: Radix UI primitives
- **Charts**: Recharts
- **WebSocket**: native WebSocket with custom hook
- **Testing**: Jest, React Testing Library, Cypress

## Getting Started

\`\`\`bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
\`\`\`

Open [http://localhost:3000](http://localhost:3000) to view the application.

## Environment Variables

Create a \`.env.local\` file:

\`\`\`env
NEXT_PUBLIC_API_URL=http://localhost:4000/api
NEXT_PUBLIC_WS_URL=ws://localhost:4000
NEXT_PUBLIC_ENVIRONMENT=development
NEXT_PUBLIC_ENABLE_REALTIME=true
\`\`\`

## Project Structure

\`\`\`
src/
├── app/                 # Next.js 14 app router pages
│   ├── page.tsx        # Dashboard home
│   └── positions/      # Position management
├── components/         # React components
│   ├── ui/            # Reusable UI components
│   └── layouts/       # Layout components
├── hooks/             # Custom React hooks
├── lib/               # Utility functions and API client
└── types/             # TypeScript type definitions
\`\`\`

## Testing

\`\`\`bash
# Run unit tests
npm test

# Run tests with coverage
npm run test:ci

# Run E2E tests
npm run test:e2e:headless
\`\`\`

## License

Proprietary - Internal Use Only`
    },
  ];

  files.forEach(f => f.size = f.content.length);

  return {
    id: 'frontend-nextjs-ts',
    name: 'Frontend (Next.js + TypeScript)',
    description: 'Next.js 14 frontend application with real-time position monitoring, compliance dashboards, and WebSocket integration',
    url: 'https://github.com/company/cftc-clearing-frontend',
    branch: 'main',
    files
  };
}

// ============================================================================
// REPOSITORY 2: Backend - Node.js + Express + TypeScript
// ============================================================================
export function generateCFTCBackendRepo(): Repository {
  const files: RepositoryFile[] = [
    {
      path: 'package.json',
      type: 'file',
      language: 'json',
      size: 0,
      content: `{
  "name": "cftc-clearing-backend",
  "version": "1.0.0",
  "description": "CFTC Clearing Platform - Backend API",
  "main": "dist/server.js",
  "scripts": {
    "dev": "tsx watch src/server.ts",
    "build": "tsc",
    "start": "node dist/server.js",
    "lint": "eslint . --ext .ts",
    "type-check": "tsc --noEmit",
    "test": "jest",
    "test:unit": "jest --testPathPattern=unit",
    "test:integration": "jest --testPathPattern=integration",
    "test:coverage": "jest --coverage",
    "migrate": "node -r tsx/register src/db/migrate.ts",
    "seed": "node -r tsx/register src/db/seed.ts"
  },
  "dependencies": {
    "express": "^4.18.2",
    "pg": "^8.11.3",
    "drizzle-orm": "^0.29.3",
    "zod": "^3.22.4",
    "bcrypt": "^5.1.1",
    "jsonwebtoken": "^9.0.2",
    "ws": "^8.16.0",
    "cors": "^2.8.5",
    "helmet": "^7.1.0",
    "express-rate-limit": "^7.1.5",
    "winston": "^3.11.0",
    "date-fns": "^3.3.1",
    "dotenv": "^16.4.1"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/node": "^20.11.5",
    "@types/pg": "^8.10.9",
    "@types/bcrypt": "^5.0.2",
    "@types/jsonwebtoken": "^9.0.5",
    "@types/ws": "^8.5.10",
    "@types/cors": "^2.8.17",
    "typescript": "^5.3.3",
    "tsx": "^4.7.0",
    "eslint": "^8.56.0",
    "@typescript-eslint/parser": "^6.19.0",
    "@typescript-eslint/eslint-plugin": "^6.19.0",
    "jest": "^29.7.0",
    "@types/jest": "^29.5.11",
    "ts-jest": "^29.1.1",
    "drizzle-kit": "^0.20.10"
  }
}`
    },
    {
      path: 'tsconfig.json',
      type: 'file',
      language: 'json',
      size: 0,
      content: `{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "lib": ["ES2020"],
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "moduleResolution": "node",
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "paths": {
      "@/*": ["./src/*"],
      "@/controllers/*": ["./src/controllers/*"],
      "@/services/*": ["./src/services/*"],
      "@/repositories/*": ["./src/repositories/*"],
      "@/types/*": ["./src/types/*"],
      "@/utils/*": ["./src/utils/*"]
    }
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "**/*.test.ts"]
}`
    },
    {
      path: 'src/server.ts',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import { config } from './config';
import { logger } from './utils/logger';
import { errorHandler } from './middleware/error-handler';
import { requestLogger } from './middleware/request-logger';
import { rateLimiter } from './middleware/rate-limiter';
import { positionsRouter } from './routes/positions';
import { reportsRouter } from './routes/reports';
import { tradersRouter } from './routes/traders';
import { authRouter } from './routes/auth';
import { setupWebSocket } from './websocket';

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server });

// Middleware
app.use(helmet());
app.use(cors({
  origin: config.cors.origin,
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(requestLogger);
app.use(rateLimiter);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// API Routes
app.use('/api/auth', authRouter);
app.use('/api/positions', positionsRouter);
app.use('/api/reports', reportsRouter);
app.use('/api/traders', tradersRouter);

// Error handling
app.use(errorHandler);

// WebSocket setup
setupWebSocket(wss);

// Start server
server.listen(config.port, () => {
  logger.info(\`Server running on port \${config.port}\`);
  logger.info(\`Environment: \${config.env}\`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, closing server gracefully');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});`
    },
    {
      path: 'src/controllers/positions.controller.ts',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `import { Request, Response, NextFunction } from 'express';
import { PositionService } from '@/services/position.service';
import { logger } from '@/utils/logger';
import { z } from 'zod';

const createPositionSchema = z.object({
  traderId: z.string().uuid(),
  commodity: z.string().min(1),
  contractMonth: z.string().regex(/^\d{4}-\d{2}$/),
  positionType: z.enum(['long', 'short']),
  quantity: z.number().positive(),
  averagePrice: z.number().positive(),
});

const updatePositionSchema = createPositionSchema.partial();

export class PositionsController {
  constructor(private positionService: PositionService) {}

  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const { traderId, commodity, type } = req.query;
      
      const filters = {
        traderId: traderId as string | undefined,
        commodity: commodity as string | undefined,
        positionType: type as 'long' | 'short' | undefined,
      };

      const positions = await this.positionService.findAll(filters);
      res.json(positions);
    } catch (error) {
      next(error);
    }
  }

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const position = await this.positionService.findById(id);
      
      if (!position) {
        return res.status(404).json({ error: 'Position not found' });
      }

      res.json(position);
    } catch (error) {
      next(error);
    }
  }

  async getSummary(req: Request, res: Response, next: NextFunction) {
    try {
      const summary = await this.positionService.getSummary();
      res.json(summary);
    } catch (error) {
      next(error);
    }
  }

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const validated = createPositionSchema.parse(req.body);
      const position = await this.positionService.create(validated);
      
      logger.info(\`Position created: \${position.id}\`);
      res.status(201).json(position);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: 'Validation failed', 
          details: error.errors 
        });
      }
      next(error);
    }
  }

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const validated = updatePositionSchema.parse(req.body);
      
      const position = await this.positionService.update(id, validated);
      
      if (!position) {
        return res.status(404).json({ error: 'Position not found' });
      }

      logger.info(\`Position updated: \${id}\`);
      res.json(position);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: 'Validation failed', 
          details: error.errors 
        });
      }
      next(error);
    }
  }

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      await this.positionService.delete(id);
      
      logger.info(\`Position deleted: \${id}\`);
      res.status(204).send();
    } catch (error) {
      next(error);
    }
  }
}`
    },
    {
      path: 'src/services/position.service.ts',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `import { PositionRepository } from '@/repositories/position.repository';
import { ReportRepository } from '@/repositories/report.repository';
import type { Position, PositionFilters, CreatePositionDTO, UpdatePositionDTO, PositionSummary } from '@/types/position.types';

export class PositionService {
  constructor(
    private positionRepo: PositionRepository,
    private reportRepo: ReportRepository
  ) {}

  async findAll(filters: PositionFilters): Promise<Position[]> {
    return this.positionRepo.findAll(filters);
  }

  async findById(id: string): Promise<Position | null> {
    return this.positionRepo.findById(id);
  }

  async create(data: CreatePositionDTO): Promise<Position> {
    // Validate trader exists
    const trader = await this.positionRepo.findTraderById(data.traderId);
    if (!trader) {
      throw new Error('Trader not found');
    }

    // Check for duplicate positions
    const existing = await this.positionRepo.findByTraderAndContract(
      data.traderId,
      data.commodity,
      data.contractMonth
    );

    if (existing) {
      throw new Error('Position already exists for this trader and contract');
    }

    const position = await this.positionRepo.create(data);

    // Trigger compliance check
    await this.checkComplianceThresholds(position);

    return position;
  }

  async update(id: string, data: UpdatePositionDTO): Promise<Position | null> {
    const position = await this.positionRepo.update(id, data);
    
    if (position) {
      await this.checkComplianceThresholds(position);
    }

    return position;
  }

  async delete(id: string): Promise<void> {
    await this.positionRepo.delete(id);
  }

  async getSummary(): Promise<PositionSummary> {
    const [totalPositions, pendingReports, complianceScore] = await Promise.all([
      this.positionRepo.count(),
      this.reportRepo.countPending(),
      this.calculateComplianceScore(),
    ]);

    return {
      totalPositions,
      positionChange: 5.2, // Calculate from historical data
      pendingReports,
      reportChange: -2,
      complianceScore,
      scoreChange: 0.3,
    };
  }

  private async checkComplianceThresholds(position: Position): Promise<void> {
    // Check if position exceeds reporting thresholds
    const threshold = 10000; // Example threshold
    
    if (position.quantity > threshold) {
      // Create compliance alert
      await this.positionRepo.createComplianceAlert({
        severity: 'warning',
        message: \`Position \${position.id} exceeds reporting threshold\`,
        relatedPositions: [position.id],
      });
    }
  }

  private async calculateComplianceScore(): Promise<number> {
    // Implement compliance scoring logic
    const totalPositions = await this.positionRepo.count();
    const compliantPositions = await this.positionRepo.countCompliant();
    
    return totalPositions > 0 
      ? (compliantPositions / totalPositions) * 100 
      : 100;
  }
}`
    },
    {
      path: 'src/repositories/position.repository.ts',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `import { db } from '@/db';
import { positions, traders, complianceAlerts } from '@/db/schema';
import { eq, and } from 'drizzle-orm';
import type { Position, PositionFilters, CreatePositionDTO, UpdatePositionDTO } from '@/types/position.types';

export class PositionRepository {
  async findAll(filters: PositionFilters): Promise<Position[]> {
    const conditions = [];

    if (filters.traderId) {
      conditions.push(eq(positions.traderId, filters.traderId));
    }
    if (filters.commodity) {
      conditions.push(eq(positions.commodity, filters.commodity));
    }
    if (filters.positionType) {
      conditions.push(eq(positions.positionType, filters.positionType));
    }

    return db
      .select()
      .from(positions)
      .where(conditions.length > 0 ? and(...conditions) : undefined);
  }

  async findById(id: string): Promise<Position | null> {
    const [position] = await db
      .select()
      .from(positions)
      .where(eq(positions.id, id))
      .limit(1);

    return position || null;
  }

  async findByTraderAndContract(
    traderId: string,
    commodity: string,
    contractMonth: string
  ): Promise<Position | null> {
    const [position] = await db
      .select()
      .from(positions)
      .where(
        and(
          eq(positions.traderId, traderId),
          eq(positions.commodity, commodity),
          eq(positions.contractMonth, contractMonth)
        )
      )
      .limit(1);

    return position || null;
  }

  async findTraderById(traderId: string) {
    const [trader] = await db
      .select()
      .from(traders)
      .where(eq(traders.id, traderId))
      .limit(1);

    return trader || null;
  }

  async create(data: CreatePositionDTO): Promise<Position> {
    const [position] = await db
      .insert(positions)
      .values({
        ...data,
        currentPrice: data.averagePrice,
        unrealizedPnL: 0,
        reportingDate: new Date().toISOString().split('T')[0],
      })
      .returning();

    return position;
  }

  async update(id: string, data: UpdatePositionDTO): Promise<Position | null> {
    const [position] = await db
      .update(positions)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(positions.id, id))
      .returning();

    return position || null;
  }

  async delete(id: string): Promise<void> {
    await db.delete(positions).where(eq(positions.id, id));
  }

  async count(): Promise<number> {
    const result = await db
      .select({ count: db.fn.count() })
      .from(positions);

    return Number(result[0]?.count || 0);
  }

  async countCompliant(): Promise<number> {
    // Implement compliance check logic
    const result = await db
      .select({ count: db.fn.count() })
      .from(positions);
      // Add WHERE clause for compliance criteria

    return Number(result[0]?.count || 0);
  }

  async createComplianceAlert(data: {
    severity: 'critical' | 'warning' | 'info';
    message: string;
    relatedPositions: string[];
  }) {
    await db.insert(complianceAlerts).values({
      ...data,
      acknowledged: false,
    });
  }
}`
    },
    {
      path: 'src/routes/positions.ts',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `import { Router } from 'express';
import { PositionsController } from '@/controllers/positions.controller';
import { PositionService } from '@/services/position.service';
import { PositionRepository } from '@/repositories/position.repository';
import { ReportRepository } from '@/repositories/report.repository';
import { authenticate } from '@/middleware/authenticate';
import { authorize } from '@/middleware/authorize';

const router = Router();

// Initialize dependencies
const positionRepo = new PositionRepository();
const reportRepo = new ReportRepository();
const positionService = new PositionService(positionRepo, reportRepo);
const positionsController = new PositionsController(positionService);

// All routes require authentication
router.use(authenticate);

// GET /api/positions - List all positions
router.get(
  '/',
  authorize(['trader', 'compliance_officer', 'admin']),
  (req, res, next) => positionsController.getAll(req, res, next)
);

// GET /api/positions/summary - Get position summary
router.get(
  '/summary',
  authorize(['trader', 'compliance_officer', 'admin']),
  (req, res, next) => positionsController.getSummary(req, res, next)
);

// GET /api/positions/:id - Get position by ID
router.get(
  '/:id',
  authorize(['trader', 'compliance_officer', 'admin']),
  (req, res, next) => positionsController.getById(req, res, next)
);

// POST /api/positions - Create new position
router.post(
  '/',
  authorize(['trader', 'admin']),
  (req, res, next) => positionsController.create(req, res, next)
);

// PATCH /api/positions/:id - Update position
router.patch(
  '/:id',
  authorize(['trader', 'admin']),
  (req, res, next) => positionsController.update(req, res, next)
);

// DELETE /api/positions/:id - Delete position
router.delete(
  '/:id',
  authorize(['admin']),
  (req, res, next) => positionsController.delete(req, res, next)
);

export { router as positionsRouter };`
    },
    {
      path: 'src/types/position.types.ts',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `export interface Position {
  id: string;
  traderId: string;
  commodity: string;
  contractMonth: string;
  positionType: 'long' | 'short';
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  unrealizedPnL: number;
  reportingDate: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreatePositionDTO {
  traderId: string;
  commodity: string;
  contractMonth: string;
  positionType: 'long' | 'short';
  quantity: number;
  averagePrice: number;
}

export interface UpdatePositionDTO extends Partial<CreatePositionDTO> {
  currentPrice?: number;
  unrealizedPnL?: number;
}

export interface PositionFilters {
  traderId?: string;
  commodity?: string;
  positionType?: 'long' | 'short';
}

export interface PositionSummary {
  totalPositions: number;
  positionChange: number;
  pendingReports: number;
  reportChange: number;
  complianceScore: number;
  scoreChange: number;
}`
    },
    {
      path: 'src/db/schema.ts',
      type: 'file',
      language: 'typescript',
      size: 0,
      content: `import { pgTable, uuid, varchar, integer, decimal, timestamp, text, pgEnum } from 'drizzle-orm/pg-core';

export const positionTypeEnum = pgEnum('position_type', ['long', 'short']);
export const severityEnum = pgEnum('severity', ['critical', 'warning', 'info']);

export const traders = pgTable('traders', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: varchar('name', { length: 255 }).notNull(),
  email: varchar('email', { length: 255 }).unique().notNull(),
  licenseNumber: varchar('license_number', { length: 50 }).unique(),
  status: varchar('status', { length: 50 }).default('active'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const positions = pgTable('positions', {
  id: uuid('id').primaryKey().defaultRandom(),
  traderId: uuid('trader_id').references(() => traders.id).notNull(),
  commodity: varchar('commodity', { length: 100 }).notNull(),
  contractMonth: varchar('contract_month', { length: 7 }).notNull(),
  positionType: positionTypeEnum('position_type').notNull(),
  quantity: integer('quantity').notNull(),
  averagePrice: decimal('average_price', { precision: 12, scale: 2 }).notNull(),
  currentPrice: decimal('current_price', { precision: 12, scale: 2 }).notNull(),
  unrealizedPnL: decimal('unrealized_pnl', { precision: 12, scale: 2 }).default('0'),
  reportingDate: varchar('reporting_date', { length: 10 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const complianceAlerts = pgTable('compliance_alerts', {
  id: uuid('id').primaryKey().defaultRandom(),
  severity: severityEnum('severity').notNull(),
  message: text('message').notNull(),
  relatedPositions: uuid('related_positions').array(),
  acknowledged: integer('acknowledged').default(0),
  createdAt: timestamp('created_at').defaultNow(),
});`
    },
    {
      path: 'README.md',
      type: 'file',
      language: 'markdown',
      size: 0,
      content: `# CFTC Clearing Platform - Backend API

Node.js + Express + TypeScript backend for CFTC compliance and position management.

## Features

- 🚀 RESTful API with Express.js
- 🔐 JWT-based authentication
- 📊 Real-time WebSocket updates
- 🗄️ PostgreSQL database with Drizzle ORM
- ✅ Request validation with Zod
- 📝 Comprehensive logging with Winston
- 🛡️ Security with Helmet and rate limiting
- 🧪 Unit and integration tests with Jest

## Tech Stack

- **Runtime**: Node.js 20
- **Framework**: Express.js
- **Language**: TypeScript
- **Database ORM**: Drizzle ORM
- **Validation**: Zod
- **Authentication**: JWT (jsonwebtoken)
- **WebSocket**: ws
- **Logging**: Winston
- **Testing**: Jest

## Getting Started

\`\`\`bash
# Install dependencies
npm install

# Run database migrations
npm run migrate

# Seed database
npm run seed

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
\`\`\`

## Environment Variables

Create a \`.env\` file:

\`\`\`env
NODE_ENV=development
PORT=4000
DATABASE_URL=postgresql://user:password@localhost:5432/cftc_clearing
JWT_SECRET=your-secret-key
CORS_ORIGIN=http://localhost:3000
\`\`\`

## Project Structure

\`\`\`
src/
├── controllers/     # Request handlers
├── services/        # Business logic
├── repositories/    # Data access layer
├── routes/          # API routes
├── middleware/      # Express middleware
├── db/             # Database schema and migrations
├── types/          # TypeScript type definitions
└── utils/          # Utility functions
\`\`\`

## API Endpoints

### Positions
- \`GET /api/positions\` - List all positions
- \`GET /api/positions/summary\` - Get position summary
- \`GET /api/positions/:id\` - Get position by ID
- \`POST /api/positions\` - Create new position
- \`PATCH /api/positions/:id\` - Update position
- \`DELETE /api/positions/:id\` - Delete position

### Reports
- \`GET /api/reports\` - List reports
- \`POST /api/reports\` - Submit report
- \`GET /api/reports/:id\` - Get report details

### Traders
- \`GET /api/traders\` - List traders
- \`POST /api/traders\` - Register trader

## Testing

\`\`\`bash
# Run all tests
npm test

# Run unit tests
npm run test:unit

# Run integration tests
npm run test:integration

# Generate coverage report
npm run test:coverage
\`\`\`

## License

Proprietary - Internal Use Only`
    },
  ];

  files.forEach(f => f.size = f.content.length);

  return {
    id: 'backend-express-ts',
    name: 'Backend (Express + TypeScript)',
    description: 'Node.js Express API with TypeScript, Drizzle ORM, WebSocket support, and comprehensive business logic',
    url: 'https://github.com/company/cftc-clearing-backend',
    branch: 'main',
    files
  };
}

// ============================================================================
// REPOSITORY 3: Database - PostgreSQL DDL + Migrations
// ============================================================================
export function generateCFTCDatabaseRepo(): Repository {
  const files: RepositoryFile[] = [
    {
      path: 'README.md',
      type: 'file',
      language: 'markdown',
      size: 0,
      content: `# CFTC Clearing Platform - Database

PostgreSQL database schema, migrations, and seed data for CFTC compliance system.

## Overview

This repository contains all database-related artifacts:
- DDL schema definitions
- Migration scripts
- Seed data for testing and development
- Database documentation

## Database Schema

### Core Tables

1. **traders** - Trader registration and profile information
2. **positions** - Trading positions (long/short)
3. **reports** - CFTC compliance report submissions
4. **submissions** - Individual report submission records
5. **audit_logs** - Comprehensive audit trail
6. **compliance_alerts** - System-generated compliance alerts

## Quick Start

\`\`\`bash
# Create database
psql -U postgres -c "CREATE DATABASE cftc_clearing;"

# Run schema
psql -U postgres -d cftc_clearing -f schema/01_schema.sql

# Run migrations
psql -U postgres -d cftc_clearing -f migrations/001_initial_schema.sql

# Seed development data
psql -U postgres -d cftc_clearing -f seed/dev_seed.sql
\`\`\`

## Migration Strategy

Migrations are numbered sequentially and should be applied in order:
- \`001_initial_schema.sql\` - Base tables and indexes
- \`002_add_audit_triggers.sql\` - Audit logging triggers
- \`003_add_compliance_views.sql\` - Compliance reporting views

## Backup & Restore

\`\`\`bash
# Backup
pg_dump -U postgres cftc_clearing > backup.sql

# Restore
psql -U postgres cftc_clearing < backup.sql
\`\`\`

## License

Proprietary - Internal Use Only`
    },
    {
      path: 'schema/01_schema.sql',
      type: 'file',
      language: 'sql',
      size: 0,
      content: `-- CFTC Clearing Platform - Database Schema
-- PostgreSQL 14+

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create custom types
CREATE TYPE position_type AS ENUM ('long', 'short');
CREATE TYPE report_type AS ENUM ('daily', 'weekly', 'monthly');
CREATE TYPE report_status AS ENUM ('pending', 'submitted', 'accepted', 'rejected');
CREATE TYPE severity_level AS ENUM ('critical', 'warning', 'info');
CREATE TYPE user_role AS ENUM ('trader', 'compliance_officer', 'admin');

-- Traders table
CREATE TABLE traders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    license_number VARCHAR(50) UNIQUE,
    phone VARCHAR(20),
    address TEXT,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_email CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$')
);

-- Positions table
CREATE TABLE positions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trader_id UUID NOT NULL REFERENCES traders(id) ON DELETE CASCADE,
    commodity VARCHAR(100) NOT NULL,
    contract_month VARCHAR(7) NOT NULL, -- Format: YYYY-MM
    position_type position_type NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    average_price DECIMAL(12, 2) NOT NULL CHECK (average_price > 0),
    current_price DECIMAL(12, 2) NOT NULL,
    unrealized_pnl DECIMAL(12, 2) DEFAULT 0,
    reporting_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_position UNIQUE (trader_id, commodity, contract_month, position_type)
);

-- Reports table
CREATE TABLE reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trader_id UUID NOT NULL REFERENCES traders(id) ON DELETE CASCADE,
    report_type report_type NOT NULL,
    reporting_period VARCHAR(20) NOT NULL, -- Format: YYYY-MM or YYYY-Www
    status report_status DEFAULT 'pending',
    total_positions INTEGER DEFAULT 0,
    total_long_quantity INTEGER DEFAULT 0,
    total_short_quantity INTEGER DEFAULT 0,
    validation_errors JSONB DEFAULT '[]'::jsonb,
    submitted_at TIMESTAMP,
    submitted_by UUID,
    reviewed_at TIMESTAMP,
    reviewed_by UUID,
    comments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_reporting_period CHECK (
        reporting_period ~ '^\d{4}-\d{2}$' OR 
        reporting_period ~ '^\d{4}-W\d{2}$'
    )
);

-- Submissions table (detailed position data per report)
CREATE TABLE submissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_id UUID NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    position_id UUID REFERENCES positions(id) ON DELETE SET NULL,
    commodity VARCHAR(100) NOT NULL,
    contract_month VARCHAR(7) NOT NULL,
    position_type position_type NOT NULL,
    quantity INTEGER NOT NULL,
    average_price DECIMAL(12, 2) NOT NULL,
    market_value DECIMAL(12, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Audit logs table
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name VARCHAR(100) NOT NULL,
    record_id UUID,
    action VARCHAR(20) NOT NULL, -- INSERT, UPDATE, DELETE
    old_values JSONB,
    new_values JSONB,
    changed_by UUID,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address INET,
    user_agent TEXT
);

-- Compliance alerts table
CREATE TABLE compliance_alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    severity severity_level NOT NULL,
    message TEXT NOT NULL,
    related_positions UUID[] DEFAULT ARRAY[]::UUID[],
    related_reports UUID[] DEFAULT ARRAY[]::UUID[],
    acknowledged BOOLEAN DEFAULT FALSE,
    acknowledged_by UUID,
    acknowledged_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users table (for authentication)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trader_id UUID REFERENCES traders(id) ON DELETE CASCADE,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role user_role NOT NULL DEFAULT 'trader',
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX idx_positions_trader_id ON positions(trader_id);
CREATE INDEX idx_positions_commodity ON positions(commodity);
CREATE INDEX idx_positions_reporting_date ON positions(reporting_date);
CREATE INDEX idx_reports_trader_id ON reports(trader_id);
CREATE INDEX idx_reports_status ON reports(status);
CREATE INDEX idx_reports_reporting_period ON reports(reporting_period);
CREATE INDEX idx_submissions_report_id ON submissions(report_id);
CREATE INDEX idx_submissions_position_id ON submissions(position_id);
CREATE INDEX idx_audit_logs_table_record ON audit_logs(table_name, record_id);
CREATE INDEX idx_audit_logs_changed_at ON audit_logs(changed_at);
CREATE INDEX idx_compliance_alerts_severity ON compliance_alerts(severity);
CREATE INDEX idx_compliance_alerts_acknowledged ON compliance_alerts(acknowledged);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply updated_at triggers
CREATE TRIGGER update_traders_updated_at BEFORE UPDATE ON traders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_positions_updated_at BEFORE UPDATE ON positions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_reports_updated_at BEFORE UPDATE ON reports
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();`
    },
    {
      path: 'migrations/001_initial_schema.sql',
      type: 'file',
      language: 'sql',
      size: 0,
      content: `-- Migration 001: Initial Schema
-- Created: 2024-01-15
-- Description: Create base tables for CFTC clearing platform

BEGIN;

-- Execute main schema
\\i schema/01_schema.sql

-- Add migration tracking
CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    description TEXT NOT NULL,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO schema_migrations (version, description) 
VALUES (1, 'Initial schema creation');

COMMIT;`
    },
    {
      path: 'migrations/002_add_audit_triggers.sql',
      type: 'file',
      language: 'sql',
      size: 0,
      content: `-- Migration 002: Add Audit Triggers
-- Created: 2024-01-20
-- Description: Add comprehensive audit logging for all critical tables

BEGIN;

-- Audit trigger function
CREATE OR REPLACE FUNCTION audit_trigger_function()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO audit_logs (table_name, record_id, action, old_values, changed_at)
        VALUES (TG_TABLE_NAME, OLD.id, 'DELETE', row_to_json(OLD), CURRENT_TIMESTAMP);
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO audit_logs (table_name, record_id, action, old_values, new_values, changed_at)
        VALUES (TG_TABLE_NAME, NEW.id, 'UPDATE', row_to_json(OLD), row_to_json(NEW), CURRENT_TIMESTAMP);
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO audit_logs (table_name, record_id, action, new_values, changed_at)
        VALUES (TG_TABLE_NAME, NEW.id, 'INSERT', row_to_json(NEW), CURRENT_TIMESTAMP);
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Apply audit triggers to critical tables
CREATE TRIGGER audit_positions
    AFTER INSERT OR UPDATE OR DELETE ON positions
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_reports
    AFTER INSERT OR UPDATE OR DELETE ON reports
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_traders
    AFTER INSERT OR UPDATE OR DELETE ON traders
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

-- Track migration
INSERT INTO schema_migrations (version, description) 
VALUES (2, 'Add audit triggers for critical tables');

COMMIT;`
    },
    {
      path: 'migrations/003_add_compliance_views.sql',
      type: 'file',
      language: 'sql',
      size: 0,
      content: `-- Migration 003: Add Compliance Views
-- Created: 2024-01-25
-- Description: Create views for compliance reporting and analytics

BEGIN;

-- View: Trader position summary
CREATE OR REPLACE VIEW v_trader_position_summary AS
SELECT 
    t.id AS trader_id,
    t.name AS trader_name,
    t.email,
    COUNT(DISTINCT p.id) AS total_positions,
    SUM(CASE WHEN p.position_type = 'long' THEN p.quantity ELSE 0 END) AS total_long_quantity,
    SUM(CASE WHEN p.position_type = 'short' THEN p.quantity ELSE 0 END) AS total_short_quantity,
    SUM(p.unrealized_pnl) AS total_unrealized_pnl,
    COUNT(DISTINCT p.commodity) AS unique_commodities
FROM traders t
LEFT JOIN positions p ON t.id = p.trader_id
GROUP BY t.id, t.name, t.email;

-- View: Pending compliance reports
CREATE OR REPLACE VIEW v_pending_reports AS
SELECT 
    r.id,
    r.trader_id,
    t.name AS trader_name,
    r.report_type,
    r.reporting_period,
    r.total_positions,
    r.created_at,
    EXTRACT(DAY FROM CURRENT_TIMESTAMP - r.created_at) AS days_pending
FROM reports r
JOIN traders t ON r.trader_id = t.id
WHERE r.status = 'pending'
ORDER BY r.created_at ASC;

-- View: Compliance alerts summary
CREATE OR REPLACE VIEW v_compliance_alerts_summary AS
SELECT 
    severity,
    COUNT(*) AS alert_count,
    COUNT(*) FILTER (WHERE acknowledged = FALSE) AS unacknowledged_count,
    MAX(created_at) AS latest_alert_time
FROM compliance_alerts
GROUP BY severity;

-- View: Monthly position trends
CREATE OR REPLACE VIEW v_monthly_position_trends AS
SELECT 
    DATE_TRUNC('month', p.reporting_date) AS month,
    p.commodity,
    COUNT(*) AS position_count,
    SUM(p.quantity) AS total_quantity,
    AVG(p.average_price) AS avg_price,
    SUM(p.unrealized_pnl) AS total_pnl
FROM positions p
WHERE p.reporting_date >= CURRENT_DATE - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', p.reporting_date), p.commodity
ORDER BY month DESC, commodity;

-- Track migration
INSERT INTO schema_migrations (version, description) 
VALUES (3, 'Add compliance views for reporting and analytics');

COMMIT;`
    },
    {
      path: 'seed/dev_seed.sql',
      type: 'file',
      language: 'sql',
      size: 0,
      content: `-- Development Seed Data
-- WARNING: This file should only be used in development environments

BEGIN;

-- Seed traders
INSERT INTO traders (id, name, email, license_number, phone, status) VALUES
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Acme Trading LLC', 'contact@acmetrading.com', 'LIC-2024-001', '+1-555-0101', 'active'),
('b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'Global Commodities Inc', 'info@globalcommodities.com', 'LIC-2024-002', '+1-555-0102', 'active'),
('c2eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'Futures Trading Group', 'admin@ftgroup.com', 'LIC-2024-003', '+1-555-0103', 'active'),
('d3eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'Energy Traders Co', 'contact@energytraders.com', 'LIC-2024-004', '+1-555-0104', 'active'),
('e4eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'Agricultural Markets Ltd', 'info@agmarkets.com', 'LIC-2024-005', '+1-555-0105', 'active');

-- Seed positions
INSERT INTO positions (id, trader_id, commodity, contract_month, position_type, quantity, average_price, current_price, unrealized_pnl, reporting_date) VALUES
-- Acme Trading positions
('10000000-0000-0000-0000-000000000001', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Crude Oil', '2024-03', 'long', 5000, 75.50, 78.20, 13500.00, '2024-01-15'),
('10000000-0000-0000-0000-000000000002', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Natural Gas', '2024-04', 'short', 3000, 3.25, 3.10, 4500.00, '2024-01-15'),
('10000000-0000-0000-0000-000000000003', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Gold', '2024-06', 'long', 1000, 2050.00, 2075.00, 25000.00, '2024-01-15'),

-- Global Commodities positions
('20000000-0000-0000-0000-000000000001', 'b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'Corn', '2024-05', 'long', 10000, 4.75, 4.90, 15000.00, '2024-01-15'),
('20000000-0000-0000-0000-000000000002', 'b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'Soybeans', '2024-05', 'long', 8000, 13.25, 13.50, 20000.00, '2024-01-15'),
('20000000-0000-0000-0000-000000000003', 'b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'Wheat', '2024-07', 'short', 6000, 6.50, 6.35, 9000.00, '2024-01-15'),

-- Futures Trading Group positions
('30000000-0000-0000-0000-000000000001', 'c2eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'Silver', '2024-03', 'long', 15000, 23.50, 24.10, 9000.00, '2024-01-15'),
('30000000-0000-0000-0000-000000000002', 'c2eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'Copper', '2024-05', 'long', 5000, 3.85, 3.95, 5000.00, '2024-01-15'),

-- Energy Traders positions
('40000000-0000-0000-0000-000000000001', 'd3eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'Crude Oil', '2024-04', 'long', 8000, 76.00, 78.20, 17600.00, '2024-01-15'),
('40000000-0000-0000-0000-000000000002', 'd3eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'Heating Oil', '2024-03', 'short', 4000, 2.45, 2.35, 4000.00, '2024-01-15'),

-- Agricultural Markets positions
('50000000-0000-0000-0000-000000000001', 'e4eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'Coffee', '2024-05', 'long', 12000, 1.75, 1.82, 8400.00, '2024-01-15'),
('50000000-0000-0000-0000-000000000002', 'e4eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'Sugar', '2024-03', 'long', 20000, 0.185, 0.192, 14000.00, '2024-01-15');

-- Seed reports
INSERT INTO reports (id, trader_id, report_type, reporting_period, status, total_positions, total_long_quantity, total_short_quantity) VALUES
('r1000000-0000-0000-0000-000000000001', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'weekly', '2024-W02', 'submitted', 3, 6000, 3000),
('r2000000-0000-0000-0000-000000000001', 'b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'weekly', '2024-W02', 'pending', 3, 18000, 6000),
('r3000000-0000-0000-0000-000000000001', 'c2eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'weekly', '2024-W02', 'submitted', 2, 20000, 0);

-- Seed compliance alerts
INSERT INTO compliance_alerts (severity, message, related_positions, acknowledged) VALUES
('warning', 'Position exceeds reporting threshold for Crude Oil futures', ARRAY['10000000-0000-0000-0000-000000000001']::UUID[], FALSE),
('info', 'Monthly report due in 3 days for trader Acme Trading LLC', ARRAY[]::UUID[], FALSE),
('critical', 'Large position concentration detected in Corn futures', ARRAY['20000000-0000-0000-0000-000000000001']::UUID[], FALSE);

-- Seed users (passwords are hashed with bcrypt, password: 'password123')
INSERT INTO users (id, trader_id, email, password_hash, role, is_active) VALUES
('u1000000-0000-0000-0000-000000000001', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'trader1@acmetrading.com', '$2b$10$rKjVZ8YpW8WqLJXxE3L5Ru6YvYYz6K5zJl9YvYYz6K5zJl9YvYYz6', 'trader', TRUE),
('u2000000-0000-0000-0000-000000000001', 'b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'trader2@globalcommodities.com', '$2b$10$rKjVZ8YpW8WqLJXxE3L5Ru6YvYYz6K5zJl9YvYYz6K5zJl9YvYYz6', 'trader', TRUE),
('u9000000-0000-0000-0000-000000000001', NULL, 'admin@cftc-platform.com', '$2b$10$rKjVZ8YpW8WqLJXxE3L5Ru6YvYYz6K5zJl9YvYYz6K5zJl9YvYYz6', 'admin', TRUE),
('u9000000-0000-0000-0000-000000000002', NULL, 'compliance@cftc-platform.com', '$2b$10$rKjVZ8YpW8WqLJXxE3L5Ru6YvYYz6K5zJl9YvYYz6K5zJl9YvYYz6', 'compliance_officer', TRUE);

COMMIT;

-- Display seed data summary
SELECT 'Traders' AS table_name, COUNT(*) AS record_count FROM traders
UNION ALL
SELECT 'Positions', COUNT(*) FROM positions
UNION ALL
SELECT 'Reports', COUNT(*) FROM reports
UNION ALL
SELECT 'Compliance Alerts', COUNT(*) FROM compliance_alerts
UNION ALL
SELECT 'Users', COUNT(*) FROM users;`
    },
  ];

  files.forEach(f => f.size = f.content.length);

  return {
    id: 'database-postgresql',
    name: 'Database (PostgreSQL)',
    description: 'PostgreSQL database schema with comprehensive DDL, migrations, audit triggers, compliance views, and seed data',
    url: 'https://github.com/company/cftc-clearing-database',
    branch: 'main',
    files
  };
}

// ============================================================================
// REPOSITORY 4: Infrastructure - DevOps + CI/CD
// ============================================================================
export function generateCFTCInfrastructureRepo(): Repository {
  const files: RepositoryFile[] = [
    {
      path: 'docker-compose.yml',
      type: 'file',
      language: 'yaml',
      size: 0,
      content: `version: '3.8'

services:
  # PostgreSQL Database
  postgres:
    image: postgres:15-alpine
    container_name: cftc-postgres
    environment:
      POSTGRES_DB: cftc_clearing
      POSTGRES_USER: \${DB_USER:-cftc_user}
      POSTGRES_PASSWORD: \${DB_PASSWORD:-cftc_pass}
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./database/schema:/docker-entrypoint-initdb.d
    networks:
      - cftc-network
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U \${DB_USER:-cftc_user}"]
      interval: 10s
      timeout: 5s
      retries: 5

  # Backend API
  backend:
    build:
      context: ../cftc-clearing-backend
      dockerfile: Dockerfile
    container_name: cftc-backend
    environment:
      NODE_ENV: production
      PORT: 4000
      DATABASE_URL: postgresql://\${DB_USER:-cftc_user}:\${DB_PASSWORD:-cftc_pass}@postgres:5432/cftc_clearing
      JWT_SECRET: \${JWT_SECRET}
      CORS_ORIGIN: http://localhost:3000
    ports:
      - "4000:4000"
    depends_on:
      postgres:
        condition: service_healthy
    networks:
      - cftc-network
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:4000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Frontend Application
  frontend:
    build:
      context: ../cftc-clearing-frontend
      dockerfile: Dockerfile
    container_name: cftc-frontend
    environment:
      NEXT_PUBLIC_API_URL: http://localhost:4000/api
      NEXT_PUBLIC_WS_URL: ws://localhost:4000
    ports:
      - "3000:3000"
    depends_on:
      - backend
    networks:
      - cftc-network
    restart: unless-stopped

  # Redis (for caching and session management)
  redis:
    image: redis:7-alpine
    container_name: cftc-redis
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    networks:
      - cftc-network
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    container_name: cftc-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
    depends_on:
      - frontend
      - backend
    networks:
      - cftc-network
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:

networks:
  cftc-network:
    driver: bridge`
    },
    {
      path: 'kubernetes/deployment.yaml',
      type: 'file',
      language: 'yaml',
      size: 0,
      content: `apiVersion: apps/v1
kind: Deployment
metadata:
  name: cftc-backend
  namespace: cftc-clearing
  labels:
    app: cftc-backend
    tier: backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: cftc-backend
  template:
    metadata:
      labels:
        app: cftc-backend
        tier: backend
    spec:
      containers:
      - name: backend
        image: registry.company.com/cftc-backend:latest
        ports:
        - containerPort: 4000
          name: http
        env:
        - name: NODE_ENV
          value: "production"
        - name: PORT
          value: "4000"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: cftc-secrets
              key: database-url
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: cftc-secrets
              key: jwt-secret
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 4000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 4000
          initialDelaySeconds: 10
          periodSeconds: 5
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cftc-frontend
  namespace: cftc-clearing
  labels:
    app: cftc-frontend
    tier: frontend
spec:
  replicas: 2
  selector:
    matchLabels:
      app: cftc-frontend
  template:
    metadata:
      labels:
        app: cftc-frontend
        tier: frontend
    spec:
      containers:
      - name: frontend
        image: registry.company.com/cftc-frontend:latest
        ports:
        - containerPort: 3000
          name: http
        env:
        - name: NEXT_PUBLIC_API_URL
          value: "http://cftc-backend-service:4000/api"
        - name: NEXT_PUBLIC_WS_URL
          value: "ws://cftc-backend-service:4000"
        resources:
          requests:
            memory: "256Mi"
            cpu: "200m"
          limits:
            memory: "512Mi"
            cpu: "400m"
---
apiVersion: v1
kind: Service
metadata:
  name: cftc-backend-service
  namespace: cftc-clearing
spec:
  selector:
    app: cftc-backend
  ports:
  - protocol: TCP
    port: 4000
    targetPort: 4000
  type: ClusterIP
---
apiVersion: v1
kind: Service
metadata:
  name: cftc-frontend-service
  namespace: cftc-clearing
spec:
  selector:
    app: cftc-frontend
  ports:
  - protocol: TCP
    port: 3000
    targetPort: 3000
  type: LoadBalancer`
    },
    {
      path: 'kubernetes/ingress.yaml',
      type: 'file',
      language: 'yaml',
      size: 0,
      content: `apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: cftc-ingress
  namespace: cftc-clearing
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/websocket-services: "cftc-backend-service"
spec:
  tls:
  - hosts:
    - cftc-clearing.company.com
    secretName: cftc-tls-secret
  rules:
  - host: cftc-clearing.company.com
    http:
      paths:
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: cftc-backend-service
            port:
              number: 4000
      - path: /
        pathType: Prefix
        backend:
          service:
            name: cftc-frontend-service
            port:
              number: 3000`
    },
    {
      path: 'Jenkinsfile',
      type: 'file',
      language: 'groovy',
      size: 0,
      content: `/* Multi-Repository CI/CD Pipeline for CFTC Clearing Platform */
pipeline {
    agent {
        label 'docker'
    }
    
    environment {
        DOCKER_REGISTRY = 'registry.company.com'
        K8S_NAMESPACE = 'cftc-clearing'
        SLACK_CHANNEL = '#cftc-deployments'
    }
    
    parameters {
        choice(
            name: 'DEPLOY_ENV',
            choices: ['dev', 'staging', 'production'],
            description: 'Target deployment environment'
        )
        booleanParam(
            name: 'RUN_E2E_TESTS',
            defaultValue: true,
            description: 'Run end-to-end tests'
        )
    }
    
    stages {
        stage('Checkout Repositories') {
            parallel {
                stage('Frontend') {
                    steps {
                        dir('frontend') {
                            git branch: 'main',
                                url: 'https://github.com/company/cftc-clearing-frontend'
                        }
                    }
                }
                stage('Backend') {
                    steps {
                        dir('backend') {
                            git branch: 'main',
                                url: 'https://github.com/company/cftc-clearing-backend'
                        }
                    }
                }
                stage('Database') {
                    steps {
                        dir('database') {
                            git branch: 'main',
                                url: 'https://github.com/company/cftc-clearing-database'
                        }
                    }
                }
            }
        }
        
        stage('Build & Test') {
            parallel {
                stage('Frontend Build') {
                    steps {
                        dir('frontend') {
                            sh '''
                                npm ci
                                npm run lint
                                npm run type-check
                                npm run test:ci
                                npm run build
                            '''
                        }
                    }
                }
                stage('Backend Build') {
                    steps {
                        dir('backend') {
                            sh '''
                                npm ci
                                npm run lint
                                npm run type-check
                                npm run test:coverage
                                npm run build
                            '''
                        }
                    }
                }
            }
        }
        
        stage('Security Scan') {
            parallel {
                stage('Frontend Security') {
                    steps {
                        dir('frontend') {
                            sh 'npm audit --audit-level=moderate || true'
                        }
                    }
                }
                stage('Backend Security') {
                    steps {
                        dir('backend') {
                            sh 'npm audit --audit-level=moderate || true'
                        }
                    }
                }
                stage('Container Scan') {
                    steps {
                        sh '''
                            trivy image --severity HIGH,CRITICAL \\
                                \${DOCKER_REGISTRY}/cftc-frontend:latest || true
                            trivy image --severity HIGH,CRITICAL \\
                                \${DOCKER_REGISTRY}/cftc-backend:latest || true
                        '''
                    }
                }
            }
        }
        
        stage('Docker Build & Push') {
            when {
                branch 'main'
            }
            parallel {
                stage('Build Frontend Image') {
                    steps {
                        dir('frontend') {
                            script {
                                docker.build("\${DOCKER_REGISTRY}/cftc-frontend:\${BUILD_NUMBER}")
                                docker.build("\${DOCKER_REGISTRY}/cftc-frontend:latest")
                            }
                        }
                    }
                }
                stage('Build Backend Image') {
                    steps {
                        dir('backend') {
                            script {
                                docker.build("\${DOCKER_REGISTRY}/cftc-backend:\${BUILD_NUMBER}")
                                docker.build("\${DOCKER_REGISTRY}/cftc-backend:latest")
                            }
                        }
                    }
                }
            }
        }
        
        stage('Database Migration') {
            when {
                expression { params.DEPLOY_ENV != 'production' }
            }
            steps {
                dir('database') {
                    sh '''
                        kubectl exec -n \${K8S_NAMESPACE} deployment/postgres -- \\
                            psql -U cftc_user -d cftc_clearing -f /migrations/latest.sql
                    '''
                }
            }
        }
        
        stage('Deploy to Kubernetes') {
            steps {
                sh """
                    kubectl apply -f kubernetes/deployment.yaml --namespace=\${K8S_NAMESPACE}-\${params.DEPLOY_ENV}
                    kubectl apply -f kubernetes/service.yaml --namespace=\${K8S_NAMESPACE}-\${params.DEPLOY_ENV}
                    kubectl apply -f kubernetes/ingress.yaml --namespace=\${K8S_NAMESPACE}-\${params.DEPLOY_ENV}
                    
                    kubectl rollout status deployment/cftc-frontend --namespace=\${K8S_NAMESPACE}-\${params.DEPLOY_ENV}
                    kubectl rollout status deployment/cftc-backend --namespace=\${K8S_NAMESPACE}-\${params.DEPLOY_ENV}
                """
            }
        }
        
        stage('E2E Tests') {
            when {
                expression { params.RUN_E2E_TESTS }
            }
            steps {
                dir('frontend') {
                    sh 'npm run test:e2e:headless'
                }
            }
        }
        
        stage('Smoke Tests') {
            steps {
                sh '''
                    curl -f http://cftc-clearing-\${DEPLOY_ENV}.company.com/health || exit 1
                    curl -f http://cftc-clearing-\${DEPLOY_ENV}.company.com/api/health || exit 1
                '''
            }
        }
    }
    
    post {
        success {
            slackSend(
                channel: SLACK_CHANNEL,
                color: 'good',
                message: "✅ CFTC Platform deployed to \${params.DEPLOY_ENV}: Build #\${BUILD_NUMBER}"
            )
        }
        failure {
            slackSend(
                channel: SLACK_CHANNEL,
                color: 'danger',
                message: "❌ CFTC Platform deployment FAILED: Build #\${BUILD_NUMBER}"
            )
        }
        always {
            cleanWs()
        }
    }
}`
    },
    {
      path: 'docker/frontend.Dockerfile',
      type: 'file',
      language: 'dockerfile',
      size: 0,
      content: `# Multi-stage build for CFTC Frontend
FROM node:20-alpine AS base
WORKDIR /app

# Dependencies stage
FROM base AS deps
RUN apk add --no-cache libc6-compat
COPY package.json package-lock.json* ./
RUN npm ci --prefer-offline --no-audit

# Builder stage
FROM base AS builder
COPY --from=deps /app/node_modules ./node_modules
COPY . .

ENV NEXT_TELEMETRY_DISABLED=1
ENV NODE_ENV=production

RUN npm run build

# Production stage
FROM base AS runner
ENV NODE_ENV=production
ENV NEXT_TELEMETRY_DISABLED=1

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs
EXPOSE 3000

ENV PORT=3000
ENV HOSTNAME="0.0.0.0"

CMD ["node", "server.js"]`
    },
    {
      path: 'docker/backend.Dockerfile',
      type: 'file',
      language: 'dockerfile',
      size: 0,
      content: `# Multi-stage build for CFTC Backend
FROM node:20-alpine AS base
WORKDIR /app

# Dependencies stage
FROM base AS deps
COPY package.json package-lock.json* ./
RUN npm ci --prefer-offline --no-audit --omit=dev

# Build stage
FROM base AS builder
COPY package.json package-lock.json* ./
RUN npm ci --prefer-offline --no-audit
COPY . .
RUN npm run build

# Production stage
FROM base AS runner
ENV NODE_ENV=production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nodeuser

COPY --from=deps --chown=nodeuser:nodejs /app/node_modules ./node_modules
COPY --from=builder --chown=nodeuser:nodejs /app/dist ./dist
COPY --from=builder --chown=nodeuser:nodejs /app/package.json ./

USER nodeuser
EXPOSE 4000

CMD ["node", "dist/server.js"]`
    },
    {
      path: '.env.example',
      type: 'file',
      language: 'bash',
      size: 0,
      content: `# Database Configuration
DB_USER=cftc_user
DB_PASSWORD=secure_password_here
DATABASE_URL=postgresql://cftc_user:secure_password_here@localhost:5432/cftc_clearing

# Application Configuration
NODE_ENV=production
PORT=4000

# Security
JWT_SECRET=your-super-secret-jwt-key-here-change-in-production
JWT_EXPIRATION=7d

# Frontend
NEXT_PUBLIC_API_URL=http://localhost:4000/api
NEXT_PUBLIC_WS_URL=ws://localhost:4000
NEXT_PUBLIC_ENVIRONMENT=production

# CORS
CORS_ORIGIN=http://localhost:3000

# Docker Registry
DOCKER_REGISTRY=registry.company.com

# Kubernetes
K8S_NAMESPACE=cftc-clearing

# Monitoring
SENTRY_DSN=
DATADOG_API_KEY=

# Email (for alerts)
SMTP_HOST=smtp.company.com
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
ALERT_EMAIL=compliance@company.com`
    },
    {
      path: 'README.md',
      type: 'file',
      language: 'markdown',
      size: 0,
      content: `# CFTC Clearing Platform - Infrastructure

DevOps and infrastructure configuration for the CFTC Clearing Platform.

## Overview

This repository contains:
- Docker Compose for local development
- Kubernetes manifests for production deployment
- CI/CD pipeline configuration (Jenkins)
- Infrastructure as Code (IaC)
- Deployment scripts and utilities

## Quick Start

### Local Development with Docker Compose

\`\`\`bash
# Copy environment file
cp .env.example .env

# Edit .env with your configuration
vim .env

# Start all services
docker-compose up -d

# Check service status
docker-compose ps

# View logs
docker-compose logs -f
\`\`\`

Access the application:
- Frontend: http://localhost:3000
- Backend API: http://localhost:4000
- Database: localhost:5432

### Production Deployment with Kubernetes

\`\`\`bash
# Create namespace
kubectl create namespace cftc-clearing

# Apply secrets
kubectl apply -f kubernetes/secrets.yaml

# Deploy applications
kubectl apply -f kubernetes/deployment.yaml
kubectl apply -f kubernetes/service.yaml
kubectl apply -f kubernetes/ingress.yaml

# Check deployment status
kubectl get pods -n cftc-clearing
kubectl rollout status deployment/cftc-backend -n cftc-clearing
\`\`\`

## Architecture

\`\`\`
┌─────────────┐
│   Nginx     │ ← Reverse Proxy & SSL Termination
└─────────────┘
       │
       ├─→ Frontend (Next.js) :3000
       └─→ Backend (Express) :4000
              │
              ├─→ PostgreSQL :5432
              └─→ Redis :6379
\`\`\`

## CI/CD Pipeline

Jenkins pipeline stages:
1. **Checkout** - Clone all repositories
2. **Build & Test** - Run tests and build artifacts
3. **Security Scan** - npm audit, Trivy container scanning
4. **Docker Build** - Build and tag Docker images
5. **Database Migration** - Apply schema changes
6. **Deploy** - Deploy to Kubernetes
7. **E2E Tests** - Run end-to-end tests
8. **Smoke Tests** - Verify deployment

## Monitoring

- **Health Checks**: /health endpoint
- **Metrics**: Prometheus metrics at /metrics
- **Logs**: Centralized logging with ELK stack
- **Alerts**: PagerDuty integration for critical alerts

## Security

- TLS/SSL encryption in transit
- Database encryption at rest
- Secrets managed via Kubernetes Secrets
- Network policies for pod-to-pod communication
- Regular security scans with Trivy

## Scaling

### Horizontal Pod Autoscaling (HPA)

\`\`\`bash
kubectl autoscale deployment cftc-backend \\
  --cpu-percent=70 \\
  --min=3 \\
  --max=10 \\
  -n cftc-clearing
\`\`\`

### Database Scaling

- Read replicas for reporting queries
- Connection pooling with PgBouncer
- Partitioning for large tables

## Disaster Recovery

- Automated daily backups
- Point-in-time recovery (PITR)
- Multi-region replication
- Backup retention: 30 days

## License

Proprietary - Internal Use Only`
    },
  ];

  files.forEach(f => f.size = f.content.length);

  return {
    id: 'infrastructure-devops',
    name: 'Infrastructure (DevOps)',
    description: 'Complete DevOps setup with Docker Compose, Kubernetes manifests, Jenkins CI/CD pipeline, and deployment configurations',
    url: 'https://github.com/company/cftc-clearing-infrastructure',
    branch: 'main',
    files
  };
}

// Export all repository generator functions
export const professionalRepoGenerators = {
  generateCFTCFrontendRepo,
  generateCFTCBackendRepo,
  generateCFTCDatabaseRepo,
  generateCFTCInfrastructureRepo,
};
