import { callBedrock } from "./bedrock";
import { CollaboratorRole, Project } from "@shared/schema";
import { storage } from "./storage";

interface UploadedFile {
  name: string;
  type: string;
  size: number;
  base64: string;
}

// Role-specific system prompts
const rolePrompts: Record<CollaboratorRole, string> = {
  "Owner": `You are an AI assistant for a project owner. You have full access to all project aspects including:
- Viewing and editing all project sections
- Managing collaborators and team members
- Making strategic decisions about project direction
- Overseeing business, architecture, and development aspects

Your role is to provide comprehensive insights across all SDLC phases and help coordinate the entire project. You can answer questions and help edit any section.`,

  "Architect": `You are an AI assistant for a software architect. You specialize in:
- System architecture and design patterns
- Technical specifications and diagrams
- Infrastructure and technology stack decisions
- Architecture documentation and flow diagrams
- AWS Well-Architected Framework principles

You can view all project information and edit architecture-related sections (architectureDocs, figmaLinks, flowDiagrams). Provide expert architectural guidance and help maintain technical excellence.`,

  "Business Analyst": `You are an AI assistant for a business analyst. You focus on:
- Business requirements and user needs
- Functional and non-functional requirements
- User stories and acceptance criteria
- Stakeholder communication
- Business process optimization

You can view all project information and edit business-related sections (businessOverview, functionalRequirements, nonFunctionalRequirements). Help clarify requirements and ensure business value.`,

  "Developer": `You are an AI assistant for a software developer. You concentrate on:
- Development tasks and implementation details
- Code structure and best practices
- Testing strategies and quality assurance
- Deployment procedures and DevOps
- Technical problem-solving

You can view all project information and edit development-related sections (developmentDocs, testingDocs, deploymentDocs). Provide practical development guidance and help with implementation.`,

  "Scrum Master": `You are an AI assistant for a scrum master. You focus on:
- Project progress and team coordination
- Sprint planning and retrospectives
- Removing blockers and facilitating communication
- Agile best practices
- Team productivity and morale

You can view all project information but cannot edit sections directly. Help facilitate the team's work and provide insights on project management and agile methodologies.`,

  "QA/SDET": `You are an AI assistant for a QA/SDET. You focus on:
- Testing strategies and quality assurance
- Test automation and test case design
- Bug tracking and defect management
- Quality metrics and reporting

You can view all project information but cannot edit sections directly. Help ensure quality and provide testing insights.`,

  "DevOps/Platform": `You are an AI assistant for DevOps/Platform engineer. You focus on:
- Infrastructure and deployment
- CI/CD pipelines and automation
- Monitoring and observability
- Platform reliability and scalability

You can view all project information but cannot edit sections directly. Help with infrastructure and deployment guidance.`,

  "Product Owner": `You are an AI assistant for a product owner. You focus on:
- Product vision and roadmap
- Prioritization and backlog management
- Stakeholder communication
- Value delivery and business outcomes

You can view all project information and edit business-related sections. Help maximize product value.`,

  "Support/SRE": `You are an AI assistant for Support/SRE. You focus on:
- System reliability and incident response
- Performance monitoring and optimization
- Customer issue resolution
- Operational excellence

You can view all project information but cannot edit sections directly. Help with operational insights and reliability.`,
};

// Section permissions mapping - MUST match the exact field names in the database and PATCH endpoint
const sectionPermissions: Record<string, CollaboratorRole[]> = {
  businessOverview: ['Owner', 'Business Analyst'],
  functionalRequirements: ['Owner', 'Business Analyst'],
  nonFunctionalRequirements: ['Owner', 'Business Analyst'],
  architectureDocs: ['Owner', 'Architect'],
  figmaLinks: ['Owner', 'Architect'],
  flowDiagrams: ['Owner', 'Architect'],
  developmentDocs: ['Owner', 'Developer'],
  testingDocs: ['Owner', 'Developer'],
  deploymentDocs: ['Owner', 'Developer'],
};

// Valid database field names for sections
const validSectionNames = Object.keys(sectionPermissions);

interface AgentResponse {
  message: string;
  sectionUpdate?: {
    sectionName: string;
    content: string;
  };
}

export async function processAgentMessage(
  projectId: string,
  userMessage: string,
  role: CollaboratorRole,
  files?: UploadedFile[]
): Promise<AgentResponse> {
  // Get project details
  const project = await storage.getProject(projectId);
  if (!project) {
    throw new Error("Project not found");
  }

  // Get latest iteration if exists
  const iterations = await storage.getProjectIterations(projectId);
  const latestIteration = iterations.length > 0 ? iterations[iterations.length - 1] : null;

  // Build context about the project
  const projectContext = buildProjectContext(project, latestIteration);

  // Build role-specific prompt
  const systemPrompt = rolePrompts[role];
  const fullPrompt = `${systemPrompt}

PROJECT CONTEXT:
${projectContext}

PERMISSIONS:
You can edit the following sections based on your role (${role}):
${getEditableSections(role).join(', ') || 'None (view only)'}

INSTRUCTIONS:
1. Answer the user's question based on the project context
2. If the user asks you to edit a section you have permission to modify, respond with a special format:
   SECTION_UPDATE: {sectionName}
   CONTENT:
   {new content here}
   END_SECTION_UPDATE
3. Be concise but helpful
4. Stay in character as a ${role}

USER QUESTION:
${userMessage}

RESPONSE:`;

  try {
    const aiResponse = await callBedrock(fullPrompt, files);
    
    // Check if response contains a section update
    const sectionUpdateMatch = aiResponse.match(/SECTION_UPDATE:\s*(\w+)\s*CONTENT:\s*([\s\S]*?)\s*END_SECTION_UPDATE/);
    
    if (sectionUpdateMatch) {
      const sectionName = sectionUpdateMatch[1];
      const content = sectionUpdateMatch[2].trim();
      
      // SECURITY: Validate section name against whitelist
      if (!validSectionNames.includes(sectionName)) {
        return {
          message: `Invalid section name "${sectionName}". Valid sections are: ${validSectionNames.join(', ')}`,
        };
      }
      
      // SECURITY: Verify permission using same logic as PATCH endpoint
      if (!canEditSection(sectionName, role)) {
        return {
          message: `I don't have permission to edit the "${sectionName}" section. As a ${role}, I can only edit: ${getEditableSections(role).join(', ')}`,
        };
      }
      
      // Update the section using validated field name
      await storage.updateProject(projectId, { [sectionName]: content });
      
      // Return message without the section update syntax
      const cleanMessage = aiResponse.replace(/SECTION_UPDATE:[\s\S]*?END_SECTION_UPDATE/, '').trim()
        || `I've updated the ${sectionName} section as requested.`;
      
      return {
        message: cleanMessage,
        sectionUpdate: {
          sectionName,
          content,
        },
      };
    }
    
    return { message: aiResponse };
  } catch (error: any) {
    console.error("Agent processing error:", error);
    throw new Error(`Failed to process message: ${error.message}`);
  }
}

function buildProjectContext(project: Project, latestIteration: any): string {
  let context = `Project Name: ${project.name}
Description: ${project.description || 'No description'}

SECTIONS:`;

  if (project.businessOverview) {
    context += `\n\nBusiness Overview:\n${project.businessOverview}`;
  }
  if (project.functionalRequirements) {
    context += `\n\nFunctional Requirements:\n${project.functionalRequirements}`;
  }
  if (project.nonFunctionalRequirements) {
    context += `\n\nNon-Functional Requirements:\n${project.nonFunctionalRequirements}`;
  }
  if (project.architectureDocs) {
    context += `\n\nArchitecture Documentation:\n${project.architectureDocs}`;
  }
  if (project.developmentDocs) {
    context += `\n\nDevelopment Documentation:\n${project.developmentDocs}`;
  }

  if (latestIteration) {
    context += `\n\nLATEST GENERATED ARTIFACTS (Version ${latestIteration.version}):`;
    
    if (latestIteration.artifacts) {
      const artifacts = latestIteration.artifacts;
      
      if (artifacts.userStories && artifacts.userStories.length > 0) {
        context += `\n\nUser Stories (${artifacts.userStories.length} total):`;
        artifacts.userStories.slice(0, 3).forEach((story: any) => {
          context += `\n- ${story.title}: ${story.description}`;
        });
      }
      
      if (artifacts.tasks && artifacts.tasks.length > 0) {
        context += `\n\nTasks (${artifacts.tasks.length} total):`;
        artifacts.tasks.slice(0, 5).forEach((task: any) => {
          context += `\n- [${task.role}] ${task.task} (${task.status})`;
        });
      }
    }
  }

  return context;
}

function getEditableSections(role: CollaboratorRole): string[] {
  const editableSections: string[] = [];
  
  for (const [section, allowedRoles] of Object.entries(sectionPermissions)) {
    if (allowedRoles.includes(role)) {
      editableSections.push(section);
    }
  }
  
  return editableSections;
}

function canEditSection(sectionName: string, role: CollaboratorRole): boolean {
  const allowedRoles = sectionPermissions[sectionName];
  return allowedRoles ? allowedRoles.includes(role) : false;
}
