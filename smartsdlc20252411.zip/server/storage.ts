// Database storage implementation for SmartSDLC
// Reference: blueprint:javascript_database + blueprint:javascript_log_in_with_replit

import { randomUUID } from "crypto";
import { eq, and, or, desc, isNull, gt } from "drizzle-orm";
import { db } from "./db";
import {
  users,
  projects,
  collaborators,
  iterations,
  adminOverrides,
  eventLogs,
  sprints,
  stories,
  type User,
  type UpsertUser,
  type Project,
  type InsertProject,
  type Collaborator,
  type InsertCollaborator,
  type IterationDB,
  type InsertIteration,
  type AdminOverride,
  type InsertAdminOverride,
  type EventLog,
  type InsertEventLog,
  type SDLCArtifacts,
  type DiffEntry,
  type Iteration,
  type CollaboratorRole,
  type Sprint,
  type InsertSprint,
  type Story,
  type InsertStory,
} from "@shared/schema";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Project operations
  getUserProjects(userId: string): Promise<Project[]>;
  getProject(projectId: string): Promise<Project | undefined>;
  createProject(name: string, description: string | null, ownerId: string): Promise<Project>;
  updateProject(projectId: string, data: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(projectId: string): Promise<void>;
  
  // Collaborator operations
  addCollaborator(projectId: string, userId: string, role: CollaboratorRole): Promise<Collaborator>;
  removeCollaborator(projectId: string, userId: string): Promise<void>;
  getProjectCollaborators(projectId: string): Promise<(Collaborator & { user: User })[]>;
  getUserRole(projectId: string, userId: string): Promise<CollaboratorRole | null>;
  
  // Iteration operations
  getProjectIterations(projectId: string): Promise<Iteration[]>;
  addIteration(projectId: string, requirements: string, artifacts: SDLCArtifacts, diff?: DiffEntry[]): Promise<Iteration>;
  getIteration(iterationId: string): Promise<Iteration | undefined>;
  
  // Admin override operations (MVP simulated SSO)
  createAdminOverride(data: Omit<InsertAdminOverride, 'id' | 'createdAt'>): Promise<AdminOverride>;
  getAdminOverride(userId: string): Promise<AdminOverride | undefined>;
  getAdminOverrides(): Promise<AdminOverride[]>;
  deleteAdminOverride(userId: string): Promise<void>;
  
  // Event logging operations
  logEvent(data: Omit<InsertEventLog, 'id' | 'createdAt'>): Promise<EventLog>;
  getEventLogs(filters?: { userId?: string; action?: string; limit?: number }): Promise<EventLog[]>;
  
  // Sprint operations
  getProjectSprints(projectId: string): Promise<Sprint[]>;
  getActiveSprint(projectId: string): Promise<Sprint | undefined>;
  createSprint(data: Omit<InsertSprint, 'id' | 'createdAt' | 'updatedAt'>): Promise<Sprint>;
  updateSprint(sprintId: string, updates: { 
    name?: string;
    startDate?: Date;
    endDate?: Date;
    sprintLengthDays?: number;
    status?: "planning" | "active" | "completed" | "archived";
    goal?: string | null;
    retrospective?: any;
  }): Promise<Sprint | undefined>;
  
  // Story operations
  getProjectStories(projectId: string): Promise<Story[]>;
  getSprintStories(sprintId: string): Promise<Story[]>;
  createStory(data: Omit<InsertStory, 'id' | 'createdAt' | 'updatedAt'>): Promise<Story>;
  updateStory(storyId: string, updates: {
    sprintId?: string | null;
    title?: string;
    description?: string | null;
    status?: "backlog" | "todo" | "in_progress" | "in_review" | "done" | "blocked";
    priority?: string;
    storyPoints?: number | null;
    assignedTo?: string | null;
    linkedStories?: string[];
    acceptanceCriteria?: string[];
  }): Promise<Story | undefined>;
  deleteStory(storyId: string): Promise<void>;
  
  // Sprint helpers (idempotent bootstrapping)
  ensureSprintZero(projectId: string): Promise<{ sprint: Sprint; created: boolean }>;
  seedSampleStories(projectId: string, sprintId: string): Promise<Story[]>;
}

export class DatabaseStorage implements IStorage {
  // ============================================
  // USER OPERATIONS (Replit Auth required)
  // ============================================
  
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // ============================================
  // PROJECT OPERATIONS
  // ============================================
  
  async getUserProjects(userId: string): Promise<Project[]> {
    // Get projects where user is owner OR collaborator
    const ownedProjects = await db
      .select()
      .from(projects)
      .where(eq(projects.ownerId, userId))
      .orderBy(desc(projects.updatedAt));

    const collaboratedProjectsData = await db
      .select()
      .from(collaborators)
      .innerJoin(projects, eq(collaborators.projectId, projects.id))
      .where(eq(collaborators.userId, userId))
      .orderBy(desc(projects.updatedAt));
    
    const collaboratedProjects = collaboratedProjectsData.map(row => row.projects);

    // Merge and deduplicate
    const allProjects = [...ownedProjects, ...collaboratedProjects];
    const uniqueProjects = Array.from(
      new Map(allProjects.map(p => [p.id, p])).values()
    );
    
    return uniqueProjects;
  }

  async getProject(projectId: string): Promise<Project | undefined> {
    const [project] = await db
      .select()
      .from(projects)
      .where(eq(projects.id, projectId));
    return project;
  }

  async createProject(name: string, description: string | null, ownerId: string): Promise<Project> {
    // Use transaction to ensure atomicity of project creation, collaborator addition, and Sprint 0 creation
    return await db.transaction(async (tx) => {
      // Create project
      const [project] = await tx
        .insert(projects)
        .values({
          id: randomUUID(),
          name,
          description,
          ownerId,
          currentVersion: 0,
        })
        .returning();
      
      // Automatically add owner as collaborator with Owner role
      await tx
        .insert(collaborators)
        .values({
          id: randomUUID(),
          projectId: project.id,
          userId: ownerId,
          role: "Owner",
        });
      
      // Auto-create Sprint 0 (initial sprint for project setup)
      const now = new Date();
      const sprintEndDate = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000); // 14 days from now
      
      await tx
        .insert(sprints)
        .values({
          id: randomUUID(),
          projectId: project.id,
          name: "Sprint 0",
          sprintNumber: 0,
          startDate: now,
          endDate: sprintEndDate,
          sprintLengthDays: 14,
          status: "active",
          goal: "Initial project setup and planning",
        });
      
      return project;
    });
  }

  async updateProject(projectId: string, data: Partial<InsertProject>): Promise<Project | undefined> {
    const [project] = await db
      .update(projects)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(projects.id, projectId))
      .returning();
    return project;
  }

  async deleteProject(projectId: string): Promise<void> {
    await db.delete(projects).where(eq(projects.id, projectId));
    // Cascade deletes will handle collaborators and iterations
  }

  // ============================================
  // COLLABORATOR OPERATIONS
  // ============================================
  
  async addCollaborator(projectId: string, userId: string, role: CollaboratorRole): Promise<Collaborator> {
    const [collaborator] = await db
      .insert(collaborators)
      .values({
        id: randomUUID(),
        projectId,
        userId,
        role,
      })
      .onConflictDoUpdate({
        target: [collaborators.projectId, collaborators.userId],
        set: { role },
      })
      .returning();
    return collaborator;
  }

  async removeCollaborator(projectId: string, userId: string): Promise<void> {
    await db
      .delete(collaborators)
      .where(
        and(
          eq(collaborators.projectId, projectId),
          eq(collaborators.userId, userId)
        )
      );
  }

  async getProjectCollaborators(projectId: string): Promise<(Collaborator & { user: User })[]> {
    const result = await db
      .select({
        id: collaborators.id,
        projectId: collaborators.projectId,
        userId: collaborators.userId,
        role: collaborators.role,
        addedAt: collaborators.addedAt,
        user: users,
      })
      .from(collaborators)
      .innerJoin(users, eq(collaborators.userId, users.id))
      .where(eq(collaborators.projectId, projectId));
    
    return result;
  }

  async getUserRole(projectId: string, userId: string): Promise<CollaboratorRole | null> {
    const [collaborator] = await db
      .select()
      .from(collaborators)
      .where(
        and(
          eq(collaborators.projectId, projectId),
          eq(collaborators.userId, userId)
        )
      );
    
    return collaborator?.role as CollaboratorRole | null;
  }

  // ============================================
  // ITERATION OPERATIONS
  // ============================================
  
  async getProjectIterations(projectId: string): Promise<Iteration[]> {
    const dbIterations = await db
      .select()
      .from(iterations)
      .where(eq(iterations.projectId, projectId))
      .orderBy(iterations.version);
    
    // Convert database iterations to schema format
    return dbIterations.map(iter => ({
      id: iter.id,
      version: iter.version,
      requirements: iter.requirements,
      artifacts: iter.artifacts as SDLCArtifacts,
      diff: (iter.diff as DiffEntry[]) || [],
      timestamp: iter.createdAt?.toISOString() || new Date().toISOString(),
    }));
  }

  async addIteration(
    projectId: string,
    requirements: string,
    artifacts: SDLCArtifacts,
    diff?: DiffEntry[]
  ): Promise<Iteration> {
    // Get current version from project
    const project = await this.getProject(projectId);
    if (!project) {
      throw new Error("Project not found");
    }
    
    const newVersion = project.currentVersion + 1;
    
    // Create iteration
    const [dbIteration] = await db
      .insert(iterations)
      .values({
        id: randomUUID(),
        projectId,
        version: newVersion,
        requirements,
        artifacts: artifacts as any, // JSONB type
        diff: diff as any, // JSONB type
      })
      .returning();
    
    // Update project's current version
    await this.updateProject(projectId, { currentVersion: newVersion });
    
    // Convert to schema format
    return {
      id: dbIteration.id,
      version: dbIteration.version,
      requirements: dbIteration.requirements,
      artifacts: dbIteration.artifacts as SDLCArtifacts,
      diff: (dbIteration.diff as DiffEntry[]) || [],
      timestamp: dbIteration.createdAt?.toISOString() || new Date().toISOString(),
    };
  }

  async getIteration(iterationId: string): Promise<Iteration | undefined> {
    const [dbIteration] = await db
      .select()
      .from(iterations)
      .where(eq(iterations.id, iterationId));
    
    if (!dbIteration) {
      return undefined;
    }
    
    return {
      id: dbIteration.id,
      version: dbIteration.version,
      requirements: dbIteration.requirements,
      artifacts: dbIteration.artifacts as SDLCArtifacts,
      diff: (dbIteration.diff as DiffEntry[]) || [],
      timestamp: dbIteration.createdAt?.toISOString() || new Date().toISOString(),
    };
  }

  // ============================================
  // ADMIN OVERRIDE OPERATIONS (MVP Simulated SSO)
  // ============================================

  async createAdminOverride(data: Omit<InsertAdminOverride, 'id' | 'createdAt'>): Promise<AdminOverride> {
    const [override] = await db
      .insert(adminOverrides)
      .values({
        id: randomUUID(),
        ...data,
      })
      .onConflictDoUpdate({
        target: adminOverrides.userId,
        set: {
          role: data.role,
          reason: data.reason,
          expiresAt: data.expiresAt,
          createdBy: data.createdBy,
          createdAt: new Date(),
        },
      })
      .returning();
    return override;
  }

  async getAdminOverride(userId: string): Promise<AdminOverride | undefined> {
    const now = new Date();
    const [override] = await db
      .select()
      .from(adminOverrides)
      .where(and(
        eq(adminOverrides.userId, userId),
        or(
          isNull(adminOverrides.expiresAt),
          gt(adminOverrides.expiresAt, now)
        )
      ));
    
    return override;
  }

  async getAdminOverrides(): Promise<AdminOverride[]> {
    return await db
      .select()
      .from(adminOverrides)
      .orderBy(desc(adminOverrides.createdAt));
  }

  async deleteAdminOverride(userId: string): Promise<void> {
    await db.delete(adminOverrides).where(eq(adminOverrides.userId, userId));
  }

  // ============================================
  // EVENT LOGGING OPERATIONS
  // ============================================

  async logEvent(data: Omit<InsertEventLog, 'id' | 'createdAt'>): Promise<EventLog> {
    const [event] = await db
      .insert(eventLogs)
      .values({
        id: randomUUID(),
        ...data,
      })
      .returning();
    return event;
  }

  async getEventLogs(filters?: { userId?: string; action?: string; limit?: number }): Promise<EventLog[]> {
    // Build WHERE conditions array
    const conditions = [];
    
    if (filters?.userId) {
      conditions.push(eq(eventLogs.userId, filters.userId));
    }
    
    if (filters?.action) {
      conditions.push(eq(eventLogs.action, filters.action));
    }
    
    // Build query with combined conditions
    let query = db
      .select()
      .from(eventLogs)
      .orderBy(desc(eventLogs.createdAt));
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }
    
    if (filters?.limit) {
      query = query.limit(filters.limit) as any;
    }
    
    return await query;
  }

  // ============================================
  // SPRINT OPERATIONS
  // ============================================

  async getProjectSprints(projectId: string): Promise<Sprint[]> {
    return await db
      .select()
      .from(sprints)
      .where(eq(sprints.projectId, projectId))
      .orderBy(sprints.sprintNumber);
  }

  async getActiveSprint(projectId: string): Promise<Sprint | undefined> {
    const [sprint] = await db
      .select()
      .from(sprints)
      .where(
        and(
          eq(sprints.projectId, projectId),
          eq(sprints.status, "active")
        )
      );
    return sprint;
  }

  async createSprint(data: Omit<InsertSprint, 'id' | 'createdAt' | 'updatedAt'>): Promise<Sprint> {
    // CRITICAL: Check for existing active sprint before creating new one
    if (data.status === 'active') {
      const existingActiveSprint = await this.getActiveSprint(data.projectId);
      if (existingActiveSprint) {
        throw new Error(`Project ${data.projectId} already has an active sprint (ID: ${existingActiveSprint.id}). Complete or archive it before creating a new active sprint.`);
      }
    }
    
    const [sprint] = await db
      .insert(sprints)
      .values({
        id: randomUUID(),
        ...data,
      })
      .returning();
    return sprint;
  }

  async updateSprint(sprintId: string, updates: { 
    name?: string;
    startDate?: Date;
    endDate?: Date;
    sprintLengthDays?: number;
    status?: "planning" | "active" | "completed" | "archived";
    goal?: string | null;
    retrospective?: any;
  }): Promise<Sprint | undefined> {
    // Fetch current sprint to get projectId
    const [currentSprint] = await db.select().from(sprints).where(eq(sprints.id, sprintId)).limit(1);
    if (!currentSprint) {
      throw new Error(`Sprint ${sprintId} not found`);
    }
    
    // If changing to active status, verify no other active sprint exists in this project
    if (updates.status === 'active') {
      const existingActiveSprint = await this.getActiveSprint(currentSprint.projectId);
      if (existingActiveSprint && existingActiveSprint.id !== sprintId) {
        throw new Error(`Cannot activate sprint ${sprintId}: project ${currentSprint.projectId} already has an active sprint (ID: ${existingActiveSprint.id})`);
      }
    }
    
    const [updatedSprint] = await db
      .update(sprints)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(sprints.id, sprintId))
      .returning();
    return updatedSprint;
  }

  // ============================================
  // STORY OPERATIONS
  // ============================================

  async getProjectStories(projectId: string): Promise<Story[]> {
    return await db
      .select()
      .from(stories)
      .where(eq(stories.projectId, projectId))
      .orderBy(desc(stories.createdAt));
  }

  async getSprintStories(sprintId: string): Promise<Story[]> {
    return await db
      .select()
      .from(stories)
      .where(eq(stories.sprintId, sprintId))
      .orderBy(stories.status, desc(stories.createdAt));
  }

  async createStory(data: Omit<InsertStory, 'id' | 'createdAt' | 'updatedAt'>): Promise<Story> {
    const [story] = await db
      .insert(stories)
      .values({
        id: randomUUID(),
        ...data,
      })
      .returning();
    return story;
  }

  async updateStory(storyId: string, updates: {
    sprintId?: string | null;
    title?: string;
    description?: string | null;
    status?: "backlog" | "todo" | "in_progress" | "in_review" | "done" | "blocked";
    priority?: string;
    storyPoints?: number | null;
    assignedTo?: string | null;
    linkedStories?: string[];
    acceptanceCriteria?: string[];
  }): Promise<Story | undefined> {
    // Validate sprint belongs to same project if changing sprintId
    if (updates.sprintId !== undefined && updates.sprintId !== null) {
      // Fetch current story to get projectId
      const [currentStory] = await db.select().from(stories).where(eq(stories.id, storyId)).limit(1);
      if (currentStory) {
        // Fetch target sprint to verify it belongs to same project
        const [targetSprint] = await db.select().from(sprints).where(eq(sprints.id, updates.sprintId)).limit(1);
        if (!targetSprint) {
          throw new Error(`Sprint ${updates.sprintId} not found`);
        }
        if (targetSprint.projectId !== currentStory.projectId) {
          throw new Error(`Cannot assign story to sprint from different project. Story project: ${currentStory.projectId}, Sprint project: ${targetSprint.projectId}`);
        }
      }
    }
    
    const [story] = await db
      .update(stories)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(stories.id, storyId))
      .returning();
    return story;
  }

  async deleteStory(storyId: string): Promise<void> {
    await db.delete(stories).where(eq(stories.id, storyId));
  }

  // ============================================
  // SPRINT HELPERS (Idempotent bootstrapping)
  // ============================================

  async ensureSprintZero(projectId: string): Promise<{ sprint: Sprint; created: boolean }> {
    // Check if Sprint 0 already exists
    const [existingSprint] = await db
      .select()
      .from(sprints)
      .where(
        and(
          eq(sprints.projectId, projectId),
          eq(sprints.sprintNumber, 0)
        )
      )
      .limit(1);

    if (existingSprint) {
      return { sprint: existingSprint, created: false };
    }

    // Create Sprint 0
    const now = new Date();
    const sprintEndDate = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000);

    const [newSprint] = await db
      .insert(sprints)
      .values({
        id: randomUUID(),
        projectId,
        name: "Sprint 0",
        sprintNumber: 0,
        startDate: now,
        endDate: sprintEndDate,
        sprintLengthDays: 14,
        status: "active",
        goal: "Initial project setup and planning",
      })
      .returning();

    return { sprint: newSprint, created: true };
  }

  async seedSampleStories(projectId: string, sprintId: string): Promise<Story[]> {
    // Story templates with deterministic IDs for idempotency
    const storyTemplates = [
      {
        slug: "sprint0-setup-ba",
        title: "Define Business Requirements",
        description: "Document functional and non-functional requirements for the project",
        priority: "high",
        storyPoints: 5,
        rolePreference: "Business Analyst",
      },
      {
        slug: "sprint0-setup-arch",
        title: "Design System Architecture",
        description: "Create architecture diagrams and define technical stack",
        priority: "high",
        storyPoints: 8,
        rolePreference: "Architect",
      },
      {
        slug: "sprint0-setup-dev",
        title: "Setup Development Environment",
        description: "Initialize repository, configure build tools, and setup CI/CD pipeline",
        priority: "medium",
        storyPoints: 5,
        rolePreference: "Developer",
      },
      {
        slug: "sprint0-setup-qa",
        title: "Create Test Strategy",
        description: "Define testing approach, tools, and initial test cases",
        priority: "medium",
        storyPoints: 3,
        rolePreference: "QA/SDET",
      },
      {
        slug: "sprint0-setup-devops",
        title: "Configure Infrastructure",
        description: "Setup cloud resources, monitoring, and deployment pipelines",
        priority: "medium",
        storyPoints: 5,
        rolePreference: "DevOps/Platform",
      },
    ];

    // Get project collaborators
    const projectCollaborators = await db
      .select()
      .from(collaborators)
      .where(eq(collaborators.projectId, projectId));

    // Get project to find owner
    const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);

    const createdStories: Story[] = [];

    for (const template of storyTemplates) {
      // Check if story with this slug already exists (idempotency)
      const [existingStory] = await db
        .select()
        .from(stories)
        .where(
          and(
            eq(stories.projectId, projectId),
            eq(stories.title, template.title)
          )
        )
        .limit(1);

      if (existingStory) {
        createdStories.push(existingStory);
        continue;
      }

      // Find a collaborator matching the role preference
      const matchingCollaborator = projectCollaborators.find(
        c => c.role === template.rolePreference
      );

      // Fallback to owner if no matching role found
      const assignee = matchingCollaborator?.userId || project?.ownerId || null;

      const [story] = await db
        .insert(stories)
        .values({
          id: randomUUID(),
          projectId,
          sprintId,
          title: template.title,
          description: template.description,
          status: "todo",
          priority: template.priority,
          storyPoints: template.storyPoints,
          assignedTo: assignee,
          linkedStories: [],
          acceptanceCriteria: [],
          createdBy: project?.ownerId || assignee || "",
        })
        .returning();

      createdStories.push(story);
    }

    return createdStories;
  }
}

export const storage = new DatabaseStorage();
