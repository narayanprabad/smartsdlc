// Simulated SSO for MVP Demo
// Reads from /devup/entitlements.json and resolves roles

import fs from 'fs';
import path from 'path';
import type { Express, RequestHandler } from 'express';
import session from 'express-session';
import MemoryStore from 'memorystore';
import { storage } from './storage';
import { createOverrideRequestSchema } from '../shared/schema';

interface DevUpUser {
  id: string;
  email: string;
  name: string;
  title: string;
  avatar: string;
  devup: {
    roles: string[];
    groups: string[];
    entitlements: string[];
  };
}

interface EntitlementsData {
  users: DevUpUser[];
  roleMapping: Record<string, string>;
}

let entitlementsData: EntitlementsData | null = null;

function loadEntitlements(): EntitlementsData {
  if (entitlementsData) return entitlementsData;
  
  const filePath = path.join(process.cwd(), 'devup', 'entitlements.json');
  const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  entitlementsData = data;
  return data;
}

function resolveRole(devupRoles: string[], roleMapping: Record<string, string>): string {
  // Map DevUp roles to application personas
  for (const role of devupRoles) {
    if (roleMapping[role]) {
      return roleMapping[role];
    }
  }
  return 'Business Analyst'; // Default fallback
}

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  
  // Use MemoryStore for MVP demo (simpler, no DB dependency)
  const Store = MemoryStore(session);
  const sessionStore = new Store({
    checkPeriod: 86400000, // Prune expired entries every 24h
  });
  
  const secret = process.env.SESSION_SECRET;
  if (!secret) {
    console.warn('⚠️  SESSION_SECRET not set, using fallback (NOT SECURE FOR PRODUCTION)');
  }
  
  return session({
    secret: secret || 'hackathon-demo-secret-change-in-production',
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: sessionTtl,
    },
  });
}

export async function setupSimulatedAuth(app: Express) {
  app.set('trust proxy', 1);
  app.use(getSession());
  
  // GET available users for login selection
  app.get('/api/auth/users', (req, res) => {
    const data = loadEntitlements();
    const users = data.users.map(u => ({
      id: u.id,
      email: u.email,
      name: u.name,
      title: u.title,
      avatar: u.avatar,
    }));
    res.json({ users });
  });
  
  // POST simulated login
  app.post('/api/auth/login-simulated', async (req: any, res) => {
    try {
      const { userId } = req.body;
      if (!userId) {
        res.status(400).json({ error: 'userId required' });
        return;
      }
      
      const data = loadEntitlements();
      const user = data.users.find(u => u.id === userId);
      
      if (!user) {
        res.status(404).json({ error: 'User not found' });
        return;
      }
      
      // Resolve primary role from entitlements
      const resolvedRole = resolveRole(user.devup.roles, data.roleMapping);
      
      // Check for admin override
      const override = await storage.getAdminOverride(user.id);
      const effectiveRole = override?.role || resolvedRole;
      const isAdmin = user.devup.roles.includes('admin');
      
      // Upsert user in database
      await storage.upsertUser({
        id: user.id,
        email: user.email,
        firstName: user.name.split(' ')[0],
        lastName: user.name.split(' ').slice(1).join(' '),
        profileImageUrl: user.avatar,
      });
      
      // Regenerate session for security
      await new Promise((resolve, reject) => {
        req.session.regenerate((err: any) => {
          if (err) reject(err);
          else resolve(true);
        });
      });
      
      // Store trusted data in session
      req.session.user = {
        id: user.id,
        email: user.email,
        name: user.name,
        title: user.title,
        avatar: user.avatar,
        roles: user.devup.roles,
        resolvedRole,
        effectiveRole,
        hasOverride: !!override,
        isAdmin, // Trusted server-side flag
      };
      
      // Log successful login
      await storage.logEvent({
        userId: user.id,
        action: 'user_login',
        payload: { resolvedRole, effectiveRole, hasOverride: !!override },
      });
      
      res.json({
        user: req.session.user,
        message: 'Login successful',
      });
    } catch (error: any) {
      console.error('Simulated login error:', error);
      res.status(500).json({ error: 'Login failed' });
    }
  });
  
  // GET current user (refresh override state)
  app.get('/api/auth/me', async (req: any, res) => {
    if (!req.session.user) {
      res.status(401).json({ error: 'Not authenticated' });
      return;
    }
    
    try {
      // Refresh effective role to honor new overrides
      const override = await storage.getAdminOverride(req.session.user.id);
      const effectiveRole = override?.role || req.session.user.resolvedRole;
      const hasOverride = !!override;
      
      // Update session if override state changed
      if (effectiveRole !== req.session.user.effectiveRole || hasOverride !== req.session.user.hasOverride) {
        req.session.user.effectiveRole = effectiveRole;
        req.session.user.hasOverride = hasOverride;
      }
      
      res.json({ user: req.session.user });
    } catch (error: any) {
      console.error('Get current user error:', error);
      res.status(500).json({ error: 'Failed to fetch user' });
    }
  });
  
  // POST logout
  app.post('/api/auth/logout', (req: any, res) => {
    req.session.destroy(() => {
      res.json({ message: 'Logged out successfully' });
    });
  });
  
  // Admin override endpoints
  app.post('/api/admin/override', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = req.session.user;
      
      // SECURITY: Check if user is admin using trusted server-side flag
      if (!currentUser.isAdmin) {
        res.status(403).json({ error: 'Admin access required' });
        return;
      }
      
      // Validate request payload
      const validation = createOverrideRequestSchema.safeParse(req.body);
      if (!validation.success) {
        res.status(400).json({ 
          error: 'Invalid request', 
          details: validation.error.errors 
        });
        return;
      }
      
      const { userId, forcedRole, reason, expiresAt } = validation.data;
      
      const override = await storage.createAdminOverride({
        userId,
        role: forcedRole,
        reason: reason || 'Admin override',
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        createdBy: currentUser.id,
      });
      
      // Log the override action
      await storage.logEvent({
        userId: currentUser.id,
        action: 'admin_override_created',
        payload: { targetUser: userId, forcedRole, reason },
      });
      
      res.json({ override, message: 'Role override applied' });
    } catch (error: any) {
      console.error('Admin override error:', error);
      res.status(500).json({ error: 'Failed to create override' });
    }
  });
  
  app.get('/api/admin/overrides', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = req.session.user;
      
      if (!currentUser.isAdmin) {
        res.status(403).json({ error: 'Admin access required' });
        return;
      }
      
      const overrides = await storage.getAdminOverrides();
      res.json({ overrides });
    } catch (error: any) {
      console.error('Get overrides error:', error);
      res.status(500).json({ error: 'Failed to fetch overrides' });
    }
  });
  
  app.delete('/api/admin/override/:userId', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = req.session.user;
      
      if (!currentUser.isAdmin) {
        res.status(403).json({ error: 'Admin access required' });
        return;
      }
      
      const { userId } = req.params;
      
      // Basic validation
      if (!userId || typeof userId !== 'string') {
        res.status(400).json({ error: 'Invalid user ID' });
        return;
      }
      
      // Check if override exists
      const existingOverride = await storage.getAdminOverride(userId);
      if (!existingOverride) {
        res.status(404).json({ error: 'Override not found' });
        return;
      }
      
      await storage.deleteAdminOverride(userId);
      
      // Log the removal
      await storage.logEvent({
        userId: currentUser.id,
        action: 'admin_override_removed',
        payload: { targetUser: userId },
      });
      
      res.json({ message: 'Override removed' });
    } catch (error: any) {
      console.error('Delete override error:', error);
      res.status(500).json({ error: 'Failed to delete override' });
    }
  });
  
  app.get('/api/admin/logs', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = req.session.user;
      
      if (!currentUser.isAdmin) {
        res.status(403).json({ error: 'Admin access required' });
        return;
      }
      
      const logs = await storage.getEventLogs();
      res.json({ logs });
    } catch (error: any) {
      console.error('Get logs error:', error);
      res.status(500).json({ error: 'Failed to fetch logs' });
    }
  });
}

export const isAuthenticated: RequestHandler = (req: any, res, next) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  next();
};
