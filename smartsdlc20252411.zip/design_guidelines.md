# SmartSDLC Design Guidelines

## Design Approach
**System-Based**: Drawing from Linear's clean efficiency, VS Code's code-centric patterns, and GitHub's familiar developer UI conventions. This utility-focused platform prioritizes information density, rapid scanning, and minimal cognitive load for technical users.

## Core Layout System

**Dual-Pane Architecture**
- Primary split: 40% input pane (left) / 60% output pane (right) with draggable divider
- Fixed header: 64px height containing logo, project name, and export actions
- Scrollable panes independently with synchronized scroll option toggle
- Collapsible left pane to maximize artifact viewing space

**Spacing Primitives**
- Use Tailwind units: 2, 3, 4, 6, 8, 12 for consistency
- Section padding: py-6 or py-8 for major containers
- Component gaps: gap-4 for related items, gap-8 for distinct sections
- Inline spacing: px-4 for horizontal padding, mx-2 for tight spacing

## Typography Hierarchy

**Font System**
- Primary: Inter (400, 500, 600 weights)
- Monospace: JetBrains Mono for code, diffs, and technical content

**Scale**
- H1 (Page Title): text-2xl font-semibold
- H2 (Section Headers): text-lg font-semibold
- H3 (Artifact Types): text-base font-medium
- Body: text-sm font-normal
- Caption/Meta: text-xs
- Code: text-sm font-mono

## Component Library

**Input Pane Components**

1. **Requirement Input Area**
   - Full-height textarea with line numbers
   - Floating placeholder: "Describe your business requirements..."
   - Character counter in bottom-right
   - Generate button: Fixed to bottom, full-width with subtle shadow

2. **Refinement Panel** (expandable)
   - Accordion-style below main input
   - Quick refinement suggestions as chips
   - Diff preview of pending changes

**Output Pane Components**

1. **Artifact Cards**
   - Stacked layout with 8px vertical spacing
   - Header: artifact type icon + title + collapse toggle
   - Content: structured lists with syntax highlighting for code blocks
   - Border-left accent (4px) to distinguish artifact types

2. **User Stories Display**
   - Checkbox + story title + description format
   - Expandable acceptance criteria (nested list, indented by 16px)
   - Effort estimate badge (top-right)

3. **Architecture Outline**
   - Tree-view structure with expand/collapse nodes
   - Monospace font for technical terms
   - Code snippets in subtle containers with copy button

4. **Task Breakdown**
   - Table layout: Role | Task | Effort | Status
   - Status indicators: small pill badges
   - Sortable columns

5. **Diff Viewer**
   - Side-by-side comparison for iterations
   - Line-by-line diff with +/- indicators
   - Summary stats at top: X added, Y modified, Z removed

**Navigation & Controls**

1. **Version Timeline** (horizontal strip below header)
   - Nodes: V0 → V1 → V2 with connecting lines
   - Current version highlighted
   - Click to switch between versions
   - Compact height: 48px

2. **Action Bar** (top-right header)
   - Export JSON button (ghost style)
   - Export Markdown button (ghost style)
   - Generate Test Cases button (primary)
   - Grouped with 2px spacing

**Feedback Elements**

1. **Loading States**
   - Skeleton screens matching artifact card structure
   - Pulsing animation for generating content
   - Progress indicator for multi-step generation

2. **Empty States**
   - Centered icon + message in output pane
   - "Get started" prompt with example requirement

3. **Toast Notifications**
   - Top-right corner, 4px from edge
   - Auto-dismiss after 4s
   - Success/error variants

## Code Display Patterns

**Syntax Highlighting Containers**
- Background: subtle contrast from main surface
- Padding: p-4
- Border-radius: rounded-md
- Font: JetBrains Mono
- Line numbers: text-xs, right-aligned, separate column

**Inline Code**
- Monospace font with subtle background
- Padding: px-2 py-1
- Slightly smaller than surrounding text

## Interaction Patterns

**Buttons**
- Primary: Solid background, medium weight text
- Ghost: Transparent with border, hover shows subtle background
- Sizes: Base (h-10 px-4), Large (h-12 px-6)
- Border-radius: rounded-lg

**Form Inputs**
- Height: h-10 for single-line, min-h-24 for textarea
- Border-radius: rounded-md
- Focus: 2px outline with offset
- Padding: px-3 py-2

**Interactive Lists**
- Hover: subtle background change
- Click target: minimum 40px height
- Selection: persistent highlight state

## Responsive Behavior

**Breakpoints**
- Desktop (default): Dual-pane side-by-side
- Tablet (< 1024px): Tabs to switch between input/output
- Mobile (< 768px): Stacked vertical layout, input always visible

**Pane Widths**
- Desktop: Draggable from 30%-70% to 70%-30%
- Tablet: Full-width tabs
- Mobile: Full-width stacked

## Data Visualization

**Effort Estimates**
- Badge format: "3d" for days, "2w" for weeks
- Size-based visual encoding for quick scanning

**Status Indicators**
- Compact pills: 4px height indicator bar + text label
- States: Not Started, In Progress, Completed, Blocked

**Change Markers**
- Added: subtle left border accent
- Modified: dotted left border
- Removed: struck-through text with reduced opacity

This developer-focused design prioritizes content density, rapid information access, and familiar patterns from modern dev tools. Every component serves the core workflow: business input → AI translation → engineering artifacts → iterative refinement.