import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Loader2, LogIn, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface MockUser {
  id: string;
  email: string;
  name: string;
  title: string;
  avatar: string;
}

export default function MockLogin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedUser, setSelectedUser] = useState<string | null>(null);

  // Fetch available users
  const { data: usersData, isLoading } = useQuery({
    queryKey: ['/api/auth/users'],
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest('POST', '/api/auth/login-simulated', { userId });
      return await res.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      toast({
        title: "Login successful",
        description: `Welcome, ${data.user.name}! Role: ${data.user.effectiveRole}`,
      });
      setLocation('/workspace');
    },
    onError: (error: any) => {
      toast({
        title: "Login failed",
        description: error.message || "Unable to login",
        variant: "destructive",
      });
    },
  });

  const handleLogin = (userId: string) => {
    setSelectedUser(userId);
    loginMutation.mutate(userId);
  };

  const users: MockUser[] = (usersData as any)?.users || [];

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-accent/5 p-4">
      <div className="w-full max-w-6xl">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Shield className="w-12 h-12 text-primary" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              SmartSDLC
            </h1>
          </div>
          <p className="text-xl text-muted-foreground">
            Role-Aware AI-Powered SDLC Workspace
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Simulated SSO Demo · Select a user to continue
          </p>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {users.map((user: MockUser) => (
              <Card
                key={user.id}
                className={`cursor-pointer transition-all hover-elevate active-elevate-2 ${
                  selectedUser === user.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => !loginMutation.isPending && handleLogin(user.id)}
                data-testid={`card-user-${user.id}`}
              >
                <CardHeader className="text-center pb-3">
                  <div className="flex justify-center mb-3">
                    <Avatar className="w-20 h-20 ring-2 ring-primary/20">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback>
                        {user.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  <CardTitle className="text-lg" data-testid={`text-name-${user.id}`}>
                    {user.name}
                  </CardTitle>
                  <CardDescription className="text-xs" data-testid={`text-title-${user.id}`}>
                    {user.title}
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center space-y-2">
                  <p className="text-xs text-muted-foreground truncate" data-testid={`text-email-${user.id}`}>
                    {user.email}
                  </p>
                  <Button
                    size="sm"
                    className="w-full"
                    disabled={loginMutation.isPending}
                    data-testid={`button-login-${user.id}`}
                  >
                    {loginMutation.isPending && selectedUser === user.id ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Logging in...
                      </>
                    ) : (
                      <>
                        <LogIn className="w-4 h-4 mr-2" />
                        Login as {user.name.split(' ')[0]}
                      </>
                    )}
                  </Button>
                  {user.id === 'admin_001' && (
                    <Badge variant="outline" className="w-full justify-center" data-testid="badge-admin">
                      <Shield className="w-3 h-3 mr-1" />
                      Admin Access
                    </Badge>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>
            This is a simulated SSO environment for demonstration purposes.
            <br />
            Users are loaded from <code className="bg-muted px-1 py-0.5 rounded">/devup/entitlements.json</code>
          </p>
        </div>
      </div>
    </div>
  );
}
