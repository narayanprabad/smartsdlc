import { useParams, Link } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ArrowLeft, Sparkles, RefreshCw, ChevronDown, ChevronRight } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { MermaidDiagram } from '@/components/MermaidDiagram';
import { DevelopmentTab } from '@/components/DevelopmentTab';
import type { SDLCArtifacts, ArchitectureDiagram } from '@shared/schema';

interface Project {
  id: string;
  name: string;
  description: string | null;
  ownerId: string;
  createdAt: string;
  updatedAt: string;
}

interface Iteration {
  id: string;
  version: number;
  requirements: string;
  artifacts: SDLCArtifacts;
  timestamp: string;
  diff?: any[];
}

interface ProjectData {
  project: Project;
  iterations: Iteration[];
  userRole: string;
}

export default function ProjectDetails() {
  const params = useParams();
  const projectId = params.id as string;
  const { toast } = useToast();
  const [requirements, setRequirements] = useState('');
  const [refinementPrompt, setRefinementPrompt] = useState('');

  const { data: projectData, isLoading } = useQuery<ProjectData>({
    queryKey: ['/api/projects', projectId],
  });

  const translateMutation = useMutation({
    mutationFn: async (requirements: string) => {
      const res = await apiRequest('POST', `/api/projects/${projectId}/translate`, { requirements });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId] });
      setRequirements('');
      toast({
        title: 'Artifacts generated',
        description: 'Your engineering artifacts have been created successfully.',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to generate artifacts',
        variant: 'destructive',
      });
    },
  });

  const refineMutation = useMutation({
    mutationFn: async (refinementPrompt: string) => {
      const res = await apiRequest('POST', `/api/projects/${projectId}/refine`, { refinementPrompt });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId] });
      setRefinementPrompt('');
      toast({
        title: 'Artifacts refined',
        description: 'Your artifacts have been updated successfully.',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to refine artifacts',
        variant: 'destructive',
      });
    },
  });

  const handleGenerate = () => {
    if (requirements.trim()) {
      translateMutation.mutate(requirements);
    }
  };

  const handleRefine = () => {
    if (refinementPrompt.trim()) {
      refineMutation.mutate(refinementPrompt);
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <Skeleton className="h-12 w-64" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  if (!projectData) {
    return (
      <div className="container mx-auto p-6">
        <Card className="p-12 text-center">
          <h2 className="text-xl font-semibold">Project not found</h2>
          <p className="text-muted-foreground mt-2">The project you're looking for doesn't exist.</p>
        </Card>
      </div>
    );
  }

  const { project, iterations, userRole } = projectData;
  const latestIteration = iterations[iterations.length - 1];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/projects">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold" data-testid="text-project-name">{project.name}</h1>
            <p className="text-muted-foreground">{project.description}</p>
          </div>
        </div>
        <Badge variant="outline" data-testid="badge-role">{userRole}</Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Generate Artifacts
          </CardTitle>
          <CardDescription>
            Describe your business requirements, and AI will generate comprehensive engineering artifacts
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Describe your requirements... (e.g., Build an e-commerce platform with user authentication, product catalog, shopping cart, and payment processing)"
            value={requirements}
            onChange={(e) => setRequirements(e.target.value)}
            className="min-h-32"
            data-testid="input-requirements"
          />
          <Button 
            onClick={handleGenerate} 
            disabled={!requirements.trim() || translateMutation.isPending}
            data-testid="button-generate"
          >
            {translateMutation.isPending ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Artifacts
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {latestIteration && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <RefreshCw className="h-5 w-5" />
                Refine Artifacts
              </CardTitle>
              <CardDescription>
                Request changes or additions to the existing artifacts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="What would you like to change or add? (e.g., Add real-time notifications using WebSockets)"
                value={refinementPrompt}
                onChange={(e) => setRefinementPrompt(e.target.value)}
                className="min-h-24"
                data-testid="input-refinement"
              />
              <Button 
                onClick={handleRefine} 
                disabled={!refinementPrompt.trim() || refineMutation.isPending}
                variant="outline"
                data-testid="button-refine"
              >
                {refineMutation.isPending ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Refining...
                  </>
                ) : (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Refine Artifacts
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <ArtifactsDisplay artifacts={latestIteration.artifacts} />
        </>
      )}
    </div>
  );
}

function ArtifactsDisplay({ artifacts }: { artifacts: SDLCArtifacts }) {
  return (
    <Tabs defaultValue="stories" className="w-full">
      <TabsList className="grid w-full grid-cols-6" data-testid="tabs-artifacts">
        <TabsTrigger value="stories">User Stories</TabsTrigger>
        <TabsTrigger value="requirements">Requirements</TabsTrigger>
        <TabsTrigger value="architecture">Architecture</TabsTrigger>
        <TabsTrigger value="diagrams">Diagrams</TabsTrigger>
        <TabsTrigger value="development">Development</TabsTrigger>
        <TabsTrigger value="tasks">Tasks</TabsTrigger>
      </TabsList>

      <TabsContent value="stories" className="space-y-4">
        {artifacts.userStories.map((story) => (
          <Card key={story.id} data-testid={`card-story-${story.id}`}>
            <CardHeader>
              <div className="flex items-start justify-between gap-2">
                <CardTitle className="text-lg">{story.title}</CardTitle>
                <div className="flex gap-2">
                  <Badge variant={story.priority === 'high' ? 'destructive' : story.priority === 'medium' ? 'default' : 'secondary'}>
                    {story.priority}
                  </Badge>
                  <Badge variant="outline">{story.effort}</Badge>
                </div>
              </div>
              <CardDescription>{story.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <h4 className="font-semibold mb-2">Acceptance Criteria:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm">
                {story.acceptanceCriteria.map((criteria, idx) => (
                  <li key={idx}>{criteria}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </TabsContent>

      <TabsContent value="requirements" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Functional Requirements</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside space-y-1">
              {artifacts.functionalRequirements.map((req, idx) => (
                <li key={idx}>{req}</li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Non-Functional Requirements</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {Object.entries(artifacts.nonFunctionalRequirements).map(([category, requirements]) => (
              <div key={category}>
                <h4 className="font-semibold capitalize mb-2">{category}</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  {requirements.map((req: string, idx: number) => (
                    <li key={idx}>{req}</li>
                  ))}
                </ul>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>AWS Well-Architected Framework</CardTitle>
            <CardDescription>Best practices aligned with AWS pillars</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {Object.entries(artifacts.wellArchitectedPillars).map(([pillar, principles]) => (
              <div key={pillar}>
                <h4 className="font-semibold capitalize mb-2">{pillar.replace(/([A-Z])/g, ' $1').trim()}</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  {principles.map((principle: string, idx: number) => (
                    <li key={idx}>{principle}</li>
                  ))}
                </ul>
              </div>
            ))}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="architecture" className="space-y-4">
        {artifacts.architectureOutline.map((component) => (
          <ArchitectureNode key={component.id} component={component} />
        ))}
      </TabsContent>

      <TabsContent value="diagrams" className="space-y-4">
        {artifacts.architectureDiagrams && artifacts.architectureDiagrams.length > 0 ? (
          artifacts.architectureDiagrams.map((diagram: ArchitectureDiagram) => (
            <MermaidDiagram 
              key={diagram.id}
              code={diagram.mermaidCode}
              title={diagram.name}
              description={diagram.description}
            />
          ))
        ) : (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground">No architecture diagrams available yet</p>
          </Card>
        )}
      </TabsContent>

      <TabsContent value="development" className="space-y-4">
        {artifacts.codeFiles && artifacts.codeFiles.length > 0 ? (
          <DevelopmentTab codeFiles={artifacts.codeFiles} />
        ) : (
          <Card>
            <CardContent className="py-12">
              <div className="text-center text-muted-foreground">
                <p>No development artifacts available yet.</p>
                <p className="text-sm mt-2">Code files will appear here once generated.</p>
              </div>
            </CardContent>
          </Card>
        )}
      </TabsContent>

      <TabsContent value="tasks" className="space-y-4">
        {artifacts.tasks.map((task) => (
          <Card key={task.id} data-testid={`card-task-${task.id}`}>
            <CardHeader>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <Badge variant="outline" className="mb-2">{task.role}</Badge>
                  <CardTitle className="text-base">{task.task}</CardTitle>
                </div>
                <div className="flex gap-2">
                  <Badge variant={
                    task.status === 'completed' ? 'default' :
                    task.status === 'in_progress' ? 'secondary' :
                    task.status === 'blocked' ? 'destructive' : 'outline'
                  }>
                    {task.status}
                  </Badge>
                  <Badge variant="outline">{task.effort}</Badge>
                </div>
              </div>
            </CardHeader>
          </Card>
        ))}
      </TabsContent>
    </Tabs>
  );
}

function ArchitectureNode({ component, depth = 0 }: { component: any; depth?: number }) {
  const [isOpen, setIsOpen] = useState(depth < 2);
  const hasChildren = component.children && component.children.length > 0;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card style={{ marginLeft: `${depth * 16}px` }}>
        <CardHeader>
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                {hasChildren && (
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                )}
                <CardTitle className="text-base">{component.name}</CardTitle>
              </div>
              <CardDescription className="mt-1">{component.description}</CardDescription>
            </div>
            <Badge variant="outline">{component.type}</Badge>
          </div>
        </CardHeader>
        {component.codeSnippet && (
          <CardContent>
            <pre className="bg-muted p-4 rounded-md overflow-x-auto text-sm">
              <code>{component.codeSnippet}</code>
            </pre>
          </CardContent>
        )}
      </Card>
      {hasChildren && (
        <CollapsibleContent className="space-y-2 mt-2">
          {component.children.map((child: any) => (
            <ArchitectureNode key={child.id} component={child} depth={depth + 1} />
          ))}
        </CollapsibleContent>
      )}
    </Collapsible>
  );
}
