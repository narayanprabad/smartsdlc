import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import { 
  Shield, 
  Clock, 
  User, 
  History,
  AlertCircle,
  CheckCircle,
  X,
  Plus,
  ArrowLeft
} from 'lucide-react';
import { useLocation } from 'wouter';
import { format } from 'date-fns';

const PERSONAS = [
  'Business Analyst',
  'Architect',
  'Developer',
  'QA/SDET',
  'DevOps/Platform',
  'Product Owner',
  'Support/SRE'
];

// Map display names to canonical role values (matches roleMapping in entitlements.json)
const PERSONA_TO_CANONICAL_ROLE: Record<string, string> = {
  'Business Analyst': 'Business Analyst',
  'Architect': 'Architect',
  'Developer': 'Developer',
  'QA/SDET': 'QA',                    // Canonical value for QA/SDET
  'DevOps/Platform': 'DevOps',        // Canonical value for DevOps/Platform
  'Product Owner': 'Product Owner',
  'Support/SRE': 'Support',           // Canonical value for Support/SRE
};

export default function AdminPanel() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  const [selectedUserId, setSelectedUserId] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [reason, setReason] = useState('');
  const [hours, setHours] = useState('24');

  // Fetch users for override selection
  const { data: usersData } = useQuery({
    queryKey: ['/api/auth/users'],
  });

  // Fetch active overrides
  const { data: overridesData, isLoading: overridesLoading } = useQuery({
    queryKey: ['/api/admin/overrides'],
    enabled: !!user?.isAdmin,
  });

  // Fetch event logs
  const { data: logsData, isLoading: logsLoading } = useQuery({
    queryKey: ['/api/admin/logs'],
    enabled: !!user?.isAdmin,
  });

  // Create override mutation
  const createOverrideMutation = useMutation({
    mutationFn: async (data: { userId: string; forcedRole: string; reason: string; expiresAt: string }) => {
      const res = await apiRequest('POST', '/api/admin/override', {
        userId: data.userId,
        forcedRole: data.forcedRole,
        reason: data.reason,
        expiresAt: data.expiresAt
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/overrides'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/logs'] });
      toast({
        title: "Override created",
        description: "Role override has been successfully applied",
      });
      setSelectedUserId('');
      setSelectedRole('');
      setReason('');
      setHours('24');
    },
    onError: (error: any) => {
      toast({
        title: "Override failed",
        description: error.message || "Unable to create role override",
        variant: "destructive",
      });
    },
  });

  // Delete override mutation
  const deleteOverrideMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest('DELETE', `/api/admin/override/${userId}`, {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/overrides'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/logs'] });
      toast({
        title: "Override removed",
        description: "Role override has been successfully removed",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Remove failed",
        description: error.message || "Unable to remove role override",
        variant: "destructive",
      });
    },
  });

  const handleCreateOverride = () => {
    if (!selectedUserId || !selectedRole) {
      toast({
        title: "Missing fields",
        description: "Please select a user and role",
        variant: "destructive",
      });
      return;
    }

    // Validate hours input (support decimal hours like 1.5, 0.5, etc.)
    const parsedHours = parseFloat(hours);
    if (!hours || isNaN(parsedHours) || parsedHours <= 0) {
      toast({
        title: "Invalid expiration",
        description: "Please enter a valid number of hours (minimum 0.1)",
        variant: "destructive",
      });
      return;
    }

    // Calculate expiration using decimal hours
    const expiresAt = new Date(Date.now() + parsedHours * 60 * 60 * 1000).toISOString();
    
    // Map display persona name to canonical role value
    const canonicalRole = PERSONA_TO_CANONICAL_ROLE[selectedRole] || selectedRole;
    
    const payload: any = {
      userId: selectedUserId,
      forcedRole: canonicalRole,  // Use canonical role value
      expiresAt,
    };
    
    // Only include reason if provided (server will apply default if omitted)
    if (reason) {
      payload.reason = reason;
    }
    
    createOverrideMutation.mutate(payload);
  };

  if (!user?.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-accent/5">
        <Card className="max-w-md">
          <CardHeader>
            <div className="flex items-center gap-2 text-destructive">
              <AlertCircle className="w-6 h-6" />
              <CardTitle>Access Denied</CardTitle>
            </div>
            <CardDescription>
              You don't have permission to access the admin panel
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => setLocation('/workspace')} className="w-full" data-testid="button-access-denied-back">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Workspace
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const users = (usersData as any)?.users || [];
  const overrides = (overridesData as any)?.overrides || [];
  const logs = (logsData as any)?.logs || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-primary" />
            <h1 className="text-2xl font-bold">Admin Panel</h1>
            <Badge variant="destructive">Admin Only</Badge>
          </div>
          
          <Button 
            variant="outline" 
            onClick={() => setLocation('/workspace')}
            data-testid="button-back-workspace"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Workspace
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Create Override Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Create Role Override
                </CardTitle>
                <CardDescription>
                  Temporarily override a user's role for testing or special scenarios
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="user-select" data-testid="label-override-user">User</Label>
                    <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                      <SelectTrigger id="user-select" data-testid="select-override-user">
                        <SelectValue placeholder="Select user" />
                      </SelectTrigger>
                      <SelectContent data-testid="content-override-user">
                        {users.map((u: any) => (
                          <SelectItem key={u.id} value={u.id} data-testid={`option-user-${u.id}`}>
                            {u.name} ({u.email})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="role-select" data-testid="label-override-role">Override Role</Label>
                    <Select value={selectedRole} onValueChange={setSelectedRole}>
                      <SelectTrigger id="role-select" data-testid="select-override-role">
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent data-testid="content-override-role">
                        {PERSONAS.map((role) => (
                          <SelectItem key={role} value={role} data-testid={`option-role-${role.toLowerCase().replace(/\//g, '-').replace(/\s+/g, '-')}`}>
                            {role}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reason" data-testid="label-override-reason">Reason</Label>
                  <Textarea
                    id="reason"
                    placeholder="Why is this override needed?"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="min-h-[80px]"
                    data-testid="input-override-reason"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="hours" data-testid="label-override-hours">Expiration (hours)</Label>
                  <Input
                    id="hours"
                    type="number"
                    value={hours}
                    onChange={(e) => setHours(e.target.value)}
                    min="1"
                    max="168"
                    data-testid="input-override-hours"
                  />
                </div>

                <Button 
                  onClick={handleCreateOverride}
                  disabled={createOverrideMutation.isPending}
                  className="w-full"
                  data-testid="button-create-override"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  {createOverrideMutation.isPending ? 'Creating...' : 'Create Override'}
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Active Overrides Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Active Overrides
                </CardTitle>
                <CardDescription>
                  Currently active role overrides with expiration times
                </CardDescription>
              </CardHeader>
              <CardContent>
                {overridesLoading ? (
                  <div className="text-center py-8 text-muted-foreground" data-testid="status-loading-overrides">
                    Loading overrides...
                  </div>
                ) : overrides.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground" data-testid="status-empty-overrides">
                    <CheckCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No active overrides</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Override Role</TableHead>
                        <TableHead>Reason</TableHead>
                        <TableHead>Expires</TableHead>
                        <TableHead>Created By</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {overrides.map((override: any) => {
                        const expiresAt = new Date(override.expiresAt);
                        const isExpired = expiresAt < new Date();
                        
                        return (
                          <TableRow key={override.userId} data-testid={`row-override-${override.userId}`}>
                            <TableCell className="font-medium" data-testid={`text-override-user-${override.userId}`}>{override.userName}</TableCell>
                            <TableCell data-testid={`cell-override-role-${override.userId}`}>
                              <Badge variant="secondary" data-testid={`badge-override-role-${override.userId}`}>{override.role}</Badge>
                            </TableCell>
                            <TableCell className="max-w-[200px] truncate" data-testid={`text-override-reason-${override.userId}`}>{override.reason}</TableCell>
                            <TableCell data-testid={`cell-override-expires-${override.userId}`}>
                              <div className="flex items-center gap-2">
                                <Clock className="w-3 h-3" />
                                <span className={isExpired ? 'text-destructive' : ''} data-testid={`text-override-expires-${override.userId}`}>
                                  {format(expiresAt, 'PPp')}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell data-testid={`text-override-createdby-${override.userId}`}>{override.createdByName}</TableCell>
                            <TableCell className="text-right" data-testid={`cell-override-actions-${override.userId}`}>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteOverrideMutation.mutate(override.userId)}
                                disabled={deleteOverrideMutation.isPending}
                                data-testid={`button-remove-override-${override.userId}`}
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Audit Log Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="w-5 h-5" />
                  Audit Log
                </CardTitle>
                <CardDescription>
                  Recent admin actions and events
                </CardDescription>
              </CardHeader>
              <CardContent>
                {logsLoading ? (
                  <div className="text-center py-8 text-muted-foreground" data-testid="status-loading-logs">
                    Loading audit logs...
                  </div>
                ) : logs.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground" data-testid="status-empty-logs">
                    <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No audit logs</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Time</TableHead>
                        <TableHead>User</TableHead>
                        <TableHead>Action</TableHead>
                        <TableHead>Details</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {logs.slice(0, 50).map((log: any, index: number) => (
                        <TableRow key={index} data-testid={`row-audit-log-${index}`}>
                          <TableCell className="text-sm text-muted-foreground" data-testid={`text-log-time-${index}`}>
                            {format(new Date(log.createdAt), 'PPp')}
                          </TableCell>
                          <TableCell className="font-medium" data-testid={`text-log-user-${index}`}>{log.userName}</TableCell>
                          <TableCell data-testid={`cell-log-action-${index}`}>
                            <Badge variant="outline" data-testid={`badge-log-action-${index}`}>{log.action}</Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground max-w-[300px] truncate" data-testid={`text-log-details-${index}`}>
                            {JSON.stringify(log.payload)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
