import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { LogIn } from 'lucide-react';

export default function Login() {
  const handleLogin = () => {
    window.location.href = '/api/login';
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-4 text-center">
          <div className="mx-auto w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-2xl font-bold text-primary-foreground">S</span>
          </div>
          <div>
            <CardTitle className="text-2xl">SmartSDLC</CardTitle>
            <CardDescription>
              AI-Powered SDLC Automation Platform
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2 text-center text-sm text-muted-foreground">
            <p>Transform business requirements into comprehensive engineering artifacts using AI</p>
            <ul className="text-left space-y-1 mt-4">
              <li>• Generate user stories and acceptance criteria</li>
              <li>• Create architecture diagrams and technical specifications</li>
              <li>• Collaborate with your team using role-based personas</li>
              <li>• Track project iterations and changes</li>
            </ul>
          </div>
          <Button 
            onClick={handleLogin} 
            className="w-full" 
            size="lg"
            data-testid="button-login"
          >
            <LogIn className="mr-2 h-5 w-5" />
            Sign in with SSO
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
