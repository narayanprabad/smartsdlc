import { useQuery } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface DebugData {
  prompt?: string;
  promptFile?: string;
  response?: any;
  responseFile?: string;
  responseStats?: {
    userStories: number;
    tasks: number;
    architectureDiagrams: number;
    architectureOutline: number;
    functionalRequirements: number;
    wellArchitectedPillars: string[];
  };
  error?: string;
}

export default function DebugPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['/api/debug/last-bedrock'],
  });

  const debugData = data as DebugData | undefined;

  if (isLoading) {
    return <div className="p-8">Loading...</div>;
  }

  if (!debugData || debugData.error) {
    return (
      <div className="p-8">
        <p className="text-muted-foreground">No Bedrock calls yet. Create a project first to see the prompt and response.</p>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6 max-w-6xl">
      <h1 className="text-3xl font-bold">Bedrock Debug Information</h1>
      
      {/* Prompt Section */}
      {debugData.prompt && (
        <Card className="p-6 space-y-3">
          <h2 className="text-2xl font-semibold">Prompt Sent to Bedrock</h2>
          <p className="text-xs text-muted-foreground">File: {debugData.promptFile}</p>
          <pre className="bg-muted p-4 rounded text-xs overflow-auto max-h-96 border">
            {debugData.prompt}
          </pre>
        </Card>
      )}

      {/* Response Stats */}
      {debugData.responseStats && (
        <Card className="p-6 space-y-4">
          <h2 className="text-2xl font-semibold">Bedrock Response Summary</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="border rounded p-3">
              <p className="text-sm text-muted-foreground">User Stories</p>
              <p className="text-2xl font-bold">{debugData.responseStats.userStories}</p>
            </div>
            <div className="border rounded p-3">
              <p className="text-sm text-muted-foreground">Tasks</p>
              <p className="text-2xl font-bold">{debugData.responseStats.tasks}</p>
            </div>
            <div className="border rounded p-3">
              <p className="text-sm text-muted-foreground">Architecture Diagrams</p>
              <p className="text-2xl font-bold">{debugData.responseStats.architectureDiagrams}</p>
            </div>
            <div className="border rounded p-3">
              <p className="text-sm text-muted-foreground">Components</p>
              <p className="text-2xl font-bold">{debugData.responseStats.architectureOutline}</p>
            </div>
            <div className="border rounded p-3">
              <p className="text-sm text-muted-foreground">Functional Requirements</p>
              <p className="text-2xl font-bold">{debugData.responseStats.functionalRequirements}</p>
            </div>
            <div className="border rounded p-3">
              <p className="text-sm text-muted-foreground">AWS Pillars</p>
              <div className="flex flex-wrap gap-1 mt-2">
                {debugData.responseStats.wellArchitectedPillars.map((pillar: string) => (
                  <Badge key={pillar} variant="outline" className="text-xs">
                    {pillar}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Full Response */}
      {debugData.response && (
        <Card className="p-6 space-y-3">
          <h2 className="text-2xl font-semibold">Complete JSON Response from Bedrock</h2>
          <p className="text-xs text-muted-foreground">File: {debugData.responseFile}</p>
          <pre className="bg-muted p-4 rounded text-xs overflow-auto max-h-96 border">
            {typeof debugData.response === 'string' ? debugData.response : JSON.stringify(debugData.response, null, 2)}
          </pre>
        </Card>
      )}
    </div>
  );
}
