import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, 
  Code, 
  GitBranch, 
  TestTube, 
  Server, 
  Users, 
  HeadphonesIcon,
  Sparkles,
  LogOut,
  Shield,
  Plus,
  FolderOpen,
  Loader2
} from 'lucide-react';
import { useLocation } from 'wouter';
import { ProjectDetail } from '@/components/project-detail';
import { WorkspaceAssistant } from '@/components/workspace-assistant';
import { Card as ImportedCard } from '@/components/ui/card';
import { FileUpload, type UploadedFile } from '@/components/file-upload';

const PERSONAS = [
  {
    id: 'business-analyst',
    name: 'Business Analyst',
    icon: FileText,
    color: 'text-blue-500',
    bgColor: 'bg-blue-500/10',
    description: 'Define requirements and user stories',
    actions: [
      'Generate User Stories with Acceptance Criteria',
      'Create Epic Breakdown',
      'Define Business Rules',
      'Write Functional Requirements'
    ]
  },
  {
    id: 'architect',
    name: 'Architect',
    icon: Code,
    color: 'text-purple-500',
    bgColor: 'bg-purple-500/10',
    description: 'Design system architecture and APIs',
    actions: [
      'Generate C4 Architecture Diagrams',
      'Create OpenAPI Specification',
      'Define System Components',
      'Design Data Models'
    ]
  },
  {
    id: 'developer',
    name: 'Developer',
    icon: GitBranch,
    color: 'text-green-500',
    bgColor: 'bg-green-500/10',
    description: 'Write code and implement features',
    actions: [
      'Generate Branch Name',
      'Create Code Skeleton',
      'Generate Unit Tests',
      'Create PR Template'
    ]
  },
  {
    id: 'qa-sdet',
    name: 'QA/SDET',
    icon: TestTube,
    color: 'text-orange-500',
    bgColor: 'bg-orange-500/10',
    description: 'Ensure quality and write test cases',
    actions: [
      'Generate Test Plan',
      'Create Test Cases',
      'Define Acceptance Tests',
      'Write E2E Test Scenarios'
    ]
  },
  {
    id: 'devops-platform',
    name: 'DevOps/Platform',
    icon: Server,
    color: 'text-cyan-500',
    bgColor: 'bg-cyan-500/10',
    description: 'Deploy and manage infrastructure',
    actions: [
      'Generate CI/CD Pipeline',
      'Create Terraform Config',
      'Define Deployment Strategy',
      'Setup Monitoring Alerts'
    ]
  },
  {
    id: 'product-owner',
    name: 'Product Owner',
    icon: Users,
    color: 'text-pink-500',
    bgColor: 'bg-pink-500/10',
    description: 'Prioritize backlog and define vision',
    actions: [
      'Create Product Roadmap',
      'Define Sprint Goals',
      'Prioritize User Stories',
      'Write Release Notes'
    ]
  },
  {
    id: 'support-sre',
    name: 'Support/SRE',
    icon: HeadphonesIcon,
    color: 'text-red-500',
    bgColor: 'bg-red-500/10',
    description: 'Monitor systems and support users',
    actions: [
      'Generate Runbook',
      'Create Incident Response Plan',
      'Define SLIs/SLOs',
      'Write Troubleshooting Guide'
    ]
  },
  {
    id: 'scrum-master',
    name: 'Scrum Master',
    icon: Users,
    color: 'text-amber-500',
    bgColor: 'bg-amber-500/10',
    description: 'Facilitate agile processes and remove blockers',
    actions: [
      'Plan Sprint',
      'Conduct Retrospective',
      'Track Sprint Progress',
      'Remove Team Blockers'
    ]
  }
];

export default function Workspace() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Derive activePersona directly from user's effectiveRole (always in sync, no stale closures)
  const getPersonaFromRole = (effectiveRole: string | undefined): string => {
    if (!effectiveRole) return PERSONAS[0].id;
    
    // Map both canonical values AND display names for backward compatibility
    const roleMap: Record<string, string> = {
      // Canonical values (from roleMapping in entitlements.json)
      'Business Analyst': 'business-analyst',
      'Architect': 'architect',
      'Developer': 'developer',
      'QA': 'qa-sdet',              // Canonical "QA" → persona
      'DevOps': 'devops-platform',  // Canonical "DevOps" → persona
      'Product Owner': 'product-owner',
      'Support': 'support-sre',     // Canonical "Support" → persona
      'Scrum Master': 'scrum-master',
      'Owner': 'business-analyst',  // Admin defaults to BA view
      
      // Display names (for backward compatibility with legacy overrides)
      'QA/SDET': 'qa-sdet',
      'DevOps/Platform': 'devops-platform',
      'Support/SRE': 'support-sre',
    };
    
    const persona = roleMap[effectiveRole];
    if (!persona) {
      console.warn(`[Workspace] Unknown effectiveRole: "${effectiveRole}", falling back to Business Analyst`);
    }
    return persona || PERSONAS[0].id;
  };
  
  // Derive activePersona from user.effectiveRole (reactive to override changes)
  const derivedPersona = getPersonaFromRole(user?.effectiveRole);
  
  // Allow manual tab switching, but default to derived persona
  const [manuallySelectedPersona, setManuallySelectedPersona] = useState<string | null>(null);
  const activePersona = manuallySelectedPersona || derivedPersona;
  
  // Reset manual selection when derived persona changes (e.g., override applied/removed)
  useEffect(() => {
    setManuallySelectedPersona(null);
  }, [derivedPersona]);
  
  const [prompt, setPrompt] = useState('');
  const [selectedProject, setSelectedProject] = useState<string>('new');
  const [attachedFiles, setAttachedFiles] = useState<UploadedFile[]>([]);
  const [isSeedingDemo, setIsSeedingDemo] = useState(false);

  // Fetch projects for the selector
  const { data: projectsData } = useQuery({
    queryKey: ['/api/projects'],
    enabled: !!user,
  });

  // Generate project with AI artifacts
  const generateProjectMutation = useMutation({
    mutationFn: async (data: { requirements: string; persona: string; userContext?: any; files?: UploadedFile[] }) => {
      const res = await apiRequest('POST', '/api/projects/generate', data);
      return await res.json();
    },
    onSuccess: async (data: any) => {
      try {
        setPrompt('');
        setAttachedFiles([]);
        
        // Extract project ID from response
        const projectId = data?.project?.id || data?.id;
        if (!projectId) {
          console.error('Failed to extract project ID from response:', data);
          throw new Error('Project ID not found in response');
        }
        
        toast({
          description: 'Project created successfully! Redirecting to project...',
        });
        
        // Refetch projects list and WAIT for completion before redirecting
        await queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
        const refetchResult = await queryClient.refetchQueries({ queryKey: ['/api/projects'] });
        
        // Small delay to ensure UI updates before switching view
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Update workspace state to show the newly created project
        // This triggers the conditional render at line 387 to show ProjectDetail
        setSelectedProject(projectId);
        
        console.log('✅ Project created and selected:', projectId);
      } catch (err: any) {
        console.error('Error processing project response:', err);
        toast({
          title: 'Error',
          description: 'Failed to display project: ' + (err.message || 'Unknown error'),
          variant: 'destructive',
        });
      }
    },
    onError: (error: any) => {
      console.error('Generation error:', error);
      toast({
        title: 'Generation Failed',
        description: error.message || 'Failed to generate project',
        variant: 'destructive',
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: 'Missing Requirements',
        description: 'Please enter your requirements first.',
        variant: 'destructive',
      });
      return;
    }
    generateProjectMutation.mutate({
      requirements: prompt,
      persona: activePersonaData.name,
      userContext: {
        userId: user?.id,
        userName: user?.name,
        userRole: user?.effectiveRole,
        userEmail: user?.email,
      },
      files: attachedFiles.length > 0 ? attachedFiles : undefined,
    });
  };

  const handleLogout = async () => {
    try {
      await apiRequest('POST', '/api/auth/logout', {});
      queryClient.clear();
      setLocation('/mock-login');
    } catch (error) {
      console.error('Logout failed:', error);
      setLocation('/mock-login');
    }
  };

  const handleSeedDemo = async () => {
    setIsSeedingDemo(true);
    try {
      toast({
        description: 'Creating demo project... This may take a few seconds.',
      });
      
      const response = await apiRequest('POST', '/api/seed-demo', {});
      const result: any = await response.json();
      
      // Invalidate and refetch projects list
      await queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      await queryClient.refetchQueries({ queryKey: ['/api/projects'] });
      
      // Navigate to the demo project
      if (result.projectId) {
        setSelectedProject(result.projectId);
        toast({
          description: '✅ Demo project ready! Viewing CFTC Clearing Platform.',
        });
      } else {
        toast({
          description: result.message || '✅ Demo project created successfully!',
        });
      }
    } catch (error: any) {
      console.error('Failed to seed demo:', error);
      toast({
        title: 'Error',
        description: `Failed to seed demo: ${error.message || 'Unknown error'}`,
        variant: 'destructive',
      });
    } finally {
      setIsSeedingDemo(false);
    }
  };

  const activePersonaData = PERSONAS.find(p => p.id === activePersona) || PERSONAS[0];
  const Icon = activePersonaData.icon;
  
  // API returns projects array directly, not wrapped in an object
  const projects = (projectsData as any) || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              <h1 className="text-2xl font-bold">SmartSDLC</h1>
            </div>
            <Badge variant="secondary">
              MVP Demo
            </Badge>
            
            {/* Project Selector */}
            <div className="flex items-center gap-2 ml-4">
              <FolderOpen className="w-4 h-4 text-muted-foreground" />
              <Select value={selectedProject} onValueChange={setSelectedProject}>
                <SelectTrigger className="w-[200px]" data-testid="select-project">
                  <SelectValue placeholder="Select project" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">
                    <div className="flex items-center gap-2">
                      <Plus className="w-3 h-3" />
                      <span>New Project</span>
                    </div>
                  </SelectItem>
                  {projects.map((project: any) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="text-right">
                <div className="text-sm font-medium">{user?.name}</div>
                <div className="text-xs text-muted-foreground">{user?.effectiveRole}</div>
              </div>
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="text-sm font-semibold text-primary">
                  {user?.name?.charAt(0)}
                </span>
              </div>
            </div>
            
            {user?.isAdmin && (
              <>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setLocation('/admin')}
                  data-testid="button-admin-panel"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Admin
                </Button>
                <Button 
                  variant="default" 
                  size="sm"
                  onClick={handleSeedDemo}
                  disabled={isSeedingDemo}
                  data-testid="button-seed-demo"
                >
                  {isSeedingDemo ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Seed Demo Project
                    </>
                  )}
                </Button>
              </>
            )}
            
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLogout}
              data-testid="button-logout"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Show Project Detail if project selected, otherwise show persona tabs */}
          {selectedProject && selectedProject !== 'new' ? (
            <ProjectDetail 
              projectId={selectedProject}
              userRole={user?.effectiveRole || ''}
              userName={user?.name || ''}
              userAvatar={user?.avatar}
            />
          ) : (
            <div className="flex flex-col lg:flex-row gap-6">
              {/* Main content area */}
              <div className="flex-1 min-w-0 lg:basis-[70%]">
              {/* Welcome Section */}
              <div className="mb-8">
                <h2 className="text-3xl font-bold mb-2">
                  Welcome to Your AI-Powered Workspace
                </h2>
                <p className="text-muted-foreground">
                  Select a role below and let AI generate role-specific artifacts for your SDLC
                </p>
              </div>

              {/* Role Tabs */}
              <Tabs value={activePersona} onValueChange={setManuallySelectedPersona} className="space-y-6">
            <TabsList className="w-full grid grid-cols-7 h-auto p-1 bg-card/50 backdrop-blur-sm">
              {PERSONAS.map((persona) => {
                const PersonaIcon = persona.icon;
                return (
                  <TabsTrigger
                    key={persona.id}
                    value={persona.id}
                    className="flex flex-col items-center gap-2 px-2 py-3 data-[state=active]:bg-background"
                    data-testid={`tab-${persona.id}`}
                  >
                    <PersonaIcon className={`w-5 h-5 ${persona.color}`} />
                    <span className="text-xs font-medium text-center leading-tight">
                      {persona.name}
                    </span>
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {/* Tab Content for Each Persona */}
            {PERSONAS.map((persona) => {
              const PersonaIcon = persona.icon;
              
              return (
                <TabsContent key={persona.id} value={persona.id}>
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className="space-y-6"
                  >
                      {/* Persona Header */}
                      <Card className={persona.bgColor}>
                    <CardHeader>
                      <div className="flex items-start gap-4">
                        <div className={`p-3 rounded-lg ${persona.bgColor}`}>
                          <PersonaIcon className={`w-8 h-8 ${persona.color}`} />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-2xl mb-1">{persona.name}</CardTitle>
                          <CardDescription className="text-base">
                            {persona.description}
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>

                  {/* Input Section */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-primary" />
                        Describe Your Requirements
                      </CardTitle>
                      <CardDescription>
                        Enter your project requirements and AI will generate {persona.name}-specific artifacts
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Textarea
                        placeholder={`Example: Build a task management system with user authentication, real-time updates, and mobile support...`}
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="min-h-[120px] resize-none"
                        data-testid="input-requirements"
                      />
                      <FileUpload
                        onFilesChange={setAttachedFiles}
                        maxFiles={5}
                        maxSizeMB={10}
                        disabled={generateProjectMutation.isPending}
                      />
                      <div className="flex gap-2">
                        <Button 
                          className="flex-1" 
                          size="lg"
                          onClick={handleGenerate}
                          disabled={!prompt.trim() || generateProjectMutation.isPending}
                          data-testid="button-generate"
                        >
                          {generateProjectMutation.isPending ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Creating Project...
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-4 h-4 mr-2" />
                              Create a Feature or Project
                            </>
                          )}
                        </Button>
                        <Button 
                          variant="outline" 
                          size="lg"
                          disabled={!prompt.trim()}
                          data-testid="button-clear"
                          onClick={() => setPrompt('')}
                        >
                          Clear
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Quick Actions */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Quick Actions</CardTitle>
                      <CardDescription>
                        Common {persona.name} tasks you can generate with AI
                      </CardDescription>
                    </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {persona.actions.map((action, index) => (
                              <Button
                                key={index}
                                variant="outline"
                                className="justify-start h-auto py-4 hover-elevate"
                                data-testid={`button-action-${persona.id}-${index}`}
                              >
                                <div className="text-left">
                                  <div className="font-medium">{action}</div>
                                  <div className="text-xs text-muted-foreground mt-1">
                                    Click to generate
                                  </div>
                                </div>
                              </Button>
                            ))}
                          </div>
                        </CardContent>
                      </Card>

                      {/* Placeholder for Generated Artifacts */}
                      <Card className="border-dashed">
                        <CardContent className="py-12">
                          <div className="text-center text-muted-foreground">
                            <PersonaIcon className={`w-12 h-12 mx-auto mb-4 ${persona.color}`} />
                            <p className="text-lg font-medium mb-2">No artifacts generated yet</p>
                            <p className="text-sm">
                              Enter requirements above and click "Generate" to see AI-powered {persona.name} artifacts
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                  </motion.div>
                </TabsContent>
              );
            })}
          </Tabs>
              </div>

              {/* AI Assistant Fixed Right Panel - Always Visible on create project page */}
              <div className="w-full lg:basis-[30%] lg:max-w-[500px] lg:min-w-[350px] flex-shrink-0">
                <Card className="sticky top-24 h-[calc(100vh-12rem)] overflow-hidden">
                  <WorkspaceAssistant />
                </Card>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
