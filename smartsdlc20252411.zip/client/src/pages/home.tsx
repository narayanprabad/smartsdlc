import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Download, FileJson, FileText, Sparkles } from "lucide-react";
import { RequirementInput } from "@/components/requirement-input";
import { ArtifactDisplay } from "@/components/artifact-display";
import { VersionTimeline } from "@/components/version-timeline";
import { ExportDialog } from "@/components/export-dialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { SDLCArtifacts, Iteration, ProjectState } from "@shared/schema";

export default function Home() {
  const [requirements, setRequirements] = useState("");
  const [refinementPrompt, setRefinementPrompt] = useState("");
  const [currentVersion, setCurrentVersion] = useState(0);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [exportFormat, setExportFormat] = useState<"json" | "markdown">("json");
  const { toast } = useToast();

  // Query project state
  const { data: projectState, isLoading: isLoadingState } = useQuery<ProjectState>({
    queryKey: ["/api/project"],
  });

  const currentIteration = projectState?.iterations[currentVersion];
  const hasArtifacts = currentIteration?.artifacts != null;

  // Translate mutation
  const translateMutation = useMutation({
    mutationFn: async (req: string) => {
      return apiRequest("POST", "/api/translate", { requirements: req });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/project"] });
      setCurrentVersion(projectState?.iterations.length || 0);
      toast({
        title: "Artifacts Generated",
        description: "Your requirements have been translated into engineering artifacts.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Refine mutation
  const refineMutation = useMutation({
    mutationFn: async (prompt: string) => {
      if (!currentIteration) throw new Error("No artifacts to refine");
      return apiRequest("POST", "/api/refine", {
        currentArtifacts: currentIteration.artifacts,
        refinementPrompt: prompt,
        previousRequirements: currentIteration.requirements,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/project"] });
      setCurrentVersion((projectState?.iterations.length || 0));
      setRefinementPrompt("");
      toast({
        title: "Artifacts Refined",
        description: "Your artifacts have been updated based on your refinement.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Refinement Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!requirements.trim()) {
      toast({
        title: "Missing Requirements",
        description: "Please enter your business requirements first.",
        variant: "destructive",
      });
      return;
    }
    translateMutation.mutate(requirements);
  };

  const handleRefine = () => {
    if (!refinementPrompt.trim()) {
      toast({
        title: "Missing Refinement",
        description: "Please enter your refinement prompt.",
        variant: "destructive",
      });
      return;
    }
    refineMutation.mutate(refinementPrompt);
  };

  const handleExport = async (format: "json" | "markdown") => {
    setExportFormat(format);
    setShowExportDialog(true);
  };

  const isGenerating = translateMutation.isPending || refineMutation.isPending;

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Header */}
      <header className="h-16 border-b flex items-center justify-between px-6 bg-card">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-foreground">SmartSDLC</h1>
            <p className="text-xs text-muted-foreground">AI-Powered SDLC Automation</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleExport("json")}
            disabled={!hasArtifacts}
            data-testid="button-export-json"
          >
            <FileJson className="w-4 h-4 mr-2" />
            Export JSON
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleExport("markdown")}
            disabled={!hasArtifacts}
            data-testid="button-export-markdown"
          >
            <FileText className="w-4 h-4 mr-2" />
            Export Markdown
          </Button>
        </div>
      </header>

      {/* Version Timeline */}
      {projectState && projectState.iterations.length > 0 && (
        <>
          <VersionTimeline
            iterations={projectState.iterations}
            currentVersion={currentVersion}
            onVersionChange={setCurrentVersion}
          />
          <Separator />
        </>
      )}

      {/* Main Content - Dual Pane */}
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal">
          {/* Left Pane - Input */}
          <ResizablePanel defaultSize={40} minSize={30} maxSize={70}>
            <RequirementInput
              requirements={requirements}
              onRequirementsChange={setRequirements}
              refinementPrompt={refinementPrompt}
              onRefinementPromptChange={setRefinementPrompt}
              onGenerate={handleGenerate}
              onRefine={handleRefine}
              isGenerating={isGenerating}
              hasArtifacts={hasArtifacts}
            />
          </ResizablePanel>

          <ResizableHandle withHandle />

          {/* Right Pane - Artifacts */}
          <ResizablePanel defaultSize={60} minSize={30}>
            <ArtifactDisplay
              iteration={currentIteration}
              isLoading={isGenerating || isLoadingState}
              previousIteration={
                currentVersion > 0 && projectState
                  ? projectState.iterations[currentVersion - 1]
                  : undefined
              }
            />
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>

      {/* Export Dialog */}
      {currentIteration && (
        <ExportDialog
          open={showExportDialog}
          onOpenChange={setShowExportDialog}
          iteration={currentIteration}
          format={exportFormat}
        />
      )}
    </div>
  );
}
