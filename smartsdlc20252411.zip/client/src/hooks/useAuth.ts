// useAuth hook for client-side authentication
// Updated for MVP simulated SSO

import { useQuery } from "@tanstack/react-query";

interface SimulatedUser {
  id: string;
  email: string;
  name: string;
  title: string;
  avatar: string;
  roles: string[];
  resolvedRole: string;
  effectiveRole: string;
  hasOverride: boolean;
  isAdmin: boolean;
}

export function useAuth() {
  const { data, isLoading, error } = useQuery<{ user: SimulatedUser }>({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  return {
    user: data?.user,
    isLoading,
    isAuthenticated: !!data?.user,
    error,
  };
}
