import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import Workspace from "@/pages/workspace";
import AdminPanel from "@/pages/admin-panel";
import Projects from "@/pages/projects";
import ProjectDetails from "@/pages/project-details";
import MockLogin from "@/pages/mock-login";
import DebugPage from "@/pages/debug";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/mock-login" component={MockLogin} />
      <Route path="/login" component={() => <Redirect to="/mock-login" />} />
      <Route path="/" component={() => <Redirect to="/workspace" />} />
      <Route path="/workspace" component={() => <ProtectedRoute component={Workspace} />} />
      <Route path="/admin" component={() => <ProtectedRoute component={AdminPanel} />} />
      <Route path="/projects" component={() => <ProtectedRoute component={Projects} />} />
      <Route path="/projects/:id" component={() => <ProtectedRoute component={ProjectDetails} />} />
      <Route path="/debug" component={() => <ProtectedRoute component={DebugPage} />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
