import { useState } from "react";
import { FileCode, ChevronRight, ChevronDown, Folder, FolderOpen } from "lucide-react";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

interface CodeFile {
  filename: string;
  language: string;
  path: string;
  code: string;
  description?: string;
  purpose?: string;
}

interface FileNode {
  name: string;
  type: "file" | "folder";
  path: string;
  file?: CodeFile;
  children?: FileNode[];
}

interface FileViewerProps {
  files: CodeFile[];
}

function buildFileTree(files: CodeFile[]): FileNode[] {
  const root: { [key: string]: FileNode } = {};

  files.forEach((file) => {
    // Handle path that might already include filename or be empty
    let cleanPath = file.path || "";
    const filename = file.filename;
    
    // If path ends with filename, remove it
    if (cleanPath.endsWith("/" + filename) || cleanPath.endsWith(filename)) {
      cleanPath = cleanPath.replace(new RegExp(`/?${filename.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`), '');
    }
    
    const pathParts = cleanPath.split("/").filter(Boolean);
    
    // If no path parts, put file in root
    if (pathParts.length === 0) {
      const fileNode: FileNode = {
        name: filename,
        type: "file",
        path: filename,
        file
      };
      root[filename] = fileNode;
      return;
    }
    
    let currentLevel = root;
    let currentPath = "";

    pathParts.forEach((part, index) => {
      currentPath += (currentPath ? "/" : "") + part;
      
      if (!currentLevel[part]) {
        currentLevel[part] = {
          name: part,
          type: "folder",
          path: currentPath,
          children: {}
        };
      }
      
      if (index === pathParts.length - 1) {
        const fileNode: FileNode = {
          name: filename,
          type: "file",
          path: currentPath + "/" + filename,
          file
        };
        (currentLevel[part].children as any)[filename] = fileNode;
      }
      
      currentLevel = currentLevel[part].children as any;
    });
  });

  const convertToArray = (obj: { [key: string]: FileNode }): FileNode[] => {
    return Object.values(obj).map((node) => ({
      ...node,
      children: node.children ? convertToArray(node.children as any) : []
    }));
  };

  return convertToArray(root);
}

function FileTreeItem({ node, onFileSelect, selectedPath }: { 
  node: FileNode; 
  onFileSelect: (file: CodeFile) => void;
  selectedPath: string | null;
}) {
  const [isExpanded, setIsExpanded] = useState(true);

  const handleClick = () => {
    if (node.type === "folder") {
      setIsExpanded(!isExpanded);
    } else if (node.file) {
      onFileSelect(node.file);
    }
  };

  const isSelected = node.type === "file" && selectedPath === node.path;

  return (
    <div>
      <div
        onClick={handleClick}
        className={`flex items-center gap-2 px-2 py-1.5 cursor-pointer hover-elevate rounded text-sm ${
          isSelected ? "bg-accent" : ""
        }`}
        data-testid={`file-tree-${node.type}-${node.name}`}
      >
        {node.type === "folder" ? (
          <>
            {isExpanded ? (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )}
            {isExpanded ? (
              <FolderOpen className="h-4 w-4 text-blue-500" />
            ) : (
              <Folder className="h-4 w-4 text-blue-500" />
            )}
          </>
        ) : (
          <>
            <span className="w-4" />
            <FileCode className="h-4 w-4 text-muted-foreground" />
          </>
        )}
        <span className={isSelected ? "font-medium" : ""}>{node.name}</span>
      </div>
      {node.type === "folder" && isExpanded && node.children && (
        <div className="ml-4">
          {node.children.map((child) => (
            <FileTreeItem
              key={child.path}
              node={child}
              onFileSelect={onFileSelect}
              selectedPath={selectedPath}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function FileViewer({ files }: FileViewerProps) {
  const [selectedFile, setSelectedFile] = useState<CodeFile | null>(files[0] || null);
  const fileTree = buildFileTree(files);

  return (
    <div className="flex gap-4 h-[600px]" data-testid="file-viewer">
      {/* File Tree - Left Panel */}
      <Card className="w-64 flex-shrink-0 overflow-hidden">
        <div className="px-4 py-3 border-b bg-muted/50">
          <h3 className="text-sm font-semibold">Files</h3>
        </div>
        <ScrollArea className="h-[550px]">
          <div className="p-2">
            {fileTree.map((node) => (
              <FileTreeItem
                key={node.path}
                node={node}
                onFileSelect={setSelectedFile}
                selectedPath={selectedFile?.path + "/" + selectedFile?.filename || null}
              />
            ))}
          </div>
        </ScrollArea>
      </Card>

      {/* File Content - Right Panel */}
      <Card className="flex-1 overflow-hidden flex flex-col">
        {selectedFile ? (
          <>
            <div className="px-4 py-3 border-b bg-muted/50">
              <div className="flex items-center gap-2">
                <FileCode className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold" data-testid="file-viewer-filename">
                  {selectedFile.filename}
                </h3>
                <span className="text-xs text-muted-foreground ml-auto">
                  {selectedFile.language}
                </span>
              </div>
              {(selectedFile.purpose || selectedFile.description) && (
                <p className="text-xs text-muted-foreground mt-1">
                  {selectedFile.purpose || selectedFile.description}
                </p>
              )}
            </div>
            <ScrollArea className="flex-1">
              <pre className="p-4 text-xs font-mono" data-testid="file-viewer-code">
                <code>{selectedFile.code}</code>
              </pre>
            </ScrollArea>
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <p className="text-sm">Select a file to view its contents</p>
          </div>
        )}
      </Card>
    </div>
  );
}
