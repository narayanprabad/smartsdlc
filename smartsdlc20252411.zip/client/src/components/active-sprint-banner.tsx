import { useQuery } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Target, TrendingUp } from 'lucide-react';
import { format } from 'date-fns';

type Sprint = {
  id: string;
  projectId: string;
  name: string;
  sprintNumber: number;
  startDate: Date;
  endDate: Date;
  sprintLengthDays: number;
  status: "planning" | "active" | "completed" | "archived";
  goal: string | null;
  retrospective: any;
  createdAt: Date;
  updatedAt: Date;
};

type ActiveSprintBannerProps = {
  projectId: string;
};

export function ActiveSprintBanner({ projectId }: ActiveSprintBannerProps) {
  const { data: activeSprint, isLoading } = useQuery<Sprint>({
    queryKey: ['/api/projects', projectId, 'sprints', 'active'],
    enabled: !!projectId,
  });

  if (isLoading) {
    return (
      <Card className="p-4 sticky top-2 z-10 bg-card/95 backdrop-blur">
        <div className="animate-pulse flex items-center gap-4">
          <div className="h-4 bg-muted rounded w-32"></div>
          <div className="h-4 bg-muted rounded w-48"></div>
        </div>
      </Card>
    );
  }

  if (!activeSprint) {
    return (
      <Card className="p-4 sticky top-2 z-10 bg-card/95 backdrop-blur border-dashed" data-testid="card-no-active-sprint">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Calendar className="w-4 h-4" />
          <span className="text-sm">No active sprint</span>
        </div>
      </Card>
    );
  }

  const statusColors = {
    planning: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    active: 'bg-green-500/10 text-green-500 border-green-500/20',
    completed: 'bg-gray-500/10 text-gray-500 border-gray-500/20',
    archived: 'bg-gray-400/10 text-gray-400 border-gray-400/20',
  };

  return (
    <Card 
      className="p-4 sticky top-2 z-10 bg-card/95 backdrop-blur border-2" 
      data-testid="card-active-sprint-banner"
    >
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-4 flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-primary" />
            <div>
              <h3 className="font-semibold text-lg" data-testid="text-sprint-name">
                {activeSprint.name}
              </h3>
              <p className="text-xs text-muted-foreground">
                {format(new Date(activeSprint.startDate), 'MMM d')} - {format(new Date(activeSprint.endDate), 'MMM d, yyyy')}
              </p>
            </div>
          </div>

          {activeSprint.goal && (
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <Target className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <p className="text-sm text-muted-foreground truncate" data-testid="text-sprint-goal">
                {activeSprint.goal}
              </p>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3">
          <Badge 
            variant="outline" 
            className={statusColors[activeSprint.status]}
            data-testid="badge-sprint-status"
          >
            {activeSprint.status.charAt(0).toUpperCase() + activeSprint.status.slice(1)}
          </Badge>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <TrendingUp className="w-4 h-4" />
            <span>{activeSprint.sprintLengthDays} days</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
