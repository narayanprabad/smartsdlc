import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Calendar, Plus, CheckCircle2, Circle, Clock, AlertCircle, User, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

type Story = {
  id: string;
  projectId: string;
  sprintId: string | null;
  title: string;
  description: string | null;
  status: "backlog" | "todo" | "in_progress" | "in_review" | "done" | "blocked";
  priority: string;
  storyPoints: number | null;
  assignedTo: string | null;
  linkedStories: string[];
  acceptanceCriteria: string[];
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
};

type Sprint = {
  id: string;
  projectId: string;
  name: string;
  sprintNumber: number;
  startDate: Date;
  endDate: Date;
  sprintLengthDays: number;
  status: "planning" | "active" | "completed" | "archived";
  goal: string | null;
  retrospective: any;
  createdAt: Date;
  updatedAt: Date;
};

type Collaborator = {
  userId: string;
  userName: string;
  role: string;
};

type SprintViewProps = {
  projectId: string;
  collaborators?: Collaborator[];
};

const statusIcons = {
  backlog: Circle,
  todo: Circle,
  in_progress: Clock,
  in_review: AlertCircle,
  done: CheckCircle2,
  blocked: AlertCircle,
};

const statusColors = {
  backlog: 'text-muted-foreground',
  todo: 'text-blue-500',
  in_progress: 'text-amber-500',
  in_review: 'text-purple-500',
  done: 'text-green-500',
  blocked: 'text-red-500',
};

export function SprintView({ projectId, collaborators = [] }: SprintViewProps) {
  const [selectedSprintId, setSelectedSprintId] = useState<string | null>(null);
  const [showAddStory, setShowAddStory] = useState(false);
  const [showServiceNowDialog, setShowServiceNowDialog] = useState(false);
  const [selectedStories, setSelectedStories] = useState<Set<string>>(new Set());
  const [serviceNowChange, setServiceNowChange] = useState({
    summary: '',
    description: '',
    priority: '3',
    riskImpact: '3',
  });
  const [newStory, setNewStory] = useState({
    title: '',
    description: '',
    priority: 'medium',
    storyPoints: '',
  });
  const { toast } = useToast();

  // Fetch ALL sprints for the project
  const { data: sprints = [], isLoading: isLoadingSprints } = useQuery<Sprint[]>({
    queryKey: ['/api/projects', projectId, 'sprints'],
    enabled: !!projectId,
  });

  // Find active sprint and selected sprint
  const activeSprint = sprints.find(s => s.status === 'active');
  const selectedSprint = sprints.find(s => s.id === selectedSprintId) || activeSprint || sprints[sprints.length - 1];
  
  // Auto-select active sprint on first load (in useEffect to avoid re-render loop)
  useEffect(() => {
    if (!selectedSprintId && activeSprint) {
      setSelectedSprintId(activeSprint.id);
    }
  }, [selectedSprintId, activeSprint]);

  // Fetch sprint stories for selected sprint
  const { data: sprintStories = [], isLoading: isLoadingStories } = useQuery<Story[]>({
    queryKey: ['/api/sprints', selectedSprint?.id, 'stories'],
    enabled: !!selectedSprint?.id,
  });

  // Fetch all project stories for backlog
  const { data: allStories = [] } = useQuery<Story[]>({
    queryKey: ['/api/projects', projectId, 'stories'],
    enabled: !!projectId,
  });
  
  const backlogStories = allStories.filter(s => !s.sprintId);

  // Create story mutation
  const createStoryMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('POST', `/api/projects/${projectId}/stories`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId, 'stories'] });
      setShowAddStory(false);
      setNewStory({ title: '', description: '', priority: 'medium', storyPoints: '' });
    },
  });

  // Update story mutation (for moving to sprint)
  const updateStoryMutation = useMutation({
    mutationFn: async ({ storyId, data }: { storyId: string; data: any }) => {
      return apiRequest('PATCH', `/api/stories/${storyId}`, { ...data, projectId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId, 'stories'] });
    },
  });

  const handleCreateStory = () => {
    if (!newStory.title.trim()) return;

    createStoryMutation.mutate({
      sprintId: selectedSprint?.id || null,
      title: newStory.title,
      description: newStory.description || null,
      priority: newStory.priority,
      storyPoints: newStory.storyPoints ? parseInt(newStory.storyPoints) : null,
      status: 'todo',
      linkedStories: [],
      acceptanceCriteria: [],
    });
  };

  const moveStoryToSprint = (storyId: string) => {
    if (!selectedSprint) return;
    updateStoryMutation.mutate({
      storyId,
      data: { sprintId: selectedSprint.id, status: 'todo' },
    });
  };

  const getAssigneeInfo = (assignedTo: string | null) => {
    if (!assignedTo) return null;
    const collaborator = collaborators.find((c: any) => c.userId === assignedTo);
    return collaborator;
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'high':
        return 'bg-red-500/10 text-red-500 border-red-500/20';
      case 'medium':
        return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
      case 'low':
        return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
      default:
        return 'bg-gray-500/10 text-gray-500 border-gray-500/20';
    }
  };

  const toggleStorySelection = (storyId: string) => {
    setSelectedStories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(storyId)) {
        newSet.delete(storyId);
      } else {
        newSet.add(storyId);
      }
      return newSet;
    });
  };

  const handleCreateServiceNowChange = async () => {
    if (selectedStories.size === 0 || !serviceNowChange.summary.trim()) return;
    
    try {
      const response = await apiRequest('POST', '/api/servicenow/change-requests', {
        projectId,
        storyIds: Array.from(selectedStories),
        summary: serviceNowChange.summary,
        description: serviceNowChange.description,
        priority: serviceNowChange.priority,
        riskImpact: serviceNowChange.riskImpact,
      });

      toast({
        title: "ServiceNow Change Created",
        description: response.message || `Successfully created change request for ${selectedStories.size} ${selectedStories.size === 1 ? 'story' : 'stories'}`,
      });

      setShowServiceNowDialog(false);
      setSelectedStories(new Set());
      setServiceNowChange({ summary: '', description: '', priority: '3', riskImpact: '3' });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create ServiceNow change request",
        variant: "destructive",
      });
    }
  };

  if (isLoadingSprints) {
    return (
      <Card data-testid="card-sprint-loading">
        <CardHeader>
          <CardTitle>Loading Sprints...</CardTitle>
        </CardHeader>
      </Card>
    );
  }

  if (sprints.length === 0) {
    return (
      <Card data-testid="card-no-sprints">
        <CardHeader>
          <CardTitle>No Sprints</CardTitle>
          <CardDescription>Create a sprint to start planning your work</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  const getSprintStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/10 text-green-500 border-green-500/20';
      case 'completed': return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
      case 'planning': return 'bg-purple-500/10 text-purple-500 border-purple-500/20';
      case 'archived': return 'bg-muted text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-4" data-testid="container-sprint-view">
      {/* Sprint Selector */}
      <Card data-testid="card-sprint-selector">
        <CardHeader>
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1">
              <Label htmlFor="sprint-select" className="text-sm font-medium">Select Sprint</Label>
              <Select 
                value={selectedSprint?.id || ''} 
                onValueChange={setSelectedSprintId}
              >
                <SelectTrigger id="sprint-select" data-testid="select-sprint" className="mt-1">
                  <SelectValue placeholder="Choose a sprint" />
                </SelectTrigger>
                <SelectContent>
                  {sprints
                    .sort((a, b) => a.sprintNumber - b.sprintNumber)
                    .map((sprint) => (
                      <SelectItem 
                        key={sprint.id} 
                        value={sprint.id}
                        data-testid={`option-sprint-${sprint.sprintNumber}`}
                      >
                        <div className="flex items-center gap-2">
                          <span>{sprint.name}</span>
                          <Badge variant={sprint.status === 'active' ? 'default' : 'secondary'} className="text-xs">
                            {sprint.status}
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
      </Card>

      {selectedSprint && (
        <>
          {/* Selected Sprint Card */}
          <Card data-testid="card-selected-sprint">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2" data-testid="text-sprint-name">
                    <Calendar className="w-5 h-5" />
                    {selectedSprint.name}
                  </CardTitle>
                  <CardDescription data-testid="text-sprint-dates">
                    {format(new Date(selectedSprint.startDate), 'MMM d, yyyy')} - {format(new Date(selectedSprint.endDate), 'MMM d, yyyy')}
                  </CardDescription>
                </div>
                <Badge 
                  className={getSprintStatusColor(selectedSprint.status)}
                  data-testid="badge-sprint-status"
                >
                  {selectedSprint.status}
                </Badge>
              </div>
            </CardHeader>
            {selectedSprint.goal && (
              <CardContent>
                <p className="text-sm text-muted-foreground" data-testid="text-sprint-goal">
                  <strong>Goal:</strong> {selectedSprint.goal}
                </p>
              </CardContent>
            )}
          </Card>

          {/* Retrospective for Completed Sprints */}
          {selectedSprint.status === 'completed' && selectedSprint.retrospective && (
            <Card data-testid="card-sprint-retrospective">
              <CardHeader>
                <CardTitle>Sprint Retrospective</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  {typeof selectedSprint.retrospective === 'string' ? (
                    <p className="text-sm text-muted-foreground">{selectedSprint.retrospective}</p>
                  ) : (
                    <pre className="text-xs">{JSON.stringify(selectedSprint.retrospective, null, 2)}</pre>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {/* Sprint Stories */}
      <Card data-testid="card-sprint-stories">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle data-testid="text-sprint-items-title">Sprint Items</CardTitle>
              <CardDescription data-testid="text-sprint-items-count">
                {sprintStories.length} {sprintStories.length === 1 ? 'story' : 'stories'} in this sprint
                {selectedStories.size > 0 && ` • ${selectedStories.size} selected`}
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              {selectedStories.size > 0 && (
                <Button 
                  size="sm" 
                  variant="default"
                  onClick={() => setShowServiceNowDialog(true)}
                  data-testid="button-create-servicenow-change"
                >
                  <FileText className="w-4 h-4 mr-1" />
                  Create ServiceNow Change ({selectedStories.size})
                </Button>
              )}
              <Dialog open={showAddStory} onOpenChange={setShowAddStory}>
                <DialogTrigger asChild>
                  <Button size="sm" data-testid="button-add-story">
                    <Plus className="w-4 h-4 mr-1" />
                    Add Story
                  </Button>
                </DialogTrigger>
                <DialogContent data-testid="dialog-add-story">
                <DialogHeader>
                  <DialogTitle>Add Story to Sprint</DialogTitle>
                  <DialogDescription>
                    Create a new story and add it to {selectedSprint?.name || "Sprint"}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title" data-testid="label-story-title">Title</Label>
                    <Input
                      id="title"
                      data-testid="input-story-title"
                      value={newStory.title}
                      onChange={(e) => setNewStory({ ...newStory, title: e.target.value })}
                      placeholder="Enter story title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="description" data-testid="label-story-description">Description</Label>
                    <Textarea
                      id="description"
                      data-testid="input-story-description"
                      value={newStory.description}
                      onChange={(e) => setNewStory({ ...newStory, description: e.target.value })}
                      placeholder="Enter story description"
                      rows={3}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="priority" data-testid="label-story-priority">Priority</Label>
                      <Select value={newStory.priority} onValueChange={(value) => setNewStory({ ...newStory, priority: value })}>
                        <SelectTrigger id="priority" data-testid="select-story-priority">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low" data-testid="option-priority-low">Low</SelectItem>
                          <SelectItem value="medium" data-testid="option-priority-medium">Medium</SelectItem>
                          <SelectItem value="high" data-testid="option-priority-high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="storyPoints" data-testid="label-story-points">Story Points</Label>
                      <Input
                        id="storyPoints"
                        data-testid="input-story-points"
                        type="number"
                        value={newStory.storyPoints}
                        onChange={(e) => setNewStory({ ...newStory, storyPoints: e.target.value })}
                        placeholder="e.g., 3"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setShowAddStory(false)}
                      data-testid="button-cancel-story"
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={handleCreateStory}
                      disabled={!newStory.title.trim() || createStoryMutation.isPending}
                      data-testid="button-create-story"
                    >
                      {createStoryMutation.isPending ? 'Creating...' : 'Create Story'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoadingStories ? (
            <p className="text-sm text-muted-foreground" data-testid="text-loading-stories">Loading stories...</p>
          ) : sprintStories.length === 0 ? (
            <p className="text-sm text-muted-foreground" data-testid="text-no-stories">
              No stories in this sprint yet. Add your first story to get started!
            </p>
          ) : (
            <div className="space-y-2" data-testid="list-sprint-stories">
              {sprintStories.map((story) => {
                const StatusIcon = statusIcons[story.status];
                const assignee = getAssigneeInfo(story.assignedTo);
                return (
                  <Card key={story.id} className="hover-elevate" data-testid={`card-story-${story.id}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <Checkbox
                          checked={selectedStories.has(story.id)}
                          onCheckedChange={() => toggleStorySelection(story.id)}
                          data-testid={`checkbox-story-${story.id}`}
                          className="mt-1"
                        />
                        <StatusIcon className={`w-5 h-5 mt-0.5 flex-shrink-0 ${statusColors[story.status]}`} data-testid={`icon-story-status-${story.id}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium" data-testid={`text-story-title-${story.id}`}>{story.title}</h4>
                              {story.description && (
                                <p className="text-sm text-muted-foreground mt-1 line-clamp-2" data-testid={`text-story-description-${story.id}`}>
                                  {story.description}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-3 mt-3 flex-wrap">
                            {assignee ? (
                              <div className="flex items-center gap-2" data-testid={`container-assignee-${story.id}`}>
                                <Avatar className="w-6 h-6">
                                  <AvatarFallback className="text-xs bg-primary/10">
                                    {assignee.userName?.split(' ').map((n: string) => n[0]).join('') || 'U'}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-sm text-muted-foreground" data-testid={`text-assignee-${story.id}`}>
                                  {assignee.userName}
                                </span>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2 text-muted-foreground" data-testid={`container-unassigned-${story.id}`}>
                                <User className="w-4 h-4" />
                                <span className="text-sm">Unassigned</span>
                              </div>
                            )}
                            {story.storyPoints && (
                              <Badge variant="secondary" className="text-xs" data-testid={`badge-story-points-${story.id}`}>
                                {story.storyPoints} pts
                              </Badge>
                            )}
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${getPriorityColor(story.priority)}`}
                              data-testid={`badge-story-priority-${story.id}`}
                            >
                              {story.priority.charAt(0).toUpperCase() + story.priority.slice(1)}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Backlog */}
      {backlogStories.length > 0 && (
        <Card data-testid="card-backlog">
          <CardHeader>
            <CardTitle data-testid="text-backlog-title">Backlog</CardTitle>
            <CardDescription data-testid="text-backlog-count">
              {backlogStories.length} {backlogStories.length === 1 ? 'story' : 'stories'} not assigned to a sprint
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2" data-testid="list-backlog-stories">
              {backlogStories.map((story) => {
                const StatusIcon = statusIcons[story.status];
                const assignee = getAssigneeInfo(story.assignedTo);
                return (
                  <Card key={story.id} className="hover-elevate" data-testid={`card-backlog-story-${story.id}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <StatusIcon className={`w-5 h-5 mt-0.5 flex-shrink-0 ${statusColors[story.status]}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium" data-testid={`text-backlog-story-title-${story.id}`}>{story.title}</h4>
                              {story.description && (
                                <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                                  {story.description}
                                </p>
                              )}
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => moveStoryToSprint(story.id)}
                              disabled={updateStoryMutation.isPending}
                              data-testid={`button-move-to-sprint-${story.id}`}
                              className="flex-shrink-0"
                            >
                              <Plus className="w-4 h-4 mr-1" />
                              Add to Sprint
                            </Button>
                          </div>
                          <div className="flex items-center gap-3 mt-3 flex-wrap">
                            {assignee ? (
                              <div className="flex items-center gap-2">
                                <Avatar className="w-6 h-6">
                                  <AvatarFallback className="text-xs bg-primary/10">
                                    {assignee.userName?.split(' ').map((n: string) => n[0]).join('') || 'U'}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-sm text-muted-foreground">
                                  {assignee.userName}
                                </span>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2 text-muted-foreground">
                                <User className="w-4 h-4" />
                                <span className="text-sm">Unassigned</span>
                              </div>
                            )}
                            {story.storyPoints && (
                              <Badge variant="secondary" className="text-xs">
                                {story.storyPoints} pts
                              </Badge>
                            )}
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${getPriorityColor(story.priority)}`}
                            >
                              {story.priority.charAt(0).toUpperCase() + story.priority.slice(1)}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ServiceNow Change Request Dialog */}
      <Dialog open={showServiceNowDialog} onOpenChange={setShowServiceNowDialog}>
        <DialogContent className="max-w-md" data-testid="dialog-servicenow-change">
          <DialogHeader>
            <DialogTitle>Create ServiceNow Change Request</DialogTitle>
            <DialogDescription>
              Create a change request for {selectedStories.size} selected {selectedStories.size === 1 ? 'story' : 'stories'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="snow-summary">Summary *</Label>
              <Input
                id="snow-summary"
                data-testid="input-snow-summary"
                value={serviceNowChange.summary}
                onChange={(e) => setServiceNowChange({ ...serviceNowChange, summary: e.target.value })}
                placeholder="Brief summary of the change"
              />
            </div>
            <div>
              <Label htmlFor="snow-description">Description</Label>
              <Textarea
                id="snow-description"
                data-testid="input-snow-description"
                value={serviceNowChange.description}
                onChange={(e) => setServiceNowChange({ ...serviceNowChange, description: e.target.value })}
                placeholder="Detailed description of the change"
                rows={4}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="snow-priority">Priority</Label>
                <Select 
                  value={serviceNowChange.priority} 
                  onValueChange={(value) => setServiceNowChange({ ...serviceNowChange, priority: value })}
                >
                  <SelectTrigger id="snow-priority" data-testid="select-snow-priority">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Critical</SelectItem>
                    <SelectItem value="2">2 - High</SelectItem>
                    <SelectItem value="3">3 - Moderate</SelectItem>
                    <SelectItem value="4">4 - Low</SelectItem>
                    <SelectItem value="5">5 - Planning</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="snow-risk">Risk & Impact</Label>
                <Select 
                  value={serviceNowChange.riskImpact} 
                  onValueChange={(value) => setServiceNowChange({ ...serviceNowChange, riskImpact: value })}
                >
                  <SelectTrigger id="snow-risk" data-testid="select-snow-risk">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - High</SelectItem>
                    <SelectItem value="2">2 - Medium</SelectItem>
                    <SelectItem value="3">3 - Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="rounded-md bg-muted p-3">
              <p className="text-sm font-medium mb-2">Selected Stories:</p>
              <ul className="text-sm space-y-1">
                {sprintStories.filter(s => selectedStories.has(s.id)).map(s => (
                  <li key={s.id} className="flex items-center gap-2">
                    <span className="text-muted-foreground">•</span>
                    <span className="truncate">{s.title}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setShowServiceNowDialog(false)}
                data-testid="button-cancel-snow"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateServiceNowChange}
                disabled={!serviceNowChange.summary.trim()}
                data-testid="button-create-snow"
              >
                Create Change Request
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
