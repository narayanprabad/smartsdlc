import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Download, Copy, Check } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import type { Iteration } from "@shared/schema";

interface ExportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  iteration: Iteration;
  format: "json" | "markdown";
}

export function ExportDialog({ open, onOpenChange, iteration, format }: ExportDialogProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const generateJSON = () => {
    return JSON.stringify(
      {
        version: iteration.version,
        timestamp: iteration.timestamp,
        requirements: iteration.requirements,
        artifacts: iteration.artifacts,
      },
      null,
      2
    );
  };

  const generateMarkdown = () => {
    const { artifacts, requirements, version, timestamp } = iteration;
    let md = `# SmartSDLC Artifacts - Version ${version}\n\n`;
    md += `**Generated:** ${new Date(timestamp).toLocaleString()}\n\n`;
    md += `## Business Requirements\n\n${requirements}\n\n`;
    md += `---\n\n`;

    // User Stories
    md += `## User Stories\n\n`;
    artifacts.userStories.forEach((story, i) => {
      md += `### ${i + 1}. ${story.title}\n\n`;
      md += `${story.description}\n\n`;
      md += `**Effort:** ${story.effort}\n\n`;
      md += `**Acceptance Criteria:**\n`;
      story.acceptanceCriteria.forEach((ac) => {
        md += `- ${ac}\n`;
      });
      md += `\n`;
    });

    // Architecture
    md += `## Architecture Outline\n\n`;
    const renderArchitecture = (components: typeof artifacts.architectureOutline, level = 0) => {
      components.forEach((comp) => {
        const indent = "  ".repeat(level);
        md += `${indent}- **${comp.name}** (${comp.type})\n`;
        md += `${indent}  ${comp.description}\n`;
        if (comp.codeSnippet) {
          md += `${indent}  \`\`\`\n${comp.codeSnippet}\n${indent}  \`\`\`\n`;
        }
        if (comp.children && comp.children.length > 0) {
          renderArchitecture(comp.children, level + 1);
        }
      });
    };
    renderArchitecture(artifacts.architectureOutline);

    // Tasks
    md += `\n## Task Breakdown\n\n`;
    md += `| Role | Task | Effort | Status |\n`;
    md += `|------|------|--------|--------|\n`;
    artifacts.tasks.forEach((task) => {
      md += `| ${task.role} | ${task.task} | ${task.effort} | ${task.status.replace("_", " ")} |\n`;
    });

    return md;
  };

  const content = format === "json" ? generateJSON() : generateMarkdown();
  const filename = `smartsdlc-v${iteration.version}.${format === "json" ? "json" : "md"}`;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({
      title: "Copied to clipboard",
      description: `${format.toUpperCase()} content copied successfully.`,
    });
  };

  const handleDownload = () => {
    // Use backend API for proper file download
    const formatPath = format === "json" ? "json" : "markdown";
    const url = `/api/export/${formatPath}/${iteration.id}`;
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    toast({
      title: "Download started",
      description: `Downloading ${filename}`,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Export as {format.toUpperCase()}</DialogTitle>
          <DialogDescription>
            Version {iteration.version} - {new Date(iteration.timestamp).toLocaleString()}
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="h-[400px] w-full rounded-md border">
          <pre className="p-4 text-xs font-mono">
            <code>{content}</code>
          </pre>
        </ScrollArea>

        <div className="flex items-center justify-end gap-2">
          <Button variant="outline" onClick={handleCopy} data-testid="button-copy-export">
            {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
            {copied ? "Copied!" : "Copy"}
          </Button>
          <Button onClick={handleDownload} data-testid="button-download-export">
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
