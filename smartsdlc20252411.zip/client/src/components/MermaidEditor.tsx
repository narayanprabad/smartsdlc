import { useState, useEffect } from 'react';
import { MermaidDiagram } from './MermaidDiagram';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface MermaidEditorProps {
  initialCode?: string;
  initialTitle?: string;
  initialDescription?: string;
  onSave?: (data: { title: string; description: string; code: string }) => void;
}

export function MermaidEditor({
  initialCode = '',
  initialTitle = '',
  initialDescription = '',
  onSave,
}: MermaidEditorProps) {
  const [title, setTitle] = useState(initialTitle);
  const [description, setDescription] = useState(initialDescription);
  const [code, setCode] = useState(initialCode);
  const [previewCode, setPreviewCode] = useState(initialCode);

  useEffect(() => {
    const timer = setTimeout(() => {
      setPreviewCode(code);
    }, 500);

    return () => clearTimeout(timer);
  }, [code]);

  const handleSave = () => {
    if (onSave) {
      onSave({ title, description, code });
    }
  };

  return (
    <div className="h-full flex flex-col gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Diagram Details</CardTitle>
          <CardDescription>Edit diagram metadata</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="diagram-title">Title</Label>
            <Input
              id="diagram-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., System Architecture"
              data-testid="input-diagram-title"
            />
          </div>
          <div>
            <Label htmlFor="diagram-description">Description</Label>
            <Input
              id="diagram-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g., High-level system overview"
              data-testid="input-diagram-description"
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex-1 grid grid-cols-2 gap-4">
        <Card className="h-full flex flex-col">
          <CardHeader>
            <CardTitle>Mermaid Code</CardTitle>
            <CardDescription>
              Edit the diagram using{' '}
              <a
                href="https://mermaid.js.org/intro/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                Mermaid syntax
              </a>
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-1">
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="font-mono text-sm h-full min-h-96"
              placeholder="graph TD&#10;    A[Client] --> B[Server]&#10;    B --> C[Database]"
              data-testid="input-diagram-code"
            />
          </CardContent>
        </Card>

        <div className="h-full overflow-y-auto">
          <MermaidDiagram code={previewCode} title={title || 'Untitled'} description={description} />
        </div>
      </div>

      {onSave && (
        <div className="flex justify-end">
          <Button onClick={handleSave} data-testid="button-save-diagram">
            Save Diagram
          </Button>
        </div>
      )}
    </div>
  );
}
