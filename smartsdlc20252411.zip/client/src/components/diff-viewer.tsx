import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Minus, Edit3 } from "lucide-react";
import type { DiffEntry } from "@shared/schema";

interface DiffViewerProps {
  diff: DiffEntry[];
}

export function DiffViewer({ diff }: DiffViewerProps) {
  const addedCount = diff.filter((d) => d.changeType === "added").length;
  const modifiedCount = diff.filter((d) => d.changeType === "modified").length;
  const removedCount = diff.filter((d) => d.changeType === "removed").length;

  return (
    <Card data-testid="card-diff-viewer">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium">Changes in This Version</CardTitle>
          <div className="flex items-center gap-2">
            {addedCount > 0 && (
              <Badge variant="secondary" className="gap-1">
                <Plus className="w-3 h-3 text-green-600" />
                {addedCount} added
              </Badge>
            )}
            {modifiedCount > 0 && (
              <Badge variant="secondary" className="gap-1">
                <Edit3 className="w-3 h-3 text-blue-600" />
                {modifiedCount} modified
              </Badge>
            )}
            {removedCount > 0 && (
              <Badge variant="secondary" className="gap-1">
                <Minus className="w-3 h-3 text-red-600" />
                {removedCount} removed
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {diff.map((entry, index) => (
          <div
            key={index}
            className={`p-3 rounded-md text-sm border-l-2 ${
              entry.changeType === "added"
                ? "bg-green-50 dark:bg-green-950/20 border-l-green-600"
                : entry.changeType === "modified"
                  ? "bg-blue-50 dark:bg-blue-950/20 border-l-blue-600"
                  : "bg-red-50 dark:bg-red-950/20 border-l-red-600"
            }`}
            data-testid={`diff-entry-${entry.changeType}`}
          >
            <div className="flex items-start gap-2">
              {entry.changeType === "added" && <Plus className="w-4 h-4 text-green-600 mt-0.5" />}
              {entry.changeType === "modified" && <Edit3 className="w-4 h-4 text-blue-600 mt-0.5" />}
              {entry.changeType === "removed" && <Minus className="w-4 h-4 text-red-600 mt-0.5" />}
              <div className="flex-1">
                <p className="font-medium text-foreground">{entry.path}</p>
                <p className="text-muted-foreground mt-1">{entry.description}</p>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
