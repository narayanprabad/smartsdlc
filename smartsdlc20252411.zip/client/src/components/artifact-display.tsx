import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileText, CheckSquare, Building2, ListTodo, Sparkles } from "lucide-react";
import { UserStoriesCard } from "./artifacts/user-stories-card";
import { ArchitectureCard } from "./artifacts/architecture-card";
import { TasksCard } from "./artifacts/tasks-card";
import { DiffViewer } from "./diff-viewer";
import type { Iteration } from "@shared/schema";

interface ArtifactDisplayProps {
  iteration?: Iteration;
  isLoading: boolean;
  previousIteration?: Iteration;
}

export function ArtifactDisplay({ iteration, isLoading, previousIteration }: ArtifactDisplayProps) {
  if (isLoading) {
    return (
      <div className="h-full p-6 space-y-4 overflow-y-auto">
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-64 w-full" />
        <Skeleton className="h-56 w-full" />
      </div>
    );
  }

  if (!iteration) {
    return (
      <div className="h-full flex items-center justify-center p-8">
        <div className="text-center max-w-md space-y-4">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
            <Sparkles className="w-8 h-8 text-primary" />
          </div>
          <h3 className="text-lg font-semibold text-foreground">No Artifacts Yet</h3>
          <p className="text-sm text-muted-foreground">
            Enter your business requirements in the left pane and click "Generate Artifacts" to transform them into user stories, architecture, and tasks.
          </p>
          <div className="text-xs text-muted-foreground space-y-1 pt-4">
            <p className="font-medium">Example requirement:</p>
            <p className="italic">
              "Build a task management app with user authentication, real-time collaboration, and Kanban boards."
            </p>
          </div>
        </div>
      </div>
    );
  }

  const { artifacts, diff } = iteration;
  const hasDiff = diff && diff.length > 0;

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-6">
        {/* Show diff if this is a refinement */}
        {hasDiff && previousIteration && (
          <DiffViewer diff={diff} />
        )}

        {/* User Stories */}
        <UserStoriesCard stories={artifacts.userStories} />

        {/* Architecture Outline */}
        <ArchitectureCard components={artifacts.architectureOutline} />

        {/* Tasks */}
        <TasksCard tasks={artifacts.tasks} />
      </div>
    </ScrollArea>
  );
}
