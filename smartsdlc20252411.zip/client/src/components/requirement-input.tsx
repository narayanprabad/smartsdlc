import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, Sparkles, RefreshCw } from "lucide-react";

interface RequirementInputProps {
  requirements: string;
  onRequirementsChange: (value: string) => void;
  refinementPrompt: string;
  onRefinementPromptChange: (value: string) => void;
  onGenerate: () => void;
  onRefine: () => void;
  isGenerating: boolean;
  hasArtifacts: boolean;
}

export function RequirementInput({
  requirements,
  onRequirementsChange,
  refinementPrompt,
  onRefinementPromptChange,
  onGenerate,
  onRefine,
  isGenerating,
  hasArtifacts,
}: RequirementInputProps) {
  const [isRefinementOpen, setIsRefinementOpen] = useState(false);
  const charCount = requirements.length;

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Main Input Area */}
      <div className="flex-1 flex flex-col p-6 gap-4 overflow-y-auto">
        <div className="flex-1 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-foreground">Business Requirements</h2>
            <span className="text-xs text-muted-foreground" data-testid="text-char-count">
              {charCount} characters
            </span>
          </div>
          
          <Textarea
            value={requirements}
            onChange={(e) => onRequirementsChange(e.target.value)}
            placeholder="Describe your business requirements...

Example: Create a payments dashboard that displays transactions by region with role-based access control. Include daily email reports and export to CSV functionality. EU data must be restricted to EU region only."
            className="flex-1 min-h-[300px] font-sans text-sm resize-none focus-visible:ring-2"
            data-testid="input-requirements"
          />
        </div>

        {/* Refinement Section */}
        {hasArtifacts && (
          <Collapsible open={isRefinementOpen} onOpenChange={setIsRefinementOpen}>
            <Card className="border-2 border-primary/20">
              <CollapsibleTrigger asChild>
                <button className="w-full p-4 flex items-center justify-between hover-elevate active-elevate-2">
                  <div className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-primary" />
                    <span className="font-medium text-sm">Refine Artifacts</span>
                  </div>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${isRefinementOpen ? "rotate-180" : ""}`}
                  />
                </button>
              </CollapsibleTrigger>
              
              <CollapsibleContent>
                <Separator />
                <div className="p-4 space-y-3">
                  <p className="text-xs text-muted-foreground">
                    Describe changes or additions to the generated artifacts
                  </p>
                  <Textarea
                    value={refinementPrompt}
                    onChange={(e) => onRefinementPromptChange(e.target.value)}
                    placeholder="Example: Add CSV export feature; restrict EU data to EU region only; add audit logging"
                    className="min-h-[100px] text-sm"
                    data-testid="input-refinement"
                  />
                  <Button
                    onClick={onRefine}
                    disabled={isGenerating || !refinementPrompt.trim()}
                    className="w-full"
                    data-testid="button-refine"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    {isGenerating ? "Refining..." : "Apply Refinement"}
                  </Button>
                </div>
              </CollapsibleContent>
            </Card>
          </Collapsible>
        )}
      </div>

      {/* Create Button - Fixed at Bottom */}
      <div className="p-6 pt-0">
        <Button
          onClick={onGenerate}
          disabled={isGenerating || !requirements.trim()}
          size="lg"
          className="w-full shadow-lg"
          data-testid="button-generate"
        >
          <Sparkles className="w-5 h-5 mr-2" />
          {isGenerating ? "Creating..." : "Create a Feature or Project"}
        </Button>
      </div>
    </div>
  );
}
