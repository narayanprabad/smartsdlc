import { useEffect, useRef } from 'react';
import mermaid from 'mermaid';

mermaid.initialize({ startOnLoad: true, theme: 'default' });

export function MermaidDiagram({ code, title }: { code: string; title: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (ref.current && code) {
      try {
        ref.current.innerHTML = '';
        mermaid.contentLoaded();
        const element = document.createElement('div');
        element.className = 'mermaid';
        element.innerHTML = code;
        ref.current.appendChild(element);
        mermaid.contentLoaded();
      } catch (error) {
        console.error('Mermaid render error:', error);
        ref.current.innerHTML = `<pre>${code}</pre>`;
      }
    }
  }, [code]);

  return (
    <div className="space-y-2">
      <h5 className="font-semibold text-sm">{title}</h5>
      <div className="border rounded-lg p-4 bg-muted/50 overflow-x-auto" ref={ref} />
    </div>
  );
}
