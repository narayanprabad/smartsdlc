import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { X, Paperclip, FileText, Image as ImageIcon } from 'lucide-react';
import { Card } from '@/components/ui/card';

export interface UploadedFile {
  name: string;
  size: number;
  type: string;
  base64: string; // raw base64 without data URL prefix
}

interface FileUploadProps {
  onFilesChange: (files: UploadedFile[]) => void;
  maxFiles?: number;
  maxSizeMB?: number;
  accept?: string;
  disabled?: boolean;
}

export function FileUpload({
  onFilesChange,
  maxFiles = 5,
  maxSizeMB = 5,
  accept = 'image/png,image/jpeg,image/gif,image/webp,.txt,.md,.json',
  disabled = false,
}: FileUploadProps) {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    const maxSizeBytes = maxSizeMB * 1024 * 1024;

    const validFiles = selectedFiles.filter(file => {
      if (file.size > maxSizeBytes) {
        alert(`File ${file.name} is too large. Maximum size is ${maxSizeMB}MB`);
        return false;
      }
      return true;
    });

    if (files.length + validFiles.length > maxFiles) {
      alert(`Maximum ${maxFiles} files allowed`);
      return;
    }

    const uploadedFiles: UploadedFile[] = await Promise.all(
      validFiles.map(async file => {
        const dataUrl = await fileToBase64(file);
        // Extract base64 data from Data URL (remove "data:image/png;base64," prefix)
        const base64 = dataUrl.split(',')[1];
        return {
          name: file.name,
          size: file.size,
          type: file.type,
          base64,
        };
      })
    );

    const newFiles = [...files, ...uploadedFiles];
    setFiles(newFiles);
    onFilesChange(newFiles);

    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  const removeFile = (index: number) => {
    const newFiles = files.filter((_, i) => i !== index);
    setFiles(newFiles);
    onFilesChange(newFiles);
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return <ImageIcon className="h-4 w-4" />;
    return <FileText className="h-4 w-4" />;
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={accept}
          onChange={handleFileChange}
          className="hidden"
          disabled={disabled || files.length >= maxFiles}
          data-testid="input-file-upload"
        />
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => inputRef.current?.click()}
          disabled={disabled || files.length >= maxFiles}
          data-testid="button-upload-file"
        >
          <Paperclip className="h-4 w-4 mr-2" />
          Attach Files
        </Button>
        <span className="text-sm text-muted-foreground">
          {files.length}/{maxFiles} files (max {maxSizeMB}MB each)
        </span>
      </div>

      {files.length > 0 && (
        <div className="space-y-1">
          {files.map((file, index) => (
            <Card key={index} className="p-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  {getFileIcon(file.type)}
                  <span className="text-sm truncate">{file.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {formatFileSize(file.size)}
                  </span>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeFile(index)}
                  data-testid={`button-remove-file-${index}`}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
