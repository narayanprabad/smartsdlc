import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronRight, ChevronDown, FileCode, Folder, FolderOpen, ExternalLink, GitBranch } from 'lucide-react';

interface CodeFile {
  name: string;
  path: string;
  content: string;
  language: string;
}

interface CodeFolder {
  name: string;
  files: (CodeFile | CodeFolder)[];
  type: 'folder';
}

interface RepositoryFile {
  path: string;
  type: 'file';
  language: string;
  size: number;
  content: string;
}

interface Repository {
  id: string; // Unique stable identifier for UI
  name: string;
  description: string;
  url: string;
  branch: string;
  files: RepositoryFile[];
}

interface CodeRepositoryProps {
  repositories: Repository[];
}

// Helper to build tree structure from flat file paths
function buildFileTree(flatFiles: RepositoryFile[]): (CodeFile | CodeFolder)[] {
  const root: { [key: string]: any } = {};
  
  flatFiles.forEach(file => {
    const parts = file.path.split('/');
    let current = root;
    
    // Build folder structure
    for (let i = 0; i < parts.length - 1; i++) {
      const part = parts[i];
      if (!current[part]) {
        current[part] = { _isFolder: true, _files: {} };
      }
      current = current[part]._files;
    }
    
    // Add file
    const fileName = parts[parts.length - 1];
    current[fileName] = {
      name: fileName,
      path: file.path,
      content: file.content,
      language: file.language
    };
  });
  
  // Convert to array structure
  function convertToArray(obj: any, name?: string): (CodeFile | CodeFolder)[] {
    const result: (CodeFile | CodeFolder)[] = [];
    
    for (const key in obj) {
      const item = obj[key];
      if (item._isFolder) {
        // It's a folder
        result.push({
          name: key,
          type: 'folder',
          files: convertToArray(item._files)
        });
      } else if (item.path) {
        // It's a file
        result.push(item);
      }
    }
    
    return result;
  }
  
  return convertToArray(root);
}

function FileTreeItem({ item, depth = 0, onFileClick }: { item: CodeFile | CodeFolder; depth?: number; onFileClick: (file: CodeFile) => void }) {
  const [isOpen, setIsOpen] = useState(depth === 0);
  const isFolder = 'type' in item && item.type === 'folder';
  
  if (isFolder) {
    const folder = item as CodeFolder;
    return (
      <div>
        <div
          className="flex items-center gap-2 py-1 px-2 hover-elevate active-elevate-2 cursor-pointer rounded-md"
          style={{ paddingLeft: `${depth * 12 + 8}px` }}
          onClick={() => setIsOpen(!isOpen)}
          data-testid={`folder-${folder.name}`}
        >
          {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          {isOpen ? <FolderOpen className="w-4 h-4 text-blue-500" /> : <Folder className="w-4 h-4 text-blue-500" />}
          <span className="text-sm font-medium">{folder.name}</span>
        </div>
        {isOpen && (
          <div>
            {folder.files.map((child, index) => (
              <FileTreeItem key={index} item={child} depth={depth + 1} onFileClick={onFileClick} />
            ))}
          </div>
        )}
      </div>
    );
  } else {
    const file = item as CodeFile;
    return (
      <div
        className="flex items-center gap-2 py-1 px-2 hover-elevate active-elevate-2 cursor-pointer rounded-md"
        style={{ paddingLeft: `${depth * 12 + 24}px` }}
        onClick={() => onFileClick(file)}
        data-testid={`file-${file.name}`}
      >
        <FileCode className="w-4 h-4 text-green-600" />
        <span className="text-sm">{file.name}</span>
      </div>
    );
  }
}

// Single repository viewer component
function RepositoryViewer({ repo }: { repo: Repository }) {
  const [selectedFile, setSelectedFile] = useState<CodeFile | null>(null);
  const fileTree = buildFileTree(repo.files);
  
  return (
    <div className="grid grid-cols-12 gap-4">
      {/* File Tree Sidebar */}
      <Card className="col-span-4">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <GitBranch className="w-4 h-4" />
                {repo.name}
              </CardTitle>
              <p className="text-xs text-muted-foreground mt-1">{repo.description}</p>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => window.open(repo.url, '_blank')}
              data-testid={`button-open-repo-${repo.name}`}
            >
              <ExternalLink className="w-4 h-4" />
            </Button>
          </div>
          <Badge variant="secondary" className="w-fit text-xs mt-2">
            {repo.branch}
          </Badge>
        </CardHeader>
        <CardContent className="max-h-[500px] overflow-y-auto">
          {fileTree.map((item, index) => (
            <FileTreeItem key={index} item={item} onFileClick={setSelectedFile} />
          ))}
        </CardContent>
      </Card>
      
      {/* Code Viewer */}
      <Card className="col-span-8">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-mono">
              {selectedFile ? selectedFile.path : 'Select a file to view'}
            </CardTitle>
            {selectedFile && (
              <Badge variant="outline">{selectedFile.language}</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {selectedFile ? (
            <pre className="bg-muted p-4 rounded-md overflow-x-auto max-h-[400px] overflow-y-auto">
              <code className="text-sm font-mono">{selectedFile.content}</code>
            </pre>
          ) : (
            <div className="text-muted-foreground text-center py-12">
              Click on a file in the tree to view its contents
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Main component that displays multiple repositories with tabs
export function CodeRepository({ repositories }: CodeRepositoryProps) {
  if (!repositories || repositories.length === 0) {
    return (
      <div className="text-muted-foreground text-center py-12 border rounded-lg">
        No repositories available
      </div>
    );
  }
  
  return (
    <Tabs defaultValue={repositories[0].id} className="w-full">
      <TabsList className="mb-4">
        {repositories.map((repo) => (
          <TabsTrigger 
            key={repo.id} 
            value={repo.id}
            data-testid={`tab-repo-${repo.id}`}
          >
            {repo.name}
          </TabsTrigger>
        ))}
      </TabsList>
      
      {repositories.map((repo) => (
        <TabsContent key={repo.id} value={repo.id}>
          <RepositoryViewer repo={repo} />
        </TabsContent>
      ))}
    </Tabs>
  );
}
