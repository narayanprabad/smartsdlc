import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Building2, ChevronRight, Copy, Check } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import type { ArchitectureComponent } from "@shared/schema";

interface ArchitectureCardProps {
  components: ArchitectureComponent[];
}

export function ArchitectureCard({ components }: ArchitectureCardProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);
  const { toast } = useToast();

  const toggleNode = (id: string) => {
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedNodes(newExpanded);
  };

  const copyCode = async (code: string, componentName: string) => {
    await navigator.clipboard.writeText(code);
    setCopiedSnippet(componentName);
    setTimeout(() => setCopiedSnippet(null), 2000);
    toast({
      title: "Code copied",
      description: `${componentName} code snippet copied to clipboard.`,
    });
  };

  const renderComponent = (component: ArchitectureComponent, level = 0) => {
    const isExpanded = expandedNodes.has(component.id);
    const hasChildren = component.children && component.children.length > 0;
    const indent = level * 16;

    return (
      <div key={component.id} style={{ marginLeft: `${indent}px` }}>
        <Collapsible open={isExpanded} onOpenChange={() => toggleNode(component.id)}>
          <CollapsibleTrigger asChild>
            <button
              className="w-full p-2 rounded-md hover-elevate active-elevate-2 text-left flex items-start gap-2"
              data-testid={`button-arch-${component.id}`}
            >
              {hasChildren && (
                <ChevronRight
                  className={`w-4 h-4 text-muted-foreground mt-0.5 transition-transform ${
                    isExpanded ? "rotate-90" : ""
                  }`}
                />
              )}
              {!hasChildren && <div className="w-4" />}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-sm font-medium text-foreground">{component.name}</span>
                  <Badge variant="outline" className="text-xs">
                    {component.type}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-0.5">{component.description}</p>
              </div>
            </button>
          </CollapsibleTrigger>

          {component.codeSnippet && (
            <div className="mt-2 mb-2">
              <div className="relative rounded-md bg-muted p-4 border">
                <pre className="text-xs font-mono overflow-x-auto">
                  <code>{component.codeSnippet}</code>
                </pre>
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute top-2 right-2"
                  onClick={() => copyCode(component.codeSnippet!, component.name)}
                >
                  {copiedSnippet === component.name ? (
                    <Check className="w-3 h-3" />
                  ) : (
                    <Copy className="w-3 h-3" />
                  )}
                </Button>
              </div>
            </div>
          )}

          {hasChildren && (
            <CollapsibleContent>
              <div className="mt-1 space-y-1">
                {component.children!.map((child) => renderComponent(child, level + 1))}
              </div>
            </CollapsibleContent>
          )}
        </Collapsible>
      </div>
    );
  };

  if (components.length === 0) return null;

  return (
    <Card data-testid="card-architecture">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-medium flex items-center gap-2">
          <Building2 className="w-4 h-4 text-purple-600" />
          Architecture Outline
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-1">
        {components.map((component) => renderComponent(component))}
      </CardContent>
    </Card>
  );
}
