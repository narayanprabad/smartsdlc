import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ListTodo, Circle, Clock, CheckCircle2, XCircle } from "lucide-react";
import type { Task } from "@shared/schema";

interface TasksCardProps {
  tasks: Task[];
}

const statusConfig = {
  not_started: {
    label: "Not Started",
    icon: Circle,
    color: "text-gray-500",
    variant: "secondary" as const,
  },
  in_progress: {
    label: "In Progress",
    icon: Clock,
    color: "text-blue-600",
    variant: "default" as const,
  },
  completed: {
    label: "Completed",
    icon: CheckCircle2,
    color: "text-green-600",
    variant: "default" as const,
  },
  blocked: {
    label: "Blocked",
    icon: XCircle,
    color: "text-red-600",
    variant: "destructive" as const,
  },
};

export function TasksCard({ tasks }: TasksCardProps) {
  if (tasks.length === 0) return null;

  return (
    <Card data-testid="card-tasks">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-medium flex items-center gap-2">
          <ListTodo className="w-4 h-4 text-orange-600" />
          Task Breakdown ({tasks.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[120px]">Role</TableHead>
                <TableHead>Task</TableHead>
                <TableHead className="w-[100px]">Effort</TableHead>
                <TableHead className="w-[140px]">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tasks.map((task) => {
                const config = statusConfig[task.status];
                const StatusIcon = config.icon;
                
                return (
                  <TableRow key={task.id} data-testid={`row-task-${task.id}`}>
                    <TableCell className="font-medium">
                      <Badge variant="outline" className="font-normal">
                        {task.role}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">{task.task}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-xs">
                        {task.effort}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <StatusIcon className={`w-4 h-4 ${config.color}`} />
                        <span className="text-sm">{config.label}</span>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
