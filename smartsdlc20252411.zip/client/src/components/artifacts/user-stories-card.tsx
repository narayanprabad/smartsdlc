import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { BookOpen, ChevronDown, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import type { UserStory } from "@shared/schema";

interface UserStoriesCardProps {
  stories: UserStory[];
}

export function UserStoriesCard({ stories }: UserStoriesCardProps) {
  const [expandedStories, setExpandedStories] = useState<Set<string>>(new Set());

  const toggleStory = (id: string) => {
    const newExpanded = new Set(expandedStories);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedStories(newExpanded);
  };

  if (stories.length === 0) return null;

  return (
    <Card data-testid="card-user-stories">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-medium flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-blue-600" />
          User Stories ({stories.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {stories.map((story) => {
          const isExpanded = expandedStories.has(story.id);
          return (
            <Collapsible key={story.id} open={isExpanded} onOpenChange={() => toggleStory(story.id)}>
              <div className="rounded-md border bg-card hover-elevate">
                <CollapsibleTrigger asChild>
                  <button className="w-full p-3 text-left flex items-start gap-3" data-testid={`button-story-${story.id}`}>
                    <Checkbox className="mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="font-medium text-sm text-foreground">{story.title}</h4>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <Badge variant="secondary" className="text-xs">
                            {story.effort}
                          </Badge>
                          {story.priority && (
                            <Badge
                              variant={story.priority === "high" ? "destructive" : "secondary"}
                              className="text-xs"
                            >
                              {story.priority}
                            </Badge>
                          )}
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{story.description}</p>
                    </div>
                    <ChevronDown
                      className={`w-4 h-4 text-muted-foreground transition-transform flex-shrink-0 ${
                        isExpanded ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                </CollapsibleTrigger>
                
                <CollapsibleContent>
                  <div className="px-3 pb-3 pl-12 space-y-2">
                    <p className="text-xs font-medium text-muted-foreground">Acceptance Criteria:</p>
                    <ul className="space-y-1.5">
                      {story.acceptanceCriteria.map((criteria, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-600 mt-0.5 flex-shrink-0" />
                          <span className="text-foreground">{criteria}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CollapsibleContent>
              </div>
            </Collapsible>
          );
        })}
      </CardContent>
    </Card>
  );
}
