import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronRight } from "lucide-react";
import type { Iteration } from "@shared/schema";
import { format } from "date-fns";

interface VersionTimelineProps {
  iterations: Iteration[];
  currentVersion: number;
  onVersionChange: (version: number) => void;
}

export function VersionTimeline({ iterations, currentVersion, onVersionChange }: VersionTimelineProps) {
  return (
    <div className="h-12 bg-card border-b px-6 flex items-center gap-2 overflow-x-auto">
      <span className="text-xs font-medium text-muted-foreground whitespace-nowrap">Versions:</span>
      <div className="flex items-center gap-1">
        {iterations.map((iteration, index) => (
          <div key={iteration.id} className="flex items-center gap-1">
            <Button
              variant={index === currentVersion ? "default" : "ghost"}
              size="sm"
              onClick={() => onVersionChange(index)}
              className="h-8"
              data-testid={`button-version-${index}`}
            >
              <span className="text-xs font-medium">V{iteration.version}</span>
              {index === currentVersion && (
                <Badge variant="secondary" className="ml-2 text-xs">
                  Current
                </Badge>
              )}
            </Button>
            {index < iterations.length - 1 && (
              <ChevronRight className="w-3 h-3 text-muted-foreground" />
            )}
          </div>
        ))}
      </div>
      {iterations[currentVersion] && (
        <span className="text-xs text-muted-foreground ml-auto whitespace-nowrap" data-testid="text-version-timestamp">
          {format(new Date(iterations[currentVersion].timestamp), "MMM d, yyyy h:mm a")}
        </span>
      )}
    </div>
  );
}
