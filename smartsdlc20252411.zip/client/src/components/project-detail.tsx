import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { FileViewer } from '@/components/FileViewer';
import { ContentRenderer } from './content-renderer';
import { CodeRepository } from './code-repository';
import { AgentChat } from './agent-chat';
import { SprintView } from './sprint-view';
import { ActiveSprintBanner } from './active-sprint-banner';
import { MermaidDiagram } from './mermaid-diagram';
import { CollaboratorRole } from '@shared/schema';
import {
  FileText,
  CheckSquare,
  Shield,
  Code,
  Layers,
  Figma,
  GitBranch,
  TestTube,
  Rocket,
  Lock,
  Edit3,
  Save,
  X,
  Bot,
  Users,
  Workflow,
  AlertTriangle
} from 'lucide-react';

type ProjectSection = {
  id: string;
  title: string;
  icon: any;
  field: string;
  roles: string[];
  color: string;
};

const SECTIONS: ProjectSection[] = [
  {
    id: 'business-overview',
    title: 'Business Context',
    icon: FileText,
    field: 'businessOverview',
    roles: ['Business Analyst'],
    color: 'text-blue-500'
  },
  {
    id: 'functional-requirements',
    title: 'Functional',
    icon: CheckSquare,
    field: 'functionalRequirements',
    roles: ['Business Analyst'],
    color: 'text-blue-500'
  },
  {
    id: 'non-functional-requirements',
    title: 'Non-Functional',
    icon: Shield,
    field: 'nonFunctionalRequirements',
    roles: ['Business Analyst'],
    color: 'text-blue-500'
  },
  {
    id: 'architecture-docs',
    title: 'Architecture Docs',
    icon: Layers,
    field: 'architectureDocs',
    roles: ['Architect'],
    color: 'text-purple-500'
  },
  {
    id: 'figma-links',
    title: 'Design Links',
    icon: Figma,
    field: 'figmaLinks',
    roles: ['Architect'],
    color: 'text-purple-500'
  },
  {
    id: 'flow-diagrams',
    title: 'Flow Diagrams',
    icon: GitBranch,
    field: 'flowDiagrams',
    roles: ['Architect'],
    color: 'text-purple-500'
  },
  {
    id: 'development-docs',
    title: 'Development Docs',
    icon: Code,
    field: 'developmentDocs',
    roles: ['Developer'],
    color: 'text-green-500'
  },
  {
    id: 'testing-docs',
    title: 'Testing Docs',
    icon: TestTube,
    field: 'testingDocs',
    roles: ['Developer'],
    color: 'text-green-500'
  },
  {
    id: 'deployment-docs',
    title: 'Deployment Docs',
    icon: Rocket,
    field: 'deploymentDocs',
    roles: ['Developer'],
    color: 'text-orange-500'
  },
];

type ProjectDetailProps = {
  projectId: string;
  userRole: string;
  userName: string;
  userAvatar?: string;
};

export function ProjectDetail({ projectId, userRole, userName, userAvatar }: ProjectDetailProps) {
  const [editingSection, setEditingSection] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Fetch project details
  const { data: projectResponse, isLoading } = useQuery({
    queryKey: ['/api/projects', projectId],
    enabled: !!projectId,
  });
  
  // Fetch collaborators separately
  const { data: collaborators = [] } = useQuery({
    queryKey: ['/api/projects', projectId, 'collaborators'],
    enabled: !!projectId,
  });
  
  const project = (projectResponse as any)?.project;
  const iterations = (projectResponse as any)?.iterations || [];
  
  // Get the latest iteration's artifacts
  const latestIteration = iterations.length > 0 ? iterations[iterations.length - 1] : null;
  const artifacts = latestIteration?.artifacts || null;
  
  const validRoles = ['Owner', 'Architect', 'Business Analyst', 'Developer', 'Scrum Master'];
  const canUseAIAssistant = validRoles.includes(userRole);

  const updateSection = useMutation({
    mutationFn: async (data: { field: string; value: string }) => {
      if (!project) {
        throw new Error('Project not loaded');
      }
      return apiRequest('PATCH', `/api/projects/${projectId}`, {
        [data.field]: data.value
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId] });
      setEditingSection(null);
      setEditValue('');
    }
  });

  const canEdit = (section: ProjectSection) => {
    return section.roles.includes(userRole);
  };

  const startEditing = (section: ProjectSection) => {
    if (!project) return;
    
    const currentValue = project[section.field] || '';
    setEditValue(currentValue);
    setEditingSection(section.id);
  };

  const saveSection = (section: ProjectSection) => {
    updateSection.mutate({
      field: section.field,
      value: editValue
    });
  };

  const cancelEditing = () => {
    setEditingSection(null);
    setEditValue('');
  };

  const renderSection = (section: ProjectSection) => {
    const SectionIcon = section.icon;
    const isEditing = editingSection === section.id;
    const hasEditAccess = canEdit(section);
    const content = project?.[section.field] || '';

    return (
      <Card
        key={section.id}
        className="overflow-hidden border-2"
        data-testid={`card-section-${section.id}`}
      >
        <div className={`px-6 py-4 border-b bg-gradient-to-r ${
          section.roles.includes('Business Analyst') 
            ? 'from-blue-500/10 to-blue-500/5 border-blue-500/20'
            : section.roles.includes('Architect')
            ? 'from-purple-500/10 to-purple-500/5 border-purple-500/20'
            : 'from-green-500/10 to-green-500/5 border-green-500/20'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${
                section.roles.includes('Business Analyst')
                  ? 'bg-blue-500/20'
                  : section.roles.includes('Architect')
                  ? 'bg-purple-500/20'
                  : 'bg-green-500/20'
              }`}>
                <SectionIcon className={`w-5 h-5 ${section.color}`} />
              </div>
              <div>
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  {section.title}
                  {!hasEditAccess && (
                    <Lock className="w-4 h-4 text-muted-foreground" />
                  )}
                </h3>
                <p className="text-xs text-muted-foreground">
                  Editable by: {section.roles.join(', ')}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {hasEditAccess && !isEditing && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => startEditing(section)}
                  data-testid={`button-edit-${section.id}`}
                >
                  <Edit3 className="w-4 h-4 mr-2" />
                  Edit
                </Button>
              )}
              {isEditing && (
                <>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={cancelEditing}
                    data-testid={`button-cancel-${section.id}`}
                  >
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => saveSection(section)}
                    disabled={updateSection.isPending}
                    data-testid={`button-save-${section.id}`}
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {updateSection.isPending ? 'Saving...' : 'Save'}
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="p-6">
          {isEditing ? (
            <Textarea
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              placeholder={`Enter ${section.title.toLowerCase()}...`}
              className="min-h-[300px] font-mono text-sm"
              data-testid={`textarea-${section.id}`}
            />
          ) : (
            <div className="min-h-[100px]">
              {content ? (
                <>
                  <ContentRenderer content={content} />
                  
                  {section.id === 'development-docs' && project?.developerResources?.repositories && project.developerResources.repositories.length > 0 && (
                    <div className="mt-8">
                      <h2 className="text-xl font-bold mb-4 flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-green-500/20">
                          <Code className="w-5 h-5 text-green-500" />
                        </div>
                        <div>
                          <div className="text-lg font-semibold">Code Repositories</div>
                          <p className="text-xs font-normal text-muted-foreground">
                            Segregated frontend and backend with Jenkins CI/CD pipelines
                          </p>
                        </div>
                      </h2>
                      <CodeRepository repositories={project.developerResources.repositories} />
                    </div>
                  )}
                </>
              ) : (
                <div className="text-muted-foreground italic text-center py-8">
                  {hasEditAccess 
                    ? `Click "Edit" to add ${section.title.toLowerCase()}`
                    : `No ${section.title.toLowerCase()} added yet`
                  }
                </div>
              )}
            </div>
          )}
        </div>
      </Card>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-full">
      {/* Main Content */}
      <div className="flex-1 min-w-0 space-y-6 lg:basis-[70%]">
        {/* Project Header */}
        <Card className="p-6 bg-gradient-to-br from-card to-card/50 border-2">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <Avatar className="w-16 h-16 border-4 border-primary/20">
                <AvatarImage src={userAvatar} alt={userName} />
                <AvatarFallback className="text-2xl font-bold bg-gradient-to-br from-primary/20 to-accent/20">
                  {userName?.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-3xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
                  {(project as any)?.name}
                </h2>
                <p className="text-muted-foreground mt-1">
                  {(project as any)?.description}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="secondary">{userName}</Badge>
                  <Badge className="bg-gradient-to-r from-primary/80 to-accent/80 text-primary-foreground">
                    {userRole}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Active Sprint Banner - Sticky at top */}
        <ActiveSprintBanner projectId={projectId} />

        {/* Tabbed Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-7 h-auto" data-testid="tabs-list-project">
            <TabsTrigger value="overview" className="gap-2" data-testid="tab-overview">
              <FileText className="w-4 h-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="requirements" className="gap-2" data-testid="tab-requirements">
              <CheckSquare className="w-4 h-4" />
              Requirements
            </TabsTrigger>
            <TabsTrigger value="architecture" className="gap-2" data-testid="tab-architecture">
              <Layers className="w-4 h-4" />
              Architecture
            </TabsTrigger>
            <TabsTrigger value="development" className="gap-2" data-testid="tab-development">
              <Code className="w-4 h-4" />
              Development
            </TabsTrigger>
            <TabsTrigger value="qa" className="gap-2" data-testid="tab-qa">
              <TestTube className="w-4 h-4" />
              QA
            </TabsTrigger>
            <TabsTrigger value="production" className="gap-2" data-testid="tab-production">
              <Rocket className="w-4 h-4" />
              Production
            </TabsTrigger>
            <TabsTrigger value="scrum" className="gap-2" data-testid="tab-scrum">
              <Workflow className="w-4 h-4" />
              Scrum
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6 mt-6">
            {renderSection(SECTIONS.find(s => s.id === 'business-overview')!)}
          </TabsContent>

          {/* Requirements Tab */}
          <TabsContent value="requirements" className="space-y-6 mt-6">
            {/* Show AI-generated user stories if available */}
            {artifacts?.userStories && artifacts.userStories.length > 0 && (
              <Card className="overflow-hidden border-2" data-testid="card-user-stories">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-blue-500/10 to-blue-500/5 border-blue-500/20">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-blue-500/20">
                      <CheckSquare className="w-5 h-5 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">User Stories</h3>
                      <p className="text-xs text-muted-foreground">
                        AI-generated from requirements
                      </p>
                    </div>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  {artifacts.userStories.map((story: any, index: number) => (
                    <div key={story.id} className="border rounded-lg p-4 space-y-2" data-testid={`user-story-${index}`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" data-testid={`badge-story-id-${index}`}>{story.id}</Badge>
                            {story.priority && (
                              <Badge 
                                variant={story.priority === 'high' ? 'destructive' : story.priority === 'medium' ? 'default' : 'secondary'}
                                data-testid={`badge-priority-${index}`}
                              >
                                {story.priority}
                              </Badge>
                            )}
                            <Badge variant="outline" data-testid={`badge-effort-${index}`}>{story.effort}</Badge>
                          </div>
                          <h4 className="font-semibold mt-2" data-testid={`text-story-title-${index}`}>{story.title}</h4>
                          <p className="text-sm text-muted-foreground mt-1" data-testid={`text-story-desc-${index}`}>{story.description}</p>
                        </div>
                      </div>
                      {story.acceptanceCriteria && story.acceptanceCriteria.length > 0 && (
                        <div className="mt-3 pt-3 border-t">
                          <p className="text-xs font-semibold text-muted-foreground mb-2">Acceptance Criteria:</p>
                          <ul className="list-disc list-inside space-y-1 text-sm">
                            {story.acceptanceCriteria.map((criterion: string, i: number) => (
                              <li key={i} data-testid={`text-criterion-${index}-${i}`}>{criterion}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </Card>
            )}
            
            {/* Show AI-generated functional requirements if available */}
            {artifacts?.functionalRequirements && artifacts.functionalRequirements.length > 0 && (
              <Card className="overflow-hidden border-2" data-testid="card-functional-requirements">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-blue-500/10 to-blue-500/5 border-blue-500/20">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-blue-500/20">
                      <CheckSquare className="w-5 h-5 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">Functional Requirements</h3>
                      <p className="text-xs text-muted-foreground">
                        AI-generated requirements
                      </p>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <ul className="list-disc list-inside space-y-2">
                    {artifacts.functionalRequirements.map((req: any, i: number) => (
                      <li key={i} className="text-sm" data-testid={`text-func-req-${i}`}>
                        {typeof req === 'string' ? req : (
                          <span>
                            <span className="font-mono text-xs text-muted-foreground">[{req.id}]</span> {req.requirement}
                            {req.priority && <span className="ml-2 text-xs text-muted-foreground">({req.priority})</span>}
                          </span>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              </Card>
            )}
            
            {/* Show AI-generated non-functional requirements if available */}
            {artifacts?.nonFunctionalRequirements && (
              <Card className="overflow-hidden border-2" data-testid="card-non-functional-requirements">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-blue-500/10 to-blue-500/5 border-blue-500/20">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-blue-500/20">
                      <Shield className="w-5 h-5 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">Non-Functional Requirements</h3>
                      <p className="text-xs text-muted-foreground">
                        AI-generated NFRs
                      </p>
                    </div>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  {Object.entries(artifacts.nonFunctionalRequirements).map(([category, items]: [string, any]) => (
                    items && items.length > 0 && (
                      <div key={category}>
                        <h4 className="font-semibold text-sm capitalize mb-2">{category}</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                          {items.map((item: string, i: number) => (
                            <li key={i} data-testid={`text-nfr-${category}-${i}`}>{item}</li>
                          ))}
                        </ul>
                      </div>
                    )
                  ))}
                </div>
              </Card>
            )}
            
            {/* Fallback to text fields if no artifacts */}
            {!artifacts && (
              <>
                {renderSection(SECTIONS.find(s => s.id === 'functional-requirements')!)}
                {renderSection(SECTIONS.find(s => s.id === 'non-functional-requirements')!)}
              </>
            )}
          </TabsContent>

          {/* Architecture Tab */}
          <TabsContent value="architecture" className="space-y-6 mt-6">
            {/* AI-generated Architecture Components */}
            {artifacts?.architectureOutline && artifacts.architectureOutline.length > 0 && (
              <Card className="overflow-hidden border-2">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-purple-500/10 to-purple-500/5 border-purple-500/20">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-purple-500/20">
                      <Layers className="w-5 h-5 text-purple-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">Architecture Components</h3>
                      <p className="text-xs text-muted-foreground">AI-generated components</p>
                    </div>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  {artifacts.architectureOutline.map((comp: any, index: number) => (
                    <div key={index} className="border rounded-lg p-4 space-y-2">
                      <h4 className="font-semibold">{comp.component}</h4>
                      <p className="text-sm text-muted-foreground">{comp.description}</p>
                      {comp.technologies && comp.technologies.length > 0 && (
                        <div className="flex gap-1 flex-wrap">
                          {comp.technologies.map((tech: string, i: number) => (
                            <Badge key={i} variant="secondary" className="text-xs">{tech}</Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* AI-generated Architecture Diagrams */}
            {artifacts?.architectureDiagrams && artifacts.architectureDiagrams.length > 0 && (
              <Card className="overflow-hidden border-2">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-purple-500/10 to-purple-500/5 border-purple-500/20">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-purple-500/20">
                      <GitBranch className="w-5 h-5 text-purple-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">Architecture Diagrams</h3>
                      <p className="text-xs text-muted-foreground">Visual architecture flows</p>
                    </div>
                  </div>
                </div>
                <div className="p-6 space-y-6">
                  {artifacts.architectureDiagrams.map((diagram: any, index: number) => (
                    <div key={index} className="border rounded-lg p-4 space-y-3">
                      <div>
                        <h4 className="font-semibold">{diagram.title}</h4>
                        <Badge variant="outline" className="mt-1 text-xs">{diagram.type}</Badge>
                        <p className="text-sm text-muted-foreground mt-2">{diagram.description}</p>
                      </div>
                      <MermaidDiagram code={diagram.mermaidCode} title={diagram.title} />
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* AI-generated Well-Architected Principles */}
            {artifacts?.wellArchitectedPillars && (
              <Card className="overflow-hidden border-2">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-purple-500/10 to-purple-500/5 border-purple-500/20">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-purple-500/20">
                      <Shield className="w-5 h-5 text-purple-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">AWS Well-Architected Framework</h3>
                      <p className="text-xs text-muted-foreground">Architecture best practices</p>
                    </div>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  {Object.entries(artifacts.wellArchitectedPillars).map(([pillar, items]: [string, any]) => (
                    items && items.length > 0 && (
                      <div key={pillar}>
                        <h4 className="font-semibold text-sm capitalize mb-2">{pillar.replace(/([A-Z])/g, ' $1')}</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                          {items.map((item: string, i: number) => (
                            <li key={i}>{item}</li>
                          ))}
                        </ul>
                      </div>
                    )
                  ))}
                </div>
              </Card>
            )}
          </TabsContent>

          {/* Development Tab */}
          <TabsContent value="development" className="space-y-6 mt-6">
            {/* Code Files - GitHub-like File Viewer */}
            {artifacts?.codeFiles && artifacts.codeFiles.length > 0 && (
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 rounded-lg bg-green-500/20">
                    <Code className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Source Code Files</h3>
                    <p className="text-xs text-muted-foreground">Browse and view production-ready code</p>
                  </div>
                </div>
                <FileViewer files={artifacts.codeFiles} />
              </div>
            )}

            {/* Development Guide */}
            {artifacts?.developmentGuide && (
              <Card className="overflow-hidden border-2">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-blue-500/10 to-blue-500/5 border-blue-500/20">
                  <h3 className="text-lg font-semibold">Development Guide</h3>
                  <p className="text-xs text-muted-foreground">Setup, conventions, and dependencies</p>
                </div>
                <div className="p-6 space-y-6">
                  {artifacts.developmentGuide.setupInstructions && (
                    <div>
                      <h4 className="font-semibold mb-3">Setup Instructions</h4>
                      <ol className="list-decimal list-inside space-y-1 text-sm">
                        {artifacts.developmentGuide.setupInstructions.map((inst: string, i: number) => (
                          <li key={i}>{inst}</li>
                        ))}
                      </ol>
                    </div>
                  )}
                  {artifacts.developmentGuide.technologyStack && (
                    <div>
                      <h4 className="font-semibold mb-3">Technology Stack</h4>
                      <ul className="space-y-1 text-sm">
                        {artifacts.developmentGuide.technologyStack.map((tech: string, i: number) => (
                          <li key={i} className="flex gap-2"><span>•</span> {tech}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {artifacts.developmentGuide.codeConventions && (
                    <div>
                      <h4 className="font-semibold mb-3">Code Conventions</h4>
                      <ul className="space-y-1 text-sm">
                        {artifacts.developmentGuide.codeConventions.map((conv: string, i: number) => (
                          <li key={i} className="flex gap-2"><span>•</span> {conv}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {artifacts.developmentGuide.dependencies && (
                    <div>
                      <h4 className="font-semibold mb-3">Dependencies</h4>
                      <div className="space-y-3 text-sm">
                        {Array.isArray(artifacts.developmentGuide.dependencies) ? (
                          artifacts.developmentGuide.dependencies.map((dep: any, i: number) => (
                            <div key={i} className="border rounded p-2">
                              <p className="font-mono font-semibold">{dep.name}@{dep.version}</p>
                              <p className="text-muted-foreground">{dep.purpose}</p>
                            </div>
                          ))
                        ) : (
                          <>
                            {artifacts.developmentGuide.dependencies.runtime && (
                              <div>
                                <h5 className="font-medium mb-2">Runtime Dependencies</h5>
                                <ul className="space-y-1 ml-4">
                                  {artifacts.developmentGuide.dependencies.runtime.map((dep: string, i: number) => (
                                    <li key={i} className="font-mono text-xs">• {dep}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                            {artifacts.developmentGuide.dependencies.development && (
                              <div>
                                <h5 className="font-medium mb-2">Development Dependencies</h5>
                                <ul className="space-y-1 ml-4">
                                  {artifacts.developmentGuide.dependencies.development.map((dep: string, i: number) => (
                                    <li key={i} className="font-mono text-xs">• {dep}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  )}
                  {artifacts.developmentGuide.environmentVariables && (
                    <div>
                      <h4 className="font-semibold mb-3">Environment Variables</h4>
                      <div className="space-y-2 text-sm">
                        {artifacts.developmentGuide.environmentVariables.map((env: any, i: number) => (
                          <div key={i} className="border rounded p-2">
                            <p className="font-mono font-semibold">{env.name}</p>
                            <p className="text-muted-foreground">{env.description}</p>
                            <p className="text-xs text-muted-foreground">Example: {env.example}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            )}
          </TabsContent>

          {/* QA Tab */}
          <TabsContent value="qa" className="space-y-6 mt-6">
            {/* Test Cases */}
            {artifacts?.testCases && artifacts.testCases.length > 0 && (
              <Card className="overflow-hidden border-2">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-blue-500/10 to-blue-500/5 border-blue-500/20">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-blue-500/20">
                      <TestTube className="w-5 h-5 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">Automated Test Scripts</h3>
                      <p className="text-xs text-muted-foreground">Jest test cases with full code</p>
                    </div>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  {artifacts.testCases.map((test: any) => (
                    <div key={test.id} className="border rounded-lg p-4 space-y-3">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="secondary">{test.testType}</Badge>
                          <Badge variant="outline">{test.language}</Badge>
                        </div>
                        <p className="text-sm font-semibold">{test.testName}</p>
                        <p className="text-xs text-muted-foreground">{test.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">Expected: {test.expectedResult}</p>
                      </div>
                      <details className="mt-2">
                        <summary className="cursor-pointer text-sm font-medium text-blue-600">View Test Code</summary>
                        <pre className="mt-3 bg-muted p-4 rounded text-xs overflow-x-auto max-h-[400px] overflow-y-auto">
                          <code>{test.testCode}</code>
                        </pre>
                      </details>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Code Review Guidelines */}
            {artifacts?.codeReviewGuidelines && artifacts.codeReviewGuidelines.length > 0 && (
              <Card className="overflow-hidden border-2">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-purple-500/10 to-purple-500/5 border-purple-500/20">
                  <h3 className="text-lg font-semibold">Code Review Guidelines</h3>
                  <p className="text-xs text-muted-foreground">Review standards and checklists</p>
                </div>
                <div className="p-6 space-y-4">
                  {artifacts.codeReviewGuidelines.map((guideline: any, i: number) => (
                    <div key={i} className="border rounded-lg p-4 space-y-3">
                      <h4 className="font-semibold">{guideline.category}</h4>
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground mb-2">Guidelines:</p>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          {guideline.guidelines.map((g: string, gi: number) => (
                            <li key={gi}>{g}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground mb-2">Review Checklist:</p>
                        <ul className="space-y-1 text-sm">
                          {guideline.checklist.map((item: string, ci: number) => (
                            <li key={ci} className="flex gap-2 items-start">
                              <input type="checkbox" className="mt-1" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </TabsContent>

          {/* Production Tab */}
          <TabsContent value="production" className="space-y-6 mt-6">
            {/* Production Tickets/Incidents */}
            {artifacts?.productionTickets && artifacts.productionTickets.length > 0 && (
              <Card className="overflow-hidden border-2">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-red-500/10 to-red-500/5 border-red-500/20">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-red-500/20">
                      <AlertTriangle className="w-5 h-5 text-red-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">Production Incidents & Issues</h3>
                      <p className="text-xs text-muted-foreground">Active and recent production tickets</p>
                    </div>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  {artifacts.productionTickets.map((ticket: any) => {
                    const severityColors = {
                      critical: 'destructive',
                      high: 'default',
                      medium: 'secondary',
                      low: 'outline'
                    };
                    const statusColors = {
                      open: 'destructive',
                      investigating: 'default',
                      resolved: 'secondary',
                      closed: 'outline'
                    };
                    const assignee = ticket.assignedTo ? collaborators.find((c: any) => c.userId === ticket.assignedTo) : null;
                    
                    return (
                      <div key={ticket.id} className="border rounded-lg p-4 space-y-3" data-testid={`card-production-ticket-${ticket.id}`}>
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge variant="outline" data-testid={`badge-ticket-id-${ticket.id}`}>{ticket.id}</Badge>
                              <Badge variant={severityColors[ticket.severity as keyof typeof severityColors] as any} data-testid={`badge-severity-${ticket.id}`}>
                                {ticket.severity.toUpperCase()}
                              </Badge>
                              <Badge variant={statusColors[ticket.status as keyof typeof statusColors] as any} data-testid={`badge-status-${ticket.id}`}>
                                {ticket.status}
                              </Badge>
                              <Badge variant="secondary" className="text-xs" data-testid={`badge-service-${ticket.id}`}>
                                {ticket.affectedService}
                              </Badge>
                            </div>
                            <h4 className="font-semibold" data-testid={`text-title-${ticket.id}`}>{ticket.title}</h4>
                            <p className="text-sm text-muted-foreground" data-testid={`text-description-${ticket.id}`}>{ticket.description}</p>
                            
                            {ticket.rootCause && (
                              <div className="text-sm bg-muted/50 p-3 rounded">
                                <p className="font-semibold text-xs text-muted-foreground mb-1">Root Cause:</p>
                                <p data-testid={`text-rootcause-${ticket.id}`}>{ticket.rootCause}</p>
                              </div>
                            )}
                            
                            {ticket.resolution && (
                              <div className="text-sm bg-green-500/10 dark:bg-green-500/20 p-3 rounded">
                                <p className="font-semibold text-xs text-green-700 dark:text-green-300 mb-1">Resolution:</p>
                                <p className="text-foreground" data-testid={`text-resolution-${ticket.id}`}>{ticket.resolution}</p>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
                          <div className="flex items-center gap-4">
                            {assignee && (
                              <div className="flex items-center gap-2" data-testid={`container-assignee-${ticket.id}`}>
                                <Avatar className="w-5 h-5">
                                  <AvatarFallback className="text-xs bg-primary/10">
                                    {assignee.userName?.split(' ').map((n: string) => n[0]).join('') || 'U'}
                                  </AvatarFallback>
                                </Avatar>
                                <span data-testid={`text-assignee-${ticket.id}`}>{assignee.userName}</span>
                              </div>
                            )}
                            <span data-testid={`text-created-${ticket.id}`}>Created: {new Date(ticket.createdAt).toLocaleDateString()}</span>
                            {ticket.resolvedAt && (
                              <span data-testid={`text-resolved-${ticket.id}`}>Resolved: {new Date(ticket.resolvedAt).toLocaleDateString()}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            )}
            
            {/* AI-generated DevOps Tasks */}
            {artifacts?.tasks && artifacts.tasks.length > 0 && (
              <Card className="overflow-hidden border-2">
                <div className="px-6 py-4 border-b bg-gradient-to-r from-orange-500/10 to-orange-500/5 border-orange-500/20">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-orange-500/20">
                      <Rocket className="w-5 h-5 text-orange-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">DevOps & Production Tasks</h3>
                      <p className="text-xs text-muted-foreground">Infrastructure and deployment work items</p>
                    </div>
                  </div>
                </div>
                <div className="p-6 space-y-3">
                  {artifacts.tasks
                    .filter((task: any) => ['DevOps Engineer', 'Security Engineer'].includes(task.role))
                    .map((task: any, index: number) => (
                      <div key={task.id} className="border rounded-lg p-4 space-y-2">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary">{task.id}</Badge>
                              <Badge variant="outline">{task.role}</Badge>
                              <Badge>{task.effort}</Badge>
                            </div>
                            <h4 className="font-semibold mt-2">{task.task}</h4>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </Card>
            )}
          </TabsContent>

          {/* Scrum Tab */}
          <TabsContent value="scrum" className="space-y-6 mt-6">
            <SprintView projectId={projectId} collaborators={collaborators as any[]} />
          </TabsContent>
        </Tabs>
      </div>

      {/* AI Assistant Fixed Right Panel - Always Visible */}
      <div className="w-full lg:basis-[30%] lg:max-w-[500px] lg:min-w-[350px] flex-shrink-0">
        <Card className="sticky top-6 h-[calc(100vh-8rem)] flex flex-col overflow-hidden">
          <div className="flex-1 overflow-hidden">
            <AgentChat
              projectId={projectId}
              userRole={userRole as CollaboratorRole}
              projectName={(project as any)?.name || 'Project'}
              onSectionUpdate={() => {
                queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId] });
              }}
            />
          </div>
        </Card>
      </div>
    </div>
  );
}
