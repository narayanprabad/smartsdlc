import { MermaidDiagram } from './MermaidDiagram';

interface ContentRendererProps {
  content: string;
  className?: string;
}

// Parse content and extract Mermaid diagrams
function parseContent(content: string) {
  const parts: Array<{ type: 'text' | 'mermaid' | 'repository'; content: string; title?: string }> = [];
  const lines = content.split('\n');
  
  let currentText: string[] = [];
  let currentMermaid: string[] = [];
  let inMermaidBlock = false;
  let mermaidTitle = 'Diagram';
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    // Check for mermaid code block start
    if (line.trim() === '```mermaid' || line.trim().startsWith('```mermaid')) {
      // Save any accumulated text
      if (currentText.length > 0) {
        parts.push({ type: 'text', content: currentText.join('\n') });
        currentText = [];
      }
      
      // Look for title in previous lines (e.g., "## User Registration Flow")
      for (let j = i - 1; j >= Math.max(0, i - 3); j--) {
        const prevLine = lines[j].trim();
        if (prevLine.startsWith('##')) {
          mermaidTitle = prevLine.replace(/^#+\s*/, '');
          break;
        }
      }
      
      inMermaidBlock = true;
      continue;
    }
    
    // Check for code block end
    if (inMermaidBlock && line.trim() === '```') {
      parts.push({
        type: 'mermaid',
        content: currentMermaid.join('\n'),
        title: mermaidTitle
      });
      currentMermaid = [];
      inMermaidBlock = false;
      mermaidTitle = 'Diagram';
      continue;
    }
    
    // Accumulate content
    if (inMermaidBlock) {
      currentMermaid.push(line);
    } else {
      currentText.push(line);
    }
  }
  
  // Save any remaining text
  if (currentText.length > 0) {
    parts.push({ type: 'text', content: currentText.join('\n') });
  }
  
  return parts;
}

export function ContentRenderer({ content, className = '' }: ContentRendererProps) {
  const parts = parseContent(content);
  
  return (
    <div className={className}>
      {parts.map((part, index) => {
        if (part.type === 'mermaid') {
          return (
            <div key={index} className="my-6">
              <MermaidDiagram
                code={part.content}
                title={part.title || 'Diagram'}
              />
            </div>
          );
        } else {
          // Render text content with basic markdown formatting
          const formattedContent = part.content
            .split('\n')
            .map((line, lineIndex) => {
              // Headers
              if (line.startsWith('### ')) {
                return <h3 key={lineIndex} className="text-lg font-semibold mt-4 mb-2">{line.substring(4)}</h3>;
              }
              if (line.startsWith('## ')) {
                return <h2 key={lineIndex} className="text-xl font-bold mt-6 mb-3">{line.substring(3)}</h2>;
              }
              if (line.startsWith('# ')) {
                return <h1 key={lineIndex} className="text-2xl font-bold mt-8 mb-4">{line.substring(2)}</h1>;
              }
              
              // Code blocks (non-mermaid)
              if (line.startsWith('```')) {
                return null; // Skip code block markers
              }
              
              // Bullet points
              if (line.trim().startsWith('- ')) {
                return (
                  <li key={lineIndex} className="ml-4 list-disc">
                    {line.trim().substring(2)}
                  </li>
                );
              }
              
              // Numbered lists
              const numberedMatch = line.trim().match(/^(\d+)\.\s+(.+)/);
              if (numberedMatch) {
                return (
                  <li key={lineIndex} className="ml-4 list-decimal">
                    {numberedMatch[2]}
                  </li>
                );
              }
              
              // Bold text
              const boldLine = line.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
              
              // Inline code
              const codeLine = boldLine.replace(/`([^`]+)`/g, '<code class="bg-muted px-1 py-0.5 rounded text-sm">$1</code>');
              
              // Empty lines
              if (!line.trim()) {
                return <br key={lineIndex} />;
              }
              
              return (
                <p
                  key={lineIndex}
                  className="leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: codeLine }}
                />
              );
            });
          
          return (
            <div key={index} className="prose prose-sm max-w-none">
              {formattedContent}
            </div>
          );
        }
      })}
    </div>
  );
}
