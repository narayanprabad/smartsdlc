import { useState, useMemo, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { CodeFile } from '@shared/schema';
import { FileViewer } from './FileViewer';
import { Code2, Settings, Rocket, AlertCircle, BookOpen, Server, Globe } from 'lucide-react';

interface DevelopmentTabProps {
  codeFiles: CodeFile[];
}

export function DevelopmentTab({ codeFiles }: DevelopmentTabProps) {
  const [selectedFrontendLanguage, setSelectedFrontendLanguage] = useState<string>('');
  const [selectedBackendLanguage, setSelectedBackendLanguage] = useState<string>('');

  const { frontendFiles, backendFiles, frontendLanguages, backendLanguages } = useMemo(() => {
    const isFrontend = (file: CodeFile) => {
      const path = file.path.toLowerCase();
      return path.includes('/frontend/') || path.includes('/client/') || 
             path.includes('/app/') || path.includes('/pages/') ||
             path.includes('/components/') || path.startsWith('frontend/') ||
             path.startsWith('client/') || path.startsWith('app/');
    };
    
    const frontend = codeFiles.filter(isFrontend);
    const backend = codeFiles.filter(f => !isFrontend(f));
    
    const frontendLangs = Array.from(new Set(frontend.map(f => f.language))).sort();
    const backendLangs = Array.from(new Set(backend.map(f => f.language))).sort();
    
    return {
      frontendFiles: frontend,
      backendFiles: backend,
      frontendLanguages: frontendLangs,
      backendLanguages: backendLangs
    };
  }, [codeFiles]);

  // Initialize selected languages when available
  useEffect(() => {
    if (!selectedFrontendLanguage && frontendLanguages.length > 0) {
      setSelectedFrontendLanguage(frontendLanguages[0]);
    }
  }, [frontendLanguages, selectedFrontendLanguage]);

  useEffect(() => {
    if (!selectedBackendLanguage && backendLanguages.length > 0) {
      setSelectedBackendLanguage(backendLanguages[0]);
    }
  }, [backendLanguages, selectedBackendLanguage]);

  const filteredFrontendFiles = frontendFiles.filter(f => f.language === selectedFrontendLanguage);
  const filteredBackendFiles = backendFiles.filter(f => f.language === selectedBackendLanguage);

  return (
    <Tabs defaultValue="frontend" className="w-full" data-testid="tabs-development">
      <TabsList className="grid w-full grid-cols-2" data-testid="tabslist-development-main">
        <TabsTrigger value="frontend" data-testid="tab-trigger-frontend">
          <Globe className="h-4 w-4 mr-2" />
          Frontend
        </TabsTrigger>
        <TabsTrigger value="backend" data-testid="tab-trigger-backend">
          <Server className="h-4 w-4 mr-2" />
          Backend
        </TabsTrigger>
      </TabsList>

      <TabsContent value="frontend" className="space-y-4 mt-4" data-testid="tab-content-frontend">
        <Card data-testid="card-frontend-overview">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Frontend Overview
            </CardTitle>
            <CardDescription>Next.js 14 with TypeScript, TailwindCSS, and modern React patterns</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Quick Setup
              </h4>
              <div className="bg-muted p-3 rounded-md text-sm space-y-1">
                <code className="block">npm install</code>
                <code className="block">npm run dev</code>
                <code className="block">Open http://localhost:3000</code>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Rocket className="h-4 w-4" />
                Key Features
              </h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Real-time position tracking dashboard</li>
                <li>• Responsive trader ID management interface</li>
                <li>• Form 102 report generation wizard</li>
                <li>• Secure mTLS CFTC submission gateway</li>
                <li>• Audit trail visualization</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Code2 className="h-4 w-4" />
                Architecture Patterns
              </h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Next.js App Router with server components</li>
                <li>• TanStack Query for data fetching and caching</li>
                <li>• Zod schemas for runtime validation</li>
                <li>• TailwindCSS + shadcn/ui components</li>
                <li>• TypeScript strict mode enabled</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                Development Tips
              </h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Use environment variables for API endpoints (NEXT_PUBLIC_ prefix)</li>
                <li>• Enable React DevTools for component debugging</li>
                <li>• Run `npm run type-check` before committing</li>
                <li>• Follow atomic commit patterns for feature branches</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {frontendLanguages.length > 0 && (
          <Card data-testid="card-frontend-code">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Frontend Implementation</CardTitle>
                <Tabs value={selectedFrontendLanguage} onValueChange={setSelectedFrontendLanguage}>
                  <TabsList data-testid="tabslist-frontend-language">
                    {frontendLanguages.map(lang => (
                      <TabsTrigger 
                        key={lang} 
                        value={lang}
                        data-testid={`tab-trigger-frontend-${lang.toLowerCase()}`}
                      >
                        {lang}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
              </div>
              <CardDescription>
                {filteredFrontendFiles.length} file{filteredFrontendFiles.length !== 1 ? 's' : ''} • {selectedFrontendLanguage}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px]">
                {filteredFrontendFiles.length > 0 ? (
                  <FileViewer files={filteredFrontendFiles} />
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    No frontend files available for {selectedFrontendLanguage}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        )}
      </TabsContent>

      <TabsContent value="backend" className="space-y-4 mt-4" data-testid="tab-content-backend">
        <Card data-testid="card-backend-overview">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Backend Overview
            </CardTitle>
            <CardDescription>Multi-language microservices architecture with unified API contracts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Quick Setup
              </h4>
              <div className="bg-muted p-3 rounded-md text-sm space-y-2">
                <div>
                  <strong>JavaScript/TypeScript:</strong>
                  <code className="block mt-1">npm install && npm run dev</code>
                </div>
                <div>
                  <strong>Java:</strong>
                  <code className="block mt-1">mvn clean install && mvn spring-boot:run</code>
                </div>
                <div>
                  <strong>Python:</strong>
                  <code className="block mt-1">poetry install && poetry run uvicorn main:app --reload</code>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Rocket className="h-4 w-4" />
                Core Services
              </h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• <strong>Position Service:</strong> Real-time position tracking with threshold monitoring</li>
                <li>• <strong>Trader ID Service:</strong> CFTC trader identification management</li>
                <li>• <strong>Report Generation:</strong> Form 102 XML/JSON generation engine</li>
                <li>• <strong>Submission Gateway:</strong> Secure mTLS CFTC API connector</li>
                <li>• <strong>Validation Service:</strong> Multi-stage report validation</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Code2 className="h-4 w-4" />
                Technology Stack
              </h4>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <strong className="block mb-1">JavaScript/TS</strong>
                  <ul className="text-muted-foreground space-y-1">
                    <li>• Express.js</li>
                    <li>• PostgreSQL</li>
                    <li>• Jest testing</li>
                  </ul>
                </div>
                <div>
                  <strong className="block mb-1">Java</strong>
                  <ul className="text-muted-foreground space-y-1">
                    <li>• Spring Boot 3</li>
                    <li>• Hibernate ORM</li>
                    <li>• JUnit 5</li>
                  </ul>
                </div>
                <div>
                  <strong className="block mb-1">Python</strong>
                  <ul className="text-muted-foreground space-y-1">
                    <li>• FastAPI</li>
                    <li>• SQLAlchemy</li>
                    <li>• Pytest</li>
                  </ul>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                Best Practices
              </h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Use environment variables for all configuration (DB URLs, API keys)</li>
                <li>• Implement comprehensive error handling and logging</li>
                <li>• Write unit tests for business logic (target 80%+ coverage)</li>
                <li>• Use database migrations for schema changes</li>
                <li>• Enable CORS only for known frontend origins</li>
                <li>• Implement rate limiting on public endpoints</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">CI/CD Pipeline</h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Jenkins pipelines configured for all repositories</li>
                <li>• Automated testing on every commit</li>
                <li>• SonarQube code quality gates</li>
                <li>• Docker containerization for deployment</li>
                <li>• Blue-green deployment strategy</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {backendLanguages.length > 0 && (
          <Card data-testid="card-backend-code">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Backend Implementation</CardTitle>
                <Tabs value={selectedBackendLanguage} onValueChange={setSelectedBackendLanguage}>
                  <TabsList data-testid="tabslist-backend-language">
                    {backendLanguages.map(lang => (
                      <TabsTrigger 
                        key={lang} 
                        value={lang}
                        data-testid={`tab-trigger-backend-${lang.toLowerCase()}`}
                      >
                        {lang}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
              </div>
              <CardDescription>
                {filteredBackendFiles.length} file{filteredBackendFiles.length !== 1 ? 's' : ''} • {selectedBackendLanguage}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px]">
                {filteredBackendFiles.length > 0 ? (
                  <FileViewer files={filteredBackendFiles} />
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    No backend files available for {selectedBackendLanguage}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        )}
      </TabsContent>
    </Tabs>
  );
}
