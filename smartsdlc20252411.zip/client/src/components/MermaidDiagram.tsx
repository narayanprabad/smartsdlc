import { useEffect, useRef, useState } from 'react';
import mermaid from 'mermaid';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

interface MermaidDiagramProps {
  code: string;
  title: string;
  description?: string;
}

mermaid.initialize({
  startOnLoad: false,
  theme: 'default',
  securityLevel: 'strict',
});

export function MermaidDiagram({ code, title, description }: MermaidDiagramProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [svg, setSvg] = useState<string>('');

  useEffect(() => {
    const renderDiagram = async () => {
      if (!containerRef.current || !code) return;

      try {
        setError(null);
        const id = `mermaid-${Math.random().toString(36).substring(7)}`;
        const { svg: renderedSvg } = await mermaid.render(id, code);
        setSvg(renderedSvg);
      } catch (err: any) {
        console.error('Mermaid rendering error:', err);
        setError(err.message || 'Failed to render diagram');
        setSvg('');
      }
    };

    renderDiagram();
  }, [code]);

  return (
    <Card data-testid={`diagram-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        {error ? (
          <Alert variant="destructive" data-testid="diagram-error">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Failed to render diagram: {error}
            </AlertDescription>
          </Alert>
        ) : (
          <div
            ref={containerRef}
            className="flex justify-center items-center p-4 bg-background rounded-md"
            dangerouslySetInnerHTML={{ __html: svg }}
            data-testid="diagram-svg"
          />
        )}
      </CardContent>
    </Card>
  );
}
