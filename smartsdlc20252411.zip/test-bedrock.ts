import { generateArtifacts } from './server/bedrock';

(async () => {
  try {
    console.log('Testing Bedrock API with prompt: "Create a project Payment gateway"\n');
    console.log('Calling AWS Bedrock...\n');
    
    const result = await generateArtifacts('Create a project Payment gateway');
    
    console.log('=================================================');
    console.log('BEDROCK RAW RESPONSE');
    console.log('=================================================\n');
    console.log(JSON.stringify(result, null, 2));
    console.log('\n=================================================');
    console.log('Summary:');
    console.log(`- User Stories: ${result.userStories?.length || 0}`);
    console.log(`- Tasks: ${result.tasks?.length || 0}`);
    console.log(`- Functional Requirements: ${result.functionalRequirements?.length || 0}`);
    console.log(`- Architecture Components: ${result.architectureOutline?.length || 0}`);
    console.log(`- Architecture Diagrams: ${result.architectureDiagrams?.length || 0}`);
    console.log('=================================================');
  } catch (error: any) {
    console.error('ERROR:', error.message);
    console.error('Stack:', error.stack);
  }
})();
