import { z } from "zod";
import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
  varchar,
  integer,
  pgEnum,
  unique,
} from "drizzle-orm/pg-core";

// Business Context schema
export const businessContextSchema = z.object({
  executiveSummary: z.string(),
  domainAnalysis: z.string(),
  keyStakeholders: z.array(z.string()),
  businessGoals: z.array(z.string()),
  riskAssessment: z.array(z.object({
    risk: z.string(),
    severity: z.enum(["high", "medium", "low"]),
    mitigation: z.string(),
  })),
});

export type BusinessContext = z.infer<typeof businessContextSchema>;

// User Story schema
export const userStorySchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  acceptanceCriteria: z.array(z.string()),
  effort: z.string().optional(),
  priority: z.enum(["high", "medium", "low"]).optional(),
  linkedRequirements: z.array(z.string()).optional(),
});

export type UserStory = z.infer<typeof userStorySchema>;

// Task schema
export const taskSchema = z.object({
  id: z.string(),
  role: z.string(),
  task: z.string(),
  effort: z.string(),
  status: z.enum(["not_started", "in_progress", "completed", "blocked"]),
});

export type Task = z.infer<typeof taskSchema>;

// Code File schema - for developer artifacts
export const codeFileSchema = z.object({
  filename: z.string(),
  language: z.string(),
  path: z.string(),
  code: z.string(),
  description: z.string().optional(),
  purpose: z.string(),
});

export type CodeFile = z.infer<typeof codeFileSchema>;

// Repository File schema - for code repository files
export const repositoryFileSchema = z.object({
  path: z.string(),
  type: z.literal('file'),
  language: z.string(),
  size: z.number(),
  content: z.string(),
});

export type RepositoryFile = z.infer<typeof repositoryFileSchema>;

// Repository schema - for multiple segregated repositories
export const repositorySchema = z.object({
  id: z.string(), // Unique stable identifier for UI (e.g., 'frontend-nextjs', 'backend-java')
  name: z.string(),
  description: z.string(),
  url: z.string(),
  branch: z.string(),
  files: z.array(repositoryFileSchema),
});

export type Repository = z.infer<typeof repositorySchema>;

// Developer Resources schema
export const developerResourcesSchema = z.object({
  repositories: z.array(repositorySchema).optional(),
});

export type DeveloperResources = z.infer<typeof developerResourcesSchema>;

// Test Case schema
export const testCaseSchema = z.object({
  id: z.string(),
  linkedRequirements: z.array(z.string()).optional(),
  testName: z.string(),
  testType: z.enum(["unit", "integration", "e2e", "performance"]),
  description: z.string(),
  preconditions: z.string().optional(),
  testSteps: z.array(z.string()).optional(),
  testCode: z.string(),
  expectedResult: z.string(),
  language: z.string(),
});

export type TestCase = z.infer<typeof testCaseSchema>;

// Production Ticket/Incident schema
export const productionTicketSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  severity: z.enum(["critical", "high", "medium", "low"]),
  status: z.enum(["open", "investigating", "resolved", "closed"]),
  affectedService: z.string(),
  assignedTo: z.string().optional(),
  createdAt: z.string(),
  resolvedAt: z.string().optional(),
  rootCause: z.string().optional(),
  resolution: z.string().optional(),
});

export type ProductionTicket = z.infer<typeof productionTicketSchema>;

// Code Review Guidelines schema
export const codeReviewSchema = z.object({
  category: z.string(),
  guidelines: z.array(z.string()),
  checklist: z.array(z.string()),
});

export type CodeReview = z.infer<typeof codeReviewSchema>;

// Development Guide schema
export const developmentGuideSchema = z.object({
  setupInstructions: z.array(z.string()),
  technologyStack: z.array(z.string()),
  codeConventions: z.array(z.string()),
  dependencies: z.union([
    z.array(z.string()),
    z.object({
      runtime: z.array(z.string()),
      development: z.array(z.string()),
    }),
  ]).optional(),
  environmentVariables: z.array(z.object({
    name: z.string(),
    description: z.string(),
    example: z.string(),
    required: z.boolean().optional(),
  })),
  repositoryStructure: z.array(z.object({
    path: z.string(),
    purpose: z.string(),
  })).optional(),
});

export type DevelopmentGuide = z.infer<typeof developmentGuideSchema>;

// Architecture Component schema with explicit type for recursion
export type ArchitectureComponent = {
  component: string;
  description: string;
  responsibilities?: string[];
  technologies?: string[];
  dependencies?: string[];
};

export const architectureComponentSchema: z.ZodType<ArchitectureComponent> = z.object({
  component: z.string(),
  description: z.string(),
  responsibilities: z.array(z.string()).optional(),
  technologies: z.array(z.string()).optional(),
  dependencies: z.array(z.string()).optional(),
});

// Non-Functional Requirements schema
export const nonFunctionalRequirementsSchema = z.object({
  performance: z.array(z.string()),
  security: z.array(z.string()),
  scalability: z.array(z.string()),
  reliability: z.array(z.string()),
  maintainability: z.array(z.string()),
});

export type NonFunctionalRequirements = z.infer<typeof nonFunctionalRequirementsSchema>;

// AWS Well-Architected Framework Pillars schema
export const wellArchitectedPillarsSchema = z.object({
  operationalExcellence: z.array(z.string()),
  security: z.array(z.string()),
  reliability: z.array(z.string()),
  performanceEfficiency: z.array(z.string()),
  costOptimization: z.array(z.string()),
  sustainability: z.array(z.string()).optional(),
});

export type WellArchitectedPillars = z.infer<typeof wellArchitectedPillarsSchema>;

// Architecture Diagram schema
export const architectureDiagramSchema = z.object({
  title: z.string(),
  type: z.string(),
  mermaidCode: z.string(),
  description: z.string().optional(),
});

export type ArchitectureDiagram = z.infer<typeof architectureDiagramSchema>;

// SDLC Artifacts schema (enhanced with code, tests, and detailed guides)
export const sdlcArtifactsSchema = z.object({
  businessContext: businessContextSchema.optional(),
  userStories: z.array(userStorySchema),
  acceptanceCriteria: z.array(z.string()).optional(),
  functionalRequirements: z.union([
    z.array(z.string()),
    z.array(z.object({
      id: z.string(),
      requirement: z.string(),
      priority: z.enum(["high", "medium", "low"]).optional(),
    })),
  ]),
  nonFunctionalRequirements: nonFunctionalRequirementsSchema,
  architectureOutline: z.array(architectureComponentSchema),
  architectureDiagrams: z.array(architectureDiagramSchema).optional(),
  infrastructureComponents: z.array(z.object({
    name: z.string(),
    type: z.string(),
    provider: z.string(),
    specifications: z.string(),
    purpose: z.string(),
  })).optional(),
  securityArchitecture: z.object({
    authentication: z.array(z.string()),
    authorization: z.array(z.string()),
    dataEncryption: z.array(z.string()),
    compliance: z.array(z.string()),
  }).optional(),
  wellArchitectedPillars: wellArchitectedPillarsSchema,
  tasks: z.array(taskSchema),
  codeFiles: z.array(codeFileSchema).optional(),
  testCases: z.array(testCaseSchema).optional(),
  codeReviewGuidelines: z.array(codeReviewSchema).optional(),
  developmentGuide: developmentGuideSchema.optional(),
  productionTickets: z.array(productionTicketSchema).optional(),
});

export type SDLCArtifacts = z.infer<typeof sdlcArtifactsSchema>;

// Change type for diff tracking
export const changeTypeSchema = z.enum(["added", "modified", "removed"]);
export type ChangeType = z.infer<typeof changeTypeSchema>;

// Diff Entry schema
export const diffEntrySchema = z.object({
  path: z.string(),
  changeType: changeTypeSchema,
  oldValue: z.any().optional(),
  newValue: z.any().optional(),
  description: z.string(),
});

export type DiffEntry = z.infer<typeof diffEntrySchema>;

// Admin Override Request/Response Schemas
export const createOverrideRequestSchema = z.object({
  userId: z.string().min(1),
  forcedRole: z.string().min(1),
  reason: z.string().optional(),
  expiresAt: z.string().datetime().optional(),
});

export type CreateOverrideRequest = z.infer<typeof createOverrideRequestSchema>;

// Iteration schema
export const iterationSchema = z.object({
  id: z.string(),
  version: z.number(),
  requirements: z.string(),
  artifacts: sdlcArtifactsSchema,
  diff: z.array(diffEntrySchema).optional(),
  timestamp: z.string(),
});

export type Iteration = z.infer<typeof iterationSchema>;

// Project State schema
export const projectStateSchema = z.object({
  projectName: z.string(),
  currentVersion: z.number(),
  iterations: z.array(iterationSchema),
});

export type ProjectState = z.infer<typeof projectStateSchema>;

// API Request/Response schemas

// Translate Request
export const translateRequestSchema = z.object({
  requirements: z.string().min(10, "Requirements must be at least 10 characters"),
});

export type TranslateRequest = z.infer<typeof translateRequestSchema>;

// Translate Response
export const translateResponseSchema = z.object({
  artifacts: sdlcArtifactsSchema,
  iterationId: z.string(),
});

export type TranslateResponse = z.infer<typeof translateResponseSchema>;

// Refine Request
export const refineRequestSchema = z.object({
  currentArtifacts: sdlcArtifactsSchema,
  refinementPrompt: z.string().min(5, "Refinement prompt must be at least 5 characters"),
  previousRequirements: z.string(),
});

export type RefineRequest = z.infer<typeof refineRequestSchema>;

// Refine Response
export const refineResponseSchema = z.object({
  artifacts: sdlcArtifactsSchema,
  iterationId: z.string(),
  changes: z.array(diffEntrySchema),
});

export type RefineResponse = z.infer<typeof refineResponseSchema>;

// Collaborator Role type
export const collaboratorRoleSchema = z.enum([
  "Owner",
  "Architect",
  "Business Analyst",
  "Developer",
  "QA/SDET",
  "DevOps/Platform",
  "Product Owner",
  "Support/SRE",
  "Scrum Master",
]);

export type CollaboratorRole = z.infer<typeof collaboratorRoleSchema>;

// Collaborator schema
export const collaboratorSchema = z.object({
  id: z.string(),
  projectId: z.string(),
  userId: z.string(),
  role: collaboratorRoleSchema,
  joinedAt: z.string(),
  isOwner: z.boolean().default(false),
});

export type Collaborator = z.infer<typeof collaboratorSchema>;

// Database Tables
export const persona = pgEnum("persona", [
  "Owner",
  "Architect",
  "Business Analyst",
  "Developer",
  "QA/SDET",
  "DevOps/Platform",
  "Product Owner",
  "Support/SRE",
  "Scrum Master",
]);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  defaultPersona: persona("default_persona").default("Developer"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type User = typeof users.$inferSelect;
export type UpsertUser = Omit<typeof users.$inferInsert, 'createdAt' | 'updatedAt'>;

export const projects = pgTable(
  "projects",
  {
    id: varchar("id").primaryKey(),
    name: varchar("name").notNull(),
    description: text("description"),
    ownerId: varchar("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    currentVersion: integer("current_version").notNull().default(0),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
    businessOverview: text("business_overview"),
    functionalRequirements: text("functional_requirements"),
    nonFunctionalRequirements: text("non_functional_requirements"),
    architectureDocs: text("architecture_docs"),
    figmaLinks: text("figma_links"),
    flowDiagrams: text("flow_diagrams"),
    developmentDocs: text("development_docs"),
    testingDocs: text("testing_docs"),
    deploymentDocs: text("deployment_docs"),
    developerResources: jsonb("developer_resources"),
  },
  (table) => ({
    ownerIdx: index("projects_owner_id_idx").on(table.ownerId),
  })
);

export const collaborators = pgTable(
  "collaborators",
  {
    id: varchar("id").primaryKey(),
    projectId: varchar("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    userId: varchar("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: varchar("role").notNull(),
    addedAt: timestamp("added_at").defaultNow(),
  },
  (table) => ({
    projectUserUnique: unique("collaborators_project_user_unique").on(
      table.projectId,
      table.userId
    ),
    projectIdx: index("collaborators_project_idx").on(table.projectId),
  })
);

export const iterations = pgTable(
  "iterations",
  {
    id: varchar("id").primaryKey(),
    projectId: varchar("project_id")
      .notNull()
      .references(() => projects.id),
    version: integer("version").notNull(),
    requirements: text("requirements"),
    artifacts: jsonb("artifacts"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    projectIdx: index("iterations_project_idx").on(table.projectId),
  })
);

export const sprints = pgTable(
  "sprints",
  {
    id: varchar("id").primaryKey(),
    projectId: varchar("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    name: varchar("name").notNull(),
    sprintNumber: integer("sprint_number").notNull(),
    startDate: timestamp("start_date").notNull(),
    endDate: timestamp("end_date").notNull(),
    sprintLengthDays: integer("sprint_length_days").notNull().default(14),
    status: varchar("status").notNull().default("planning"),
    goal: text("goal"),
    retrospective: jsonb("retrospective").default(sql`'{}'::jsonb`),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => ({
    projectIdx: index("sprints_project_id_idx").on(table.projectId),
    statusIdx: index("sprints_status_idx").on(table.status),
    projectNumberUnique: unique("sprints_project_number_unique").on(table.projectId, table.sprintNumber),
  })
);

export const stories = pgTable(
  "stories",
  {
    id: varchar("id").primaryKey(),
    projectId: varchar("project_id")
      .notNull()
      .references(() => projects.id),
    sprintId: varchar("sprint_id").references(() => sprints.id),
    title: varchar("title").notNull(),
    description: text("description"),
    status: varchar("status"),
    priority: varchar("priority"),
    storyPoints: integer("story_points"),
    assignedTo: varchar("assigned_to"),
    createdBy: varchar("created_by"),
    linkedStories: jsonb("linked_stories"),
    acceptanceCriteria: jsonb("acceptance_criteria"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at"),
  },
  (table) => ({
    projectIdx: index("stories_project_idx").on(table.projectId),
    sprintIdx: index("stories_sprint_idx").on(table.sprintId),
  })
);

export const adminOverrides = pgTable(
  "admin_overrides",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    userId: varchar("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: varchar("role").notNull(),
    reason: text("reason"),
    createdBy: varchar("created_by")
      .notNull()
      .references(() => users.id),
    expiresAt: timestamp("expires_at"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    userIdx: index("admin_overrides_user_idx").on(table.userId),
    userUnique: unique("admin_overrides_user_unique").on(table.userId),
  })
);

export const eventLogs = pgTable(
  "event_logs",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    userId: varchar("user_id").references(() => users.id, { onDelete: "set null" }),
    action: varchar("action").notNull(),
    payload: jsonb("payload"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    userIdx: index("event_logs_user_id_idx").on(table.userId),
    actionIdx: index("event_logs_action_idx").on(table.action),
    createdAtIdx: index("event_logs_created_at_idx").on(table.createdAt),
  })
);

// Type exports for database tables
export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

export type Collaborator_DB = typeof collaborators.$inferSelect;
export type InsertCollaborator = typeof collaborators.$inferInsert;

export type IterationDB = typeof iterations.$inferSelect;
export type InsertIteration = typeof iterations.$inferInsert;

export type Sprint = typeof sprints.$inferSelect;
export type InsertSprint = typeof sprints.$inferInsert;

export type Story = typeof stories.$inferSelect;
export type InsertStory = typeof stories.$inferInsert;

export type AdminOverride = typeof adminOverrides.$inferSelect;
export type InsertAdminOverride = typeof adminOverrides.$inferInsert;

export type EventLog = typeof eventLogs.$inferSelect;
export type InsertEventLog = typeof eventLogs.$inferInsert;
