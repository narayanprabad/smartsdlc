# SmartSDLC - Role-Aware AI-Powered SDLC Workspace

## Overview
SmartSDLC is an AI-powered, prompt-driven workspace that automates the Software Development Life Cycle (SDLC). It leverages AWS Bedrock's Claude models to generate role-specific artifacts for key personas across the SDLC. The platform features a simulated SSO, a tab-based workspace UI, mock connectors for SDLC tools (Jira, GitHub, Jenkins), traceability graph visualization, and file-based artifact generation. The project aims to streamline SDLC processes, enhance collaboration, and improve artifact consistency through AI-driven automation, focusing on professional-grade output and comprehensive business intelligence.

## User Preferences
- Preferred communication style: Simple, everyday language
- No "Replit" branding in user-facing UI (use "SSO" instead)
- Cost-conscious development

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript, Vite build system, Wouter for routing.
- **State Management**: TanStack Query (React Query).
- **UI Components**: shadcn/ui (Radix UI) and Tailwind CSS.
- **Diagrams**: Mermaid.js for rendering architecture diagrams.
- **Authentication**: Protected routes with `ProtectedRoute` HOC and `useAuth` hook.
- **Key Features**: Tabbed project interface, responsive and always-visible AI Assistant panel, sticky active sprint banner, enhanced story cards, and a GitHub-like code repository viewer in the Development tab.

### Backend Architecture
- **Framework**: Express.js on Node.js with TypeScript.
- **Authentication**: Replit Auth (OpenID Connect) via Passport.js, with PostgreSQL for session storage.
- **API Design**: RESTful endpoints for projects, collaborators, sprint and story management, and artifact generation, with robust role-based authorization.
- **Role-Based Permissions**: Granular permissions (e.g., `view`, `edit_requirements`, `manage_collaborators`) defined per role (Owner, Architect, Business Analyst, Developer, Scrum Master).
- **Transactional Safety**: Atomic project creation with full rollback on failure for `POST /api/projects/generate`.

### Data Storage Solutions
- **Database**: PostgreSQL via Neon (serverless).
- **ORM**: Drizzle ORM for type-safe database interactions.
- **Schema**: Includes `users`, `projects`, `collaborators`, `iterations`, `sprints`, `stories`, `admin_overrides`, and `event_logs` tables.
- **Data Models**: `SDLCArtifacts` structure for requirements, architecture, tasks, and `ArchitectureDiagram` with Mermaid.js code.

### AI Integration
- **AI Model**: AWS Bedrock's Claude 3.7 Sonnet (model: `us.anthropic.claude-3-7-sonnet-20250219-v1:0`).
- **Workflows**: Multi-pass artifact generation (Business Context, Architecture, Development, QA & Requirements) from business requirements, iterative refinement.
- **Prompt Engineering**: Structured JSON output, AWS Well-Architected Framework principles, Mermaid.js diagram generation, intelligent project title generation.
- **Token Management**: Max 8,192 output tokens (Bedrock limit), with prompt constraints.
- **File Upload Integration**: Comprehensive file upload system (images, text documents) integrated with Claude for multi-modal vision and document analysis to enhance artifact quality. Files are sent directly to Bedrock without persistent storage and undergo server-side validation for type, size, and quantity, with text truncation to prevent token overflow.

## External Dependencies

### Third-Party Services
- **AWS Bedrock**: AI model for artifact generation and multi-modal input processing.
- **Neon Database**: Serverless PostgreSQL database.
- **Replit Auth**: OpenID Connect authentication provider.

### Key NPM Packages
- **Frontend**: `@radix-ui/*`, `@tanstack/react-query`, `react`, `wouter`, `tailwindcss`, `mermaid`, `date-fns`, `lucide-react`, `zod`, `react-hook-form`.
- **Backend**: `express`, `@aws-sdk/client-bedrock-runtime`, `drizzle-orm`, `@neondatabase/serverless`, `passport`, `openid-client`, `express-session`, `connect-pg-simple`.

### Environment Variables Required
- `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_REGION`
- `DATABASE_URL`, `SESSION_SECRET`
- `REPL_ID`, `ISSUER_URL`
- `NODE_ENV`