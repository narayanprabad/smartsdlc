import { type User, type InsertUser, type Project, type InsertProject, type UseCase, type InsertUseCase, type Deliverable, type InsertDeliverable, type UserStory, type InsertUserStory, productBacklog, type Architecture, type InsertArchitecture } from "@shared/schema";

// Product backlog types
type ProductBacklogItem = typeof productBacklog.$inferSelect;
type InsertProductBacklogItem = typeof productBacklog.$inferInsert;
import { promises as fs } from "fs";
import path from "path";
import type { IStorage } from "./storage";

export class FileStorage implements IStorage {
  private dataDir: string;
  private currentUserId: number = 3;
  private currentProjectId: number = 4;
  private currentUseCaseId: number = 7;
  private currentDeliverableId: number = 1;
  private currentUserStoryId: number = 1;
  private currentBacklogId: number = 1;
  private currentArchitectureId: number = 1;

  constructor() {
    this.dataDir = path.join(process.cwd(), 'data');
    this.ensureDataDir();
  }

  private async ensureDataDir() {
    try {
      await fs.access(this.dataDir);
    } catch {
      await fs.mkdir(this.dataDir, { recursive: true });
    }
  }

  private async readJsonFile<T>(filename: string): Promise<T[]> {
    try {
      const filePath = path.join(this.dataDir, filename);
      const data = await fs.readFile(filePath, 'utf-8');
      return JSON.parse(data);
    } catch (error) {
      return [];
    }
  }

  private async writeJsonFile<T>(filename: string, data: T[]): Promise<void> {
    const filePath = path.join(this.dataDir, filename);
    await fs.writeFile(filePath, JSON.stringify(data, null, 2));
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const users = await this.readJsonFile<User>('users.json');
    return users.find(user => user.id === id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await this.readJsonFile<User>('users.json');
    return users.find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const users = await this.readJsonFile<User>('users.json');
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    users.push(user);
    await this.writeJsonFile('users.json', users);
    return user;
  }

  async updateUserRole(userId: number, role: string): Promise<User | undefined> {
    const users = await this.readJsonFile<User>('users.json');
    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex === -1) return undefined;
    
    users[userIndex].currentRole = role;
    await this.writeJsonFile('users.json', users);
    return users[userIndex];
  }

  // Project methods
  async getProjects(): Promise<Project[]> {
    return this.readJsonFile<Project>('projects.json');
  }

  async getProject(id: number): Promise<Project | undefined> {
    const projects = await this.readJsonFile<Project>('projects.json');
    return projects.find(project => project.id === id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const projects = await this.readJsonFile<Project>('projects.json');
    
    // Find the highest existing ID to prevent conflicts
    const maxId = projects.reduce((max, p) => Math.max(max, p.id || 0), 0);
    const id = Math.max(this.currentProjectId, maxId + 1);
    this.currentProjectId = id + 1;
    
    const project: Project = { 
      ...insertProject, 
      id,
      createdAt: new Date().toISOString(),
      ownerId: insertProject.ownerId || null,
      approvalStatus: "draft",
      approvedById: null,
      approvedAt: null,
      sealApplicationId: null,
      managedByScrumMasterId: null
    };
    projects.push(project);
    await this.writeJsonFile('projects.json', projects);
    return project;
  }

  async updateProject(id: number, updateData: Partial<InsertProject>): Promise<Project | undefined> {
    const projects = await this.readJsonFile<Project>('projects.json');
    const projectIndex = projects.findIndex(p => p.id === id);
    if (projectIndex === -1) return undefined;
    
    projects[projectIndex] = { ...projects[projectIndex], ...updateData };
    await this.writeJsonFile('projects.json', projects);
    return projects[projectIndex];
  }

  async getProjectsByOwner(ownerId: number): Promise<Project[]> {
    const projects = await this.readJsonFile<Project>('projects.json');
    return projects.filter(project => project.ownerId === ownerId);
  }

  // Use case methods
  async getUseCasesByProject(projectId: number): Promise<UseCase[]> {
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    return useCases.filter(useCase => useCase.projectId === projectId);
  }

  async getUseCase(id: number): Promise<UseCase | undefined> {
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    return useCases.find(useCase => useCase.id === id);
  }

  async createUseCase(insertUseCase: InsertUseCase): Promise<UseCase> {
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    const id = this.currentUseCaseId++;
    const useCase: UseCase = { 
      ...insertUseCase, 
      id,
      actor: insertUseCase.actor || null,
      category: insertUseCase.category || null
    };
    useCases.push(useCase);
    await this.writeJsonFile('use-cases.json', useCases);
    return useCase;
  }

  async updateUseCase(id: number, updateData: Partial<InsertUseCase>): Promise<UseCase | undefined> {
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    const useCaseIndex = useCases.findIndex(uc => uc.id === id);
    if (useCaseIndex === -1) return undefined;
    
    useCases[useCaseIndex] = { ...useCases[useCaseIndex], ...updateData };
    await this.writeJsonFile('use-cases.json', useCases);
    return useCases[useCaseIndex];
  }

  async deleteUseCase(id: number): Promise<boolean> {
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    const initialLength = useCases.length;
    const filteredUseCases = useCases.filter(uc => uc.id !== id);
    
    if (filteredUseCases.length === initialLength) return false;
    
    await this.writeJsonFile('use-cases.json', filteredUseCases);
    return true;
  }

  async deleteProject(id: number): Promise<boolean> {
    const projects = await this.readJsonFile<Project>('projects.json');
    const initialLength = projects.length;
    const filteredProjects = projects.filter(p => p.id !== id);
    
    if (filteredProjects.length === initialLength) return false;
    
    await this.writeJsonFile('projects.json', filteredProjects);
    
    // Also delete associated use cases
    const useCases = await this.readJsonFile<UseCase>('use-cases.json');
    const filteredUseCases = useCases.filter(uc => uc.projectId !== id);
    await this.writeJsonFile('use-cases.json', filteredUseCases);
    
    return true;
  }

  // Deliverable methods
  async getDeliverablesByProject(projectId: number): Promise<Deliverable[]> {
    const deliverables = await this.readJsonFile<Deliverable>('deliverables.json');
    return deliverables.filter(deliverable => deliverable.projectId === projectId);
  }

  async getDeliverable(id: number): Promise<Deliverable | undefined> {
    const deliverables = await this.readJsonFile<Deliverable>('deliverables.json');
    return deliverables.find(deliverable => deliverable.id === id);
  }

  async createDeliverable(insertDeliverable: InsertDeliverable): Promise<Deliverable> {
    const deliverables = await this.readJsonFile<Deliverable>('deliverables.json');
    const id = this.currentDeliverableId++;
    const deliverable: Deliverable = { 
      ...insertDeliverable, 
      id,
      assignedTo: insertDeliverable.assignedTo || null,
      assignedBy: insertDeliverable.assignedBy || null,
      jiraProjectKey: insertDeliverable.jiraProjectKey || null,
      jiraEpicKey: insertDeliverable.jiraEpicKey || null
    };
    deliverables.push(deliverable);
    await this.writeJsonFile('deliverables.json', deliverables);
    return deliverable;
  }

  async updateDeliverable(id: number, updateData: Partial<InsertDeliverable>): Promise<Deliverable | undefined> {
    const deliverables = await this.readJsonFile<Deliverable>('deliverables.json');
    const index = deliverables.findIndex(deliverable => deliverable.id === id);
    if (index === -1) return undefined;

    const updatedDeliverable: Deliverable = {
      ...deliverables[index],
      ...updateData,
      id,
    };
    
    deliverables[index] = updatedDeliverable;
    await this.writeJsonFile('deliverables.json', deliverables);
    return updatedDeliverable;
  }

  async deleteDeliverable(id: number): Promise<boolean> {
    const deliverables = await this.readJsonFile<Deliverable>('deliverables.json');
    const initialLength = deliverables.length;
    const filteredDeliverables = deliverables.filter(d => d.id !== id);
    
    if (filteredDeliverables.length === initialLength) return false;
    
    await this.writeJsonFile('deliverables.json', filteredDeliverables);
    
    // Also delete associated user stories
    const userStories = await this.readJsonFile<UserStory>('user-stories.json');
    const filteredStories = userStories.filter(story => story.deliverableId !== id);
    await this.writeJsonFile('user-stories.json', filteredStories);
    
    return true;
  }

  // User story methods
  async getUserStoriesByDeliverable(deliverableId: number): Promise<UserStory[]> {
    const userStories = await this.readJsonFile<UserStory>('user-stories.json');
    return userStories.filter(story => story.deliverableId === deliverableId);
  }

  async getUserStory(id: number): Promise<UserStory | undefined> {
    const userStories = await this.readJsonFile<UserStory>('user-stories.json');
    return userStories.find(story => story.id === id);
  }

  async createUserStory(insertUserStory: InsertUserStory): Promise<UserStory> {
    const userStories = await this.readJsonFile<UserStory>('user-stories.json');
    const id = this.currentUserStoryId++;
    const userStory: UserStory = { 
      ...insertUserStory, 
      id,
      storyPoints: insertUserStory.storyPoints || null,
      jiraIssueKey: insertUserStory.jiraIssueKey || null,
      assignedTo: insertUserStory.assignedTo || null
    };
    userStories.push(userStory);
    await this.writeJsonFile('user-stories.json', userStories);
    return userStory;
  }

  async updateUserStory(id: number, updateData: Partial<InsertUserStory>): Promise<UserStory | undefined> {
    const userStories = await this.readJsonFile<UserStory>('user-stories.json');
    const index = userStories.findIndex(story => story.id === id);
    if (index === -1) return undefined;

    const updatedUserStory: UserStory = {
      ...userStories[index],
      ...updateData,
      id,
    };
    
    userStories[index] = updatedUserStory;
    await this.writeJsonFile('user-stories.json', userStories);
    return updatedUserStory;
  }

  async deleteUserStory(id: number): Promise<boolean> {
    const userStories = await this.readJsonFile<UserStory>('user-stories.json');
    const initialLength = userStories.length;
    const filteredStories = userStories.filter(story => story.id !== id);
    
    if (filteredStories.length === initialLength) return false;
    
    await this.writeJsonFile('user-stories.json', filteredStories);
    return true;
  }

  // Product backlog methods
  async getProductBacklog(projectId: number): Promise<ProductBacklogItem[]> {
    const backlog = await this.readJsonFile<ProductBacklogItem>('product-backlog.json');
    return backlog.filter(item => item.projectId === projectId);
  }

  async createBacklogItem(insertItem: InsertProductBacklogItem): Promise<ProductBacklogItem> {
    const backlog = await this.readJsonFile<ProductBacklogItem>('product-backlog.json');
    const id = this.currentBacklogId++;
    
    const item: ProductBacklogItem = { 
      ...insertItem, 
      id,
      status: insertItem.status || "backlog",
      storyPoints: insertItem.storyPoints || null,
      assignedTo: insertItem.assignedTo || null,
      sprint: insertItem.sprint || null,
      tags: insertItem.tags || null,
      businessValue: insertItem.businessValue || null,
      risk: insertItem.risk || null,
      dependencies: insertItem.dependencies || null,
      kanbanColumn: insertItem.kanbanColumn || "To Do",
      scrumStatus: insertItem.scrumStatus || "Product Backlog",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    backlog.push(item);
    await this.writeJsonFile('product-backlog.json', backlog);
    return item;
  }

  async updateBacklogItem(id: number, updateData: Partial<InsertProductBacklogItem>): Promise<ProductBacklogItem | undefined> {
    const backlog = await this.readJsonFile<ProductBacklogItem>('product-backlog.json');
    const index = backlog.findIndex(item => item.id === id);
    if (index === -1) return undefined;

    const updatedItem: ProductBacklogItem = {
      ...backlog[index],
      ...updateData,
      id,
      updatedAt: new Date().toISOString(),
    };
    
    backlog[index] = updatedItem;
    await this.writeJsonFile('product-backlog.json', backlog);
    return updatedItem;
  }

  async deleteBacklogItem(id: number): Promise<boolean> {
    const backlog = await this.readJsonFile<ProductBacklogItem>('product-backlog.json');
    const initialLength = backlog.length;
    const filteredBacklog = backlog.filter(item => item.id !== id);
    
    if (filteredBacklog.length === initialLength) return false;
    
    await this.writeJsonFile('product-backlog.json', filteredBacklog);
    return true;
  }

  // Workflow methods
  async assignArchitect(projectId: number, architectId: number): Promise<Project | undefined> {
    const projects = await this.readJsonFile<Project>('projects.json');
    const index = projects.findIndex(p => p.id === projectId);
    if (index === -1) return undefined;

    const updatedProject: Project = {
      ...projects[index],
      assignedArchitectId: architectId,
      assignedAt: new Date().toISOString(),
    };
    
    projects[index] = updatedProject;
    await this.writeJsonFile('projects.json', projects);
    return updatedProject;
  }

  async setBoardType(projectId: number, boardType: string, scrumMasterId: number): Promise<Project | undefined> {
    const projects = await this.readJsonFile<Project>('projects.json');
    const index = projects.findIndex(p => p.id === projectId);
    if (index === -1) return undefined;

    const updatedProject: Project = {
      ...projects[index],
      boardType,
      managedByScrumMasterId: scrumMasterId,
    };
    
    projects[index] = updatedProject;
    await this.writeJsonFile('projects.json', projects);
    return updatedProject;
  }

  async getArchitectProjects(architectId: number): Promise<Project[]> {
    const projects = await this.readJsonFile<Project>('projects.json');
    return projects.filter(project => project.assignedArchitectId === architectId);
  }

  // Architecture methods
  async getArchitecture(projectId: number): Promise<Architecture | undefined> {
    const architectures = await this.readJsonFile<Architecture>('architectures.json');
    const architecture = architectures.find(arch => arch.projectId === projectId);
    console.log(`🔍 FileStorage: Getting architecture for project ${projectId} from architectures.json:`, architecture ? 'Found comprehensive architecture' : 'Not found');
    return architecture;
  }

  async createArchitecture(insertArchitecture: InsertArchitecture): Promise<Architecture> {
    const architectures = await this.readJsonFile<Architecture>('architectures.json');
    const id = this.currentArchitectureId++;
    const architecture: Architecture = { 
      ...insertArchitecture, 
      id,
      status: "draft",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    architectures.push(architecture);
    await this.writeJsonFile('architectures.json', architectures);
    return architecture;
  }

  async updateArchitecture(projectId: number, updateData: Partial<InsertArchitecture>): Promise<Architecture | undefined> {
    const architectures = await this.readJsonFile<Architecture>('architectures.json');
    const index = architectures.findIndex(architecture => architecture.projectId === projectId);
    
    if (index === -1) return undefined;
    
    const updatedArchitecture: Architecture = {
      ...architectures[index],
      ...updateData,
      updatedAt: new Date().toISOString()
    };
    
    architectures[index] = updatedArchitecture;
    await this.writeJsonFile('architectures.json', architectures);
    return updatedArchitecture;
  }



  async getUserStoriesByBacklogItem(backlogItemId: number): Promise<UserStory[]> {
    const userStories = await this.readJsonFile<UserStory>('userStories.json');
    return userStories.filter(story => story.backlogItemId === backlogItemId);
  }

  // Remove duplicate architecture operations - using the one above
}