import { users, projects, useCases, deliverables, userStories, productBacklog, architecture, type User, type InsertUser, type Project, type InsertProject, type UseCase, type InsertUseCase, type Deliverable, type InsertDeliverable, type UserStory, type InsertUserStory, type Architecture, type InsertArchitecture } from "@shared/schema";

// Product backlog types
type ProductBacklogItem = typeof productBacklog.$inferSelect;
type InsertProductBacklogItem = typeof productBacklog.$inferInsert;
import { promises as fs } from "fs";
import path from "path";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserRole(userId: number, role: string): Promise<User | undefined>;

  // Project methods
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  getProjectsByOwner(ownerId: number): Promise<Project[]>;

  // Use case methods
  getUseCasesByProject(projectId: number): Promise<UseCase[]>;
  getUseCase(id: number): Promise<UseCase | undefined>;
  createUseCase(useCase: InsertUseCase): Promise<UseCase>;
  updateUseCase(id: number, useCase: Partial<InsertUseCase>): Promise<UseCase | undefined>;
  deleteUseCase(id: number): Promise<boolean>;

  // Deliverable methods
  getDeliverablesByProject(projectId: number): Promise<Deliverable[]>;
  getDeliverable(id: number): Promise<Deliverable | undefined>;
  createDeliverable(deliverable: InsertDeliverable): Promise<Deliverable>;
  updateDeliverable(id: number, deliverable: Partial<InsertDeliverable>): Promise<Deliverable | undefined>;
  deleteDeliverable(id: number): Promise<boolean>;

  // User story methods
  getUserStoriesByDeliverable(deliverableId: number): Promise<UserStory[]>;
  getUserStoriesByBacklogItem(backlogItemId: number): Promise<UserStory[]>;
  getUserStory(id: number): Promise<UserStory | undefined>;
  createUserStory(userStory: InsertUserStory): Promise<UserStory>;
  updateUserStory(id: number, userStory: Partial<InsertUserStory>): Promise<UserStory | undefined>;
  deleteUserStory(id: number): Promise<boolean>;

  // Project deletion
  deleteProject(id: number): Promise<boolean>;

  // Product backlog methods
  getProductBacklog(projectId: number): Promise<ProductBacklogItem[]>;
  createBacklogItem(item: InsertProductBacklogItem): Promise<ProductBacklogItem>;
  updateBacklogItem(id: number, item: Partial<InsertProductBacklogItem>): Promise<ProductBacklogItem | undefined>;
  deleteBacklogItem(id: number): Promise<boolean>;

  // Architecture methods
  getArchitecture(projectId: number): Promise<Architecture | undefined>;
  createArchitecture(architecture: InsertArchitecture): Promise<Architecture>;
  updateArchitecture(projectId: number, architecture: Partial<InsertArchitecture>): Promise<Architecture | undefined>;
  finalizeArchitecture(projectId: number): Promise<Architecture | undefined>;

  // Workflow methods
  assignArchitect(projectId: number, architectId: number): Promise<Project | undefined>;
  setBoardType(projectId: number, boardType: string, scrumMasterId: number): Promise<Project | undefined>;
  getArchitectProjects(architectId: number): Promise<Project[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private useCases: Map<number, UseCase>;
  private deliverables: Map<number, Deliverable>;
  private userStories: Map<number, UserStory>;
  private productBacklog: Map<number, ProductBacklogItem>;
  private architectures: Map<number, Architecture>;
  private currentUserId: number;
  private currentProjectId: number;
  private currentUseCaseId: number;
  private currentDeliverableId: number;
  private currentUserStoryId: number;
  private currentBacklogId: number;
  private currentArchitectureId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.useCases = new Map();
    this.deliverables = new Map();
    this.userStories = new Map();
    this.productBacklog = new Map();
    this.architectures = new Map();
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.currentUseCaseId = 1;
    this.currentDeliverableId = 1;
    this.currentUserStoryId = 1;
    this.currentBacklogId = 1;
    this.currentArchitectureId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample users with multiple roles
    const user1: User = {
      id: 1,
      username: "gpraharaj",
      password: "password123", // In production, this would be hashed
      name: "Gobind Praharaj",
      roles: ["business-analyst", "product-owner", "scrum-master", "architect", "ui-designer", "developer", "production-management", "devops", "approver"],
      currentRole: "architect",
      sealApplications: ["34678: Regulatory Reporting Workbench", "111015: Engineering Controls and Reg. reporting"]
    };

    const user2: User = {
      id: 2,
      username: "approver",
      password: "password123",
      name: "Sarah Wilson",
      roles: ["approver", "architect"],
      currentRole: "approver",
      sealApplications: ["111015: Engineering Controls and Reg. reporting"]
    };

    this.users.set(1, user1);
    this.users.set(2, user2);
    this.currentUserId = 3;

    // Create sample projects with approval workflow
    const project1: Project = {
      id: 1,
      name: "Global Clearing and Settlement Platform",
      description: "Enterprise settlement system for trade clearing and regulatory compliance",
      status: "Active",
      type: "Web Application",
      startDate: "Dec 2024",
      teamSize: 8,
      ownerId: 1,
      approvalStatus: "approved",
      approvedById: 2,
      approvedAt: "2024-12-01",
      createdAt: "2024-11-15",
      sealApplicationId: "34678",
      sealApplicationName: "Regulatory Reporting Workbench",
      assignedArchitectId: null,
      assignedAt: null,
      boardType: null,
      managedByScrumMasterId: null,
    };

    const project2: Project = {
      id: 2,
      name: "EMIR Trade Reporting System",
      description: "Automated EMIR trade repository submission and regulatory compliance system",
      status: "Planning",
      type: "Web Application",
      startDate: "Jan 2025",
      teamSize: 5,
      ownerId: 1,
      approvalStatus: "pending",
      approvedById: null,
      approvedAt: null,
      createdAt: "2024-12-10",
      sealApplicationId: "34678",
      sealApplicationName: "Regulatory Reporting Workbench",
      assignedArchitectId: null,
      assignedAt: null,
      boardType: null,
      managedByScrumMasterId: null,
    };

    const project3: Project = {
      id: 3,
      name: "Risk Control Framework",
      description: "Real-time risk monitoring and control system for trading operations",
      status: "Development",
      type: "Data Analytics",
      startDate: "Nov 2024",
      teamSize: 6,
      ownerId: 1,
      approvalStatus: "approved",
      approvedById: 2,
      approvedAt: "2024-11-20",
      createdAt: "2024-11-10",
      sealApplicationId: "111015",
      sealApplicationName: "Engineering Controls and Reg. reporting",
      assignedArchitectId: null,
      assignedAt: null,
      boardType: null,
      managedByScrumMasterId: null,
    };

    this.projects.set(1, project1);
    this.projects.set(2, project2);
    this.projects.set(3, project3);
    this.currentProjectId = 4;

    // Create sample use cases for project 1
    const useCases = [
      {
        id: 1,
        projectId: 1,
        ucId: "UC-001",
        title: "User Registration",
        description: "Allow new users to create an account with email verification and profile setup",
        type: "functional",
        priority: "High",
        status: "Approved",
        actor: "Customer",
        category: null,
        updatedAt: "2 days ago"
      },
      {
        id: 2,
        projectId: 1,
        ucId: "UC-002",
        title: "Product Search",
        description: "Enable users to search for products using filters, categories, and AI-powered recommendations",
        type: "functional",
        priority: "High",
        status: "In Review",
        actor: "Customer",
        category: null,
        updatedAt: "1 day ago"
      },
      {
        id: 3,
        projectId: 1,
        ucId: "UC-003",
        title: "Shopping Cart Management",
        description: "Allow users to add, remove, and modify items in their shopping cart with persistence across sessions",
        type: "functional",
        priority: "Medium",
        status: "Approved",
        actor: "Customer",
        category: null,
        updatedAt: "3 days ago"
      },
      {
        id: 4,
        projectId: 1,
        ucId: "NF-001",
        title: "Performance Requirements",
        description: "System must handle 10,000 concurrent users with response time under 2 seconds",
        type: "non-functional",
        priority: "Critical",
        status: "Approved",
        actor: null,
        category: "Performance",
        updatedAt: "1 day ago"
      },
      {
        id: 5,
        projectId: 1,
        ucId: "NF-002",
        title: "Security Requirements",
        description: "All user data must be encrypted at rest and in transit with multi-factor authentication",
        type: "non-functional",
        priority: "Critical",
        status: "Approved",
        actor: null,
        category: "Security",
        updatedAt: "2 days ago"
      },
      {
        id: 6,
        projectId: 1,
        ucId: "NF-003",
        title: "Scalability Requirements",
        description: "System architecture must support horizontal scaling to accommodate 5x traffic growth",
        type: "non-functional",
        priority: "High",
        status: "In Review",
        actor: null,
        category: "Scalability",
        updatedAt: "4 days ago"
      }
    ];

    useCases.forEach(uc => {
      this.useCases.set(uc.id, uc as UseCase);
    });
    this.currentUseCaseId = 7;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      sealApplications: insertUser.sealApplications || null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserRole(userId: number, role: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    user.currentRole = role;
    this.users.set(userId, user);
    return user;
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const project: Project = { 
      ...insertProject, 
      id,
      ownerId: insertProject.ownerId || null,
      approvalStatus: insertProject.approvalStatus || "pending",
      approvedById: insertProject.approvedById || null,
      approvedAt: insertProject.approvedAt || null,
      sealApplicationId: insertProject.sealApplicationId || null,
      sealApplicationName: insertProject.sealApplicationName || null,
      assignedArchitectId: insertProject.assignedArchitectId || null,
      assignedAt: insertProject.assignedAt || null,
      boardType: insertProject.boardType || null,
      managedByScrumMasterId: insertProject.managedByScrumMasterId || null,
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, updateData: Partial<InsertProject>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;

    const updatedProject: Project = {
      ...project,
      ...updateData,
      id, // Ensure ID is preserved
      assignedArchitectId: updateData.assignedArchitectId ?? project.assignedArchitectId,
      assignedAt: updateData.assignedAt ?? project.assignedAt,
      boardType: updateData.boardType ?? project.boardType,
      managedByScrumMasterId: updateData.managedByScrumMasterId ?? project.managedByScrumMasterId,
    };
    
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async getProjectsByOwner(ownerId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(project => project.ownerId === ownerId);
  }

  async getUseCasesByProject(projectId: number): Promise<UseCase[]> {
    return Array.from(this.useCases.values()).filter(uc => uc.projectId === projectId);
  }

  async getUseCase(id: number): Promise<UseCase | undefined> {
    return this.useCases.get(id);
  }

  async createUseCase(insertUseCase: InsertUseCase): Promise<UseCase> {
    const id = this.currentUseCaseId++;
    const useCase: UseCase = { 
      ...insertUseCase, 
      id,
      actor: insertUseCase.actor || null,
      category: insertUseCase.category || null
    };
    this.useCases.set(id, useCase);
    return useCase;
  }

  async updateUseCase(id: number, updateData: Partial<InsertUseCase>): Promise<UseCase | undefined> {
    const useCase = this.useCases.get(id);
    if (!useCase) return undefined;
    
    const updated = { ...useCase, ...updateData };
    this.useCases.set(id, updated);
    return updated;
  }

  async deleteUseCase(id: number): Promise<boolean> {
    return this.useCases.delete(id);
  }

  async deleteProject(id: number): Promise<boolean> {
    const deleted = this.projects.delete(id);
    if (deleted) {
      // Also delete all associated use cases
      const useCases = Array.from(this.useCases.entries());
      useCases.forEach(([ucId, useCase]) => {
        if (useCase.projectId === id) {
          this.useCases.delete(ucId);
        }
      });
    }
    return deleted;
  }

  // Deliverable methods
  async getDeliverablesByProject(projectId: number): Promise<Deliverable[]> {
    return Array.from(this.deliverables.values()).filter(deliverable => deliverable.projectId === projectId);
  }

  async getDeliverable(id: number): Promise<Deliverable | undefined> {
    return this.deliverables.get(id);
  }

  async createDeliverable(insertDeliverable: InsertDeliverable): Promise<Deliverable> {
    const id = this.currentDeliverableId++;
    const deliverable: Deliverable = { 
      ...insertDeliverable, 
      id,
      assignedTo: insertDeliverable.assignedTo || null,
      assignedBy: insertDeliverable.assignedBy || null,
      jiraProjectKey: insertDeliverable.jiraProjectKey || null,
      jiraEpicKey: insertDeliverable.jiraEpicKey || null
    };
    this.deliverables.set(id, deliverable);
    return deliverable;
  }

  async updateDeliverable(id: number, updateData: Partial<InsertDeliverable>): Promise<Deliverable | undefined> {
    const deliverable = this.deliverables.get(id);
    if (!deliverable) return undefined;

    const updatedDeliverable: Deliverable = {
      ...deliverable,
      ...updateData,
      id,
    };
    
    this.deliverables.set(id, updatedDeliverable);
    return updatedDeliverable;
  }

  async deleteDeliverable(id: number): Promise<boolean> {
    const deleted = this.deliverables.delete(id);
    if (deleted) {
      // Also delete associated user stories
      this.userStories.forEach((story, storyId) => {
        if (story.deliverableId === id) {
          this.userStories.delete(storyId);
        }
      });
    }
    return deleted;
  }

  // User story methods
  async getUserStoriesByDeliverable(deliverableId: number): Promise<UserStory[]> {
    return Array.from(this.userStories.values()).filter(story => story.deliverableId === deliverableId);
  }

  async getUserStoriesByBacklogItem(backlogItemId: number): Promise<UserStory[]> {
    return Array.from(this.userStories.values()).filter(story => story.backlogItemId === backlogItemId);
  }

  async getUserStory(id: number): Promise<UserStory | undefined> {
    return this.userStories.get(id);
  }

  async createUserStory(insertUserStory: InsertUserStory): Promise<UserStory> {
    const id = this.currentUserStoryId++;
    const userStory: UserStory = { 
      ...insertUserStory, 
      id,
      storyPoints: insertUserStory.storyPoints || null,
      jiraIssueKey: insertUserStory.jiraIssueKey || null,
      assignedTo: insertUserStory.assignedTo || null
    };
    this.userStories.set(id, userStory);
    return userStory;
  }

  async updateUserStory(id: number, updateData: Partial<InsertUserStory>): Promise<UserStory | undefined> {
    const userStory = this.userStories.get(id);
    if (!userStory) return undefined;

    const updatedUserStory: UserStory = {
      ...userStory,
      ...updateData,
      id,
    };
    
    this.userStories.set(id, updatedUserStory);
    return updatedUserStory;
  }

  async deleteUserStory(id: number): Promise<boolean> {
    return this.userStories.delete(id);
  }

  // Product backlog methods
  async getProductBacklog(projectId: number): Promise<ProductBacklogItem[]> {
    return Array.from(this.productBacklog.values()).filter(item => item.projectId === projectId);
  }

  async createBacklogItem(insertItem: InsertProductBacklogItem): Promise<ProductBacklogItem> {
    const id = this.currentBacklogId++;
    const item: ProductBacklogItem = { 
      id,
      projectId: insertItem.projectId,
      title: insertItem.title,
      description: insertItem.description,
      userStory: insertItem.userStory,
      acceptanceCriteria: insertItem.acceptanceCriteria,
      priority: insertItem.priority,
      storyPoints: insertItem.storyPoints || null,
      tags: insertItem.tags || [],
      businessValue: insertItem.businessValue,
      risk: insertItem.risk,
      status: insertItem.status || "To Do",
      assignedTo: insertItem.assignedTo || null,
      sprint: insertItem.sprint || null,
      scrumStatus: insertItem.scrumStatus || null,
      createdById: insertItem.createdById,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.productBacklog.set(id, item);
    return item;
  }

  async updateBacklogItem(id: number, updateData: Partial<InsertProductBacklogItem>): Promise<ProductBacklogItem | undefined> {
    const item = this.productBacklog.get(id);
    if (!item) return undefined;

    const updatedItem: ProductBacklogItem = {
      ...item,
      ...updateData,
      id,
      updatedAt: new Date().toISOString(),
    };
    
    this.productBacklog.set(id, updatedItem);
    return updatedItem;
  }

  async deleteBacklogItem(id: number): Promise<boolean> {
    return this.productBacklog.delete(id);
  }

  // Workflow methods
  async assignArchitect(projectId: number, architectId: number): Promise<Project | undefined> {
    const project = this.projects.get(projectId);
    if (!project) return undefined;

    const updatedProject: Project = {
      ...project,
      assignedArchitectId: architectId,
      assignedAt: new Date().toISOString(),
    };
    
    this.projects.set(projectId, updatedProject);
    return updatedProject;
  }

  async setBoardType(projectId: number, boardType: string, scrumMasterId: number): Promise<Project | undefined> {
    const project = this.projects.get(projectId);
    if (!project) return undefined;

    const updatedProject: Project = {
      ...project,
      boardType,
      managedByScrumMasterId: scrumMasterId,
    };
    
    this.projects.set(projectId, updatedProject);
    return updatedProject;
  }

  async getArchitectProjects(architectId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(project => 
      project.assignedArchitectId === architectId
    );
  }

  // Architecture methods
  async getArchitecture(projectId: number): Promise<Architecture | undefined> {
    return Array.from(this.architectures.values()).find(arch => arch.projectId === projectId);
  }

  async createArchitecture(architecture: InsertArchitecture): Promise<Architecture> {
    const id = this.currentArchitectureId++;
    const now = new Date().toISOString();
    const newArchitecture: Architecture = {
      ...architecture,
      id,
      createdAt: now,
      updatedAt: now,
      finalizedAt: null,
    };
    this.architectures.set(id, newArchitecture);
    return newArchitecture;
  }

  async updateArchitecture(projectId: number, architecture: Partial<InsertArchitecture>): Promise<Architecture | undefined> {
    const existing = await this.getArchitecture(projectId);
    if (!existing) return undefined;

    const updatedArchitecture: Architecture = {
      ...existing,
      ...architecture,
      updatedAt: new Date().toISOString(),
    };
    this.architectures.set(existing.id, updatedArchitecture);
    return updatedArchitecture;
  }

  async finalizeArchitecture(projectId: number): Promise<Architecture | undefined> {
    const existing = await this.getArchitecture(projectId);
    if (!existing) return undefined;

    const finalizedArchitecture: Architecture = {
      ...existing,
      status: "finalized",
      finalizedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.architectures.set(existing.id, finalizedArchitecture);
    return finalizedArchitecture;
  }
}

import { FileStorage } from "./file-storage";

export const storage = new FileStorage();
