import { users, projects, useCases, type User, type InsertUser, type Project, type InsertProject, type UseCase, type InsertUseCase } from "@shared/schema";
import { promises as fs } from "fs";
import path from "path";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserRole(userId: number, role: string): Promise<User | undefined>;

  // Project methods
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  getProjectsByOwner(ownerId: number): Promise<Project[]>;

  // Use case methods
  getUseCasesByProject(projectId: number): Promise<UseCase[]>;
  getUseCase(id: number): Promise<UseCase | undefined>;
  createUseCase(useCase: InsertUseCase): Promise<UseCase>;
  updateUseCase(id: number, useCase: Partial<InsertUseCase>): Promise<UseCase | undefined>;
  deleteUseCase(id: number): Promise<boolean>;

  // Project deletion
  deleteProject(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private useCases: Map<number, UseCase>;
  private currentUserId: number;
  private currentProjectId: number;
  private currentUseCaseId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.useCases = new Map();
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.currentUseCaseId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample users with multiple roles
    const user1: User = {
      id: 1,
      username: "johndoe",
      password: "password123", // In production, this would be hashed
      name: "John Doe",
      roles: ["business-analyst", "product-owner", "scrum-master", "architect", "ui-designer", "developer", "production-management", "devops", "approver"],
      currentRole: "business-analyst"
    };

    const user2: User = {
      id: 2,
      username: "approver",
      password: "password123",
      name: "Sarah Wilson",
      roles: ["approver", "architect"],
      currentRole: "approver"
    };

    this.users.set(1, user1);
    this.users.set(2, user2);
    this.currentUserId = 3;

    // Create sample projects with approval workflow
    const project1: Project = {
      id: 1,
      name: "E-Commerce Platform",
      description: "Modern e-commerce solution with advanced analytics and AI-powered recommendations",
      status: "Active",
      type: "Web Application",
      startDate: "Dec 2024",
      teamSize: 8,
      ownerId: 1,
      approvalStatus: "approved",
      approvedById: 2,
      approvedAt: "2024-12-01",
      createdAt: "2024-11-15"
    };

    const project2: Project = {
      id: 2,
      name: "Customer Portal",
      description: "Self-service portal for customer account management and support",
      status: "Planning",
      type: "Web Application",
      startDate: "Jan 2025",
      teamSize: 5,
      ownerId: 1,
      approvalStatus: "pending",
      approvedById: null,
      approvedAt: null,
      createdAt: "2024-12-10"
    };

    const project3: Project = {
      id: 3,
      name: "Analytics Dashboard",
      description: "Real-time business intelligence dashboard with predictive analytics",
      status: "Development",
      type: "Data Analytics",
      startDate: "Nov 2024",
      teamSize: 6,
      ownerId: 1,
      approvalStatus: "approved",
      approvedById: 2,
      approvedAt: "2024-11-20",
      createdAt: "2024-11-10"
    };

    this.projects.set(1, project1);
    this.projects.set(2, project2);
    this.projects.set(3, project3);
    this.currentProjectId = 4;

    // Create sample use cases for project 1
    const useCases = [
      {
        id: 1,
        projectId: 1,
        ucId: "UC-001",
        title: "User Registration",
        description: "Allow new users to create an account with email verification and profile setup",
        type: "functional",
        priority: "High",
        status: "Approved",
        actor: "Customer",
        category: null,
        updatedAt: "2 days ago"
      },
      {
        id: 2,
        projectId: 1,
        ucId: "UC-002",
        title: "Product Search",
        description: "Enable users to search for products using filters, categories, and AI-powered recommendations",
        type: "functional",
        priority: "High",
        status: "In Review",
        actor: "Customer",
        category: null,
        updatedAt: "1 day ago"
      },
      {
        id: 3,
        projectId: 1,
        ucId: "UC-003",
        title: "Shopping Cart Management",
        description: "Allow users to add, remove, and modify items in their shopping cart with persistence across sessions",
        type: "functional",
        priority: "Medium",
        status: "Approved",
        actor: "Customer",
        category: null,
        updatedAt: "3 days ago"
      },
      {
        id: 4,
        projectId: 1,
        ucId: "NF-001",
        title: "Performance Requirements",
        description: "System must handle 10,000 concurrent users with response time under 2 seconds",
        type: "non-functional",
        priority: "Critical",
        status: "Approved",
        actor: null,
        category: "Performance",
        updatedAt: "1 day ago"
      },
      {
        id: 5,
        projectId: 1,
        ucId: "NF-002",
        title: "Security Requirements",
        description: "All user data must be encrypted at rest and in transit with multi-factor authentication",
        type: "non-functional",
        priority: "Critical",
        status: "Approved",
        actor: null,
        category: "Security",
        updatedAt: "2 days ago"
      },
      {
        id: 6,
        projectId: 1,
        ucId: "NF-003",
        title: "Scalability Requirements",
        description: "System architecture must support horizontal scaling to accommodate 5x traffic growth",
        type: "non-functional",
        priority: "High",
        status: "In Review",
        actor: null,
        category: "Scalability",
        updatedAt: "4 days ago"
      }
    ];

    useCases.forEach(uc => {
      this.useCases.set(uc.id, uc as UseCase);
    });
    this.currentUseCaseId = 7;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUserRole(userId: number, role: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    user.currentRole = role;
    this.users.set(userId, user);
    return user;
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const project: Project = { 
      ...insertProject, 
      id,
      ownerId: insertProject.ownerId || null,
      approvalStatus: insertProject.approvalStatus || "pending",
      approvedById: insertProject.approvedById || null,
      approvedAt: insertProject.approvedAt || null
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, updateData: Partial<InsertProject>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;

    const updatedProject: Project = {
      ...project,
      ...updateData,
      id, // Ensure ID is preserved
    };
    
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async getProjectsByOwner(ownerId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(project => project.ownerId === ownerId);
  }

  async getUseCasesByProject(projectId: number): Promise<UseCase[]> {
    return Array.from(this.useCases.values()).filter(uc => uc.projectId === projectId);
  }

  async getUseCase(id: number): Promise<UseCase | undefined> {
    return this.useCases.get(id);
  }

  async createUseCase(insertUseCase: InsertUseCase): Promise<UseCase> {
    const id = this.currentUseCaseId++;
    const useCase: UseCase = { 
      ...insertUseCase, 
      id,
      actor: insertUseCase.actor || null,
      category: insertUseCase.category || null
    };
    this.useCases.set(id, useCase);
    return useCase;
  }

  async updateUseCase(id: number, updateData: Partial<InsertUseCase>): Promise<UseCase | undefined> {
    const useCase = this.useCases.get(id);
    if (!useCase) return undefined;
    
    const updated = { ...useCase, ...updateData };
    this.useCases.set(id, updated);
    return updated;
  }

  async deleteUseCase(id: number): Promise<boolean> {
    return this.useCases.delete(id);
  }

  async deleteProject(id: number): Promise<boolean> {
    const deleted = this.projects.delete(id);
    if (deleted) {
      // Also delete all associated use cases
      const useCases = Array.from(this.useCases.entries());
      useCases.forEach(([ucId, useCase]) => {
        if (useCase.projectId === id) {
          this.useCases.delete(ucId);
        }
      });
    }
    return deleted;
  }
}

import { FileStorage } from "./file-storage";

export const storage = new FileStorage();
