import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, createProjectSchema, chatMessageSchema, approveProjectSchema, assignDeliverableSchema } from "@shared/schema";
import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";
import * as tf from '@tensorflow/tfjs-node';
import { aiAgentFramework } from './ai-agents';
import { DeliverableService } from "./jira-integration";

// BERT Enhancement Function
async function applyBERTEnhancement(rawResponse: string): Promise<string> {
  try {
    console.log("🤖 Applying BERT semantic enhancement...");
    
    // Simple tokenization (simplified for demo purposes)
    const words = rawResponse.toLowerCase().split(/\s+/);
    const maxLength = 512; // BERT max sequence length
    const tokenIds = words.slice(0, maxLength).map(word => {
      // Simple vocabulary mapping (in production, use proper vocab.txt)
      return word.charCodeAt(0) % 30522; // BERT vocab size
    });
    
    // Pad sequence to fixed length
    while (tokenIds.length < 128) tokenIds.push(0);
    
    // Create input tensor
    const inputTensor = tf.tensor2d([tokenIds.slice(0, 128)], [1, 128]);
    
    // Mock BERT processing with tensor operations
    const enhanced = tf.mul(inputTensor, tf.scalar(1.1)); // Semantic enhancement simulation
    const embeddings = await enhanced.data();
    
    // Apply domain-specific enhancement rules
    const enhancedText = applyFinancialDomainRefinement(rawResponse, new Float32Array(embeddings));
    
    // Cleanup
    inputTensor.dispose();
    enhanced.dispose();
    
    console.log("✅ BERT enhancement completed");
    return enhancedText;
    
  } catch (error) {
    console.log("⚠️ BERT enhancement failed, using original response");
    return rawResponse;
  }
}

// Financial Domain Refinement
function applyFinancialDomainRefinement(originalText: string, embeddings: Float32Array | Int32Array | Uint8Array): string {
  let enhanced = originalText;
  
  // Investment banking terminology enhancement
  const financialTerms = {
    'system': 'enterprise platform',
    'application': 'financial application',
    'data': 'market data',
    'process': 'business process',
    'user': 'trading desk user',
    'report': 'regulatory report',
    'transaction': 'financial transaction'
  };
  
  // Apply terminology enhancements
  Object.entries(financialTerms).forEach(([generic, specific]) => {
    const regex = new RegExp(`\\b${generic}\\b`, 'gi');
    enhanced = enhanced.replace(regex, specific);
  });
  
  // Add regulatory compliance context
  enhanced = enhanced.replace(/\b(requirement|specification)\b/gi, '$1 with regulatory compliance');
  enhanced = enhanced.replace(/\b(security|access)\b/gi, '$1 and MiFID II compliance');
  enhanced = enhanced.replace(/\b(reporting|audit)\b/gi, '$1 per Basel III standards');
  
  // Enhance technical language
  enhanced = enhanced.replace(/\bapi\b/gi, 'REST API with enterprise security');
  enhanced = enhanced.replace(/\bdatabase\b/gi, 'enterprise data warehouse');
  enhanced = enhanced.replace(/\binterface\b/gi, 'trading desk interface');
  
  return enhanced;
}

// Initialize deliverable service for Jira integration
const deliverableService = new DeliverableService();

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // In production, you'd set up proper session management
      res.json({
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          roles: user.roles,
          currentRole: user.currentRole,
          sealApplications: user.sealApplications
        }
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // SSO Login route
  app.post("/api/auth/sso-login", async (req, res) => {
    try {
      // Simulate JPMC SSO authentication
      const user = await storage.getUserByUsername('gpraharaj');
      if (!user) {
        return res.status(401).json({ message: "SSO authentication failed" });
      }

      res.json({
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          roles: user.roles,
          currentRole: user.currentRole,
          sealApplications: user.sealApplications
        }
      });
    } catch (error) {
      res.status(500).json({ message: "SSO authentication failed" });
    }
  });

  app.post("/api/auth/logout", async (req, res) => {
    // In production, you'd clear the session
    res.json({ message: "Logged out successfully" });
  });

  app.get("/api/auth/user", async (req, res) => {
    // In production, you'd get this from session/JWT
    const user = await storage.getUser(1); // Mock user ID
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    res.json({
      id: user.id,
      username: user.username,
      name: user.name,
      roles: user.roles,
      currentRole: user.currentRole,
      sealApplications: user.sealApplications
    });
  });

  // User routes
  app.put("/api/users/:id/role", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { role } = req.body;
      
      const user = await storage.updateUserRole(userId, role);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          roles: user.roles,
          currentRole: user.currentRole
        }
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // AI-powered project creation route
  app.post("/api/ai/create-project", async (req, res) => {
    try {
      const { description, currentRole, userRole } = req.body;
      const role = currentRole || userRole;
      
      if (!description) {
        return res.status(400).json({ message: "Project description is required" });
      }
      
      if (role !== "Business Analyst" && role !== "business-analyst" && role !== "Product Owner" && role !== "product-owner") {
        return res.status(403).json({ message: "Only Business Analysts and Product Owners can create AI projects" });
      }

      console.log("🤖 Starting AI-powered project creation with AWS Bedrock...");
      
      // Use AI Agent Framework to process business requirements
      const aiResponse = await aiAgentFramework.processBusinessRequirements(description, {
        userRole: role,
        requestType: 'project_creation'
      });

      // Apply BERT enhancement for financial domain refinement
      const enhancedResponse = await applyBERTEnhancement(JSON.stringify(aiResponse));
      console.log("🎯 AI-powered project analysis completed with enterprise-grade specifications");

      // Extract project details intelligently from user input BEFORE AI processing
      const projectName = extractProjectName(description);
      const projectDescription = extractProjectDescription(description) || description;
      
      // Generate unique project name if needed
      const existingProjects = await storage.getProjects();
      let finalProjectName = projectName;
      let counter = 1;
      
      while (existingProjects.find(p => p.name.toLowerCase() === finalProjectName.toLowerCase())) {
        finalProjectName = `${projectName} v${counter}`;
        counter++;
      }
      
      if (finalProjectName !== projectName) {
        console.log(`📝 Generated unique project name: ${finalProjectName}`);
      }
      
      // Determine if this is a Product Owner technical project (auto-approve)
      const isProductOwnerTechProject = (role === "Product Owner" || role === "product-owner") &&
        (projectName.toLowerCase().includes('migration') ||
         projectName.toLowerCase().includes('upgrade') ||
         projectName.toLowerCase().includes('infrastructure') ||
         projectName.toLowerCase().includes('deployment') ||
         projectName.toLowerCase().includes('devops') ||
         description.toLowerCase().includes('technical') ||
         description.toLowerCase().includes('infrastructure'));

      const projectStatus = isProductOwnerTechProject ? "Approved for Development" : "Draft";
      const approvalStatus = isProductOwnerTechProject ? "approved" : "draft";
      const approvedAt = isProductOwnerTechProject ? new Date().toISOString() : null;

      // Create the project
      const project = await storage.createProject({
        name: finalProjectName,
        description: projectDescription,
        type: "Financial Services Platform",
        status: projectStatus,
        startDate: new Date().toISOString().split('T')[0],
        teamSize: 8,
        createdAt: new Date().toISOString(),
        ownerId: 1, // In production, get from authenticated user
        approvalStatus: approvalStatus,
        approvedById: isProductOwnerTechProject ? 1 : null,
        approvedAt: approvedAt,
        sealApplicationId: null,
        managedByScrumMasterId: null
      });

      if (isProductOwnerTechProject) {
        console.log(`🚀 Product Owner technical project "${projectName}" auto-approved for development`);
      }

      // Generate simplified functional requirements from AI response
      const functionalRequirements = [];
      for (let i = 0; i < Math.min(aiResponse.functionalRequirements.length, 6); i++) {
        const req = aiResponse.functionalRequirements[i];
        const createdUseCase = await storage.createUseCase({
          projectId: project.id,
          ucId: `UC-F-${String(i + 1).padStart(3, '0')}`,
          title: req.length > 80 ? req.substring(0, 80) + "..." : req,
          description: req,
          type: 'functional',
          priority: 'Medium',
          status: 'Draft',
          updatedAt: new Date().toISOString()
        });
        functionalRequirements.push(createdUseCase);
      }

      // Generate simplified non-functional requirements
      const nonFunctionalRequirements = [];
      for (let i = 0; i < Math.min(aiResponse.nonFunctionalRequirements.length, 4); i++) {
        const req = aiResponse.nonFunctionalRequirements[i];
        const createdUseCase = await storage.createUseCase({
          projectId: project.id,
          ucId: `UC-NF-${String(i + 1).padStart(3, '0')}`,
          title: req.length > 80 ? req.substring(0, 80) + "..." : req,
          description: req,
          type: 'non-functional',
          priority: 'High',
          status: 'Draft',
          updatedAt: new Date().toISOString()
        });
        nonFunctionalRequirements.push(createdUseCase);
      }

      // Add enhanced EMIR requirements if detected
      if (description.toLowerCase().includes('emir') || description.toLowerCase().includes('reporting')) {
        const emirRequirements = enhanceEMIRFunctionalRequirements([]);
        for (const req of emirRequirements.slice(0, 2)) { // Add top 2 EMIR requirements
          const createdUseCase = await storage.createUseCase({
            projectId: project.id,
            ucId: `UC-F-EMIR-${String(functionalRequirements.length + 1).padStart(3, '0')}`,
            title: req.title,
            description: req.description,
            type: 'functional',
            priority: 'Critical',
            status: 'Draft',
            updatedAt: new Date().toISOString()
          });
          functionalRequirements.push(createdUseCase);
        }
      }

      const allUseCases = [...functionalRequirements, ...nonFunctionalRequirements];

      console.log(`✅ Created project "${project.name}" with ${functionalRequirements.length} functional and ${nonFunctionalRequirements.length} non-functional requirements`);

      // Auto-create deliverables for Product Owner technical projects
      if (isProductOwnerTechProject) {
        try {
          const { deliverables, jiraProjectKey, userStories } = await deliverableService.createDeliverablesFromApproval(
            project.id,
            project.name,
            allUseCases
          );
          
          console.log(`🎯 Auto-created ${deliverables.length} deliverables for technical project`);
          
          res.json({
            project,
            functionalRequirements,
            nonFunctionalRequirements,
            useCases: allUseCases,
            useCasesCreated: functionalRequirements.length + nonFunctionalRequirements.length,
            autoApproved: true,
            deliverables: deliverables,
            jiraProjectKey: jiraProjectKey,
            userStoriesCreated: userStories.length,
            message: "Technical project auto-approved and deliverables created"
          });
        } catch (error) {
          console.error("Error creating deliverables for auto-approved project:", error);
          res.json({
            project,
            functionalRequirements,
            nonFunctionalRequirements,
            useCases: allUseCases,
            useCasesCreated: functionalRequirements.length + nonFunctionalRequirements.length,
            autoApproved: true,
            message: "Technical project auto-approved (deliverables will be created later)"
          });
        }
      } else {
        res.json({
          project,
          functionalRequirements,
          nonFunctionalRequirements,
          useCases: allUseCases,
          aiAnalysis: aiResponse,
          enhancedAnalysis: enhancedResponse
        });
      }

    } catch (error) {
      console.error("❌ AI project creation failed:", error);
      res.status(500).json({ 
        message: "Failed to create AI-powered project", 
        error: error.message 
      });
    }
  });

  // Project creation route
  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = createProjectSchema.parse(req.body);
      
      const project = await storage.createProject({
        ...projectData,
        status: "Planning", // Default status for new projects
        ownerId: 1, // In production, get from authenticated user
        approvalStatus: "pending",
        approvedById: null,
        approvedAt: null,
        createdAt: new Date().toISOString()
      });

      res.json(project);
    } catch (error) {
      res.status(400).json({ message: "Invalid project data" });
    }
  });

  // Use case creation route
  app.post("/api/use-cases", async (req, res) => {
    try {
      const useCaseData = req.body;
      
      const useCase = await storage.createUseCase(useCaseData);
      res.json(useCase);
    } catch (error) {
      res.status(400).json({ message: "Invalid use case data" });
    }
  });

  // Project routes
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      
      // Get use case counts for each project
      const projectsWithUseCases = await Promise.all(
        projects.map(async (project) => {
          const useCases = await storage.getUseCasesByProject(project.id);
          const functionalCount = useCases.filter(uc => uc.type === 'functional').length;
          const nonFunctionalCount = useCases.filter(uc => uc.type === 'non-functional').length;
          
          return {
            ...project,
            functionalUseCases: functionalCount,
            nonFunctionalUseCases: nonFunctionalCount
          };
        })
      );

      res.json(projectsWithUseCases);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json(project);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Submit project for approval
  app.post("/api/projects/:id/submit-for-approval", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Enhanced validation - check multiple conditions for true draft status
      const isDraft = project.approvalStatus === 'draft' && 
                     !project.submittedAt && 
                     !project.approvedAt &&
                     project.status === 'Draft';
      
      if (!isDraft) {
        console.log(`❌ Project ${projectId} "${project.name}" not in valid draft status:`, {
          approvalStatus: project.approvalStatus,
          status: project.status,
          submittedAt: project.submittedAt,
          approvedAt: project.approvedAt
        });
        return res.status(400).json({ 
          message: "Project is not in draft status",
          currentStatus: project.status,
          currentApprovalStatus: project.approvalStatus
        });
      }

      // Update project status to pending review
      const updatedProject = await storage.updateProject(projectId, {
        status: 'Pending Review',
        approvalStatus: 'pending',
        submittedAt: new Date().toISOString()
      });

      if (!updatedProject) {
        console.log(`❌ Failed to update project ${projectId} during submission`);
        return res.status(500).json({ message: "Failed to update project status" });
      }

      console.log(`✅ Project ${projectId} "${project.name}" submitted for approval`);

      res.json({ 
        message: "Project submitted for approval successfully",
        project: updatedProject 
      });
    } catch (error) {
      console.error("Error submitting project for approval:", error);
      res.status(500).json({ message: "Failed to submit project for approval" });
    }
  });

  // Delete project (only draft projects)
  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      // Only allow deletion of draft projects
      if (project.status !== "Draft" && project.approvalStatus !== "draft") {
        return res.status(400).json({ message: "Only draft projects can be deleted" });
      }
      
      const deleted = await storage.deleteProject(projectId);
      if (deleted) {
        res.json({ message: "Project deleted successfully" });
      } else {
        res.status(404).json({ message: "Project not found" });
      }
    } catch (error) {
      console.error("Error deleting project:", error);
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Use case routes
  app.get("/api/projects/:id/use-cases", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const useCases = await storage.getUseCasesByProject(projectId);
      
      res.json(useCases);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.get("/api/use-cases/:id", async (req, res) => {
    try {
      const useCaseId = parseInt(req.params.id);
      const useCase = await storage.getUseCase(useCaseId);
      
      if (!useCase) {
        return res.status(404).json({ message: "Use case not found" });
      }

      res.json(useCase);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.put("/api/use-cases/:id", async (req, res) => {
    try {
      const useCaseId = parseInt(req.params.id);
      const updateData = req.body;
      
      const updatedUseCase = await storage.updateUseCase(useCaseId, updateData);
      
      if (!updatedUseCase) {
        return res.status(404).json({ message: "Use case not found" });
      }

      res.json(updatedUseCase);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.delete("/api/use-cases/:id", async (req, res) => {
    try {
      const useCaseId = parseInt(req.params.id);
      const deleted = await storage.deleteUseCase(useCaseId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Use case not found" });
      }

      res.json({ message: "Use case deleted successfully" });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.post("/api/use-cases/:id/submit", async (req, res) => {
    try {
      const useCaseId = parseInt(req.params.id);
      const updatedUseCase = await storage.updateUseCase(useCaseId, { 
        status: "in-review" 
      });
      
      if (!updatedUseCase) {
        return res.status(404).json({ message: "Use case not found" });
      }

      res.json(updatedUseCase);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const deleted = await storage.deleteProject(projectId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json({ message: "Project deleted successfully" });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Project approval workflow endpoints
  app.post("/api/projects/:id/submit", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const updatedProject = await storage.updateProject(projectId, { 
        status: "in_review",
        approvalStatus: "pending" 
      });
      
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json(updatedProject);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.post("/api/projects/:id/approve", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      
      // Get project and use cases before approval
      const project = await storage.getProject(projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      const useCases = await storage.getUseCasesByProject(projectId);
      
      // Update project status to move to Development section
      const updatedProject = await storage.updateProject(projectId, { 
        status: "Approved for Development",
        approvalStatus: "approved",
        approvedAt: new Date().toISOString()
      });

      // Create deliverables and Jira integration
      console.log(`🎯 Project approved: ${project.name}. Creating deliverables and Jira epics...`);
      
      const { deliverables, jiraProjectKey, userStories } = await deliverableService.createDeliverablesFromApproval(
        projectId,
        project.name,
        useCases
      );

      // Store deliverables in the system
      const createdDeliverables = [];
      for (const deliverable of deliverables) {
        const created = await storage.createDeliverable({
          projectId: deliverable.projectId,
          name: deliverable.name,
          description: deliverable.description,
          status: deliverable.status,
          assignedTo: deliverable.assignedTo,
          assignedBy: deliverable.assignedBy,
          jiraProjectKey: deliverable.jiraProjectKey,
          jiraEpicKey: deliverable.jiraEpicKey,
          createdAt: deliverable.createdAt,
          updatedAt: deliverable.updatedAt
        });
        createdDeliverables.push(created);
      }

      // Store user stories with proper deliverable IDs
      for (let i = 0; i < userStories.length; i++) {
        const story = userStories[i];
        const deliverableIndex = Math.floor(i / Math.ceil(userStories.length / createdDeliverables.length));
        const deliverable = createdDeliverables[deliverableIndex] || createdDeliverables[0];
        
        await storage.createUserStory({
          deliverableId: deliverable.id,
          useCaseId: story.useCaseId,
          title: story.title,
          description: story.description,
          acceptanceCriteria: story.acceptanceCriteria,
          storyPoints: story.storyPoints,
          priority: story.priority,
          status: story.status,
          jiraIssueKey: story.jiraIssueKey,
          assignedTo: story.assignedTo,
          createdAt: story.createdAt,
          updatedAt: story.updatedAt
        });
      }

      // Intelligent product backlog generation from functional and non-functional requirements
      const projectUseCases = await storage.getUseCasesByProject(projectId);
      
      // Categorize requirements for intelligent backlog creation
      const functionalRequirements = projectUseCases.filter(uc => uc.type === 'functional');
      const nonFunctionalRequirements = projectUseCases.filter(uc => uc.type === 'non-functional');
      
      // Generate detailed backlog items from functional requirements
      for (const funcReq of functionalRequirements) {
        const intelligentBacklogItems = generateIntelligentBacklogItems(funcReq, project);
        
        for (const item of intelligentBacklogItems) {
          const createdBacklogItem = await storage.createBacklogItem({
            projectId,
            ...item,
            createdById: 1,
            status: "backlog",
            sprint: null,
            kanbanColumn: "To Do",
            scrumStatus: "Product Backlog",
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
          
          // Generate multiple user stories for this backlog item based on complexity
          const userStories = generateUserStoriesForBacklogItem(createdBacklogItem, funcReq);
          let totalStoryPoints = 0;
          
          for (const storyData of userStories) {
            const userStory = await storage.createUserStory({
              deliverableId: 1, // Default deliverable for now
              useCaseId: funcReq.id,
              backlogItemId: createdBacklogItem.id,
              ...storyData,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            });
            totalStoryPoints += userStory.storyPoints || 0;
          }
          
          // Update the backlog item with total story points
          await storage.updateBacklogItem(createdBacklogItem.id, {
            totalStoryPoints: totalStoryPoints
          });
        }
      }
      
      // Generate comprehensive infrastructure and quality backlog items from non-functional requirements
      for (const nonFuncReq of nonFunctionalRequirements) {
        const infraBacklogItems = generateInfrastructureBacklogItems(nonFuncReq, project);
        
        for (const item of infraBacklogItems) {
          await storage.createBacklogItem({
            projectId,
            ...item,
            createdById: 1,
            status: "To Do",
            assignedTo: null,
            sprint: null,
            scrumStatus: "Product Backlog",
            kanbanColumn: "To Do",
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
        }
      }
      
      // Generate cross-cutting concerns and epic-level items
      const epicItems = generateEpicBacklogItems(project, functionalRequirements, nonFunctionalRequirements);
      for (const item of epicItems) {
        await storage.createBacklogItem({
          projectId,
          ...item,
          createdById: 1,
          status: "To Do",
          assignedTo: null,
          sprint: null,
          scrumStatus: null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
      }

      res.json({
        project: updatedProject,
        deliverables: createdDeliverables,
        jiraProjectKey,
        userStoriesCreated: userStories.length,
        backlogItemsCreated: useCases.length,
        message: `Project approved! Created ${createdDeliverables.length} deliverables, ${userStories.length} user stories, and ${useCases.length} product backlog items`
      });
    } catch (error) {
      console.error("Project approval error:", error);
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.post("/api/projects/:id/reject", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const updatedProject = await storage.updateProject(projectId, { 
        status: "draft",
        approvalStatus: "rejected"
      });
      
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json(updatedProject);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Deliverables management endpoints
  app.get("/api/projects/:id/deliverables", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const deliverables = await storage.getDeliverablesByProject(projectId);
      res.json(deliverables);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.get("/api/deliverables/:id/stories", async (req, res) => {
    try {
      const deliverableId = parseInt(req.params.id);
      const userStories = await storage.getUserStoriesByDeliverable(deliverableId);
      res.json(userStories);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Scrum Master assignment endpoint
  app.post("/api/deliverables/:id/assign", async (req, res) => {
    try {
      const deliverableId = parseInt(req.params.id);
      const { assignedTo, comments } = assignDeliverableSchema.parse(req.body);
      
      const deliverable = await storage.getDeliverable(deliverableId);
      if (!deliverable) {
        return res.status(404).json({ message: "Deliverable not found" });
      }

      // Update deliverable assignment
      const updatedDeliverable = await storage.updateDeliverable(deliverableId, {
        assignedTo,
        assignedBy: 1, // Scrum Master user ID
        status: "in_progress",
        updatedAt: new Date().toISOString()
      });

      // Update Jira epic assignment
      if (deliverable.jiraEpicKey) {
        await deliverableService.assignDeliverableToRole(
          deliverableId,
          deliverable.jiraEpicKey,
          assignedTo
        );
      }

      res.json({
        deliverable: updatedDeliverable,
        message: `Deliverable assigned to ${assignedTo}`,
        jiraUpdated: !!deliverable.jiraEpicKey
      });
    } catch (error) {
      console.error("Assignment error:", error);
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Enhanced AI Agent endpoints for role-specific intelligence

  // Business Analyst Agent - Process requirements and generate structured analysis
  app.post("/api/agents/business-analyst/analyze", async (req, res) => {
    try {
      const { input, projectId } = req.body;
      const projectContext = projectId ? await storage.getProject(projectId) : null;
      
      const analysis = await aiAgentFramework.processBusinessRequirements(input, projectContext);
      
      res.json({
        analysis,
        recommendations: analysis.recommendations,
        nextSteps: [
          "Review and refine functional requirements",
          "Validate non-functional requirements with stakeholders",
          "Submit structured proposal to Product Owner",
          "Schedule stakeholder review meeting"
        ]
      });
    } catch (error) {
      console.error("Business Analyst Agent error:", error);
      res.status(500).json({ message: "Analysis processing failed" });
    }
  });

  // Product Owner Agent - Evaluate project proposals
  app.post("/api/agents/product-owner/evaluate", async (req, res) => {
    try {
      const { projectId } = req.body;
      const project = await storage.getProject(projectId);
      const requirements = await storage.getUseCasesByProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const evaluation = await aiAgentFramework.evaluateProjectProposal(project, requirements);
      
      res.json({
        evaluation,
        actionItems: evaluation.recommendation === 'approve' ? 
          ["Create Jira epics and deliverables", "Assign to Scrum Master", "Schedule kick-off meeting"] :
          ["Request additional information", "Schedule stakeholder meeting", "Provide detailed feedback"]
      });
    } catch (error) {
      console.error("Product Owner Agent error:", error);
      res.status(500).json({ message: "Evaluation processing failed" });
    }
  });

  // Scrum Master Agent - Create sprint planning and team assignments
  app.post("/api/agents/scrum-master/plan", async (req, res) => {
    try {
      const { projectId } = req.body;
      const project = await storage.getProject(projectId);
      const deliverables = await storage.getDeliverablesByProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const sprintPlan = await aiAgentFramework.createSprintPlan(project, deliverables);
      
      res.json({
        sprintPlan,
        teamCoordination: {
          architect: "System design and technology selection",
          uiDesigner: "Wireframes and design system creation",
          developer: "Core development and implementation",
          devops: "Infrastructure setup and deployment strategy"
        },
        nextActions: [
          "Review sprint goals with team",
          "Assign deliverables to team members",
          "Schedule sprint planning meeting",
          "Set up project tracking dashboard"
        ]
      });
    } catch (error) {
      console.error("Scrum Master Agent error:", error);
      res.status(500).json({ message: "Sprint planning failed" });
    }
  });

  // Architect Agent - Generate system architecture recommendations
  app.post("/api/agents/architect/design", async (req, res) => {
    try {
      const { projectId } = req.body;
      const project = await storage.getProject(projectId);
      const requirements = await storage.getUseCasesByProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const architecture = await aiAgentFramework.generateArchitectureRecommendations(project, requirements);
      
      res.json({
        architecture,
        deliverables: [
          "System architecture diagram",
          "Technology stack documentation",
          "Infrastructure requirements specification",
          "Security architecture plan",
          "Integration design document"
        ],
        timeline: "2-3 weeks for complete architecture design"
      });
    } catch (error) {
      console.error("Architect Agent error:", error);
      res.status(500).json({ message: "Architecture design failed" });
    }
  });

  // UI Designer Agent - Generate UI/UX recommendations and wireframes
  app.post("/api/agents/ui-designer/design", async (req, res) => {
    try {
      const { projectId } = req.body;
      const project = await storage.getProject(projectId);
      const userStories = await storage.getUserStoriesByDeliverable(1); // Get sample user stories
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const uiRecommendations = await aiAgentFramework.generateUIRecommendations(project, userStories);
      
      res.json({
        uiRecommendations,
        deliverables: [
          "User interface wireframes",
          "User flow diagrams",
          "Design system components",
          "Responsive design specifications",
          "Accessibility compliance checklist"
        ],
        tools: ["Figma", "Adobe XD", "Sketch", "InVision"],
        timeline: "1-2 weeks for complete UI design"
      });
    } catch (error) {
      console.error("UI Designer Agent error:", error);
      res.status(500).json({ message: "UI design generation failed" });
    }
  });

  // Developer Agent - Generate development guidance and code structure
  app.post("/api/agents/developer/guide", async (req, res) => {
    try {
      const { userStoryId, projectId } = req.body;
      const userStory = await storage.getUserStory(userStoryId);
      const project = await storage.getProject(projectId);
      
      if (!userStory || !project) {
        return res.status(404).json({ message: "User story or project not found" });
      }
      
      // Get architecture context (simplified for demo)
      const architectureContext = { stack: "Node.js + React + PostgreSQL" };
      
      const guidance = await aiAgentFramework.generateDevelopmentGuidance(userStory, architectureContext);
      
      res.json({
        guidance,
        estimatedEffort: `${userStory.storyPoints || 5} story points`,
        technologies: ["TypeScript", "React", "Node.js", "PostgreSQL"],
        codeReview: "Required before merge to main branch",
        timeline: "3-5 days for implementation and testing"
      });
    } catch (error) {
      console.error("Developer Agent error:", error);
      res.status(500).json({ message: "Development guidance failed" });
    }
  });

  // DevOps Agent - Generate deployment and infrastructure strategy
  app.post("/api/agents/devops/deploy", async (req, res) => {
    try {
      const { projectId } = req.body;
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      // Get architecture context (simplified for demo)
      const architectureContext = { 
        type: "microservices",
        stack: "Node.js + React + PostgreSQL",
        scale: "enterprise"
      };
      
      const deploymentStrategy = await aiAgentFramework.generateDeploymentStrategy(project, architectureContext);
      
      res.json({
        deploymentStrategy,
        environments: ["Development", "Staging", "Production"],
        tools: ["Docker", "Kubernetes", "Terraform", "Jenkins"],
        monitoring: ["Prometheus", "Grafana", "ELK Stack"],
        timeline: "1-2 weeks for complete DevOps setup"
      });
    } catch (error) {
      console.error("DevOps Agent error:", error);
      res.status(500).json({ message: "Deployment strategy failed" });
    }
  });

  // Universal AI Chat endpoint with role-based context
  app.post("/api/agents/chat", async (req, res) => {
    try {
      const { message, role, projectId, context } = req.body;
      
      let aiResponse = "";
      let actionItems: string[] = [];
      
      // Route to appropriate agent based on role
      switch (role) {
        case 'business-analyst':
          if (message.toLowerCase().includes('requirements') || message.toLowerCase().includes('analyze')) {
            const analysis = await aiAgentFramework.processBusinessRequirements(message, context);
            aiResponse = `I've analyzed your requirements and identified ${analysis.functionalRequirements.length} functional and ${analysis.nonFunctionalRequirements.length} non-functional requirements. Key recommendations include: ${analysis.recommendations.slice(0, 2).join(', ')}.`;
            actionItems = ["Review functional requirements", "Validate with stakeholders"];
          }
          break;
          
        case 'product-owner':
          if (projectId) {
            const project = await storage.getProject(projectId);
            const requirements = await storage.getUseCasesByProject(projectId);
            const evaluation = await aiAgentFramework.evaluateProjectProposal(project, requirements);
            aiResponse = `Project evaluation complete. Priority score: ${evaluation.priorityScore}/10. Recommendation: ${evaluation.recommendation}. ${evaluation.feedback.slice(0, 1).join(' ')}`;
            actionItems = evaluation.recommendation === 'approve' ? ["Create deliverables", "Assign to Scrum Master"] : ["Request changes", "Schedule review"];
          }
          break;
          
        case 'scrum-master':
          if (projectId) {
            const project = await storage.getProject(projectId);
            const deliverables = await storage.getDeliverablesByProject(projectId);
            const sprintPlan = await aiAgentFramework.createSprintPlan(project, deliverables);
            aiResponse = `Sprint planning complete. Recommended ${sprintPlan.sprints.length} sprints with focus on ${sprintPlan.sprints[0]?.goals.join(', ')}. Key dependencies identified: ${sprintPlan.dependencies.slice(0, 2).join(', ')}.`;
            actionItems = ["Review with team", "Assign deliverables"];
          }
          break;
          
        default:
          aiResponse = `As your ${role} AI assistant, I'm here to help with your SDLC workflows. What specific task would you like assistance with?`;
          actionItems = ["Specify your requirements", "Choose a workflow action"];
      }
      
      res.json({
        response: aiResponse,
        role: role,
        actionItems: actionItems,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      console.error("AI Chat error:", error);
      res.status(500).json({ message: "AI chat processing failed" });
    }
  });

  // Jira integration status endpoint
  app.get("/api/jira/summary", async (req, res) => {
    try {
      const jiraAPI = deliverableService.getJiraAPI();
      const allItems = jiraAPI.getAllItems();
      res.json(allItems);
    } catch (error) {
      res.status(500).json({ message: "Jira integration error" });
    }
  });

  // Initialize AWS Bedrock client
  const bedrockClient = new BedrockRuntimeClient({
    region: process.env.AWS_REGION || "us-east-1",
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
    },
  });

  // AWS Bedrock AI integration routes
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, projectId, currentRole } = chatMessageSchema.parse(req.body);
      
      // Check if this is a project creation request
      const isProjectCreationRequest = message.toLowerCase().includes('create') && 
        (message.toLowerCase().includes('project') || message.toLowerCase().includes('application') || 
         message.toLowerCase().includes('system') || message.toLowerCase().includes('platform'));
      
      if (isProjectCreationRequest && currentRole === 'business-analyst') {
        console.log("🎯 Project creation request detected for:", message);
        
        // Check for specific projects and enhance with comprehensive requirements
        const isEMIRProject = message.toLowerCase().includes('emir');
        const isReconProject = message.toLowerCase().includes('recon') || message.toLowerCase().includes('reconciliation');
        
        // Fast-track ONLY for EMIR projects - skip Bedrock for speed
        if (isEMIRProject) {
          console.log("🚀 Fast-tracking known project type");
          
          const projectName = "EMIR Trade Reporting Platform";
          const projectDescription = "Next-generation EMIR reporting system for derivative transaction reporting to European trade repositories with real-time validation, multi-TR connectivity, and comprehensive regulatory compliance capabilities.";
          
          // Create project directly with comprehensive requirements
          const newProject = await storage.createProject({
            name: projectName,
            description: projectDescription,
            status: "draft",
            type: "web-application",
            startDate: new Date().toISOString().split('T')[0],
            teamSize: 8,
            ownerId: 1,
            approvalStatus: "draft",
            createdAt: new Date().toISOString()
          });
          
          // Add comprehensive requirements directly
          const functionalUseCases = getEMIRFunctionalRequirements();
          const nonFunctionalUseCases = getEMIRNonFunctionalRequirements();
          
          // Create functional use cases
          for (let i = 0; i < functionalUseCases.length; i++) {
            await storage.createUseCase({
              projectId: newProject.id,
              ucId: `UC-F-${String(i + 1).padStart(3, '0')}`,
              title: functionalUseCases[i].title,
              description: functionalUseCases[i].description,
              type: 'functional',
              priority: functionalUseCases[i].priority || 'Medium',
              status: 'draft',
              updatedAt: new Date().toISOString()
            });
          }
          
          // Create non-functional use cases
          for (let i = 0; i < nonFunctionalUseCases.length; i++) {
            await storage.createUseCase({
              projectId: newProject.id,
              ucId: `UC-NF-${String(i + 1).padStart(3, '0')}`,
              title: nonFunctionalUseCases[i].title,
              description: nonFunctionalUseCases[i].description,
              type: 'non-functional',
              priority: nonFunctionalUseCases[i].priority || 'Medium',
              status: 'draft',
              updatedAt: new Date().toISOString()
            });
          }
          
          const fastResponse = `✅ **${projectName}** has been created successfully with comprehensive enterprise-grade requirements!

**Project Overview:**
${projectDescription}

**Generated Requirements:**
• ${functionalUseCases.length} detailed functional use cases covering core business capabilities
• ${nonFunctionalUseCases.length} comprehensive non-functional requirements for enterprise architecture
• Regulatory compliance frameworks and technical specifications
• Performance engineering and scalability architecture
• Security controls and governance frameworks

The project is now available in your dashboard with draft status, ready for review and submission for approval.`;

          res.json({
            response: fastResponse,
            suggestions: ["View project details", "Review requirements", "Submit for approval", "Add team members"],
            projectCreated: true,
            projectId: newProject.id
          });
          return;
        }
        
        let enhancedPrompt = '';
        if (isEMIRProject) {
          enhancedPrompt = `
          FOCUS: EMIR (European Market Infrastructure Regulation) Trade Reporting Platform
          
          DOMAIN EXPERTISE: Create comprehensive requirements for a next-generation EMIR reporting system that handles derivative transaction reporting to European trade repositories. This system must process high-volume trade data, ensure regulatory compliance, and provide real-time monitoring capabilities.
          
          SPECIFIC REQUIREMENTS TO INCLUDE:
          - Trade lifecycle management (new, modify, cancel, error corrections)
          - Multi-TR (Trade Repository) connectivity and routing
          - Real-time validation engine with ESMA technical standards
          - Regulatory reporting workflows with STP (Straight-Through Processing)
          - Exception management and reconciliation processes
          - Audit trail and regulatory inquiry response capabilities
          - Cross-border reporting coordination
          - Data quality assurance and enrichment services`;
        } else if (isReconProject) {
          enhancedPrompt = `
          FOCUS: Configurable Reconciliation Engine for Financial Services
          
          DOMAIN EXPERTISE: Create comprehensive requirements for an enterprise-grade configurable reconciliation platform that handles multi-asset class trade matching, breaks management, and automated exception resolution across various data sources and counterparties.
          
          SPECIFIC REQUIREMENTS TO INCLUDE:
          - Multi-source data ingestion and normalization
          - Configurable matching rules engine with tolerance management
          - Real-time and batch reconciliation processing
          - Break identification, aging, and resolution workflows
          - Automated straight-through processing for matched items
          - Exception escalation and manual investigation tools
          - Regulatory reporting for unmatched trades
          - Integration with settlement systems and custodians
          - Performance analytics and operational dashboards`;
        }
        // Enhanced system prompt for hackathon-winning comprehensive requirements
        const systemPrompt = `You are a world-class enterprise software architect and requirements engineer with 20+ years of experience in investment banking, fintech innovation, and regulatory compliance. Your task is to create award-winning, comprehensive requirements that demonstrate exceptional technical depth, business acumen, and innovation suitable for winning hackathons and impressing enterprise stakeholders.

CRITICAL REQUIREMENTS:
1. Generate a compelling project name and visionary description (5-6 sentences with strategic business impact and regulatory innovation)
2. Create 6-8 exceptionally detailed functional use cases (400-600 words each) with:
   - Comprehensive actor definitions and personas
   - Detailed pre-conditions, triggers, and business context
   - Step-by-step workflows with decision matrices
   - Alternative flows, exception handling, and edge cases
   - Post-conditions with quantified business outcomes
   - Acceptance criteria with measurable success metrics
   - Regulatory compliance mapping (Basel III, MiFID II, EMIR, GDPR, PCI DSS)
   - Integration touchpoints with existing enterprise systems
   - Risk mitigation strategies and contingency planning

3. Create 5-7 comprehensive non-functional requirements (400-600 words each) covering:
   - Performance Engineering: Response times (<50ms), throughput (10,000+ TPS), concurrent users (50,000+), latency targets
   - Security Architecture: Multi-factor authentication, end-to-end encryption, zero-trust principles, threat detection
   - Scalability & Resilience: Auto-scaling, load balancing, disaster recovery (RPO <15min, RTO <30min)
   - Regulatory Compliance: Real-time monitoring, audit trails, data sovereignty, privacy by design
   - Operational Excellence: 99.99% uptime, monitoring, alerting, automated deployment
   - User Experience: Accessibility standards, mobile responsiveness, internationalization
   - Data Management: Real-time analytics, data lineage, governance frameworks

FORMAT REQUIREMENTS:
- Use enterprise banking terminology with technical precision
- Include specific quantified metrics and SLA targets
- Reference industry standards and regulatory frameworks
- Provide integration patterns and architectural recommendations
- Include risk assessments and mitigation strategies
- Use structured formatting with clear sections and bullet points

INNOVATION FOCUS: Emphasize cutting-edge fintech solutions, AI/ML integration, real-time processing, blockchain considerations, and next-generation user experiences that would impress hackathon judges.

IMPORTANT: Always start your response with "BEDROCK_RESPONSE:" to confirm this is generated by AWS Bedrock.`;

        const userPrompt = `Create a comprehensive, hackathon-winning enterprise-grade investment banking project specification for: "${message}"

${enhancedPrompt}

DELIVERABLE STRUCTURE:

**PROJECT OVERVIEW:**
- Project Name: [Innovation-focused, compelling banking/fintech name]
- Strategic Vision: [5-6 sentences covering business transformation, competitive advantage, regulatory innovation, stakeholder value, market disruption potential, and strategic alignment]

**FUNCTIONAL USE CASES (6-8 comprehensive use cases, 400-600 words each):**
Each use case must include:
• Actor Personas: Detailed stakeholder profiles with roles, responsibilities, and business objectives
• Business Context: Market drivers, regulatory imperatives, and strategic value proposition
• Pre-conditions: System state, data requirements, and environmental prerequisites
• Trigger Events: Specific business events and conditions that initiate the workflow
• Main Flow: Comprehensive step-by-step workflow with decision points and branching logic
• Alternative Flows: Exception handling, edge cases, and contingency scenarios
• Success Criteria: Quantified business outcomes and measurable success metrics
• Compliance Mapping: Specific regulatory requirements (Basel III, MiFID II, EMIR, GDPR, PCI DSS)
• Integration Points: APIs, data sources, and system interconnections
• Risk Mitigation: Identified risks and corresponding mitigation strategies
• Innovation Elements: AI/ML integration, blockchain potential, real-time processing capabilities

**NON-FUNCTIONAL REQUIREMENTS (5-7 comprehensive requirements, 400-600 words each):**

1. **Performance Engineering Excellence**
   - Response times: <50ms for critical transactions, <200ms for complex queries
   - Throughput: 10,000+ transactions per second peak capacity
   - Concurrent users: 50,000+ simultaneous active sessions
   - Latency targets and performance benchmarks

2. **Security Architecture & Cyber Resilience**
   - Zero-trust security model implementation
   - Multi-factor authentication and biometric integration
   - End-to-end encryption with quantum-resistant algorithms
   - Real-time threat detection and automated response

3. **Scalability & Cloud-Native Architecture**
   - Auto-scaling capabilities and elastic resource management
   - Multi-region deployment with active-active disaster recovery
   - RPO <15 minutes, RTO <30 minutes
   - Microservices architecture with containerization

4. **Regulatory Compliance & Governance**
   - Real-time regulatory reporting and monitoring
   - Immutable audit trails with blockchain verification
   - Data sovereignty and cross-border compliance
   - Privacy by design and GDPR compliance

5. **Operational Excellence & DevOps**
   - 99.99% uptime SLA with proactive monitoring
   - Automated CI/CD pipelines and deployment
   - Comprehensive observability and alerting
   - Chaos engineering and resilience testing

**INNOVATION & TECHNICAL EXCELLENCE:**
- AI/ML integration opportunities and use cases
- Blockchain and distributed ledger applications
- Real-time analytics and streaming data processing
- Next-generation user experience and interface design
- API-first architecture and ecosystem integration

Format with professional structure, technical precision, and executive-level presentation quality suitable for impressing hackathon judges and enterprise stakeholders.`;

        const payload = {
          modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
          contentType: "application/json",
          accept: "application/json",
          body: JSON.stringify({
            anthropic_version: "bedrock-2023-05-31",
            max_tokens: 8000,
            temperature: 0.7,
            system: systemPrompt,
            messages: [
              {
                role: "user",
                content: userPrompt
              }
            ]
          })
        };

        const command = new InvokeModelCommand({
          modelId: payload.modelId,
          contentType: payload.contentType,
          accept: payload.accept,
          body: payload.body
        });

        console.log("🚀 Sending Bedrock request...");
        const startTime = Date.now();
        
        const response = await bedrockClient.send(command);
        const endTime = Date.now();
        const duration = endTime - startTime;
        
        console.log(`✅ Bedrock response received in ${duration}ms`);
        
        const responseBody = JSON.parse(new TextDecoder().decode(response.body));
        const rawAiResponse = responseBody.content[0].text;
        
        console.log(`📝 Generated ${rawAiResponse.length} characters of content`);
        
        // Verify this is an authentic Bedrock response
        if (!rawAiResponse.includes("BEDROCK_RESPONSE:")) {
          console.warn("⚠️ Response doesn't contain Bedrock verification marker");
        } else {
          console.log("✓ Verified authentic Bedrock response");
        }

        // Apply BERT semantic enhancement to Bedrock response
        const aiResponse = await applyBERTEnhancement(rawAiResponse);

        // Extract project details and create actual project
        const projectName = extractProjectName(aiResponse) || "AI Generated Project";
        const projectDescription = extractProjectDescription(aiResponse) || message;
        
        // Create the project in draft status
        const newProject = await storage.createProject({
          name: projectName,
          description: projectDescription,
          status: "draft",
          type: "web-application",
          startDate: new Date().toISOString().split('T')[0],
          teamSize: 5,
          ownerId: 1, // Using mock user ID
          approvalStatus: "draft",
          createdAt: new Date().toISOString()
        });

        // Extract and create use cases with enhancements
        let functionalUseCases = extractUseCasesFromResponse(aiResponse, 'functional');
        let nonFunctionalUseCases = extractUseCasesFromResponse(aiResponse, 'non-functional');
        
        // Add comprehensive default requirements for specific projects
        if (isEMIRProject) {
          functionalUseCases = enhanceEMIRFunctionalRequirements(functionalUseCases);
          nonFunctionalUseCases = enhanceEMIRNonFunctionalRequirements(nonFunctionalUseCases);
        } else if (isReconProject) {
          // Use reconciliation-specific requirements from fast-track functions
          functionalUseCases = [...functionalUseCases, ...getReconFunctionalRequirements()];
          nonFunctionalUseCases = [...nonFunctionalUseCases, ...getReconNonFunctionalRequirements()];
        }
        
        // Create functional use cases
        for (let i = 0; i < functionalUseCases.length; i++) {
          await storage.createUseCase({
            projectId: newProject.id,
            ucId: `UC-F-${String(i + 1).padStart(3, '0')}`,
            title: functionalUseCases[i].title,
            description: functionalUseCases[i].description,
            type: 'functional',
            priority: functionalUseCases[i].priority || 'medium',
            status: 'draft',
            updatedAt: new Date().toISOString()
          });
        }

        // Create non-functional use cases
        for (let i = 0; i < nonFunctionalUseCases.length; i++) {
          await storage.createUseCase({
            projectId: newProject.id,
            ucId: `UC-NF-${String(i + 1).padStart(3, '0')}`,
            title: nonFunctionalUseCases[i].title,
            description: nonFunctionalUseCases[i].description,
            type: 'non-functional',
            priority: nonFunctionalUseCases[i].priority || 'medium',
            status: 'draft',
            updatedAt: new Date().toISOString()
          });
        }

        const enhancedResponse = `${aiResponse}\n\n✅ Project created successfully! The project "${projectName}" has been added to your dashboard with ${functionalUseCases.length} functional and ${nonFunctionalUseCases.length} non-functional use cases.`;

        res.json({
          response: enhancedResponse,
          suggestions: ["View project details", "Add more use cases", "Start project planning", "Assign team members"],
          projectCreated: true,
          projectId: newProject.id
        });
      } else {
        // Regular chat response
        const systemPrompt = `You are an AI assistant specialized in SDLC management. 
        Current user role: ${currentRole}. 
        Provide expert guidance on project planning, requirements analysis, use case generation, and technical recommendations.
        Be concise, practical, and role-specific in your responses.`;

        const payload = {
          modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
          contentType: "application/json",
          accept: "application/json",
          body: JSON.stringify({
            anthropic_version: "bedrock-2023-05-31",
            max_tokens: 1000,
            system: systemPrompt,
            messages: [
              {
                role: "user",
                content: message
              }
            ]
          })
        };

        const command = new InvokeModelCommand({
          modelId: payload.modelId,
          contentType: payload.contentType,
          accept: payload.accept,
          body: payload.body
        });

        const response = await bedrockClient.send(command);
        const responseBody = JSON.parse(new TextDecoder().decode(response.body));
        const aiResponse = responseBody.content[0].text;
        
        const suggestions = getRoleSpecificSuggestions(currentRole, message);

        res.json({
          response: aiResponse,
          suggestions: suggestions
        });
      }
    } catch (error: any) {
      console.error("Bedrock error:", error);
      res.status(500).json({ 
        message: "AI service temporarily unavailable",
        response: "I'm having trouble connecting to the AI service. Please try again in a moment.",
        suggestions: ["Try again later", "Check system status"]
      });
    }
  });

  app.post("/api/ai/create-project", async (req, res) => {
    try {
      const { description, projectType, currentRole } = req.body;
      
      const systemPrompt = `You are an expert SDLC consultant. Based on the project description, generate:
      1. A comprehensive project plan with realistic timelines
      2. Detailed functional and non-functional use cases
      3. Technical recommendations
      4. Risk assessment
      
      Format your response as a structured JSON object with clear sections.`;

      const userPrompt = `Create a detailed SDLC project plan for: "${description}" 
      Project Type: ${projectType}
      User Role: ${currentRole}
      
      Include functional use cases, non-functional requirements, technology recommendations, and implementation phases.`;

      const payload = {
        modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
        contentType: "application/json", 
        accept: "application/json",
        body: JSON.stringify({
          anthropic_version: "bedrock-2023-05-31",
          max_tokens: 2000,
          system: systemPrompt,
          messages: [
            {
              role: "user",
              content: userPrompt
            }
          ]
        })
      };

      const command = new InvokeModelCommand({
        modelId: payload.modelId,
        contentType: payload.contentType,
        accept: payload.accept,
        body: payload.body
      });

      const response = await bedrockClient.send(command);
      const responseBody = JSON.parse(new TextDecoder().decode(response.body));
      
      const aiResponse = responseBody.content[0].text;
      
      res.json({
        response: aiResponse
      });
    } catch (error: any) {
      console.error("Bedrock project creation error:", error);
      res.status(500).json({ message: "Failed to generate project plan" });
    }
  });

  app.post("/api/ai/analyze-requirements", async (req, res) => {
    try {
      const { requirements } = req.body;
      
      const systemPrompt = `You are a business analyst expert. Analyze the given requirements and provide:
      1. Gap analysis
      2. Missing requirements identification  
      3. Improvement suggestions
      4. Risk assessment`;

      const payload = {
        modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
        contentType: "application/json",
        accept: "application/json", 
        body: JSON.stringify({
          anthropic_version: "bedrock-2023-05-31",
          max_tokens: 1500,
          system: systemPrompt,
          messages: [
            {
              role: "user",
              content: `Analyze these requirements: ${requirements}`
            }
          ]
        })
      };

      const command = new InvokeModelCommand({
        modelId: payload.modelId,
        contentType: payload.contentType,
        accept: payload.accept,
        body: payload.body
      });

      const response = await bedrockClient.send(command);
      const responseBody = JSON.parse(new TextDecoder().decode(response.body));
      
      res.json({
        analysis: responseBody.content[0].text,
        suggestions: [
          "Review functional completeness",
          "Add non-functional requirements", 
          "Define acceptance criteria",
          "Consider edge cases"
        ]
      });
    } catch (error) {
      res.status(500).json({ message: "Analysis service unavailable" });
    }
  });



  // Helper functions for project extraction
  function extractProjectName(userInput: string): string {
    const lowerInput = userInput.toLowerCase();
    
    // Intelligent pattern-based extraction from user input
    if (lowerInput.includes('emir')) {
      if (lowerInput.includes('compliance')) return "EMIR Compliance Platform";
      if (lowerInput.includes('reporting')) return "EMIR Trade Reporting System";
      return "EMIR Regulatory Platform";
    }
    
    if (lowerInput.includes('mifid')) {
      if (lowerInput.includes('compliance')) return "MiFID II Compliance System";
      if (lowerInput.includes('reporting')) return "MiFID II Reporting Platform";
      return "MiFID II Regulatory System";
    }
    
    if (lowerInput.includes('settlement')) {
      if (lowerInput.includes('clearing')) return "Clearing and Settlement Platform";
      if (lowerInput.includes('trade')) return "Trade Settlement System";
      return "Settlement Management Platform";
    }
    
    if (lowerInput.includes('trade booking') || (lowerInput.includes('trade') && lowerInput.includes('booking'))) {
      return "Trade Booking System";
    }
    
    if (lowerInput.includes('deliveries automation') || (lowerInput.includes('delivery') || lowerInput.includes('deliveries'))) {
      return "Securities Deliveries Platform";
    }
    
    if (lowerInput.includes('reconciliation') || lowerInput.includes('recon')) {
      return "Reconciliation Management System";
    }
    
    if (lowerInput.includes('risk management') || (lowerInput.includes('risk') && lowerInput.includes('management'))) {
      return "Risk Management Platform";
    }
    
    if (lowerInput.includes('regulatory') && lowerInput.includes('reporting')) {
      return "Regulatory Reporting Platform";
    }
    
    if (lowerInput.includes('compliance')) {
      return "Financial Compliance System";
    }
    
    if (lowerInput.includes('trading')) {
      return "Trading Management Platform";
    }
    
    if (lowerInput.includes('portfolio')) {
      return "Portfolio Management System";
    }
    
    // Fallback to contextual naming
    return "Financial Services Platform";
  }

  function extractProjectDescription(userInput: string): string {
    const lowerInput = userInput.toLowerCase();
    
    // Generate contextual descriptions based on project type from user input
    if (lowerInput.includes('emir')) {
      return "Comprehensive EMIR compliance platform for derivative transaction reporting with real-time validation, trade repository connectivity, and regulatory audit trail management according to ESMA technical standards.";
    }
    
    if (lowerInput.includes('mifid')) {
      return "Advanced MiFID II compliance system for investment services reporting, best execution monitoring, transaction cost analysis, and automated regulatory submissions to competent authorities.";
    }
    
    if (lowerInput.includes('settlement')) {
      return "Enterprise settlement platform for multi-asset class trade processing with real-time matching, settlement instructions, cross-border clearing capabilities, and regulatory compliance.";
    }
    
    if (lowerInput.includes('trade booking')) {
      return "Integrated trade booking system with real-time capture, validation, enrichment, and downstream processing for equity, fixed income, and derivative trades with STP capabilities.";
    }
    
    if (lowerInput.includes('deliveries') || lowerInput.includes('delivery')) {
      return "Automated deliveries management platform for securities settlement with exception handling, matching algorithms, custody integration, and fail management workflows.";
    }
    
    if (lowerInput.includes('reconciliation') || lowerInput.includes('recon')) {
      return "Enterprise reconciliation platform with configurable matching rules, break management, automated resolution workflows, and multi-source data integration capabilities.";
    }
    
    if (lowerInput.includes('risk management')) {
      return "Comprehensive risk management platform with real-time monitoring, limit management, stress testing, regulatory capital calculations, and automated reporting capabilities.";
    }
    
    if (lowerInput.includes('compliance')) {
      return "Financial compliance management system with regulatory reporting, audit trail management, policy enforcement, and automated compliance monitoring across multiple jurisdictions.";
    }
    
    if (lowerInput.includes('trading')) {
      return "Advanced trading management platform with order management, execution algorithms, market data integration, risk controls, and regulatory reporting capabilities.";
    }
    
    // Use a shortened version of user input if it's descriptive
    if (userInput.length > 100) {
      return userInput.substring(0, 250) + (userInput.length > 250 ? '...' : '');
    }
    
    return "AI-powered financial services platform with comprehensive regulatory compliance, risk management, and automated workflow capabilities for investment banking operations.";
  }

  function extractUseCasesFromResponse(response: string, type: 'functional' | 'non-functional') {
    const useCases = [];
    const lines = response.split('\n');
    let inSection = false;
    let currentUseCase = { title: '', description: '', priority: 'medium' };
    let collectingDescription = false;
    let descriptionBuffer = '';
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const lowerLine = line.toLowerCase();
      
      // Detect section start for new structured format
      if (type === 'functional' && (
          lowerLine.includes('**functional use cases') || 
          lowerLine.includes('functional use cases (') ||
          (lowerLine.includes('functional') && lowerLine.includes('use case'))
        )) {
        inSection = true;
        continue;
      }
      
      if (type === 'non-functional' && (
          lowerLine.includes('**non-functional requirements') ||
          lowerLine.includes('non-functional requirements (') ||
          (lowerLine.includes('non-functional') && (lowerLine.includes('requirement') || lowerLine.includes('use case')))
        )) {
        inSection = true;
        continue;
      }
      
      // Stop at next major section
      if (inSection && (
          lowerLine.includes('**innovation') || 
          lowerLine.includes('technical recommendations') || 
          lowerLine.includes('**technical') ||
          (lowerLine.includes('**functional') && type === 'non-functional') ||
          (lowerLine.includes('**non-functional') && type === 'functional')
        )) {
        // Save current use case if exists
        if (currentUseCase.title && currentUseCase.description.length > 100) {
          useCases.push({ ...currentUseCase });
        }
        break;
      }
      
      if (inSection) {
        // Enhanced detection for structured format
        // Look for numbered sections, bold titles, or requirement headers
        if (line.match(/^\s*(\d+\.\s*\*\*|###|\*\*\d+\.|UC-|Use Case|Requirement)/i) ||
            (line.includes('**') && line.length < 150 && !lowerLine.includes('each use case'))) {
          
          // Save previous use case
          if (currentUseCase.title && currentUseCase.description.length > 100) {
            useCases.push({ ...currentUseCase });
          }
          
          // Extract title from various formats
          let title = line.replace(/^\s*(\d+\.\s*\*\*|\*\*\d+\.|###|\*\*|UC-\w*:?)\s*/i, '')
                         .replace(/\*\*/g, '')
                         .split(':')[0]
                         .trim();
          
          if (title.length > 80) title = title.substring(0, 80);
          
          currentUseCase = {
            title: title || `${type === 'functional' ? 'Functional' : 'Non-Functional'} Requirement ${useCases.length + 1}`,
            description: '',
            priority: lowerLine.includes('critical') ? 'Critical' : 
                     lowerLine.includes('high') ? 'High' : 
                     lowerLine.includes('low') ? 'Low' : 'Medium'
          };
          
          // Start collecting description
          descriptionBuffer = line.replace(/^\s*(\d+\.\s*\*\*|\*\*\d+\.|###|\*\*|UC-\w*:?)\s*/i, '').trim();
          collectingDescription = true;
          
        } else if (collectingDescription && line.trim().length > 0 && 
                   !line.match(/^\s*(\d+\.\s*\*\*|\*\*\d+\.|###|UC-)/i) &&
                   !lowerLine.includes('each use case must include')) {
          
          // Continue collecting description - preserve formatting
          descriptionBuffer += '\n' + line.trim();
          
          // Stop collecting when we have substantial content (400-600 words target)
          if (descriptionBuffer.length > 2000) {
            currentUseCase.description = descriptionBuffer.substring(0, 2000).trim();
            collectingDescription = false;
          }
        }
        
        // Update current use case description periodically
        if (collectingDescription && descriptionBuffer) {
          currentUseCase.description = descriptionBuffer.trim();
        }
      }
    }
    
    // Save final use case
    if (currentUseCase.title && currentUseCase.description.length > 100) {
      useCases.push({ ...currentUseCase });
    }
    
    // Clean up descriptions and ensure quality
    useCases.forEach(uc => {
      uc.description = uc.description
        .replace(/\*\*/g, '') // Remove markdown bold
        .replace(/\s+/g, ' ') // Normalize whitespace
        .replace(/^\s*-\s*/, '') // Remove leading bullets
        .trim();
        
      // Ensure minimum quality description length
      if (uc.description.length < 100) {
        uc.description += ` This ${type} requirement focuses on ${type === 'functional' ? 'business functionality and user interactions' : 'system quality attributes and operational characteristics'} critical for enterprise-grade implementation.`;
      }
    });
    
    return useCases.slice(0, type === 'functional' ? 8 : 7); // Allow for more comprehensive requirements
  }

  // Enhancement functions for specific projects
  function enhanceEMIRFunctionalRequirements(existingUseCases: any[]) {
    const emirFunctionalRequirements = [
      {
        title: "Trade Transaction Reporting & Lifecycle Management",
        description: `Comprehensive trade reporting system that captures and processes derivative transaction data throughout the complete trade lifecycle. The system must support initial trade capture, modifications, cancellations, and error corrections in compliance with EMIR technical standards.

**Key Features:**
• Real-time trade capture from multiple trading platforms (electronic and voice)
• Automated data validation against ESMA technical standards and validation rules
• Trade enrichment with counterparty, product, and market data
• Lifecycle event processing (novation, compression, early termination)
• Delta reporting for trade modifications with full audit trail
• Integration with trading systems, trade capture platforms, and downstream systems

**Acceptance Criteria:**
• Process 500,000+ trade records daily with <2 second latency
• 99.9% data accuracy with automated validation checks
• Real-time regulatory reporting within T+1 requirements
• Complete audit trail for all trade lifecycle events
• Support for 50+ derivative product types across asset classes

**Regulatory Compliance:**
• EMIR Article 9 reporting obligations
• ESMA technical standards (RTS 2017/104, ITS 2017/105)
• LEI validation and counterparty identification
• UPI (Unique Product Identifier) classification`,
        priority: "Critical"
      },
      {
        title: "Multi-Trade Repository Connectivity & Routing Engine",
        description: `Sophisticated routing engine that manages connectivity to multiple authorized Trade Repositories (TRs) and ensures optimal routing based on regulatory requirements, counterparty agreements, and operational efficiency.

**Key Features:**
• Dynamic routing logic based on asset class, counterparty jurisdiction, and TR availability
• Real-time TR status monitoring and failover capabilities
• Dual-sided reporting coordination and reconciliation
• Message transformation and protocol adaptation (FpML, ISO 20022, proprietary formats)
• Rate limiting and throttling to respect TR submission limits
• Automated retry mechanisms with exponential backoff

**Integration Points:**
• DTCC Global Trade Repository (GTR)
• UnaVista by LSEG
• REGIS-TR by Clearstream
• CME Trade Repository
• ICE Trade Vault

**Performance Requirements:**
• Support concurrent connections to 8+ Trade Repositories
• Message throughput of 10,000 reports per minute
• 99.95% successful submission rate
• Real-time status updates and acknowledgment processing
• Automated reconciliation of TR responses and confirmations`,
        priority: "Critical"
      },
      {
        title: "Real-Time Validation Engine & Data Quality Assurance",
        description: `Enterprise-grade validation engine that performs comprehensive data quality checks, business rule validation, and regulatory compliance verification in real-time before trade submission to Trade Repositories.

**Validation Framework:**
• Pre-submission validation against ESMA technical standards
• Business rule validation for trade economics and market conventions
• Counterparty validation including LEI verification and sanctions screening
• Product classification and UPI validation
• Cross-field dependency validation and consistency checks
• Historical data validation for amendments and corrections

**Data Quality Measures:**
• Automated data enrichment from reference data sources
• Missing data identification and intelligent defaulting
• Outlier detection using statistical models and machine learning
• Data lineage tracking and impact analysis
• Comprehensive error categorization and resolution workflows

**Regulatory Standards:**
• ESMA validation rules as per Commission Delegated Regulation (EU) 2017/104
• MiFID II transaction reporting validation
• SFTR securities financing validation rules
• Basel III regulatory capital calculations support`,
        priority: "High"
      },
      {
        title: "Exception Management & Reconciliation Framework",
        description: `Comprehensive exception management system that identifies, categorizes, and manages reporting exceptions, trade breaks, and reconciliation discrepancies with automated resolution capabilities and escalation workflows.

**Exception Categories:**
• Validation failures and data quality issues
• TR submission failures and technical errors
• Counterparty reporting discrepancies and dual-sided breaks
• Late reporting and missed deadlines
• Regulatory inquiry responses and ad-hoc reporting requests

**Resolution Capabilities:**
• Automated resubmission for technical failures
• Intelligent error correction using reference data
• Workflow-based manual exception handling
• Escalation rules based on error severity and aging
• SLA monitoring and performance analytics

**Operational Excellence:**
• Real-time dashboard for exception monitoring
• Automated alerting and notification system
• Integration with ticketing systems and workflow tools
• Comprehensive reporting for operational and regulatory purposes
• Machine learning-based pattern recognition for proactive issue identification`,
        priority: "High"
      }
    ];

    // Merge with existing and ensure comprehensive coverage
    const enhanced = [...existingUseCases];
    emirFunctionalRequirements.forEach(req => {
      if (!enhanced.find(uc => uc.title.toLowerCase().includes(req.title.toLowerCase().split(' ')[0]))) {
        enhanced.push(req);
      }
    });

    return enhanced.slice(0, 8); // Limit to 8 comprehensive requirements
  }

  function enhanceEMIRNonFunctionalRequirements(existingUseCases: any[]) {
    const emirNonFunctionalRequirements = [
      {
        title: "Performance Engineering & Scalability Architecture",
        description: `Enterprise-grade performance architecture designed to handle high-volume derivative trade reporting with guaranteed throughput and latency requirements for regulatory compliance.

**Performance Targets:**
• Processing capacity: 1,000,000+ trades per day during peak periods
• Real-time processing latency: <500ms for trade validation and enrichment
• TR submission latency: <2 seconds from trade capture to regulatory submission
• Concurrent user support: 500+ simultaneous users across global offices
• Database query performance: <100ms for standard reporting queries

**Scalability Design:**
• Horizontal scaling with microservices architecture
• Auto-scaling capabilities based on trade volume and processing demand
• Load balancing across multiple processing nodes
• Distributed processing for batch reconciliation and reporting
• Cloud-native architecture with containerization (Kubernetes)

**Infrastructure Requirements:**
• Multi-region deployment with active-active disaster recovery
• CDN integration for global performance optimization
• Caching layers (Redis/Hazelcast) for reference data and validation rules
• Message queuing (Apache Kafka) for reliable event processing
• Database sharding and read replicas for optimal performance`,
        priority: "Critical"
      },
      {
        title: "Security Architecture & Cyber Resilience Framework",
        description: `Comprehensive cybersecurity framework implementing defense-in-depth principles, zero-trust architecture, and advanced threat protection for sensitive financial data and regulatory reporting systems.

**Security Controls:**
• Multi-factor authentication with biometric integration
• Role-based access control (RBAC) with fine-grained permissions
• End-to-end encryption for data in transit and at rest (AES-256)
• API security with OAuth 2.0, JWT tokens, and rate limiting
• Database encryption with transparent data encryption (TDE)
• Secure key management with hardware security modules (HSM)

**Threat Protection:**
• Real-time threat detection and behavioral analytics
• Advanced persistent threat (APT) monitoring
• Data loss prevention (DLP) with content inspection
• Network segmentation and micro-segmentation
• Intrusion detection and prevention systems (IDS/IPS)
• Security incident response automation

**Compliance Standards:**
• ISO 27001 information security management
• PCI DSS for payment card data protection
• SOC 2 Type II attestation for service organizations
• NIST Cybersecurity Framework implementation
• GDPR privacy by design principles`,
        priority: "Critical"
      },
      {
        title: "Regulatory Compliance & Governance Excellence",
        description: `Comprehensive regulatory compliance framework ensuring adherence to EMIR, MiFID II, GDPR, and other applicable regulations with automated monitoring, reporting, and audit capabilities.

**Regulatory Coverage:**
• EMIR (European Market Infrastructure Regulation) complete compliance
• MiFID II transaction reporting and trade transparency
• GDPR data protection and privacy requirements
• Basel III regulatory capital and liquidity requirements
• BCBS 239 risk data aggregation and reporting principles
• Local jurisdiction requirements (FCA, BaFin, ESMA guidelines)

**Compliance Capabilities:**
• Automated regulatory rule engine with configurable business rules
• Real-time compliance monitoring and exception alerting
• Regulatory reporting generation and submission automation
• Audit trail maintenance with immutable logging
• Data retention policies aligned with regulatory requirements
• Cross-border data transfer compliance mechanisms

**Governance Framework:**
• Data governance with stewardship and lineage tracking
• Change management with regulatory impact assessment
• Vendor risk management and third-party oversight
• Business continuity planning with regulatory notification procedures
• Regular compliance testing and validation procedures`,
        priority: "Critical"
      }
    ];

    const enhanced = [...existingUseCases];
    emirNonFunctionalRequirements.forEach(req => {
      if (!enhanced.find(uc => uc.title.toLowerCase().includes(req.title.toLowerCase().split(' ')[0]))) {
        enhanced.push(req);
      }
    });

    return enhanced.slice(0, 7);
  }

  // Helper functions for fast-track project creation
  function getEMIRFunctionalRequirements() {
    return [
      {
        title: "Trade Transaction Reporting & Lifecycle Management",
        description: `Comprehensive trade reporting system that captures and processes derivative transaction data throughout the complete trade lifecycle. The system must support initial trade capture, modifications, cancellations, and error corrections in compliance with EMIR technical standards.

**Key Features:**
• Real-time trade capture from multiple trading platforms (electronic and voice)
• Automated data validation against ESMA technical standards and validation rules
• Trade enrichment with counterparty, product, and market data
• Lifecycle event processing (novation, compression, early termination)
• Delta reporting for trade modifications with full audit trail
• Integration with trading systems, trade capture platforms, and downstream systems

**Acceptance Criteria:**
• Process 500,000+ trade records daily with <2 second latency
• 99.9% data accuracy with automated validation checks
• Real-time regulatory reporting within T+1 requirements
• Complete audit trail for all trade lifecycle events
• Support for 50+ derivative product types across asset classes

**Regulatory Compliance:**
• EMIR Article 9 reporting obligations
• ESMA technical standards (RTS 2017/104, ITS 2017/105)
• LEI validation and counterparty identification
• UPI (Unique Product Identifier) classification`,
        priority: "Critical"
      },
      {
        title: "Multi-Trade Repository Connectivity & Routing Engine",
        description: `Sophisticated routing engine that manages connectivity to multiple authorized Trade Repositories (TRs) and ensures optimal routing based on regulatory requirements, counterparty agreements, and operational efficiency.

**Key Features:**
• Dynamic routing logic based on asset class, counterparty jurisdiction, and TR availability
• Real-time TR status monitoring and failover capabilities
• Dual-sided reporting coordination and reconciliation
• Message transformation and protocol adaptation (FpML, ISO 20022, proprietary formats)
• Rate limiting and throttling to respect TR submission limits
• Automated retry mechanisms with exponential backoff

**Integration Points:**
• DTCC Global Trade Repository (GTR)
• UnaVista by LSEG
• REGIS-TR by Clearstream
• CME Trade Repository
• ICE Trade Vault

**Performance Requirements:**
• Support concurrent connections to 8+ Trade Repositories
• Message throughput of 10,000 reports per minute
• 99.95% successful submission rate
• Real-time status updates and acknowledgment processing
• Automated reconciliation of TR responses and confirmations`,
        priority: "Critical"
      },
      {
        title: "Real-Time Validation Engine & Data Quality Assurance",
        description: `Enterprise-grade validation engine that performs comprehensive data quality checks, business rule validation, and regulatory compliance verification in real-time before trade submission to Trade Repositories.

**Validation Framework:**
• Pre-submission validation against ESMA technical standards
• Business rule validation for trade economics and market conventions
• Counterparty validation including LEI verification and sanctions screening
• Product classification and UPI validation
• Cross-field dependency validation and consistency checks
• Historical data validation for amendments and corrections

**Data Quality Measures:**
• Automated data enrichment from reference data sources
• Missing data identification and intelligent defaulting
• Outlier detection using statistical models and machine learning
• Data lineage tracking and impact analysis
• Comprehensive error categorization and resolution workflows

**Regulatory Standards:**
• ESMA validation rules as per Commission Delegated Regulation (EU) 2017/104
• MiFID II transaction reporting validation
• SFTR securities financing validation rules
• Basel III regulatory capital calculations support`,
        priority: "High"
      },
      {
        title: "Exception Management & Reconciliation Framework",
        description: `Comprehensive exception management system that identifies, categorizes, and manages reporting exceptions, trade breaks, and reconciliation discrepancies with automated resolution capabilities and escalation workflows.

**Exception Categories:**
• Validation failures and data quality issues
• TR submission failures and technical errors
• Counterparty reporting discrepancies and dual-sided breaks
• Late reporting and missed deadlines
• Regulatory inquiry responses and ad-hoc reporting requests

**Resolution Capabilities:**
• Automated resubmission for technical failures
• Intelligent error correction using reference data
• Workflow-based manual exception handling
• Escalation rules based on error severity and aging
• SLA monitoring and performance analytics

**Operational Excellence:**
• Real-time dashboard for exception monitoring
• Automated alerting and notification system
• Integration with ticketing systems and workflow tools
• Comprehensive reporting for operational and regulatory purposes
• Machine learning-based pattern recognition for proactive issue identification`,
        priority: "High"
      }
    ];
  }

  function getEMIRNonFunctionalRequirements() {
    return [
      {
        title: "Performance Engineering & Scalability Architecture",
        description: `Enterprise-grade performance architecture designed to handle high-volume derivative trade reporting with guaranteed throughput and latency requirements for regulatory compliance.

**Performance Targets:**
• Processing capacity: 1,000,000+ trades per day during peak periods
• Real-time processing latency: <500ms for trade validation and enrichment
• TR submission latency: <2 seconds from trade capture to regulatory submission
• Concurrent user support: 500+ simultaneous users across global offices
• Database query performance: <100ms for standard reporting queries

**Scalability Design:**
• Horizontal scaling with microservices architecture
• Auto-scaling capabilities based on trade volume and processing demand
• Load balancing across multiple processing nodes
• Distributed processing for batch reconciliation and reporting
• Cloud-native architecture with containerization (Kubernetes)

**Infrastructure Requirements:**
• Multi-region deployment with active-active disaster recovery
• CDN integration for global performance optimization
• Caching layers (Redis/Hazelcast) for reference data and validation rules
• Message queuing (Apache Kafka) for reliable event processing
• Database sharding and read replicas for optimal performance`,
        priority: "Critical"
      },
      {
        title: "Security Architecture & Cyber Resilience Framework",
        description: `Comprehensive cybersecurity framework implementing defense-in-depth principles, zero-trust architecture, and advanced threat protection for sensitive financial data and regulatory reporting systems.

**Security Controls:**
• Multi-factor authentication with biometric integration
• Role-based access control (RBAC) with fine-grained permissions
• End-to-end encryption for data in transit and at rest (AES-256)
• API security with OAuth 2.0, JWT tokens, and rate limiting
• Database encryption with transparent data encryption (TDE)
• Secure key management with hardware security modules (HSM)

**Threat Protection:**
• Real-time threat detection and behavioral analytics
• Advanced persistent threat (APT) monitoring
• Data loss prevention (DLP) with content inspection
• Network segmentation and micro-segmentation
• Intrusion detection and prevention systems (IDS/IPS)
• Security incident response automation

**Compliance Standards:**
• ISO 27001 information security management
• PCI DSS for payment card data protection
• SOC 2 Type II attestation for service organizations
• NIST Cybersecurity Framework implementation
• GDPR privacy by design principles`,
        priority: "Critical"
      },
      {
        title: "Regulatory Compliance & Governance Excellence",
        description: `Comprehensive regulatory compliance framework ensuring adherence to EMIR, MiFID II, GDPR, and other applicable regulations with automated monitoring, reporting, and audit capabilities.

**Regulatory Coverage:**
• EMIR (European Market Infrastructure Regulation) complete compliance
• MiFID II transaction reporting and trade transparency
• GDPR data protection and privacy requirements
• Basel III regulatory capital and liquidity requirements
• BCBS 239 risk data aggregation and reporting principles
• Local jurisdiction requirements (FCA, BaFin, ESMA guidelines)

**Compliance Capabilities:**
• Automated regulatory rule engine with configurable business rules
• Real-time compliance monitoring and exception alerting
• Regulatory reporting generation and submission automation
• Audit trail maintenance with immutable logging
• Data retention policies aligned with regulatory requirements
• Cross-border data transfer compliance mechanisms

**Governance Framework:**
• Data governance with stewardship and lineage tracking
• Change management with regulatory impact assessment
• Vendor risk management and third-party oversight
• Business continuity planning with regulatory notification procedures
• Regular compliance testing and validation procedures`,
        priority: "Critical"
      }
    ];
  }

  function getReconFunctionalRequirements() {
    return [
      {
        title: "Multi-Source Data Ingestion & Normalization Engine",
        description: `Advanced data ingestion platform capable of processing trade data from diverse sources including trading systems, custodians, prime brokers, and counterparties with real-time normalization and enrichment capabilities.

**Data Source Integration:**
• Trading platforms (Bloomberg AIM, Tradeweb, MarketAxess, dealer platforms)
• Custodian banks (State Street, BNY Mellon, JPMorgan, Citi)
• Prime brokers and executing brokers across global markets
• Central counterparties (LCH, CME, Eurex, JSCC)
• Market data providers (Bloomberg, Refinitiv, ICE Data Services)

**Processing Capabilities:**
• Real-time streaming data ingestion with Apache Kafka
• Batch file processing (CSV, XML, FpML, SWIFT messages)
• API-based data feeds with RESTful and WebSocket protocols
• Data transformation using configurable mapping rules
• Reference data enrichment and validation
• Duplicate detection and data deduplication logic

**Normalization Features:**
• Universal trade representation model across asset classes
• Currency conversion using real-time FX rates
• Time zone normalization and trade date adjustments
• Security master integration for instrument identification
• Counterparty master data management and LEI mapping`,
        priority: "Critical"
      },
      {
        title: "Configurable Matching Rules Engine with AI-Powered Analytics",
        description: `Sophisticated matching engine that employs configurable business rules, tolerance management, and machine learning algorithms to identify matched trades, breaks, and exceptions across multiple data sources.

**Matching Algorithms:**
• Exact matching for identical trade attributes
• Fuzzy matching with configurable tolerance thresholds
• Probabilistic matching using machine learning models
• Multi-dimensional matching across trade economics, timing, and counterparties
• Pattern recognition for systematic breaks and data quality issues

**Configuration Management:**
• Business user-friendly rule configuration interface
• A/B testing framework for matching rule optimization
• Performance analytics and matching effectiveness metrics
• Rule versioning and change management
• Impact analysis for rule modifications

**AI/ML Integration:**
• Anomaly detection for unusual trade patterns
• Predictive analytics for break identification
• Natural language processing for trade narrative analysis
• Automated threshold optimization based on historical performance
• Continuous learning from user feedback and manual adjustments

**Asset Class Coverage:**
• Equities (cash, derivatives, structured products)
• Fixed income (government, corporate, municipal bonds)
• Foreign exchange (spot, forwards, swaps, options)
• Commodities (precious metals, energy, agriculture)
• Cryptocurrencies and digital assets`,
        priority: "Critical"
      },
      {
        title: "Real-Time Break Management & Resolution Workflow",
        description: `Comprehensive break management system that automatically identifies, categorizes, ages, and facilitates resolution of trade discrepancies through intelligent workflow automation and escalation procedures.

**Break Classification:**
• Price/rate discrepancies with tolerance-based categorization
• Quantity/notional mismatches and partial fill handling
• Settlement date differences and T+ convention variations
• Counterparty identification errors and entity mapping issues
• Product classification mismatches and security identifier conflicts

**Workflow Automation:**
• Automated break aging with configurable business day calculations
• Dynamic prioritization based on break value, age, and risk impact
• Intelligent routing to appropriate resolution teams
• SLA tracking and escalation based on break characteristics
• Integration with communication tools (email, Slack, Microsoft Teams)

**Resolution Capabilities:**
• Automated resolution for common systematic breaks
• Template-based communication with counterparties
• Bulk resolution tools for similar break patterns
• Exception approval workflows for high-value breaks
• Integration with settlement systems for automatic corrections

**Reporting & Analytics:**
• Real-time break dashboards with drill-down capabilities
• Trend analysis and root cause identification
• Operational metrics and KPI tracking
• Regulatory reporting for unmatched trades
• Performance benchmarking and process optimization insights`,
        priority: "High"
      }
    ];
  }

  function getReconNonFunctionalRequirements() {
    return [
      {
        title: "High-Performance Computing & Real-Time Processing Architecture",
        description: `Advanced computing architecture designed for high-frequency trade reconciliation with sub-second processing capabilities and massive parallel processing for complex matching algorithms.

**Performance Specifications:**
• Processing throughput: 10 million trade comparisons per minute
• Real-time matching latency: <100ms for standard trades
• Complex derivative matching: <500ms including valuation checks
• Concurrent reconciliation runs: 50+ simultaneous processes
• Memory optimization: 16GB RAM handling 100M+ trade records

**Architecture Components:**
• In-memory computing with Apache Ignite or Hazelcast
• Stream processing with Apache Flink for real-time reconciliation
• GPU acceleration for complex mathematical calculations
• Distributed computing with Apache Spark for batch processing
• Event-driven architecture with reactive programming patterns

**Scalability Features:**
• Horizontal auto-scaling based on trade volume
• Dynamic resource allocation during peak processing periods
• Geo-distributed processing for global market coverage
• Load balancing with intelligent workload distribution
• Container orchestration with Kubernetes for optimal resource utilization`,
        priority: "Critical"
      },
      {
        title: "Enterprise Data Management & Analytics Platform",
        description: `Comprehensive data management platform providing data governance, lineage tracking, analytics, and business intelligence capabilities for reconciliation processes and operational decision-making.

**Data Management:**
• Master data management (MDM) for securities, counterparties, and reference data
• Data lake architecture with structured and unstructured data support
• Real-time data streaming with change data capture (CDC)
• Data quality monitoring with automated profiling and cleansing
• Blockchain-based data integrity verification for audit trails

**Analytics Capabilities:**
• Self-service business intelligence with drag-and-drop interfaces
• Advanced analytics with machine learning model deployment
• Predictive analytics for break forecasting and prevention
• Real-time operational dashboards with customizable KPIs
• Ad-hoc reporting with natural language query processing

**Data Governance:**
• Comprehensive data lineage from source to reconciliation output
• Data classification and sensitivity labeling
• Access control with attribute-based access control (ABAC)
• Data retention policies with automated archival and purging
• Compliance monitoring with GDPR, CCPA, and financial regulations
• Data catalog with searchable metadata and business glossary`,
        priority: "High"
      }
    ];
  }

  function getRoleSpecificSuggestions(role: string, message: string): string[] {
    const baseSuggestions = {
      "business-analyst": [
        "Create detailed use case",
        "Analyze requirements gap",
        "Generate test scenarios",
        "Review compliance needs"
      ],
      "product-owner": [
        "Define acceptance criteria",
        "Prioritize backlog items",
        "Plan sprint scope",
        "Review stakeholder feedback"
      ],
      "developer": [
        "Review technical specs",
        "Estimate development effort",
        "Identify dependencies",
        "Plan architecture"
      ]
    };

    const suggestions = baseSuggestions[role as keyof typeof baseSuggestions] || baseSuggestions["business-analyst"];
    
    if (message.toLowerCase().includes('performance')) {
      return [...suggestions, "Analyze performance requirements", "Define SLA targets"];
    }
    if (message.toLowerCase().includes('security')) {
      return [...suggestions, "Review security protocols", "Plan compliance audit"];
    }
    
    return suggestions;
  }

  // Product Backlog API Routes
  app.get("/api/projects/:id/backlog", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const backlog = await storage.getProductBacklog(projectId);
      res.json(backlog);
    } catch (error) {
      console.error("Error fetching product backlog:", error);
      res.status(500).json({ message: "Failed to fetch product backlog" });
    }
  });

  app.post("/api/projects/:id/backlog", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const backlogItem = await storage.createBacklogItem({
        ...req.body,
        projectId,
        createdById: 1,
      });
      res.json(backlogItem);
    } catch (error) {
      console.error("Error creating backlog item:", error);
      res.status(500).json({ message: "Failed to create backlog item" });
    }
  });

  app.put("/api/backlog/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updatedItem = await storage.updateBacklogItem(id, req.body);
      if (!updatedItem) {
        return res.status(404).json({ message: "Backlog item not found" });
      }
      res.json(updatedItem);
    } catch (error) {
      console.error("Error updating backlog item:", error);
      res.status(500).json({ message: "Failed to update backlog item" });
    }
  });

  // Board Management API Routes
  app.post("/api/projects/:id/manage-board", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const { boardType } = req.body; // 'kanban' or 'scrum'
      const scrumMasterId = 1; // Current user ID
      
      const updatedProject = await storage.setBoardType(projectId, boardType, scrumMasterId);
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json({
        project: updatedProject,
        message: `Project set to ${boardType} board management by Scrum Master`
      });
    } catch (error) {
      console.error("Error setting board type:", error);
      res.status(500).json({ message: "Failed to set board type" });
    }
  });

  // Architect Assignment API Routes
  app.post("/api/projects/:id/assign-architect", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const { architectId } = req.body;
      
      const updatedProject = await storage.assignArchitect(projectId, architectId);
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json({
        project: updatedProject,
        message: "Architect assigned successfully"
      });
    } catch (error) {
      console.error("Error assigning architect:", error);
      res.status(500).json({ message: "Failed to assign architect" });
    }
  });

  // Get projects assigned to architect
  app.get("/api/architect/projects", async (req, res) => {
    try {
      const architectId = 1; // Current user ID
      const projects = await storage.getArchitectProjects(architectId);
      res.json(projects);
    } catch (error) {
      console.error("Error fetching architect projects:", error);
      res.status(500).json({ message: "Failed to fetch architect projects" });
    }
  });

  // Get available architects for assignment
  app.get("/api/architects", async (req, res) => {
    try {
      // Return users with architect role
      const architects = [
        { id: 1, name: "Gobind Praharaj", role: "architect" },
        { id: 2, name: "Senior Architect", role: "architect" }
      ];
      res.json(architects);
    } catch (error) {
      console.error("Error fetching architects:", error);
      res.status(500).json({ message: "Failed to fetch architects" });
    }
  });

  // Architecture API Routes
  app.get("/api/projects/:projectId/architecture", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      console.log(`🔍 API: Getting architecture for project ${projectId}`);
      let architecture = await storage.getArchitecture(projectId);
      console.log(`🔍 API: Architecture found:`, architecture ? 'YES' : 'NO');
      
      // If no architecture exists, auto-generate one from project requirements
      if (!architecture) {
        const project = await storage.getProject(projectId);
        const useCases = await storage.getUseCasesByProject(projectId);
        
        if (project && useCases.length > 0) {
          const architectureRecommendations = await aiAgentFramework.generateArchitectureRecommendations(project, useCases);
          
          // Create initial architecture with AI recommendations
          architecture = await storage.createArchitecture({
            projectId,
            systemOverview: architectureRecommendations.systemArchitecture || "AI-generated enterprise-grade system architecture optimized for financial services compliance and scalability.",
            architecturalPrinciples: "Microservices architecture with event-driven design, domain-driven development, CQRS pattern implementation, and comprehensive security layers.",
            componentDiagram: "Frontend Layer (React SPA) → API Gateway → Authentication Service → Core Business Services → Data Access Layer → Database Cluster → External Integrations",
            dataFlow: "Client Request → Load Balancer → API Gateway → JWT Validation → Business Logic Processing → Database Operations → Response Aggregation → Client Response",
            technologyStack: JSON.stringify({
              frontend: ["React 18", "TypeScript", "Tailwind CSS", "Redux Toolkit"],
              backend: ["Node.js", "Express.js", "TypeScript", "GraphQL"],
              database: ["PostgreSQL 15", "Redis 7", "TimescaleDB"],
              infrastructure: ["Docker", "Kubernetes", "AWS EKS", "Terraform"],
              security: ["OAuth 2.0", "JWT", "HTTPS/TLS 1.3", "Rate Limiting", "RBAC"]
            }),
            securityArchitecture: architectureRecommendations.securityConsiderations?.join('. ') || "Multi-layered security with zero-trust architecture, end-to-end encryption, comprehensive audit logging, and regulatory compliance frameworks.",
            deploymentStrategy: architectureRecommendations.deploymentStrategy || "Blue-green deployment with automated CI/CD pipelines, canary releases, and comprehensive monitoring.",
            scalabilityConsiderations: "Horizontal auto-scaling, event-driven microservices, distributed caching, database sharding, and CDN integration for global performance.",
            integrationPoints: architectureRecommendations.integrationPoints?.join('. ') || "REST APIs, GraphQL endpoints, message queues, webhook systems, and real-time WebSocket connections.",
            riskAssessment: "Identified risks: service dependencies, data consistency, security vulnerabilities. Mitigation: circuit breakers, distributed tracing, security scanning, and disaster recovery.",
            status: "draft",
            createdById: 1,
            assignedArchitectId: 1
          });
        } else {
          return res.status(404).json({ message: "Architecture not found and cannot be generated without project requirements" });
        }
      }
      
      // Parse technologyStack if it's a string
      if (typeof architecture.technologyStack === 'string') {
        try {
          architecture.technologyStack = JSON.parse(architecture.technologyStack);
        } catch (e) {
          architecture.technologyStack = {
            frontend: ["React", "TypeScript"],
            backend: ["Node.js", "Express"],
            database: ["PostgreSQL"],
            infrastructure: ["Docker", "AWS"],
            security: ["OAuth 2.0", "JWT"]
          };
        }
      }
      
      res.json(architecture);
    } catch (error) {
      console.error("Error fetching architecture:", error);
      res.status(500).json({ message: "Failed to fetch architecture" });
    }
  });

  app.post("/api/projects/:projectId/architecture", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const architectureData = req.body;

      const architecture = await storage.createArchitecture({
        ...architectureData,
        projectId,
        technologyStack: JSON.stringify(architectureData.technologyStack || {}),
        status: "draft",
        createdById: 1,
        assignedArchitectId: 1
      });

      res.json(architecture);
    } catch (error) {
      console.error("Error creating architecture:", error);
      res.status(500).json({ message: "Failed to create architecture" });
    }
  });

  app.put("/api/projects/:projectId/architecture", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const architectureData = req.body;

      const architecture = await storage.updateArchitecture(projectId, {
        ...architectureData,
        technologyStack: JSON.stringify(architectureData.technologyStack || {})
      });

      if (!architecture) {
        return res.status(404).json({ message: "Architecture not found" });
      }

      res.json(architecture);
    } catch (error) {
      console.error("Error updating architecture:", error);
      res.status(500).json({ message: "Failed to update architecture" });
    }
  });

  app.post("/api/projects/:projectId/architecture/finalize", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      
      const architecture = await storage.finalizeArchitecture(projectId);
      
      if (!architecture) {
        return res.status(404).json({ message: "Architecture not found" });
      }

      res.json(architecture);
    } catch (error) {
      console.error("Error finalizing architecture:", error);
      res.status(500).json({ message: "Failed to finalize architecture" });
    }
  });

  app.post("/api/projects/:projectId/architecture/generate", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const project = await storage.getProject(projectId);
      const useCases = await storage.getUseCasesByProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const architectureRecommendations = await aiAgentFramework.generateArchitectureRecommendations(project, useCases);
      
      const generatedArchitecture = {
        systemOverview: architectureRecommendations.systemArchitecture || "AI-generated system overview based on project requirements and use cases.",
        architecturalPrinciples: "Microservices architecture with domain-driven design, event sourcing, and CQRS patterns.",
        componentDiagram: "Frontend: React/Angular, API Gateway, Microservices (Auth, Core Business Logic, Notifications), Database Layer (PostgreSQL, Redis), External Integrations",
        dataFlow: "User requests → API Gateway → Authentication Service → Business Logic Services → Database → Response via API Gateway",
        technologyStack: {
          frontend: ["React", "TypeScript", "Tailwind CSS"],
          backend: ["Node.js", "Express", "TypeScript"],
          database: ["PostgreSQL", "Redis"],
          infrastructure: ["Docker", "Kubernetes", "AWS"],
          security: ["OAuth 2.0", "JWT", "HTTPS", "API Rate Limiting"]
        },
        securityArchitecture: architectureRecommendations.securityConsiderations?.join('. ') || "Multi-layered security with OAuth 2.0 authentication, JWT tokens, API rate limiting, data encryption at rest and in transit, and comprehensive audit logging.",
        deploymentStrategy: architectureRecommendations.deploymentStrategy || "Container-based deployment using Docker and Kubernetes, with CI/CD pipeline, blue-green deployment strategy, and automated testing.",
        scalabilityConsiderations: "Horizontal scaling with load balancers, microservices architecture, caching strategies, database sharding, and event-driven communication.",
        integrationPoints: architectureRecommendations.integrationPoints?.join('. ') || "REST APIs for client communication, message queues for service communication, webhook endpoints for external integrations, and event streaming for real-time updates.",
        riskAssessment: "Key risks include service dependencies, data consistency in distributed systems, security vulnerabilities, and performance bottlenecks. Mitigation strategies include circuit breakers, monitoring, and comprehensive testing."
      };

      res.json(generatedArchitecture);
    } catch (error) {
      console.error("Error generating architecture:", error);
      res.status(500).json({ message: "Failed to generate architecture with AI" });
    }
  });

  // Intelligent Product Backlog Generation Functions
  function generateIntelligentBacklogItems(functionalReq: any, project: any) {
    const backlogItems = [];
    const baseTitle = functionalReq.title;
    const baseDescription = functionalReq.description;
    
    // 1. Core Feature Implementation - Main epic
    const coreFeature = {
      title: `${baseTitle} - Core Implementation`,
      description: `${baseDescription}\n\nCore feature implementation covering the primary business logic, data models, and essential functionality. This epic encompasses the foundational capabilities required for ${baseTitle.toLowerCase()}.`,
      userStory: `As a ${functionalReq.actor || 'financial services professional'}, I want to ${baseTitle.toLowerCase()} so that I can ${baseDescription.substring(0, 100).toLowerCase()}...`,
      acceptanceCriteria: generateComprehensiveAcceptanceCriteria(functionalReq),
      priority: functionalReq.priority,
      storyPoints: calculateIntelligentStoryPoints(functionalReq) + 3,
      tags: [...determineFeatureTags(functionalReq), "core-feature", "epic"],
      businessValue: mapBusinessValue(functionalReq.priority),
      risk: assessTechnicalRisk(functionalReq),
      complexity: assessComplexity(functionalReq),
      userTypes: extractUserTypes(functionalReq),
      functionalArea: determineFunctionalArea(functionalReq),
      assignedTeam: determineTeam(functionalReq),
    };
    backlogItems.push(coreFeature);

    // 2. User Interface & Experience - Frontend epic
    const uiFeature = {
      title: `${baseTitle} - User Interface & Dashboard`,
      description: `Design and implement comprehensive user interface for ${baseTitle.toLowerCase()}. Includes responsive web interface, mobile-friendly design, real-time data visualization, and intuitive user workflows.\n\nFeatures:\n• Interactive dashboards with real-time updates\n• Advanced filtering and search capabilities\n• Export/import functionality\n• User preference management\n• Accessibility compliance (WCAG 2.1)`,
      userStory: `As a ${functionalReq.actor || 'business user'}, I want an intuitive and responsive interface for ${baseTitle.toLowerCase()} so that I can efficiently manage my daily operations and access critical information quickly.`,
      acceptanceCriteria: generateUIAcceptanceCriteria(functionalReq),
      priority: adjustPriority(functionalReq.priority, -1),
      storyPoints: calculateIntelligentStoryPoints(functionalReq) + 2,
      tags: ["frontend", "ui-ux", "dashboard", "responsive"],
      businessValue: mapBusinessValue(functionalReq.priority),
      risk: "Medium",
      complexity: "Medium",
      userTypes: extractUserTypes(functionalReq),
      functionalArea: "user-interface",
      assignedTeam: "frontend",
    };
    backlogItems.push(uiFeature);

    // 3. API & Integration Layer - Backend epic
    const apiFeature = {
      title: `${baseTitle} - API & Integration Services`,
      description: `Develop robust REST API endpoints and integration services for ${baseTitle.toLowerCase()}. Includes comprehensive API documentation, rate limiting, authentication, and integration with external systems.\n\nTechnical Components:\n• RESTful API endpoints with OpenAPI specification\n• WebSocket connections for real-time updates\n• Message queue integration (Apache Kafka)\n• External system connectors and adapters\n• API versioning and backward compatibility`,
      userStory: `As a system integrator, I want comprehensive API access for ${baseTitle.toLowerCase()} so that I can integrate with existing enterprise systems and enable automation workflows.`,
      acceptanceCriteria: generateAPIAcceptanceCriteria(functionalReq),
      priority: functionalReq.priority,
      storyPoints: calculateIntelligentStoryPoints(functionalReq) + 4,
      tags: ["backend", "api", "integration", "microservices"],
      businessValue: "High",
      risk: assessTechnicalRisk(functionalReq),
      complexity: "High",
      userTypes: ["system-integrator", "developer", "automation-engineer"],
      functionalArea: "api-integration",
      assignedTeam: "backend",
    };
    backlogItems.push(apiFeature);

    // 4. Data Validation & Quality Assurance
    const validationFeature = {
      title: `${baseTitle} - Data Validation & Quality Control`,
      description: `Implement comprehensive data validation, quality checks, and error handling for ${baseTitle.toLowerCase()}. Ensures data integrity, regulatory compliance, and business rule enforcement.\n\nValidation Framework:\n• Real-time data validation engine\n• Business rule configuration interface\n• Exception handling and workflow routing\n• Data quality metrics and reporting\n• Automated correction suggestions`,
      userStory: `As a data quality manager, I want automated validation and quality control for ${baseTitle.toLowerCase()} so that I can ensure data accuracy and compliance with regulatory requirements.`,
      acceptanceCriteria: generateValidationAcceptanceCriteria(functionalReq),
      priority: ensureMinimumPriority(functionalReq.priority, "High"),
      storyPoints: calculateIntelligentStoryPoints(functionalReq) + 1,
      tags: ["validation", "quality-assurance", "compliance", "data-integrity"],
      businessValue: "High",
      risk: "Medium",
      complexity: "Medium",
      userTypes: ["data-analyst", "compliance-officer", "quality-manager"],
      functionalArea: "data-quality",
      assignedTeam: "backend",
    };
    backlogItems.push(validationFeature);

    // 5. Reporting & Analytics (for business-critical features)
    if (functionalReq.priority === "Critical" || functionalReq.priority === "High") {
      const reportingFeature = {
        title: `${baseTitle} - Advanced Reporting & Analytics`,
        description: `Develop comprehensive reporting and analytics capabilities for ${baseTitle.toLowerCase()}. Includes real-time dashboards, historical analysis, regulatory reports, and business intelligence features.\n\nReporting Features:\n• Interactive business intelligence dashboards\n• Scheduled report generation and distribution\n• Drill-down analytics with data visualization\n• Export capabilities (PDF, Excel, CSV)\n• Regulatory reporting templates\n• Performance metrics and KPI tracking`,
        userStory: `As a business analyst, I want comprehensive reporting and analytics for ${baseTitle.toLowerCase()} so that I can monitor performance, identify trends, and generate regulatory reports efficiently.`,
        acceptanceCriteria: generateReportingAcceptanceCriteria(functionalReq),
        priority: adjustPriority(functionalReq.priority, -1),
        storyPoints: calculateIntelligentStoryPoints(functionalReq) + 2,
        tags: ["reporting", "analytics", "business-intelligence", "dashboards"],
        businessValue: mapBusinessValue(functionalReq.priority),
        risk: "Medium",
        complexity: "Medium",
        userTypes: ["business-analyst", "manager", "compliance-officer"],
        functionalArea: "reporting-analytics",
        assignedTeam: "frontend",
      };
      backlogItems.push(reportingFeature);
    }

    // 6. Security & Audit Trail (for all features)
    const securityFeature = {
      title: `${baseTitle} - Security & Audit Framework`,
      description: `Implement comprehensive security controls and audit trail capabilities for ${baseTitle.toLowerCase()}. Ensures regulatory compliance, data protection, and complete activity tracking.\n\nSecurity Components:\n• Role-based access control (RBAC)\n• Multi-factor authentication integration\n• Data encryption at rest and in transit\n• Comprehensive audit logging\n• Activity monitoring and alerting\n• GDPR and regulatory compliance features`,
      userStory: `As a security officer, I want comprehensive security controls and audit trails for ${baseTitle.toLowerCase()} so that I can ensure data protection and regulatory compliance.`,
      acceptanceCriteria: generateSecurityAcceptanceCriteria(functionalReq),
      priority: "High",
      storyPoints: calculateIntelligentStoryPoints(functionalReq),
      tags: ["security", "audit", "compliance", "access-control"],
      businessValue: "High",
      risk: "High",
      complexity: "High",
      userTypes: ["security-officer", "compliance-officer", "auditor"],
      functionalArea: "security-compliance",
      assignedTeam: "security",
    };
    backlogItems.push(securityFeature);
    
    return backlogItems;
  }

  function generateComprehensiveAcceptanceCriteria(req: any): string {
    const title = req.title.toLowerCase();
    const description = req.description?.toLowerCase() || '';
    
    let criteria = `**Core Functionality:**\n`;
    criteria += `• System successfully implements ${req.title} with complete business logic\n`;
    criteria += `• All data inputs are validated and processed correctly\n`;
    criteria += `• Error handling provides meaningful feedback to users\n`;
    criteria += `• Performance meets specified SLA requirements (<5 second response time)\n\n`;
    
    if (title.includes('trade') || title.includes('transaction') || description.includes('trade')) {
      criteria += `**Trading Specific:**\n`;
      criteria += `• Trade details captured with unique identifiers (UTI/USI)\n`;
      criteria += `• Real-time validation against counterparty limits\n`;
      criteria += `• Trade confirmation generated within 1 second\n`;
      criteria += `• Position updates reflect immediately in risk systems\n`;
      criteria += `• Integration with market data feeds for pricing validation\n\n`;
    }
    
    if (title.includes('settlement') || title.includes('clearing') || description.includes('settlement')) {
      criteria += `**Settlement & Clearing:**\n`;
      criteria += `• Settlement instructions generated in SWIFT MT format\n`;
      criteria += `• Multi-currency support with real-time FX rates\n`;
      criteria += `• Integration with correspondent banking networks\n`;
      criteria += `• Failed settlement handling and retry mechanisms\n`;
      criteria += `• T+0, T+1, T+2 settlement cycle support\n\n`;
    }
    
    if (title.includes('risk') || title.includes('margin') || description.includes('risk')) {
      criteria += `**Risk Management:**\n`;
      criteria += `• Real-time risk calculations using industry models (SIMM, Basel)\n`;
      criteria += `• Portfolio-level netting and cross-margining\n`;
      criteria += `• Automated margin call generation and notifications\n`;
      criteria += `• Stress testing and scenario analysis capabilities\n`;
      criteria += `• Integration with market volatility feeds\n\n`;
    }
    
    if (title.includes('report') || title.includes('compliance') || description.includes('regulatory')) {
      criteria += `**Regulatory & Compliance:**\n`;
      criteria += `• Automated regulatory report generation (EMIR, MiFID II, Dodd-Frank)\n`;
      criteria += `• Data validation against regulatory schemas\n`;
      criteria += `• Submission to trade repositories and regulators\n`;
      criteria += `• Complete audit trail with immutable records\n`;
      criteria += `• Data retention policies (7+ years) implemented\n\n`;
    }
    
    criteria += `**Quality Assurance:**\n`;
    criteria += `• Unit test coverage minimum 90%\n`;
    criteria += `• Integration tests cover all API endpoints\n`;
    criteria += `• Security testing validates access controls\n`;
    criteria += `• Performance testing under peak load conditions\n`;
    criteria += `• User acceptance testing with business stakeholders\n\n`;
    
    criteria += `**Production Readiness:**\n`;
    criteria += `• Monitoring and alerting configured\n`;
    criteria += `• Disaster recovery procedures documented\n`;
    criteria += `• Runbook and operational procedures available\n`;
    criteria += `• Security review and approval completed\n`;
    criteria += `• Go-live checklist signed off by all stakeholders`;
    
    return criteria;
  }

  function generateUIAcceptanceCriteria(req: any): string {
    return `**User Interface Requirements:**
• Responsive design works across desktop (1920x1080), tablet (768x1024), and mobile (375x667) viewports
• Interactive dashboard displays real-time data with auto-refresh every 30 seconds
• Advanced filtering and sorting capabilities with multi-column support
• Drag-and-drop functionality for data organization and workflow management
• Keyboard navigation support for accessibility compliance (WCAG 2.1 AA)

**User Experience:**
• Page load time under 3 seconds for standard data volumes (<10K records)
• Intuitive navigation with breadcrumb trails and clear action buttons
• Context-sensitive help tooltips and guided user onboarding
• Bulk actions for mass data operations (select all, batch edit, export)
• User preferences saved (column widths, default filters, dashboard layout)

**Data Visualization:**
• Interactive charts and graphs with drill-down capabilities
• Real-time data updates without page refresh using WebSocket connections
• Export functionality (PDF, Excel, CSV) with custom formatting options
• Print-friendly layouts with proper page breaks and headers
• Color-coded status indicators with consistent design system

**Error Handling & Feedback:**
• Graceful error handling with user-friendly error messages
• Loading spinners and progress indicators for long-running operations
• Success confirmations for all CRUD operations
• Validation messages displayed inline with form fields
• Network error recovery with automatic retry mechanisms`;
  }

  function generateAPIAcceptanceCriteria(req: any): string {
    return `**API Design & Documentation:**
• RESTful API endpoints following OpenAPI 3.0 specification
• Comprehensive API documentation with interactive Swagger UI
• Request/response examples for all endpoints with sample data
• SDK/client libraries available for major programming languages (JavaScript, Python, Java)
• API versioning strategy (v1, v2) with backward compatibility guarantee

**Performance & Scalability:**
• API response time under 200ms for simple operations, 2 seconds for complex queries
• Support for pagination with configurable page sizes (default 100, max 1000)
• Bulk operations support for mass data manipulation (batch create/update/delete)
• Connection pooling and database optimization for concurrent requests
• Horizontal scaling capability tested up to 10,000 concurrent users

**Security & Authentication:**
• OAuth 2.0 / JWT token-based authentication with refresh token support
• Role-based authorization with granular permission controls
• API key management with rotation and revocation capabilities
• Rate limiting (1000 requests/hour per user, 10,000/hour per organization)
• CORS configuration for cross-origin requests from approved domains

**Integration & Reliability:**
• WebSocket endpoints for real-time data streaming and notifications
• Webhook support for event-driven integrations with external systems
• Message queue integration (Apache Kafka) for asynchronous processing
• Circuit breaker pattern implemented for external service dependencies
• Comprehensive error handling with standardized error response format

**Monitoring & Observability:**
• API metrics collection (response times, error rates, throughput)
• Request/response logging with correlation IDs for tracing
• Health check endpoints for monitoring system status
• OpenTelemetry integration for distributed tracing
• Automated alerts for API performance degradation or failures`;
  }

  function generateValidationAcceptanceCriteria(req: any): string {
    return `**Data Validation Framework:**
• Real-time validation engine processes all data inputs within 100ms
• Configurable business rules engine with rule versioning and rollback capability
• Multi-layer validation: format, business logic, cross-reference, and regulatory compliance
• Batch validation support for large data imports (10K+ records)
• Custom validation rule creation interface for business users

**Validation Rules & Logic:**
• Format validation for all data types (dates, numbers, text patterns, file types)
• Business rule validation against configurable constraints and limits
• Cross-reference validation with master data and external systems
• Regulatory compliance checks for financial instruments and jurisdictions
• Duplicate detection and prevention with configurable matching criteria

**Error Handling & User Experience:**
• Detailed error messages with specific field-level guidance
• Error categorization (Warning, Error, Critical) with appropriate handling
• Bulk error reporting for batch operations with line-by-line details
• Auto-correction suggestions for common data entry mistakes
• Progressive validation with real-time feedback during data entry

**Exception Management:**
• Exception workflow routing based on error severity and business rules
• Assignment and escalation procedures for manual review requirements
• Exception tracking dashboard with aging reports and SLA monitoring
• Automated resolution for known error patterns and data corrections
• Integration with case management system for complex exceptions

**Quality Metrics & Reporting:**
• Data quality scorecard with accuracy, completeness, and timeliness metrics
• Trend analysis and quality improvement recommendations
• Exception rate monitoring with automated alerts for threshold breaches
• Quality audit trails for regulatory compliance and internal reviews
• Performance analytics for validation processing times and bottlenecks`;
  }

  function generateSecurityAcceptanceCriteria(req: any): string {
    return `**Access Control & Authentication:**
• Role-based access control (RBAC) with granular permission management
• Multi-factor authentication (MFA) required for privileged operations
• Single sign-on (SSO) integration with enterprise identity providers (AD, LDAP, SAML)
• Session management with configurable timeout and concurrent session limits
• Privileged access monitoring and approval workflows for sensitive operations

**Data Protection & Encryption:**
• AES-256 encryption for data at rest in databases and file systems
• TLS 1.3 encryption for all data in transit between components
• End-to-end encryption for sensitive data fields (PII, financial data)
• Key management system with automatic key rotation and escrow procedures
• Database column-level encryption for highly sensitive information

**Audit Trail & Monitoring:**
• Comprehensive audit logging for all user actions and system events
• Immutable audit trail with digital signatures and tamper detection
• Real-time security monitoring with behavioral analytics and anomaly detection
• SIEM integration for centralized security event management
• Automated incident response and alerting for security violations

**Vulnerability Management:**
• Regular security scanning and penetration testing (quarterly)
• OWASP Top 10 compliance validation with automated testing
• Dependency scanning for third-party libraries and components
• Static and dynamic application security testing (SAST/DAST)
• Vulnerability remediation tracking with SLA compliance

**Compliance & Governance:**
• SOX compliance for financial data handling and change management
• GDPR compliance with data privacy rights and consent management
• ISO 27001 security controls implementation and documentation
• Regulatory compliance validation (SEC, FINRA, banking regulations)
• Data loss prevention (DLP) controls and sensitive data classification`;
  }

  function generatePerformanceAcceptanceCriteria(req: any): string {
    return `**Performance Targets:**
• 99.99% uptime SLA with maximum 4.32 minutes downtime per month
• API response time <200ms for simple operations, <2 seconds for complex queries
• Page load time <3 seconds for standard business workflows
• Database query performance <100ms for indexed lookups, <500ms for complex joins
• File upload/download throughput minimum 10MB/s for enterprise networks

**Load & Scalability:**
• Load testing validates 10x expected peak traffic (100K concurrent users)
• Auto-scaling triggers activate at 70% CPU/memory utilization
• Horizontal scaling capability tested up to 50 application instances
• Database connection pooling supports 1000+ concurrent connections
• CDN cache hit ratio >95% for static assets and frequently accessed data

**Monitoring & Optimization:**
• Real-time performance monitoring with 1-minute granularity
• Automated alerting for response time degradation >20% baseline
• Application Performance Monitoring (APM) with distributed tracing
• Database performance monitoring with slow query identification
• Resource utilization trending and capacity planning reports

**Quality Assurance:**
• Performance regression testing integrated into CI/CD pipeline
• Stress testing validates system behavior under 150% expected load
• Memory leak detection and garbage collection optimization
• Network latency optimization for cross-region deployments
• Performance budgets enforced for all new feature development`;
  }

  function generateReportingAcceptanceCriteria(req: any): string {
    return `**Business Intelligence & Analytics:**
• Interactive dashboards with drill-down capabilities and real-time data refresh
• Customizable reports with save/share functionality and scheduled delivery
• Advanced data visualization (charts, graphs, heatmaps, trend analysis)
• Export capabilities (PDF, Excel, CSV, PowerPoint) with corporate branding
• Self-service reporting tools for business users with drag-and-drop interface

**Performance & Scalability:**
• Report generation time <30 seconds for standard reports, <5 minutes for complex analytics
• Support for large datasets (1M+ records) with pagination and progressive loading
• Concurrent user support (100+ simultaneous report executions)
• Caching layer for frequently accessed reports with configurable TTL
• Resource optimization to prevent database performance impact

**Data Integration & Sources:**
• Real-time data integration from operational systems and data warehouses
• Historical data analysis with configurable time ranges and trending
• Data quality indicators and confidence scores for all metrics
• Cross-functional data correlation and dependency mapping
• API integration for external data sources and third-party systems

**Regulatory & Compliance Reporting:**
• Automated regulatory report templates (CFTC, SEC, ESMA, local authorities)
• Audit trail for all report generation and distribution activities
• Data lineage tracking and impact analysis for regulatory changes
• Compliance validation with regulatory schema and format requirements
• Secure report distribution with access controls and digital signatures`;
  }

  function generateAvailabilityAcceptanceCriteria(req: any): string {
    return `**High Availability Requirements:**
• 99.99% uptime SLA with maximum 52.56 minutes downtime per year
• Multi-region deployment with active-passive failover capabilities
• Load balancing across multiple application instances with health checks
• Database clustering with automatic failover and data synchronization
• Network redundancy with multiple ISP connections and BGP routing

**Disaster Recovery:**
• Recovery Time Objective (RTO) <4 hours for critical systems
• Recovery Point Objective (RPO) <1 hour with minimal data loss
• Automated backup procedures with cross-region replication
• Regular disaster recovery testing (quarterly) with documented procedures
• Business continuity planning with stakeholder communication protocols

**Monitoring & Alerting:**
• Real-time system health monitoring with proactive alerting
• Application performance monitoring with threshold-based notifications
• Infrastructure monitoring (CPU, memory, disk, network) with trending
• Database performance monitoring with query optimization recommendations
• End-to-end synthetic transaction monitoring for critical business workflows

**Failover & Recovery:**
• Automated failover procedures with minimal manual intervention
• Database point-in-time recovery with granular restoration capabilities
• Application state preservation during failover events
• Session management and user experience continuity during outages
• Post-incident analysis and continuous improvement processes`;
  }

  function generateMonitoringAcceptanceCriteria(req: any): string {
    return `**Comprehensive Monitoring Stack:**
• Application Performance Monitoring (APM) with distributed tracing and code-level insights
• Infrastructure monitoring covering all system components (servers, databases, networks)
• Real-time log aggregation and analysis with centralized logging platform
• Business metrics monitoring with custom KPI tracking and trending
• Security monitoring with threat detection and incident response capabilities

**Alerting & Notification:**
• Multi-channel alerting (email, SMS, Slack, PagerDuty) with escalation procedures
• Intelligent alerting with noise reduction and correlation of related events
• Threshold-based alerting with dynamic baselines and anomaly detection
• Alert acknowledgment and resolution tracking with SLA compliance
• On-call rotation management with automated escalation and handoff procedures

**Observability & Analytics:**
• Service map visualization showing component dependencies and data flow
• Performance trending and capacity planning with predictive analytics
• Error tracking and root cause analysis with automated issue correlation
• User experience monitoring with real user monitoring (RUM) and synthetic testing
• Cost monitoring and optimization recommendations for cloud resources

**Dashboard & Reporting:**
• Executive dashboards with business metrics and operational health indicators
• Technical dashboards for development and operations teams with customizable views
• Mobile-responsive dashboards for on-the-go monitoring and incident response
• Historical reporting with configurable time ranges and data retention policies
• Integration with existing monitoring tools and enterprise systems (ITSM, CMDB)`;
  }

  function generateScalabilityAcceptanceCriteria(req: any): string {
    return `**Horizontal Scaling:**
• Auto-scaling groups with predictive scaling based on historical patterns
• Microservices architecture with independent scaling capabilities per service
• Container orchestration with Kubernetes for dynamic resource allocation
• Database read replicas and sharding strategies for data layer scaling
• CDN integration for global content delivery and reduced origin server load

**Load Testing & Validation:**
• Automated load testing integrated into CI/CD pipeline with performance gates
• Stress testing validates system behavior at 200% expected peak load
• Spike testing for sudden traffic surges and Black Friday-type scenarios
• Endurance testing for sustained high load over extended periods (24+ hours)
• Performance baseline establishment and regression detection

**Capacity Planning:**
• Resource utilization monitoring with trending and forecasting capabilities
• Automated capacity recommendations based on usage patterns and growth projections
• Cost optimization analysis for scaling decisions and resource rightsizing
• Performance modeling for architecture changes and technology upgrades
• Business growth correlation with infrastructure scaling requirements

**Performance Optimization:**
• Application-level optimization with code profiling and bottleneck identification
• Database query optimization with indexing and query plan analysis
• Caching strategies implementation at multiple layers (application, database, CDN)
• Network optimization with connection pooling and bandwidth management
• Resource allocation optimization based on workload characteristics and priorities`;
  }
  
  function determineFeatureTags(req: any): string[] {
    const tags: string[] = [];
    const title = req.title.toLowerCase();
    
    if (title.includes('authentication') || title.includes('login') || title.includes('user')) {
      tags.push('authentication', 'security');
    }
    if (title.includes('report') || title.includes('dashboard') || title.includes('analytics')) {
      tags.push('reporting', 'frontend');
    }
    if (title.includes('api') || title.includes('integration') || title.includes('service')) {
      tags.push('api', 'backend');
    }
    if (title.includes('trade') || title.includes('settlement') || title.includes('clearing')) {
      tags.push('trading', 'finance');
    }
    if (title.includes('compliance') || title.includes('audit') || title.includes('regulation')) {
      tags.push('compliance', 'audit');
    }
    
    return tags.length > 0 ? tags : ['general'];
  }
  
  function assessComplexity(req: any): string {
    const description = req.description?.toLowerCase() || '';
    const title = req.title.toLowerCase();
    
    if (title.includes('integration') || description.includes('multiple systems') || 
        description.includes('complex workflow') || req.priority === 'Critical') {
      return 'Complex';
    }
    if (title.includes('enhancement') || title.includes('improvement') || 
        description.includes('existing') || req.priority === 'Medium') {
      return 'Medium';
    }
    return 'Simple';
  }
  
  function extractUserTypes(req: any): string[] {
    const userTypes: string[] = [];
    const text = `${req.title} ${req.description || ''}`.toLowerCase();
    
    if (text.includes('trader') || text.includes('trading')) userTypes.push('trader');
    if (text.includes('admin') || text.includes('administrator')) userTypes.push('admin');
    if (text.includes('auditor') || text.includes('compliance')) userTypes.push('auditor');
    if (text.includes('manager') || text.includes('supervisor')) userTypes.push('manager');
    if (text.includes('client') || text.includes('customer')) userTypes.push('client');
    
    return userTypes.length > 0 ? userTypes : ['user'];
  }
  
  function determineFunctionalArea(req: any): string {
    const title = req.title.toLowerCase();
    
    if (title.includes('authentication') || title.includes('login') || title.includes('security')) {
      return 'authentication';
    }
    if (title.includes('report') || title.includes('dashboard') || title.includes('analytics')) {
      return 'reporting';
    }
    if (title.includes('trade') || title.includes('settlement') || title.includes('clearing')) {
      return 'trading';
    }
    if (title.includes('compliance') || title.includes('audit') || title.includes('regulation')) {
      return 'compliance';
    }
    if (title.includes('notification') || title.includes('alert') || title.includes('message')) {
      return 'notifications';
    }
    
    return 'general';
  }
  
  function determineTeam(req: any): string {
    const tags = determineFeatureTags(req);
    
    if (tags.includes('frontend') && tags.includes('backend')) {
      return 'fullstack';
    }
    if (tags.includes('frontend') || tags.includes('reporting')) {
      return 'frontend';
    }
    if (tags.includes('backend') || tags.includes('api')) {
      return 'backend';
    }
    if (tags.includes('security') || tags.includes('compliance')) {
      return 'security';
    }
    
    return 'fullstack';
  }
  
  function generateUserStoriesForBacklogItem(backlogItem: any, functionalReq: any) {
    const stories = [];
    const complexity = backlogItem.complexity;
    const functionalArea = backlogItem.functionalArea;
    const reqTitle = functionalReq.title.toLowerCase();
    
    // Core implementation story - always included
    stories.push({
      title: `Core Implementation: ${functionalReq.title}`,
      description: `Implement the core functionality for ${functionalReq.description}`,
      acceptanceCriteria: generateDetailedAcceptanceCriteria(functionalReq),
      priority: functionalReq.priority,
      storyPoints: calculateCoreStoryPoints(complexity),
      status: "backlog",
      assignedTo: null,
    });
    
    // UI/Frontend story if user-facing
    if (isUserFacing(reqTitle) || functionalArea === 'reporting') {
      stories.push({
        title: `UI Implementation: ${functionalReq.title} Interface`,
        description: `Design and implement user interface for ${functionalReq.title}`,
        acceptanceCriteria: generateUIAcceptanceCriteria(functionalReq),
        priority: adjustPriority(functionalReq.priority, -1),
        storyPoints: 3,
        status: "backlog",
        assignedTo: null,
      });
    }
    
    // API/Backend story if requires integration
    if (requiresAPI(reqTitle) || functionalArea === 'trading' || functionalArea === 'compliance') {
      stories.push({
        title: `API Service: ${functionalReq.title} Endpoint`,
        description: `Develop REST API endpoint and service layer for ${functionalReq.title}`,
        acceptanceCriteria: generateAPIAcceptanceCriteria(functionalReq),
        priority: functionalReq.priority,
        storyPoints: 5,
        status: "backlog",
        assignedTo: null,
      });
    }
    
    // Data validation story - critical for financial services
    stories.push({
      title: `Data Validation: ${functionalReq.title}`,
      description: `Implement comprehensive data validation and business rules for ${functionalReq.title}`,
      acceptanceCriteria: generateValidationAcceptanceCriteria(functionalReq),
      priority: ensureMinimumPriority(functionalReq.priority, "Medium"),
      storyPoints: 2,
      status: "backlog",
      assignedTo: null,
    });
    
    // Security/Compliance story for sensitive areas
    if (functionalArea === 'authentication' || functionalArea === 'compliance' || 
        reqTitle.includes('security') || reqTitle.includes('audit')) {
      stories.push({
        title: `Security & Compliance: ${functionalReq.title}`,
        description: `Implement security controls and compliance requirements for ${functionalReq.title}`,
        acceptanceCriteria: generateSecurityAcceptanceCriteria(functionalReq),
        priority: "High",
        storyPoints: 3,
        status: "backlog",
        assignedTo: null,
      });
    }
    
    // Performance story for complex features
    if (complexity === 'Complex' || functionalArea === 'trading') {
      stories.push({
        title: `Performance Optimization: ${functionalReq.title}`,
        description: `Optimize performance and scalability for ${functionalReq.title}`,
        acceptanceCriteria: generatePerformanceAcceptanceCriteria(functionalReq),
        priority: adjustPriority(functionalReq.priority, -1),
        storyPoints: 4,
        status: "backlog",
        assignedTo: null,
      });
    }
    
    return stories;
  }
  
  function calculateCoreStoryPoints(complexity: string): number {
    switch (complexity) {
      case 'Simple': return 3;
      case 'Medium': return 5;
      case 'Complex': return 8;
      default: return 5;
    }
  }
  
  function adjustPriority(priority: string, adjustment: number): string {
    const priorities = ['Low', 'Medium', 'High', 'Critical'];
    const currentIndex = priorities.indexOf(priority);
    const newIndex = Math.max(0, Math.min(priorities.length - 1, currentIndex + adjustment));
    return priorities[newIndex];
  }
  
  function ensureMinimumPriority(priority: string, minimum: string): string {
    const priorities = ['Low', 'Medium', 'High', 'Critical'];
    const currentIndex = priorities.indexOf(priority);
    const minimumIndex = priorities.indexOf(minimum);
    return currentIndex >= minimumIndex ? priority : minimum;
  }
  
  function generateInfrastructureBacklogItems(nonFuncReq: any, project: any) {
    const items = [];
    const reqTitle = nonFuncReq.title.toLowerCase();
    
    // Performance optimization
    if (reqTitle.includes('performance') || reqTitle.includes('speed') || reqTitle.includes('latency')) {
      items.push({
        title: `Performance Optimization: ${nonFuncReq.title}`,
        description: `Implement performance optimizations to meet ${nonFuncReq.description}`,
        userStory: `As a user, I want fast response times for ${nonFuncReq.title.toLowerCase()} so that my workflow is not disrupted`,
        acceptanceCriteria: generatePerformanceAcceptanceCriteria(nonFuncReq),
        priority: "High",
        storyPoints: 8,
        tags: [`performance`, `optimization`, `non-functional`],
        businessValue: "High",
        risk: "High",
      });
    }
    
    // Security implementation
    if (reqTitle.includes('security') || reqTitle.includes('authentication') || reqTitle.includes('authorization')) {
      items.push({
        title: `Security Implementation: ${nonFuncReq.title}`,
        description: `Implement security measures for ${nonFuncReq.description}`,
        userStory: `As a financial services organization, I want robust security for ${nonFuncReq.title.toLowerCase()} so that regulatory compliance is maintained`,
        acceptanceCriteria: generateSecurityAcceptanceCriteria(nonFuncReq),
        priority: "Critical",
        storyPoints: 13,
        tags: [`security`, `compliance`, `sox`, `pci`],
        businessValue: "High",
        risk: "High",
      });
    }
    
    // Scalability architecture
    if (reqTitle.includes('scalability') || reqTitle.includes('capacity') || reqTitle.includes('load')) {
      items.push({
        title: `Scalability Architecture: ${nonFuncReq.title}`,
        description: `Design scalable architecture for ${nonFuncReq.description}`,
        userStory: `As a system architect, I want scalable infrastructure for ${nonFuncReq.title.toLowerCase()} so that the system can handle enterprise load`,
        acceptanceCriteria: generateScalabilityAcceptanceCriteria(nonFuncReq),
        priority: "High",
        storyPoints: 21,
        tags: [`scalability`, `architecture`, `infrastructure`],
        businessValue: "High",
        risk: "High",
      });
    }
    
    // Monitoring and observability
    items.push({
      title: `Monitoring Setup: ${nonFuncReq.title}`,
      description: `Implement monitoring and alerting for ${nonFuncReq.title}`,
      userStory: `As a DevOps engineer, I want comprehensive monitoring for ${nonFuncReq.title.toLowerCase()} so that I can proactively manage system health`,
      acceptanceCriteria: generateMonitoringAcceptanceCriteria(nonFuncReq),
      priority: "Medium",
      storyPoints: 5,
      tags: [`monitoring`, `observability`, `devops`],
      businessValue: "Medium",
      risk: "Medium",
    });
    
    return items;
  }
  
  function generateEpicBacklogItems(project: any, functionalReqs: any[], nonFunctionalReqs: any[]) {
    const items = [];
    
    // Project setup and infrastructure
    items.push({
      title: `Epic: Project Infrastructure Setup`,
      description: `Establish development, testing, and production environments for ${project.name}`,
      userStory: `As a development team, I want a complete infrastructure setup so that I can efficiently develop and deploy the application`,
      acceptanceCriteria: `Given: Project requirements\nWhen: Infrastructure is set up\nThen: Development, staging, and production environments are ready\nAnd: CI/CD pipelines are configured\nAnd: Monitoring and logging are in place`,
      priority: "High",
      storyPoints: 34,
      tags: [`epic`, `infrastructure`, `devops`, `setup`],
      businessValue: "High",
      risk: "Medium",
    });
    
    // Integration framework
    if (functionalReqs.some(req => req.title.toLowerCase().includes('integration') || req.title.toLowerCase().includes('api'))) {
      items.push({
        title: `Epic: System Integration Framework`,
        description: `Build comprehensive integration framework for external system connectivity`,
        userStory: `As a system integrator, I want a robust integration framework so that all external systems can communicate seamlessly`,
        acceptanceCriteria: `Given: Integration requirements\nWhen: Framework is implemented\nThen: All external APIs are connected\nAnd: Error handling is comprehensive\nAnd: Data transformation is accurate`,
        priority: "Critical",
        storyPoints: 55,
        tags: [`epic`, `integration`, `api`, `framework`],
        businessValue: "High",
        risk: "High",
      });
    }
    
    // Compliance and regulatory
    if (project.name.toLowerCase().includes('emir') || project.name.toLowerCase().includes('regulatory')) {
      items.push({
        title: `Epic: Regulatory Compliance Framework`,
        description: `Implement comprehensive regulatory compliance for financial reporting`,
        userStory: `As a compliance officer, I want full regulatory compliance so that all reporting meets EMIR, MiFID II, and Basel III requirements`,
        acceptanceCriteria: `Given: Regulatory requirements\nWhen: Compliance framework is implemented\nThen: All reports meet regulatory standards\nAnd: Audit trails are complete\nAnd: Data validation passes regulatory checks`,
        priority: "Critical",
        storyPoints: 89,
        tags: [`epic`, `compliance`, `regulatory`, `emir`, `mifid`, `basel`],
        businessValue: "High",
        risk: "High",
      });
    }
    
    return items;
  }
  
  // Helper functions for intelligent backlog generation
  function generateDetailedAcceptanceCriteria(req: any): string {
    return `Given: ${req.description}\nWhen: User initiates ${req.title.toLowerCase()}\nThen: System should process the request successfully\nAnd: Data should be validated and persisted\nAnd: User should receive confirmation\nAnd: Audit log should be updated\nAnd: Performance should meet SLA requirements`;
  }
  
  function generateUIAcceptanceCriteria(req: any): string {
    return `Given: User interface for ${req.title}\nWhen: User accesses the interface\nThen: UI should be responsive and intuitive\nAnd: All form validations should work\nAnd: Error messages should be clear\nAnd: Accessibility standards should be met\nAnd: Mobile compatibility should be maintained`;
  }
  
  function generateAPIAcceptanceCriteria(req: any): string {
    return `Given: API endpoint for ${req.title}\nWhen: External system makes API call\nThen: Response should follow REST standards\nAnd: Authentication should be enforced\nAnd: Rate limiting should be applied\nAnd: Error responses should be standardized\nAnd: API documentation should be complete`;
  }
  
  function generateValidationAcceptanceCriteria(req: any): string {
    return `Given: Data validation for ${req.title}\nWhen: Invalid data is submitted\nThen: Appropriate error messages should be shown\nAnd: Valid data should be processed\nAnd: Business rules should be enforced\nAnd: Data integrity should be maintained\nAnd: Regulatory compliance should be verified`;
  }
  
  function generatePerformanceAcceptanceCriteria(req: any): string {
    return `Given: Performance requirements for ${req.title}\nWhen: System is under normal load\nThen: Response time should be < 2 seconds\nAnd: System should handle 1000+ concurrent users\nAnd: Database queries should be optimized\nAnd: Caching should be implemented\nAnd: Resource utilization should be monitored`;
  }
  
  function generateSecurityAcceptanceCriteria(req: any): string {
    return `Given: Security requirements for ${req.title}\nWhen: Security measures are implemented\nThen: Authentication should be multi-factor\nAnd: Authorization should be role-based\nAnd: Data should be encrypted in transit and at rest\nAnd: Security headers should be configured\nAnd: Vulnerability scanning should pass`;
  }
  
  function generateScalabilityAcceptanceCriteria(req: any): string {
    return `Given: Scalability requirements for ${req.title}\nWhen: System experiences high load\nThen: Auto-scaling should activate\nAnd: Performance should remain consistent\nAnd: Database should handle increased connections\nAnd: Load balancing should distribute traffic\nAnd: System should recover from failures`;
  }
  
  function generateMonitoringAcceptanceCriteria(req: any): string {
    return `Given: Monitoring setup for ${req.title}\nWhen: System is running\nThen: All metrics should be collected\nAnd: Alerts should trigger on thresholds\nAnd: Dashboards should show real-time data\nAnd: Log aggregation should be working\nAnd: Health checks should be automated`;
  }
  
  function calculateIntelligentStoryPoints(req: any): number {
    let points = 3; // Base points
    
    // Increase based on priority
    if (req.priority === "Critical") points += 5;
    else if (req.priority === "High") points += 3;
    else if (req.priority === "Medium") points += 1;
    
    // Increase based on complexity indicators
    const description = req.description.toLowerCase();
    if (description.includes('integration')) points += 3;
    if (description.includes('complex') || description.includes('advanced')) points += 2;
    if (description.includes('real-time') || description.includes('streaming')) points += 3;
    if (description.includes('reporting') || description.includes('analytics')) points += 2;
    
    return Math.min(points, 21); // Cap at 21 (largest Fibonacci number for story points)
  }
  
  function mapBusinessValue(priority: string): "High" | "Medium" | "Low" {
    switch (priority) {
      case "Critical": return "High";
      case "High": return "High";
      case "Medium": return "Medium";
      case "Low": return "Low";
      default: return "Medium";
    }
  }
  
  function assessTechnicalRisk(req: any): "High" | "Medium" | "Low" {
    const description = req.description.toLowerCase();
    if (description.includes('integration') || description.includes('complex') || description.includes('new technology')) {
      return "High";
    }
    if (description.includes('modification') || description.includes('enhancement')) {
      return "Medium";
    }
    return "Low";
  }
  
  function isUserFacing(title: string): boolean {
    return title.includes('interface') || title.includes('dashboard') || title.includes('report') || 
           title.includes('form') || title.includes('screen') || title.includes('view');
  }
  
  function requiresAPI(title: string): boolean {
    return title.includes('integration') || title.includes('service') || title.includes('api') ||
           title.includes('external') || title.includes('submission') || title.includes('transfer');
  }
  
  function getBusinessDomain(title: string): string {
    if (title.includes('trade') || title.includes('transaction')) return 'trading';
    if (title.includes('settlement') || title.includes('clearing')) return 'clearing';
    if (title.includes('report') || title.includes('regulatory')) return 'reporting';
    if (title.includes('risk') || title.includes('compliance')) return 'risk-management';
    if (title.includes('user') || title.includes('authentication')) return 'user-management';
    return 'core-business';
  }

  // Additional Architecture API Routes
  app.get("/api/projects/:id/architecture", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const architecture = await storage.getArchitecture(projectId);
      if (!architecture) {
        return res.status(404).json({ message: "Architecture not found" });
      }
      res.json(architecture);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch architecture" });
    }
  });

  app.post("/api/projects/:id/architecture", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const architecture = await storage.createArchitecture({
        projectId,
        ...req.body,
        updatedAt: new Date().toISOString()
      });
      res.json(architecture);
    } catch (error) {
      res.status(400).json({ message: "Failed to create architecture" });
    }
  });

  app.put("/api/projects/:id/architecture", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const architecture = await storage.updateArchitecture(projectId, {
        ...req.body,
        updatedAt: new Date().toISOString()
      });
      res.json(architecture);
    } catch (error) {
      res.status(400).json({ message: "Failed to update architecture" });
    }
  });

  const server = createServer(app);
  return server;
}
