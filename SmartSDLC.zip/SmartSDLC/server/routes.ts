import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, createProjectSchema, chatMessageSchema, approveProjectSchema } from "@shared/schema";
import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // In production, you'd set up proper session management
      res.json({
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          roles: user.roles,
          currentRole: user.currentRole
        }
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.post("/api/auth/logout", async (req, res) => {
    // In production, you'd clear the session
    res.json({ message: "Logged out successfully" });
  });

  app.get("/api/auth/user", async (req, res) => {
    // In production, you'd get this from session/JWT
    const user = await storage.getUser(1); // Mock user ID
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    res.json({
      id: user.id,
      username: user.username,
      name: user.name,
      roles: user.roles,
      currentRole: user.currentRole
    });
  });

  // User routes
  app.put("/api/users/:id/role", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { role } = req.body;
      
      const user = await storage.updateUserRole(userId, role);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          roles: user.roles,
          currentRole: user.currentRole
        }
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Project creation route
  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = createProjectSchema.parse(req.body);
      
      const project = await storage.createProject({
        ...projectData,
        status: "Planning", // Default status for new projects
        ownerId: 1, // In production, get from authenticated user
        approvalStatus: "pending",
        approvedById: null,
        approvedAt: null,
        createdAt: new Date().toISOString()
      });

      res.json(project);
    } catch (error) {
      res.status(400).json({ message: "Invalid project data" });
    }
  });

  // Use case creation route
  app.post("/api/use-cases", async (req, res) => {
    try {
      const useCaseData = req.body;
      
      const useCase = await storage.createUseCase(useCaseData);
      res.json(useCase);
    } catch (error) {
      res.status(400).json({ message: "Invalid use case data" });
    }
  });

  // Project routes
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      
      // Get use case counts for each project
      const projectsWithUseCases = await Promise.all(
        projects.map(async (project) => {
          const useCases = await storage.getUseCasesByProject(project.id);
          const functionalCount = useCases.filter(uc => uc.type === 'functional').length;
          const nonFunctionalCount = useCases.filter(uc => uc.type === 'non-functional').length;
          
          return {
            ...project,
            functionalUseCases: functionalCount,
            nonFunctionalUseCases: nonFunctionalCount
          };
        })
      );

      res.json(projectsWithUseCases);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json(project);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Use case routes
  app.get("/api/projects/:id/use-cases", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const useCases = await storage.getUseCasesByProject(projectId);
      
      res.json(useCases);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.get("/api/use-cases/:id", async (req, res) => {
    try {
      const useCaseId = parseInt(req.params.id);
      const useCase = await storage.getUseCase(useCaseId);
      
      if (!useCase) {
        return res.status(404).json({ message: "Use case not found" });
      }

      res.json(useCase);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.put("/api/use-cases/:id", async (req, res) => {
    try {
      const useCaseId = parseInt(req.params.id);
      const updateData = req.body;
      
      const updatedUseCase = await storage.updateUseCase(useCaseId, updateData);
      
      if (!updatedUseCase) {
        return res.status(404).json({ message: "Use case not found" });
      }

      res.json(updatedUseCase);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.delete("/api/use-cases/:id", async (req, res) => {
    try {
      const useCaseId = parseInt(req.params.id);
      const deleted = await storage.deleteUseCase(useCaseId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Use case not found" });
      }

      res.json({ message: "Use case deleted successfully" });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.post("/api/use-cases/:id/submit", async (req, res) => {
    try {
      const useCaseId = parseInt(req.params.id);
      const updatedUseCase = await storage.updateUseCase(useCaseId, { 
        status: "in-review" 
      });
      
      if (!updatedUseCase) {
        return res.status(404).json({ message: "Use case not found" });
      }

      res.json(updatedUseCase);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const deleted = await storage.deleteProject(projectId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json({ message: "Project deleted successfully" });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Initialize AWS Bedrock client
  const bedrockClient = new BedrockRuntimeClient({
    region: process.env.AWS_REGION || "us-east-1",
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
    },
  });

  // AWS Bedrock AI integration routes
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, projectId, currentRole } = chatMessageSchema.parse(req.body);
      
      // Check if this is a project creation request
      const isProjectCreationRequest = message.toLowerCase().includes('create') && 
        (message.toLowerCase().includes('project') || message.toLowerCase().includes('application') || 
         message.toLowerCase().includes('system') || message.toLowerCase().includes('platform'));
      
      if (isProjectCreationRequest && currentRole === 'business-analyst') {
        // Enhanced system prompt for comprehensive project creation with detailed requirements
        const systemPrompt = `You are an expert enterprise software architect and business analyst specializing in comprehensive requirements engineering for investment banking and financial services. Your task is to create detailed, professional-grade functional and non-functional requirements that would meet enterprise banking standards.

When analyzing a project request, you must:
1. Generate a precise project name and comprehensive description (4-5 sentences with regulatory context)
2. Create 5-7 detailed functional use cases with comprehensive descriptions (300-500 words each)
3. Create 4-6 detailed non-functional requirements covering performance, security, scalability, compliance, and usability (300-500 words each)
4. Each use case must include specific actors, detailed workflows, acceptance criteria, business value, and regulatory compliance
5. Non-functional requirements must include specific metrics, industry standards (Basel III, MiFID II, EMIR), and measurable compliance criteria

Format requirements using enterprise banking terminology and include specific technical details, regulatory compliance requirements (GDPR, PCI DSS, SOX), integration points with core banking systems, and measurable acceptance criteria with quantified performance targets.`;

        const userPrompt = `Create a comprehensive enterprise-grade investment banking project specification for: "${message}"

Requirements Structure:
- Project Name: [Clear, professional banking/fintech name]
- Project Description: [4-5 sentences with business scope, regulatory purpose, stakeholder value, and compliance context]
- Functional Use Cases: [5-7 detailed use cases with comprehensive descriptions including:
  * Primary and secondary actors (traders, compliance officers, risk managers, clients)
  * Detailed pre-conditions and business context
  * Step-by-step main workflow with decision points
  * Alternative flows and exception handling
  * Post-conditions and business outcomes
  * Acceptance criteria with measurable success metrics
  * Regulatory compliance requirements
  * Integration touchpoints with existing systems]
- Non-Functional Requirements: [4-6 detailed requirements covering:
  * Performance: Response times, throughput, concurrent users with specific SLA metrics
  * Security: Authentication, authorization, data encryption, audit trails with compliance standards
  * Scalability: User load capacity, data volume growth, geographic distribution requirements
  * Compliance: Regulatory adherence (Basel III, MiFID II, EMIR, GDPR), audit requirements, reporting standards
  * Availability: Uptime requirements, disaster recovery, business continuity with RPO/RTO targets
  * Usability: User experience standards, accessibility compliance, training requirements]
- Technical Recommendations: [Enterprise architecture patterns, technology stack, integration frameworks, security controls]

Each functional use case should be 300-500 words with comprehensive business context, detailed workflows, and regulatory considerations.
Each non-functional requirement should be 300-500 words with specific quantified metrics, industry compliance standards, and measurable acceptance criteria.`;

        const payload = {
          modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
          contentType: "application/json",
          accept: "application/json",
          body: JSON.stringify({
            anthropic_version: "bedrock-2023-05-31",
            max_tokens: 8000,
            system: systemPrompt,
            messages: [
              {
                role: "user",
                content: userPrompt
              }
            ]
          })
        };

        const command = new InvokeModelCommand({
          modelId: payload.modelId,
          contentType: payload.contentType,
          accept: payload.accept,
          body: payload.body
        });

        const response = await bedrockClient.send(command);
        const responseBody = JSON.parse(new TextDecoder().decode(response.body));
        const aiResponse = responseBody.content[0].text;

        // Extract project details and create actual project
        const projectName = extractProjectName(aiResponse) || "AI Generated Project";
        const projectDescription = extractProjectDescription(aiResponse) || message;
        
        // Create the project
        const newProject = await storage.createProject({
          name: projectName,
          description: projectDescription,
          status: "planning",
          type: "web-application",
          startDate: new Date().toISOString().split('T')[0],
          teamSize: 5,
          ownerId: 1, // Using mock user ID
          approvalStatus: "pending",
          createdAt: new Date().toISOString()
        });

        // Extract and create use cases
        const functionalUseCases = extractUseCasesFromResponse(aiResponse, 'functional');
        const nonFunctionalUseCases = extractUseCasesFromResponse(aiResponse, 'non-functional');
        
        // Create functional use cases
        for (let i = 0; i < functionalUseCases.length; i++) {
          await storage.createUseCase({
            projectId: newProject.id,
            ucId: `UC-F-${String(i + 1).padStart(3, '0')}`,
            title: functionalUseCases[i].title,
            description: functionalUseCases[i].description,
            type: 'functional',
            priority: functionalUseCases[i].priority || 'medium',
            status: 'draft',
            updatedAt: new Date().toISOString()
          });
        }

        // Create non-functional use cases
        for (let i = 0; i < nonFunctionalUseCases.length; i++) {
          await storage.createUseCase({
            projectId: newProject.id,
            ucId: `UC-NF-${String(i + 1).padStart(3, '0')}`,
            title: nonFunctionalUseCases[i].title,
            description: nonFunctionalUseCases[i].description,
            type: 'non-functional',
            priority: nonFunctionalUseCases[i].priority || 'medium',
            status: 'draft',
            updatedAt: new Date().toISOString()
          });
        }

        const enhancedResponse = `${aiResponse}\n\n✅ Project created successfully! The project "${projectName}" has been added to your dashboard with ${functionalUseCases.length} functional and ${nonFunctionalUseCases.length} non-functional use cases.`;

        res.json({
          response: enhancedResponse,
          suggestions: ["View project details", "Add more use cases", "Start project planning", "Assign team members"],
          projectCreated: true,
          projectId: newProject.id
        });
      } else {
        // Regular chat response
        const systemPrompt = `You are an AI assistant specialized in SDLC management. 
        Current user role: ${currentRole}. 
        Provide expert guidance on project planning, requirements analysis, use case generation, and technical recommendations.
        Be concise, practical, and role-specific in your responses.`;

        const payload = {
          modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
          contentType: "application/json",
          accept: "application/json",
          body: JSON.stringify({
            anthropic_version: "bedrock-2023-05-31",
            max_tokens: 1000,
            system: systemPrompt,
            messages: [
              {
                role: "user",
                content: message
              }
            ]
          })
        };

        const command = new InvokeModelCommand({
          modelId: payload.modelId,
          contentType: payload.contentType,
          accept: payload.accept,
          body: payload.body
        });

        const response = await bedrockClient.send(command);
        const responseBody = JSON.parse(new TextDecoder().decode(response.body));
        const aiResponse = responseBody.content[0].text;
        
        const suggestions = getRoleSpecificSuggestions(currentRole, message);

        res.json({
          response: aiResponse,
          suggestions: suggestions
        });
      }
    } catch (error: any) {
      console.error("Bedrock error:", error);
      res.status(500).json({ 
        message: "AI service temporarily unavailable",
        response: "I'm having trouble connecting to the AI service. Please try again in a moment.",
        suggestions: ["Try again later", "Check system status"]
      });
    }
  });

  app.post("/api/ai/create-project", async (req, res) => {
    try {
      const { description, projectType, currentRole } = req.body;
      
      const systemPrompt = `You are an expert SDLC consultant. Based on the project description, generate:
      1. A comprehensive project plan with realistic timelines
      2. Detailed functional and non-functional use cases
      3. Technical recommendations
      4. Risk assessment
      
      Format your response as a structured JSON object with clear sections.`;

      const userPrompt = `Create a detailed SDLC project plan for: "${description}" 
      Project Type: ${projectType}
      User Role: ${currentRole}
      
      Include functional use cases, non-functional requirements, technology recommendations, and implementation phases.`;

      const payload = {
        modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
        contentType: "application/json", 
        accept: "application/json",
        body: JSON.stringify({
          anthropic_version: "bedrock-2023-05-31",
          max_tokens: 2000,
          system: systemPrompt,
          messages: [
            {
              role: "user",
              content: userPrompt
            }
          ]
        })
      };

      const command = new InvokeModelCommand({
        modelId: payload.modelId,
        contentType: payload.contentType,
        accept: payload.accept,
        body: payload.body
      });

      const response = await bedrockClient.send(command);
      const responseBody = JSON.parse(new TextDecoder().decode(response.body));
      
      const aiResponse = responseBody.content[0].text;
      
      res.json({
        response: aiResponse
      });
    } catch (error: any) {
      console.error("Bedrock project creation error:", error);
      res.status(500).json({ message: "Failed to generate project plan" });
    }
  });

  app.post("/api/ai/analyze-requirements", async (req, res) => {
    try {
      const { requirements } = req.body;
      
      const systemPrompt = `You are a business analyst expert. Analyze the given requirements and provide:
      1. Gap analysis
      2. Missing requirements identification  
      3. Improvement suggestions
      4. Risk assessment`;

      const payload = {
        modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
        contentType: "application/json",
        accept: "application/json", 
        body: JSON.stringify({
          anthropic_version: "bedrock-2023-05-31",
          max_tokens: 1500,
          system: systemPrompt,
          messages: [
            {
              role: "user",
              content: `Analyze these requirements: ${requirements}`
            }
          ]
        })
      };

      const command = new InvokeModelCommand({
        modelId: payload.modelId,
        contentType: payload.contentType,
        accept: payload.accept,
        body: payload.body
      });

      const response = await bedrockClient.send(command);
      const responseBody = JSON.parse(new TextDecoder().decode(response.body));
      
      res.json({
        analysis: responseBody.content[0].text,
        suggestions: [
          "Review functional completeness",
          "Add non-functional requirements", 
          "Define acceptance criteria",
          "Consider edge cases"
        ]
      });
    } catch (error) {
      res.status(500).json({ message: "Analysis service unavailable" });
    }
  });

  // Helper functions for project extraction
  function extractProjectName(response: string): string {
    const lines = response.split('\n');
    for (const line of lines) {
      if (line.toLowerCase().includes('project name') || line.toLowerCase().includes('project:')) {
        const match = line.match(/[:]\s*(.+)/);
        if (match) return match[1].trim().replace(/['"]/g, '');
      }
      if (line.match(/^#\s+(.+)|^\*\*(.+)\*\*/) && !line.toLowerCase().includes('use case')) {
        const match = line.match(/^#\s+(.+)|^\*\*(.+)\*\*/);
        if (match) return (match[1] || match[2]).trim().replace(/['"]/g, '');
      }
    }
    return "AI Generated Project";
  }

  function extractProjectDescription(response: string): string {
    const lines = response.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.toLowerCase().includes('description') || line.toLowerCase().includes('overview')) {
        const match = line.match(/[:]\s*(.+)/);
        if (match) return match[1].trim();
        if (i + 1 < lines.length) return lines[i + 1].trim();
      }
    }
    return response.split('\n')[0].substring(0, 200) + "...";
  }

  function extractUseCasesFromResponse(response: string, type: 'functional' | 'non-functional') {
    const useCases = [];
    const lines = response.split('\n');
    let inSection = false;
    let currentUseCase = { title: '', description: '', priority: 'medium' };
    let collectingDescription = false;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const lowerLine = line.toLowerCase();
      
      // Detect section start
      if (type === 'functional' && (lowerLine.includes('functional') && (lowerLine.includes('use case') || lowerLine.includes('requirement')))) {
        inSection = true;
        continue;
      }
      if (type === 'non-functional' && (lowerLine.includes('non-functional') || lowerLine.includes('nonfunctional'))) {
        inSection = true;
        continue;
      }
      
      // Stop at next major section
      if (inSection && (lowerLine.includes('recommendation') || lowerLine.includes('technical') || 
          (lowerLine.includes('functional') && type === 'non-functional') ||
          (lowerLine.includes('non-functional') && type === 'functional'))) {
        // Save current use case if exists
        if (currentUseCase.title && currentUseCase.description.length > 50) {
          useCases.push({ ...currentUseCase });
        }
        break;
      }
      
      if (inSection) {
        // Detect use case titles (numbered, bulleted, or titled lines)
        if (line.match(/^\s*(\d+\.|\*|-|UC-|Use Case|Requirement)/i) || 
            (line.includes(':') && !line.includes('Description:') && line.length < 100)) {
          
          // Save previous use case
          if (currentUseCase.title && currentUseCase.description.length > 50) {
            useCases.push({ ...currentUseCase });
          }
          
          // Start new use case
          const title = line.replace(/^\s*(\d+\.|\*|-|UC-\w*:?)\s*/i, '').split(':')[0].trim();
          currentUseCase = {
            title: title.substring(0, 80),
            description: line.replace(/^\s*(\d+\.|\*|-|UC-\w*:?)\s*/i, '').trim(),
            priority: lowerLine.includes('high') ? 'high' : lowerLine.includes('low') ? 'low' : 'medium'
          };
          collectingDescription = true;
          
        } else if (collectingDescription && line.trim().length > 0 && 
                   !line.match(/^\s*(\d+\.|\*|-|UC-)/i)) {
          // Continue collecting description
          currentUseCase.description += ' ' + line.trim();
          
          // Limit description length while keeping it comprehensive
          if (currentUseCase.description.length > 800) {
            currentUseCase.description = currentUseCase.description.substring(0, 800) + '...';
            collectingDescription = false;
          }
        }
      }
    }
    
    // Save final use case
    if (currentUseCase.title && currentUseCase.description.length > 50) {
      useCases.push({ ...currentUseCase });
    }
    
    // Clean up descriptions
    useCases.forEach(uc => {
      uc.description = uc.description
        .replace(/\s+/g, ' ')
        .trim();
    });
    
    return useCases.slice(0, type === 'functional' ? 6 : 5);
  }

  function getRoleSpecificSuggestions(role: string, message: string): string[] {
    const baseSuggestions = {
      "business-analyst": [
        "Generate use case document",
        "Analyze stakeholder requirements", 
        "Create requirement traceability matrix",
        "Validate business rules"
      ],
      "product-owner": [
        "Prioritize product backlog",
        "Define user acceptance criteria",
        "Plan sprint objectives",
        "Review feature specifications"
      ],
      "architect": [
        "Design system architecture",
        "Review technology stack",
        "Create technical specifications", 
        "Assess scalability requirements"
      ],
      "developer": [
        "Generate code templates",
        "Review implementation patterns",
        "Optimize code structure",
        "Debug technical issues"
      ]
    };
    
    return baseSuggestions[role as keyof typeof baseSuggestions] || [
      "Ask for help",
      "Get recommendations", 
      "Analyze requirements",
      "Generate documentation"
    ];
  }



  const httpServer = createServer(app);
  return httpServer;
}
