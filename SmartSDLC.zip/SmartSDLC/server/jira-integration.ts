// Mock Jira API Integration for Demo Purposes
import { Deliverable, UserStory } from "@shared/schema";

export interface JiraProject {
  key: string;
  name: string;
  projectTypeKey: string;
  lead: string;
}

export interface JiraEpic {
  key: string;
  summary: string;
  description: string;
  status: string;
  assignee?: string;
}

export interface JiraIssue {
  key: string;
  summary: string;
  description: string;
  issueType: string;
  status: string;
  storyPoints?: number;
  assignee?: string;
  epicLink?: string;
}

export class MockJiraAPI {
  private static instance: MockJiraAPI;
  private projects: Map<string, JiraProject> = new Map();
  private epics: Map<string, JiraEpic> = new Map();
  private issues: Map<string, JiraIssue> = new Map();
  private keyCounter = 1;

  static getInstance(): MockJiraAPI {
    if (!MockJiraAPI.instance) {
      MockJiraAPI.instance = new MockJiraAPI();
    }
    return MockJiraAPI.instance;
  }

  // Mock API delay simulation
  private async simulateAPIDelay(): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, 100 + Math.random() * 200));
  }

  async createProject(projectName: string): Promise<JiraProject> {
    await this.simulateAPIDelay();
    
    const projectKey = `SDLC${this.keyCounter++}`;
    const project: JiraProject = {
      key: projectKey,
      name: projectName,
      projectTypeKey: "software",
      lead: "scrum.master"
    };
    
    this.projects.set(projectKey, project);
    console.log(`🎯 Created Jira Project: ${projectKey} - ${projectName}`);
    return project;
  }

  async createEpic(projectKey: string, epicName: string, description: string): Promise<JiraEpic> {
    await this.simulateAPIDelay();
    
    const epicKey = `${projectKey}-${this.keyCounter++}`;
    const epic: JiraEpic = {
      key: epicKey,
      summary: epicName,
      description: description,
      status: "To Do",
      assignee: undefined
    };
    
    this.epics.set(epicKey, epic);
    console.log(`📋 Created Jira Epic: ${epicKey} - ${epicName}`);
    return epic;
  }

  async createUserStory(projectKey: string, epicKey: string, story: {
    title: string;
    description: string;
    acceptanceCriteria: string;
    storyPoints?: number;
  }): Promise<JiraIssue> {
    await this.simulateAPIDelay();
    
    const issueKey = `${projectKey}-${this.keyCounter++}`;
    const issue: JiraIssue = {
      key: issueKey,
      summary: story.title,
      description: `${story.description}\n\nAcceptance Criteria:\n${story.acceptanceCriteria}`,
      issueType: "Story",
      status: "Backlog",
      storyPoints: story.storyPoints,
      epicLink: epicKey
    };
    
    this.issues.set(issueKey, issue);
    console.log(`📝 Created User Story: ${issueKey} - ${story.title}`);
    return issue;
  }

  async assignEpic(epicKey: string, assignee: string): Promise<JiraEpic | null> {
    await this.simulateAPIDelay();
    
    const epic = this.epics.get(epicKey);
    if (!epic) return null;
    
    epic.assignee = assignee;
    epic.status = "In Progress";
    this.epics.set(epicKey, epic);
    
    console.log(`👤 Assigned Epic ${epicKey} to ${assignee}`);
    return epic;
  }

  async getProjectSummary(projectKey: string): Promise<{
    project: JiraProject | undefined;
    epics: JiraEpic[];
    stories: JiraIssue[];
  }> {
    await this.simulateAPIDelay();
    
    const project = this.projects.get(projectKey);
    const epics = Array.from(this.epics.values()).filter(epic => epic.key.startsWith(projectKey));
    const stories = Array.from(this.issues.values()).filter(issue => issue.key.startsWith(projectKey));
    
    return { project, epics, stories };
  }

  // Demo method to show all created Jira items
  getAllItems() {
    return {
      projects: Array.from(this.projects.values()),
      epics: Array.from(this.epics.values()),
      issues: Array.from(this.issues.values())
    };
  }
}

// Service for converting Use Cases to User Stories with Jira integration
export class DeliverableService {
  private jiraAPI = MockJiraAPI.getInstance();

  async createDeliverablesFromApproval(
    projectId: number,
    projectName: string,
    useCases: any[]
  ): Promise<{
    deliverables: Deliverable[];
    jiraProjectKey: string;
    userStories: UserStory[];
  }> {
    console.log(`🚀 Creating deliverables for approved project: ${projectName}`);
    
    // Create Jira project
    const jiraProject = await this.jiraAPI.createProject(`${projectName} - Development`);
    
    // Group use cases by type to create logical deliverables
    const functionalUseCases = useCases.filter(uc => uc.type === 'functional');
    const nonFunctionalUseCases = useCases.filter(uc => uc.type === 'non-functional');
    
    const deliverables: Deliverable[] = [];
    const userStories: UserStory[] = [];
    
    // Create Frontend Deliverable
    if (functionalUseCases.length > 0) {
      const frontendDeliverable: Deliverable = {
        id: 0, // Will be set by storage
        projectId,
        name: "Frontend Development",
        description: "User interface and user experience implementation covering all functional requirements",
        status: "planning",
        assignedTo: null,
        assignedBy: null,
        jiraProjectKey: jiraProject.key,
        jiraEpicKey: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const frontendEpic = await this.jiraAPI.createEpic(
        jiraProject.key,
        "Frontend Development Epic",
        "Complete user interface implementation for all functional requirements"
      );
      
      frontendDeliverable.jiraEpicKey = frontendEpic.key;
      deliverables.push(frontendDeliverable);
      
      // Create user stories for functional requirements
      for (const useCase of functionalUseCases.slice(0, 6)) {
        const story = await this.jiraAPI.createUserStory(
          jiraProject.key,
          frontendEpic.key,
          {
            title: `Implement ${useCase.title}`,
            description: useCase.description,
            acceptanceCriteria: this.generateAcceptanceCriteria(useCase),
            storyPoints: this.calculateStoryPoints(useCase)
          }
        );
        
        userStories.push({
          id: 0, // Will be set by storage
          deliverableId: 0, // Will be updated after deliverable creation
          useCaseId: useCase.id,
          title: story.summary,
          description: story.description,
          acceptanceCriteria: this.generateAcceptanceCriteria(useCase),
          storyPoints: story.storyPoints || null,
          priority: useCase.priority,
          status: "backlog",
          jiraIssueKey: story.key,
          assignedTo: null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }
    }
    
    // Create Backend API Deliverable
    if (functionalUseCases.length > 3) {
      const backendDeliverable: Deliverable = {
        id: 0,
        projectId,
        name: "Backend API Development",
        description: "REST API implementation, database design, and business logic for all system functionality",
        status: "planning",
        assignedTo: null,
        assignedBy: null,
        jiraProjectKey: jiraProject.key,
        jiraEpicKey: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const backendEpic = await this.jiraAPI.createEpic(
        jiraProject.key,
        "Backend API Development Epic",
        "Complete REST API and database implementation"
      );
      
      backendDeliverable.jiraEpicKey = backendEpic.key;
      deliverables.push(backendDeliverable);
      
      // Create API user stories
      for (const useCase of functionalUseCases.slice(3)) {
        const story = await this.jiraAPI.createUserStory(
          jiraProject.key,
          backendEpic.key,
          {
            title: `API for ${useCase.title}`,
            description: `Implement REST API endpoints for: ${useCase.description}`,
            acceptanceCriteria: this.generateAPIAcceptanceCriteria(useCase),
            storyPoints: this.calculateStoryPoints(useCase) + 1
          }
        );
        
        userStories.push({
          id: 0,
          deliverableId: 0,
          useCaseId: useCase.id,
          title: story.summary,
          description: story.description,
          acceptanceCriteria: this.generateAPIAcceptanceCriteria(useCase),
          storyPoints: story.storyPoints || null,
          priority: useCase.priority,
          status: "backlog",
          jiraIssueKey: story.key,
          assignedTo: null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }
    }
    
    // Create Infrastructure Deliverable for non-functional requirements
    if (nonFunctionalUseCases.length > 0) {
      const infrastructureDeliverable: Deliverable = {
        id: 0,
        projectId,
        name: "Infrastructure & Security",
        description: "System architecture, security implementation, performance optimization, and deployment automation",
        status: "planning",
        assignedTo: null,
        assignedBy: null,
        jiraProjectKey: jiraProject.key,
        jiraEpicKey: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const infraEpic = await this.jiraAPI.createEpic(
        jiraProject.key,
        "Infrastructure & Security Epic",
        "Complete system architecture and security implementation"
      );
      
      infrastructureDeliverable.jiraEpicKey = infraEpic.key;
      deliverables.push(infrastructureDeliverable);
      
      // Create infrastructure user stories
      for (const useCase of nonFunctionalUseCases.slice(0, 4)) {
        const story = await this.jiraAPI.createUserStory(
          jiraProject.key,
          infraEpic.key,
          {
            title: `Implement ${useCase.title}`,
            description: useCase.description,
            acceptanceCriteria: this.generateInfraAcceptanceCriteria(useCase),
            storyPoints: this.calculateStoryPoints(useCase) + 2
          }
        );
        
        userStories.push({
          id: 0,
          deliverableId: 0,
          useCaseId: useCase.id,
          title: story.summary,
          description: story.description,
          acceptanceCriteria: this.generateInfraAcceptanceCriteria(useCase),
          storyPoints: story.storyPoints || null,
          priority: useCase.priority,
          status: "backlog",
          jiraIssueKey: story.key,
          assignedTo: null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }
    }
    
    console.log(`✅ Created ${deliverables.length} deliverables and ${userStories.length} user stories in Jira project ${jiraProject.key}`);
    
    return {
      deliverables,
      jiraProjectKey: jiraProject.key,
      userStories
    };
  }

  private generateAcceptanceCriteria(useCase: any): string {
    return `Given the system is operational
When a user ${useCase.actor || 'user'} interacts with ${useCase.title}
Then the system should ${useCase.description.substring(0, 100)}...
And all security and performance requirements are met`;
  }

  private generateAPIAcceptanceCriteria(useCase: any): string {
    return `Given the API endpoint is available
When a valid request is made for ${useCase.title}
Then the API should return appropriate data with 200 status
And response time should be under 100ms
And proper error handling for invalid inputs`;
  }

  private generateInfraAcceptanceCriteria(useCase: any): string {
    return `Given the infrastructure requirement for ${useCase.title}
When the system is under load
Then ${useCase.description.substring(0, 100)}...
And monitoring and alerting are properly configured
And security compliance is maintained`;
  }

  private calculateStoryPoints(useCase: any): number {
    const complexity = useCase.description.length;
    if (complexity > 500) return 8;
    if (complexity > 300) return 5;
    if (complexity > 150) return 3;
    return 2;
  }

  async assignDeliverableToRole(deliverableId: number, jiraEpicKey: string, assignedTo: string): Promise<void> {
    console.log(`👤 Assigning deliverable ${deliverableId} (Epic: ${jiraEpicKey}) to ${assignedTo}`);
    
    // Update Jira epic assignment
    await this.jiraAPI.assignEpic(jiraEpicKey, assignedTo);
    
    console.log(`✅ Successfully assigned Epic ${jiraEpicKey} to ${assignedTo} in Jira`);
  }

  getJiraAPI(): MockJiraAPI {
    return this.jiraAPI;
  }
}