import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  roles: text("roles").array().notNull(), // ['business-analyst', 'product-owner', 'scrum-master', 'architect', 'ui-designer', 'developer', 'production-management', 'devops', 'approver']
  currentRole: text("current_role").notNull(),
  sealApplications: text("seal_applications").array(), // SEAL application access
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull(), // 'Active', 'Planning', 'Development', 'On Hold', 'Completed'
  type: text("type").notNull(), // 'Web Application', 'Mobile App', 'API Development', 'Data Analytics'
  startDate: text("start_date").notNull(),
  teamSize: integer("team_size").notNull(),
  ownerId: integer("owner_id").references(() => users.id),
  approvalStatus: text("approval_status").notNull().default("pending"), // 'pending', 'approved', 'rejected'
  approvedById: integer("approved_by_id").references(() => users.id),
  approvedAt: text("approved_at"),
  createdAt: text("created_at").notNull(),
  sealApplicationId: text("seal_application_id"), // Associated SEAL application
  sealApplicationName: text("seal_application_name"), // SEAL application display name
  assignedArchitectId: integer("assigned_architect_id").references(() => users.id), // Assigned architect
  assignedAt: text("assigned_at"), // When assigned to architect
  boardType: text("board_type"), // 'kanban', 'scrum'
  managedByScrumMasterId: integer("managed_by_scrum_master_id").references(() => users.id),
});

export const useCases = pgTable("use_cases", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  ucId: text("uc_id").notNull(), // UC-001, NF-001, etc.
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // 'functional', 'non-functional'
  priority: text("priority").notNull(), // 'High', 'Medium', 'Low', 'Critical'
  status: text("status").notNull(), // 'Approved', 'In Review', 'Draft'
  actor: text("actor"), // 'Customer', 'Admin', etc.
  category: text("category"), // For non-functional: 'Performance', 'Security', 'Scalability'
  updatedAt: text("updated_at").notNull(),
});

export const deliverables = pgTable("deliverables", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull(), // planning, in_progress, completed
  assignedTo: text("assigned_to"), // architect, ui-designer, developer
  assignedBy: integer("assigned_by").references(() => users.id), // scrum master user id
  jiraProjectKey: text("jira_project_key"),
  jiraEpicKey: text("jira_epic_key"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const userStories = pgTable("user_stories", {
  id: serial("id").primaryKey(),
  deliverableId: integer("deliverable_id").references(() => deliverables.id).notNull(),
  useCaseId: integer("use_case_id").references(() => useCases.id).notNull(),
  backlogItemId: integer("backlog_item_id").references(() => productBacklog.id), // Links to parent backlog item
  title: text("title").notNull(),
  description: text("description").notNull(),
  acceptanceCriteria: text("acceptance_criteria").notNull(),
  storyPoints: integer("story_points"),
  priority: text("priority").notNull(),
  status: text("status").notNull(), // backlog, in_progress, completed
  jiraIssueKey: text("jira_issue_key"),
  assignedTo: text("assigned_to"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});

// Product Backlog Items - High-level features or epics
export const productBacklog = pgTable("product_backlog", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  epic: text("epic").notNull(), // High-level feature description
  priority: text("priority").notNull(), // High, Medium, Low, Critical
  totalStoryPoints: integer("total_story_points"), // Sum of all child user stories
  status: text("status").notNull().default("backlog"), // backlog, in_progress, done, blocked
  assignedTeam: text("assigned_team"), // frontend, backend, fullstack, devops
  sprint: text("sprint"), // Sprint 1, Sprint 2, etc.
  tags: text("tags").array(), // Feature labels: authentication, payments, reporting, etc.
  businessValue: text("business_value"), // High, Medium, Low
  risk: text("risk"), // High, Medium, Low
  dependencies: text("dependencies"), // Other backlog item IDs or external dependencies
  complexity: text("complexity"), // Simple, Medium, Complex - helps determine story breakdown
  userTypes: text("user_types").array(), // ['trader', 'admin', 'auditor'] - helps group related stories
  functionalArea: text("functional_area"), // 'authentication', 'reporting', 'trading', 'compliance'
  createdById: integer("created_by_id").references(() => users.id).notNull(),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
  kanbanColumn: text("kanban_column").default("To Do"), // To Do, In Progress, In Review, Done
  scrumStatus: text("scrum_status").default("Product Backlog"), // Product Backlog, Sprint Backlog, In Progress, Done
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
}).extend({
  sealApplications: z.array(z.string()).optional(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
});

export const insertUseCaseSchema = createInsertSchema(useCases).omit({
  id: true,
});

export const insertDeliverableSchema = createInsertSchema(deliverables).omit({
  id: true,
});

export const insertUserStorySchema = createInsertSchema(userStories).omit({
  id: true,
});

export const insertProductBacklogSchema = createInsertSchema(productBacklog).omit({
  id: true,
});

// Architecture table for storing project architecture documentation
export const architecture = pgTable("architecture", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  overview: text("overview"),
  systemArchitecture: text("system_architecture"),
  contextDiagram: text("context_diagram"),
  containerDiagram: text("container_diagram"),
  deploymentDiagram: text("deployment_diagram"),
  technologyStack: jsonb("technology_stack"),
  wellArchitectedScores: jsonb("well_architected_scores"),
  deploymentStrategy: text("deployment_strategy"),
  observabilityPlan: text("observability_plan"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertArchitectureSchema = createInsertSchema(architecture).omit({
  id: true,
});

// Additional schemas
export const createProjectSchema = z.object({
  name: z.string().min(1),
  description: z.string().min(1),
  type: z.string().min(1),
  teamSize: z.number().min(1),
  startDate: z.string(),
});

export const chatMessageSchema = z.object({
  message: z.string().min(1),
  projectId: z.number().optional(),
  currentRole: z.string(),
});

export const approveProjectSchema = z.object({
  projectId: z.number(),
  status: z.enum(["approved", "rejected"]),
  comments: z.string().optional(),
});

export const assignDeliverableSchema = z.object({
  deliverableId: z.number(),
  assignedTo: z.enum(["architect", "ui-designer", "developer"]),
  comments: z.string().optional(),
});

export const assignArchitectSchema = z.object({
  projectId: z.number(),
  architectId: z.number(),
});

export const manageBoardSchema = z.object({
  projectId: z.number(),
  boardType: z.enum(["kanban", "scrum"]),
});

export const createBacklogItemSchema = z.object({
  projectId: z.number(),
  title: z.string().min(1),
  description: z.string().min(1),
  userStory: z.string().min(1),
  acceptanceCriteria: z.string().min(1),
  priority: z.enum(["Critical", "High", "Medium", "Low"]),
  storyPoints: z.number().optional(),
  tags: z.array(z.string()).optional(),
  businessValue: z.enum(["High", "Medium", "Low"]).optional(),
  risk: z.enum(["High", "Medium", "Low"]).optional(),
});

// Login schema
export const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertUseCase = z.infer<typeof insertUseCaseSchema>;
export type UseCase = typeof useCases.$inferSelect;
export type InsertDeliverable = z.infer<typeof insertDeliverableSchema>;
export type Deliverable = typeof deliverables.$inferSelect;
export type InsertUserStory = z.infer<typeof insertUserStorySchema>;
export type UserStory = typeof userStories.$inferSelect;


export type InsertProductBacklogItem = z.infer<typeof insertProductBacklogSchema>;
export type ProductBacklogItem = typeof productBacklog.$inferSelect;

export type Architecture = typeof architecture.$inferSelect;
export type InsertArchitecture = typeof architecture.$inferInsert;

export type LoginRequest = z.infer<typeof loginSchema>;
export type CreateProjectRequest = z.infer<typeof createProjectSchema>;
export type ChatMessage = z.infer<typeof chatMessageSchema>;
export type ApproveProjectRequest = z.infer<typeof approveProjectSchema>;
export type AssignDeliverableRequest = z.infer<typeof assignDeliverableSchema>;
export type AssignArchitectRequest = z.infer<typeof assignArchitectSchema>;
export type ManageBoardRequest = z.infer<typeof manageBoardSchema>;
export type CreateBacklogItemRequest = z.infer<typeof createBacklogItemSchema>;
