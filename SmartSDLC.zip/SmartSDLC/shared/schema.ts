import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  roles: text("roles").array().notNull(), // ['business-analyst', 'product-owner', 'scrum-master', 'architect', 'ui-designer', 'developer', 'production-management', 'devops', 'approver']
  currentRole: text("current_role").notNull(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull(), // 'Active', 'Planning', 'Development', 'On Hold', 'Completed'
  type: text("type").notNull(), // 'Web Application', 'Mobile App', 'API Development', 'Data Analytics'
  startDate: text("start_date").notNull(),
  teamSize: integer("team_size").notNull(),
  ownerId: integer("owner_id").references(() => users.id),
  approvalStatus: text("approval_status").notNull().default("pending"), // 'pending', 'approved', 'rejected'
  approvedById: integer("approved_by_id").references(() => users.id),
  approvedAt: text("approved_at"),
  createdAt: text("created_at").notNull(),
});

export const useCases = pgTable("use_cases", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  ucId: text("uc_id").notNull(), // UC-001, NF-001, etc.
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // 'functional', 'non-functional'
  priority: text("priority").notNull(), // 'High', 'Medium', 'Low', 'Critical'
  status: text("status").notNull(), // 'Approved', 'In Review', 'Draft'
  actor: text("actor"), // 'Customer', 'Admin', etc.
  category: text("category"), // For non-functional: 'Performance', 'Security', 'Scalability'
  updatedAt: text("updated_at").notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
});

export const insertUseCaseSchema = createInsertSchema(useCases).omit({
  id: true,
});

// Additional schemas
export const createProjectSchema = z.object({
  name: z.string().min(1),
  description: z.string().min(1),
  type: z.string().min(1),
  teamSize: z.number().min(1),
  startDate: z.string(),
});

export const chatMessageSchema = z.object({
  message: z.string().min(1),
  projectId: z.number().optional(),
  currentRole: z.string(),
});

export const approveProjectSchema = z.object({
  projectId: z.number(),
  status: z.enum(["approved", "rejected"]),
  comments: z.string().optional(),
});

// Login schema
export const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertUseCase = z.infer<typeof insertUseCaseSchema>;
export type UseCase = typeof useCases.$inferSelect;
export type LoginRequest = z.infer<typeof loginSchema>;
export type CreateProjectRequest = z.infer<typeof createProjectSchema>;
export type ChatMessage = z.infer<typeof chatMessageSchema>;
export type ApproveProjectRequest = z.infer<typeof approveProjectSchema>;
