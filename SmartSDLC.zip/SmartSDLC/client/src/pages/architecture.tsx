import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { 
  Brain, 
  Save, 
  Send, 
  FileText, 
  Layers, 
  Database, 
  Cloud, 
  Shield, 
  Zap,
  CheckCircle,
  Clock,
  Eye
} from "lucide-react";

interface ArchitectureDocument {
  id: number;
  projectId: number;
  systemOverview: string;
  architecturalPrinciples: string;
  componentDiagram: string;
  dataFlow: string;
  technologyStack: {
    frontend: string[];
    backend: string[];
    database: string[];
    infrastructure: string[];
    security: string[];
  };
  securityArchitecture: string;
  deploymentStrategy: string;
  scalabilityConsiderations: string;
  integrationPoints: string;
  riskAssessment: string;
  status: "draft" | "in_progress" | "review_ready" | "finalized";
  createdById: number;
  assignedArchitectId: number;
  finalizedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export default function Architecture() {
  const { projectId } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [architecture, setArchitecture] = useState<Partial<ArchitectureDocument>>({});

  const { data: project } = useQuery({
    queryKey: ["/api/projects", projectId],
  });

  const { data: useCases = [] } = useQuery({
    queryKey: ["/api/projects", projectId, "use-cases"],
  });

  const { data: architectureDoc, isLoading } = useQuery({
    queryKey: ["/api/projects", projectId, "architecture"],
    queryFn: () => fetch(`/api/projects/${projectId}/architecture`).then(res => {
      if (res.status === 404) return null;
      if (!res.ok) throw new Error('Failed to fetch architecture');
      return res.json();
    }),
  });

  const createArchitectureMutation = useMutation({
    mutationFn: (data: any) => apiRequest(`/api/projects/${projectId}/architecture`, {
      method: "POST",
      body: data
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "architecture"] });
      toast({
        title: "Architecture Created",
        description: "Architecture document has been created successfully",
      });
    },
  });

  const updateArchitectureMutation = useMutation({
    mutationFn: (data: any) => apiRequest(`/api/projects/${projectId}/architecture`, {
      method: "PUT",
      body: data
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "architecture"] });
      toast({
        title: "Architecture Updated",
        description: "Architecture document has been updated successfully",
      });
    },
  });

  const finalizeArchitectureMutation = useMutation({
    mutationFn: () => apiRequest(`/api/projects/${projectId}/architecture/finalize`, {
      method: "POST"
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "architecture"] });
      toast({
        title: "Architecture Finalized",
        description: "Architecture is now visible to Scrum Master and Product Owner",
      });
    },
  });

  const generateArchitectureWithAI = async () => {
    setIsGenerating(true);
    try {
      const response = await apiRequest(`/api/projects/${projectId}/architecture/generate`, {
        method: "POST",
        body: {
          useCases: useCases,
          project: project
        }
      });

      setArchitecture(response);
      toast({
        title: "Architecture Generated",
        description: "AI has generated the architecture. Review and customize as needed.",
      });
    } catch (error) {
      toast({
        title: "Generation Failed",
        description: "Failed to generate architecture with AI",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    const saveData = {
      ...architecture,
      projectId: parseInt(projectId!),
      assignedArchitectId: user?.id,
      status: architectureDoc ? architectureDoc.status : "draft"
    };

    if (architectureDoc) {
      updateArchitectureMutation.mutate(saveData);
    } else {
      createArchitectureMutation.mutate(saveData);
    }
  };

  const handleFinalize = () => {
    finalizeArchitectureMutation.mutate();
  };

  const canEdit = user?.currentRole === "architect" && 
    (!architectureDoc || architectureDoc.status !== "finalized");
  
  const canView = user?.currentRole === "architect" || 
    (architectureDoc?.status === "finalized" && 
     (user?.currentRole === "scrum-master" || user?.currentRole === "product-owner"));

  useEffect(() => {
    if (architectureDoc) {
      setArchitecture(architectureDoc);
    }
  }, [architectureDoc]);

  if (isLoading) {
    return <div className="flex justify-center items-center h-64">Loading architecture...</div>;
  }

  if (!canView) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <Card>
          <CardContent className="p-8 text-center">
            <Shield className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h2 className="text-xl font-semibold mb-2">Architecture Not Available</h2>
            <p className="text-gray-600">
              {user?.currentRole === "architect" 
                ? "No architecture document exists for this project yet."
                : "Architecture document is not finalized yet or you don't have permission to view it."
              }
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { color: "bg-gray-100 text-gray-800", icon: FileText },
      in_progress: { color: "bg-blue-100 text-blue-800", icon: Clock },
      review_ready: { color: "bg-yellow-100 text-yellow-800", icon: Eye },
      finalized: { color: "bg-green-100 text-green-800", icon: CheckCircle },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig];
    const Icon = config?.icon || FileText;
    
    return (
      <Badge className={config?.color || "bg-gray-100 text-gray-800"}>
        <Icon className="h-3 w-3 mr-1" />
        {status.replace('_', ' ').toUpperCase()}
      </Badge>
    );
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            System Architecture
          </h1>
          <p className="text-gray-600">{project?.name}</p>
        </div>
        <div className="flex items-center gap-3">
          {architectureDoc?.status && getStatusBadge(architectureDoc.status)}
          {canEdit && (
            <div className="flex gap-2">
              <Button
                onClick={generateArchitectureWithAI}
                disabled={isGenerating}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Brain className="h-4 w-4" />
                {isGenerating ? "Generating..." : "Generate with AI"}
              </Button>
              <Button
                onClick={handleSave}
                disabled={createArchitectureMutation.isPending || updateArchitectureMutation.isPending}
                className="flex items-center gap-2"
              >
                <Save className="h-4 w-4" />
                Save Draft
              </Button>
              {architectureDoc && architectureDoc.status !== "finalized" && (
                <Button
                  onClick={handleFinalize}
                  disabled={finalizeArchitectureMutation.isPending}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                >
                  <Send className="h-4 w-4" />
                  Finalize
                </Button>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* System Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Layers className="h-5 w-5" />
              System Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Describe the high-level system architecture and key components..."
              value={architecture.systemOverview || ""}
              onChange={(e) => setArchitecture(prev => ({ ...prev, systemOverview: e.target.value }))}
              className="min-h-32"
              disabled={!canEdit}
            />
          </CardContent>
        </Card>

        {/* Architectural Principles */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Architectural Principles
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Define the key architectural principles and design patterns..."
              value={architecture.architecturalPrinciples || ""}
              onChange={(e) => setArchitecture(prev => ({ ...prev, architecturalPrinciples: e.target.value }))}
              className="min-h-32"
              disabled={!canEdit}
            />
          </CardContent>
        </Card>

        {/* Component Diagram */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Layers className="h-5 w-5" />
              Component Diagram & Architecture
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Describe the component diagram, microservices architecture, and system interactions..."
              value={architecture.componentDiagram || ""}
              onChange={(e) => setArchitecture(prev => ({ ...prev, componentDiagram: e.target.value }))}
              className="min-h-48"
              disabled={!canEdit}
            />
          </CardContent>
        </Card>

        {/* Technology Stack */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Technology Stack
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label className="text-sm font-medium">Frontend Technologies</Label>
                <Input
                  placeholder="React, Angular, Vue..."
                  value={architecture.technologyStack?.frontend?.join(", ") || ""}
                  onChange={(e) => setArchitecture(prev => ({
                    ...prev,
                    technologyStack: {
                      ...prev.technologyStack,
                      frontend: e.target.value.split(", ").filter(Boolean)
                    }
                  }))}
                  disabled={!canEdit}
                />
              </div>
              <div>
                <Label className="text-sm font-medium">Backend Technologies</Label>
                <Input
                  placeholder="Node.js, Java, .NET..."
                  value={architecture.technologyStack?.backend?.join(", ") || ""}
                  onChange={(e) => setArchitecture(prev => ({
                    ...prev,
                    technologyStack: {
                      ...prev.technologyStack,
                      backend: e.target.value.split(", ").filter(Boolean)
                    }
                  }))}
                  disabled={!canEdit}
                />
              </div>
              <div>
                <Label className="text-sm font-medium">Database Technologies</Label>
                <Input
                  placeholder="PostgreSQL, MongoDB..."
                  value={architecture.technologyStack?.database?.join(", ") || ""}
                  onChange={(e) => setArchitecture(prev => ({
                    ...prev,
                    technologyStack: {
                      ...prev.technologyStack,
                      database: e.target.value.split(", ").filter(Boolean)
                    }
                  }))}
                  disabled={!canEdit}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Data Flow */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              Data Flow & Integration
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Describe data flow patterns, API integrations, and messaging..."
              value={architecture.dataFlow || ""}
              onChange={(e) => setArchitecture(prev => ({ ...prev, dataFlow: e.target.value }))}
              className="min-h-32"
              disabled={!canEdit}
            />
          </CardContent>
        </Card>

        {/* Security Architecture */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Security Architecture
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Define security controls, authentication, authorization, and compliance measures..."
              value={architecture.securityArchitecture || ""}
              onChange={(e) => setArchitecture(prev => ({ ...prev, securityArchitecture: e.target.value }))}
              className="min-h-32"
              disabled={!canEdit}
            />
          </CardContent>
        </Card>

        {/* Deployment Strategy */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Cloud className="h-5 w-5" />
              Deployment Strategy
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Describe deployment architecture, environments, and CI/CD pipeline..."
              value={architecture.deploymentStrategy || ""}
              onChange={(e) => setArchitecture(prev => ({ ...prev, deploymentStrategy: e.target.value }))}
              className="min-h-32"
              disabled={!canEdit}
            />
          </CardContent>
        </Card>

        {/* Scalability Considerations */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              Scalability & Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Define scalability patterns, performance optimization, and capacity planning..."
              value={architecture.scalabilityConsiderations || ""}
              onChange={(e) => setArchitecture(prev => ({ ...prev, scalabilityConsiderations: e.target.value }))}
              className="min-h-32"
              disabled={!canEdit}
            />
          </CardContent>
        </Card>
      </div>

      {architectureDoc?.finalizedAt && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-green-800">
              <CheckCircle className="h-5 w-5" />
              <span className="font-medium">Architecture Finalized</span>
              <span className="text-sm">
                on {new Date(architectureDoc.finalizedAt).toLocaleDateString()}
              </span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}