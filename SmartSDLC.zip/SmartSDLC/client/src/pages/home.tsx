import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Workflow, Shield, Zap, Users, BarChart3, Bot, Sparkles } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";

export default function Home() {
  const [, setLocation] = useLocation();
  const [isSigningIn, setIsSigningIn] = useState(false);

  const loginMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/auth/sso-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ provider: "jpmc-sso" })
      });
      if (!response.ok) throw new Error("SSO login failed");
      return response.json();
    },
    onSuccess: () => {
      setLocation("/dashboard");
    },
    onError: () => {
      setIsSigningIn(false);
    }
  });

  const handleSSOLogin = () => {
    setIsSigningIn(true);
    loginMutation.mutate();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Smart SDLC</h1>
              <p className="text-sm text-gray-500">AI-Powered Development Lifecycle</p>
            </div>
          </div>
          <Button 
            onClick={handleSSOLogin}
            disabled={isSigningIn}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isSigningIn ? "Signing in..." : "Sign in with SSO"}
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-6 py-16">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-blue-100 text-blue-700 hover:bg-blue-100">
            <Sparkles className="w-4 h-4 mr-1" />
            Next-Generation SDLC Platform
          </Badge>
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Revolutionize Your Software Development with AI
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Smart SDLC transforms enterprise software development with intelligent automation, 
            AI-powered workflows, and role-based collaboration tools designed for financial services.
          </p>
          <div className="mt-8 flex justify-center space-x-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">60%</div>
              <div className="text-sm text-gray-500">Cost Reduction</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">3x</div>
              <div className="text-sm text-gray-500">Faster Delivery</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">7</div>
              <div className="text-sm text-gray-500">AI Agents</div>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Bot className="w-6 h-6 text-blue-600" />
              </div>
              <CardTitle>Multi-Agent AI Architecture</CardTitle>
              <CardDescription>
                7 specialized AI agents for each SDLC role: Business Analyst, Product Owner, 
                Scrum Master, Architect, UI Designer, Developer, and DevOps
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <Workflow className="w-6 h-6 text-green-600" />
              </div>
              <CardTitle>Intelligent Workflows</CardTitle>
              <CardDescription>
                Automated project creation, requirement generation, and approval workflows 
                with cross-role coordination and AI-powered handoffs
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-purple-600" />
              </div>
              <CardTitle>Regulatory Compliance</CardTitle>
              <CardDescription>
                Built-in compliance for Basel III, MiFID II, and EMIR regulations 
                with automated mapping and audit trail generation
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-amber-600" />
              </div>
              <CardTitle>AWS Bedrock Integration</CardTitle>
              <CardDescription>
                Powered by Claude 3 Sonnet with BERT semantic enhancement 
                for intelligent requirement analysis and project recommendations
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-red-600" />
              </div>
              <CardTitle>Role-Based Access</CardTitle>
              <CardDescription>
                Secure access control with role-specific interfaces, permissions, 
                and AI assistant integration for enterprise environments
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-indigo-600" />
              </div>
              <CardTitle>Enterprise Integration</CardTitle>
              <CardDescription>
                Seamless integration with Jira, ServiceNow replacement capabilities, 
                and comprehensive project management dashboards
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Use Cases */}
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Designed for Financial Services Excellence
          </h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Key Capabilities</h4>
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <span className="text-gray-600">AI-powered project requirement generation</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <span className="text-gray-600">Automated EMIR and regulatory reporting templates</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <span className="text-gray-600">Real-time collaboration across SDLC roles</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <span className="text-gray-600">Architecture diagram generation and editing</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <span className="text-gray-600">Sprint planning with AI recommendations</span>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Business Impact</h4>
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                  <span className="text-gray-600">Replace expensive ServiceNow and Atlassian licenses</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                  <span className="text-gray-600">Reduce SDLC operational costs by 60%</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                  <span className="text-gray-600">Accelerate project delivery by 3x</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                  <span className="text-gray-600">Ensure regulatory compliance automation</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                  <span className="text-gray-600">Enterprise-grade security and audit trails</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-gray-50 py-8">
        <div className="container mx-auto px-6 text-center text-gray-600">
          <p>&copy; 2025 Smart SDLC Platform. Revolutionizing enterprise software development.</p>
        </div>
      </footer>
    </div>
  );
}