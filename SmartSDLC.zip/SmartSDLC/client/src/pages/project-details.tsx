import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { PageHeader } from "@/components/page-header";

import { 
  ArrowLeft, 
  Calendar, 
  Users, 
  CheckCircle, 
  AlertCircle, 
  Clock,
  FileText,
  Target,
  Package,
  Layers,
  Settings,
  BarChart3
} from "lucide-react";
import { ProductBacklog } from "@/components/product-backlog";
import { SprintPlanning } from "@/components/sprint-planning";
import { ArchitectureWorkspace } from "@/components/architecture-workspace-simple";
import { DeliverablesModal } from "@/components/deliverables-modal";
import { ArchitectureTab } from "@/components/architecture-tab";

interface UseCase {
  id: number;
  projectId: number;
  ucId: string;
  title: string;
  description: string;
  actor: string;
  priority: "Critical" | "High" | "Medium" | "Low";
  type: "functional" | "non-functional";
  status: string;
  createdAt: string;
  updatedAt: string;
}

interface Project {
  id: number;
  name: string;
  description: string;
  status: string;
  type: string;
  startDate: string;
  teamSize: number;
  approvalStatus: string;
  sealApplicationId?: string;
  sealApplicationName?: string;
  createdAt: string;
}

export default function ProjectDetails() {
  const [match, params] = useRoute("/projects/:id");
  const projectId = params?.id ? parseInt(params.id) : 1;
  
  console.log('Project ID from URL:', projectId, 'Raw params:', params);

  const { data: project, isLoading: projectLoading } = useQuery<Project>({
    queryKey: [`/api/projects/${projectId}`],
  });

  const { data: useCases = [], isLoading: useCasesLoading } = useQuery<UseCase[]>({
    queryKey: [`/api/projects/${projectId}/use-cases`],
  });

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
  });
  
  console.log('Project data:', project);
  console.log('User data:', user);

  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const submitForApprovalMutation = useMutation({
    mutationFn: async (projectId: number) => {
      return apiRequest(`/api/projects/${projectId}/submit-for-approval`, {
        method: 'POST',
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Project submitted for approval successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit project for approval",
        variant: "destructive",
      });
    },
  });

  const handleSubmitForApproval = async () => {
    if (!project) return;
    
    setSubmitting(true);
    try {
      await submitForApprovalMutation.mutateAsync(project.id);
    } finally {
      setSubmitting(false);
    }
  };

  if (projectLoading || useCasesLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="container mx-auto p-6 text-center">
        <h1 className="text-2xl font-bold text-gray-900">Project not found</h1>
      </div>
    );
  }

  const functionalUseCases = useCases?.filter((uc: UseCase) => uc.type === "functional") || [];
  const nonFunctionalUseCases = useCases?.filter((uc: UseCase) => uc.type === "non-functional") || [];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Critical": return "bg-red-100 text-red-800 border-red-200";
      case "High": return "bg-orange-100 text-orange-800 border-orange-200";
      case "Medium": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Low": return "bg-green-100 text-green-800 border-green-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved": return "bg-green-100 text-green-800 border-green-200";
      case "pending": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "rejected": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-blue-100 text-blue-800 border-blue-200";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Page Header */}
      <PageHeader
        title={project.name}
        subtitle={project.description}
        user={user || {
          id: 1,
          name: "User",
          currentRole: "Business Analyst",
          username: "user",
          roles: ["Business Analyst"],
          sealApplications: null
        }}
        breadcrumbs={[
          { label: "Projects", href: "/" },
          { label: project.name }
        ]}
      />



      <div className="container mx-auto p-6 space-y-6">
        {/* Project Actions */}
        <div className="flex gap-4 mb-6">
          <Button variant="outline" onClick={() => window.history.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          

        </div>
        {/* Project Info Cards */}
        <div className="grid gap-6 md:grid-cols-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Calendar className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Start Date</p>
                  <p className="font-semibold">{new Date(project.startDate).toLocaleDateString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Users className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Team Size</p>
                  <p className="font-semibold">{project.teamSize} members</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Target className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Status</p>
                  <Badge className={getStatusColor(project.status)}>
                    {project.status}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-100 rounded-lg">
                  <FileText className="h-5 w-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Type</p>
                  <p className="font-semibold">{project.type}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Card>
          <CardContent className="p-0">
            <Tabs defaultValue="requirements" className="w-full">
              <div className="border-b px-6 pt-6">
                <TabsList className={`grid w-full ${project?.status === 'Draft' || project?.approvalStatus === 'draft' ? 'grid-cols-3' : 'grid-cols-6'}`}>
                  <TabsTrigger value="requirements" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Requirements
                  </TabsTrigger>
                  {/* Only show advanced tabs for approved projects */}
                  {project?.status !== 'Draft' && project?.approvalStatus !== 'draft' && (
                    <>
                      <TabsTrigger value="backlog" className="flex items-center gap-2">
                        <Package className="h-4 w-4" />
                        Product Backlog
                      </TabsTrigger>
                      <TabsTrigger value="sprint" className="flex items-center gap-2">
                        <Target className="h-4 w-4" />
                        Sprint Planning
                      </TabsTrigger>
                      <TabsTrigger value="architecture" className="flex items-center gap-2">
                        <Layers className="h-4 w-4" />
                        Architecture
                      </TabsTrigger>
                      <TabsTrigger value="settings" className="flex items-center gap-2">
                        <Settings className="h-4 w-4" />
                        Settings
                      </TabsTrigger>
                    </>
                  )}
                  <TabsTrigger value="analytics" className="flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    Lifecycle
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="requirements" className="p-6 space-y-6">
                {/* Use Cases Overview */}
                <div className="grid gap-6 md:grid-cols-3">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Target className="h-5 w-5 text-blue-600" />
                        Requirements Summary
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Total Use Cases</span>
                        <Badge variant="outline">{useCases.length}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Functional</span>
                        <Badge className="bg-blue-100 text-blue-800">{functionalUseCases.length}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Non-Functional</span>
                        <Badge className="bg-purple-100 text-purple-800">{nonFunctionalUseCases.length}</Badge>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <AlertCircle className="h-5 w-5 text-orange-600" />
                        Priority Breakdown
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {["Critical", "High", "Medium", "Low"].map((priority) => {
                        const count = useCases.filter((uc: UseCase) => uc.priority === priority).length;
                        return (
                          <div key={priority} className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">{priority}</span>
                            <Badge className={getPriorityColor(priority)}>{count}</Badge>
                          </div>
                        );
                      })}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        Status Overview
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Approval Status</span>
                        <Badge className={getStatusColor(project.approvalStatus)}>
                          {project.approvalStatus}
                        </Badge>
                      </div>
                      {project.sealApplicationId && (
                        <div className="text-sm">
                          <span className="text-gray-600">SEAL Application:</span>
                          <p className="font-medium">{project.sealApplicationName}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Side-by-Side Requirements Table */}
                <Card>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr>
                            <th className="w-1/2 px-6 py-4 text-left bg-blue-50 border-r border-blue-200">
                              <div className="flex items-center gap-2">
                                <Target className="h-5 w-5 text-blue-600" />
                                <span className="font-semibold text-blue-900">Functional Requirements ({functionalUseCases.length})</span>
                              </div>
                            </th>
                            <th className="w-1/2 px-6 py-4 text-left bg-purple-50">
                              <div className="flex items-center gap-2">
                                <Settings className="h-5 w-5 text-purple-600" />
                                <span className="font-semibold text-purple-900">Non-Functional Requirements ({nonFunctionalUseCases.length})</span>
                              </div>
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {Array.from({ length: Math.max(functionalUseCases.length, nonFunctionalUseCases.length) }).map((_, index) => {
                            const functionalReq = functionalUseCases[index];
                            const nonFunctionalReq = nonFunctionalUseCases[index];
                            
                            return (
                              <tr key={index} className={`border-b ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                                <td className="px-6 py-4 border-r border-gray-200 align-top w-1/2">
                                  {functionalReq ? (
                                    <div className="space-y-2">
                                      <div className="flex items-center gap-2 mb-2">
                                        <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200 font-mono">
                                          {functionalReq.ucId}
                                        </Badge>
                                        <Badge variant={
                                          functionalReq.priority === 'Critical' ? 'destructive' :
                                          functionalReq.priority === 'High' ? 'default' : 
                                          'secondary'
                                        } className="text-xs">
                                          {functionalReq.priority}
                                        </Badge>
                                      </div>
                                      <h4 className="font-medium text-gray-900 text-sm">{functionalReq.title}</h4>
                                      <p className="text-xs text-gray-600 leading-relaxed">{functionalReq.description}</p>
                                      <div className="text-xs text-gray-500 flex items-center gap-2">
                                        <span>Actor: {functionalReq.actor}</span>
                                        <span>•</span>
                                        <span>Status: {functionalReq.status}</span>
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="h-20"></div>
                                  )}
                                </td>
                                
                                <td className="px-6 py-4 align-top w-1/2">
                                  {nonFunctionalReq ? (
                                    <div className="space-y-2">
                                      <div className="flex items-center gap-2 mb-2">
                                        <Badge variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200 font-mono">
                                          {nonFunctionalReq.ucId}
                                        </Badge>
                                        <Badge variant={
                                          nonFunctionalReq.priority === 'Critical' ? 'destructive' :
                                          nonFunctionalReq.priority === 'High' ? 'default' : 
                                          'secondary'
                                        } className="text-xs">
                                          {nonFunctionalReq.priority}
                                        </Badge>
                                      </div>
                                      <h4 className="font-medium text-gray-900 text-sm">{nonFunctionalReq.title}</h4>
                                      <p className="text-xs text-gray-600 leading-relaxed">{nonFunctionalReq.description}</p>
                                      <div className="text-xs text-gray-500 flex items-center gap-2">
                                        <span>Actor: {nonFunctionalReq.actor}</span>
                                        <span>•</span>
                                        <span>Status: {nonFunctionalReq.status}</span>
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="h-20"></div>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="backlog" className="p-6">
                <ProductBacklog projectId={projectId} userRole={user?.currentRole || "Business Analyst"} />
              </TabsContent>

              <TabsContent value="sprint" className="p-6">
                <SprintPlanning projectId={projectId} userRole={user?.currentRole || "Business Analyst"} />
              </TabsContent>

              <TabsContent value="architecture" className="p-6">
                <ArchitectureWorkspace projectId={projectId} userRole={user?.currentRole || "Business Analyst"} />
              </TabsContent>

              <TabsContent value="settings" className="p-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Project Settings</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">Project configuration and settings will be available here.</p>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="analytics" className="p-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5 text-blue-600" />
                      Project Lifecycle
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {/* Project Lifecycle Swimlane */}
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <h4 className="text-lg font-semibold">Project Status Timeline</h4>
                        <Badge variant="outline" className="text-sm">
                          Current: {project?.status === 'Draft' ? 'Draft' : project?.approvalStatus === 'pending' ? 'Pending Approval' : project?.approvalStatus === 'approved' ? 'Approved' : 'In Progress'}
                        </Badge>
                      </div>
                      
                      {/* Swimlane View */}
                      <div className="relative">
                        <div className="flex items-center justify-between">
                          {/* Step 1: Created */}
                          <div className="flex flex-col items-center space-y-2">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              project ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-500'
                            }`}>
                              <CheckCircle className="h-4 w-4" />
                            </div>
                            <div className="text-center">
                              <div className="font-medium text-sm">Created</div>
                              <div className="text-xs text-gray-500">Draft Status</div>
                              {project && (
                                <div className="text-xs text-gray-400 mt-1">
                                  {new Date(project.startDate).toLocaleDateString()}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Connection Line */}
                          <div className={`flex-1 h-0.5 mx-4 ${
                            project?.approvalStatus === 'pending' || project?.approvalStatus === 'approved' ? 'bg-green-500' : 'bg-gray-300'
                          }`}></div>

                          {/* Step 2: Submitted */}
                          <div className="flex flex-col items-center space-y-2">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              project?.approvalStatus === 'pending' || project?.approvalStatus === 'approved' ? 'bg-green-500 text-white' : 
                              project?.status === 'Draft' ? 'bg-yellow-500 text-white' : 'bg-gray-300 text-gray-500'
                            }`}>
                              <Clock className="h-4 w-4" />
                            </div>
                            <div className="text-center">
                              <div className="font-medium text-sm">Submitted</div>
                              <div className="text-xs text-gray-500">For Approval</div>
                              {project?.approvalStatus === 'pending' && (
                                <div className="text-xs text-yellow-600 mt-1">Pending Review</div>
                              )}
                            </div>
                          </div>

                          {/* Connection Line */}
                          <div className={`flex-1 h-0.5 mx-4 ${
                            project?.approvalStatus === 'approved' ? 'bg-green-500' : 'bg-gray-300'
                          }`}></div>

                          {/* Step 3: Approved */}
                          <div className="flex flex-col items-center space-y-2">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              project?.approvalStatus === 'approved' ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-500'
                            }`}>
                              <CheckCircle className="h-4 w-4" />
                            </div>
                            <div className="text-center">
                              <div className="font-medium text-sm">Approved</div>
                              <div className="text-xs text-gray-500">Ready for Development</div>
                              {project?.approvedAt && (
                                <div className="text-xs text-gray-400 mt-1">
                                  {new Date(project.approvedAt).toLocaleDateString()}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Connection Line */}
                          <div className={`flex-1 h-0.5 mx-4 ${
                            project?.status === 'in-progress' || project?.status === 'development' ? 'bg-green-500' : 'bg-gray-300'
                          }`}></div>

                          {/* Step 4: In Development */}
                          <div className="flex flex-col items-center space-y-2">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              project?.status === 'in-progress' || project?.status === 'development' ? 'bg-blue-500 text-white' : 'bg-gray-300 text-gray-500'
                            }`}>
                              <Settings className="h-4 w-4" />
                            </div>
                            <div className="text-center">
                              <div className="font-medium text-sm">Development</div>
                              <div className="text-xs text-gray-500">In Progress</div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Current Status Details */}
                      <div className="mt-8 p-4 bg-gray-50 rounded-lg">
                        <h5 className="font-medium mb-2">Current Status Details</h5>
                        <div className="grid gap-3 md:grid-cols-2">
                          <div>
                            <span className="text-sm text-gray-600">Project Status:</span>
                            <span className="ml-2 font-medium">{project?.status || 'Draft'}</span>
                          </div>
                          <div>
                            <span className="text-sm text-gray-600">Approval Status:</span>
                            <span className="ml-2 font-medium capitalize">{project?.approvalStatus || 'draft'}</span>
                          </div>
                          <div>
                            <span className="text-sm text-gray-600">Created Date:</span>
                            <span className="ml-2 font-medium">
                              {project ? new Date(project.startDate).toLocaleDateString() : 'N/A'}
                            </span>
                          </div>
                          <div>
                            <span className="text-sm text-gray-600">Team Size:</span>
                            <span className="ml-2 font-medium">{project?.teamSize || 0} members</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <TabsContent value="architecture" className="space-y-6">
                  {user?.currentRole === "architect" ? (
                    <ArchitectureTab projectId={projectId} />
                  ) : (
                    <Card>
                      <CardHeader>
                        <CardTitle>Architecture Documentation</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600">
                          Architecture documentation is available for architects. Switch to the Architect role to view and edit architecture details.
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}