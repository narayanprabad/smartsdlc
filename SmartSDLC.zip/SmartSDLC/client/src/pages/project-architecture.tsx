import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Edit, 
  Save, 
  X, 
  Compass, 
  Layers, 
  ImageIcon, 
  Wrench, 
  CheckCircle, 
  Rocket,
  Star,
  Shield,
  Zap,
  RefreshCw,
  DollarSign,
  Leaf
} from "lucide-react";

interface Architecture {
  id?: number;
  projectId: number;
  overview: string;
  systemArchitecture: string;
  contextDiagram: string;
  containerDiagram: string;
  deploymentDiagram: string;
  technologyStack: TechStackItem[];
  wellArchitectedScores: WellArchitectedPillar[];
  deploymentStrategy: string;
  observabilityPlan: string;
  updatedAt: string;
}

interface TechStackItem {
  category: string;
  technology: string;
  notes: string;
}

interface WellArchitectedPillar {
  pillar: string;
  score: number;
  notes: string;
  icon: string;
}

const defaultTechStack: TechStackItem[] = [
  { category: "Frontend", technology: "React 18 + TypeScript", notes: "Component-based UI with strict type safety, hooks for state management" },
  { category: "Frontend", technology: "Tailwind CSS + shadcn/ui", notes: "Utility-first styling with accessible, composable components" },
  { category: "Frontend", technology: "Wouter Router", notes: "Lightweight client-side routing, 1.3kB gzipped" },
  { category: "Frontend", technology: "TanStack Query v5", notes: "Server state management, caching, and synchronization" },
  { category: "Frontend", technology: "Framer Motion", notes: "Production-ready motion library for React animations" },
  
  { category: "Backend / API", technology: "Node.js 20 + Express.js", notes: "High-performance JavaScript runtime with mature ecosystem" },
  { category: "Backend / API", technology: "TypeScript 5.0", notes: "Strong typing for enterprise-grade applications" },
  { category: "Backend / API", technology: "AWS API Gateway", notes: "Managed API service with rate limiting and authentication" },
  { category: "Backend / API", technology: "AWS Lambda", notes: "Serverless compute for event-driven microservices" },
  { category: "Backend / API", technology: "Zod Validation", notes: "Runtime type checking and API request validation" },
  
  { category: "AI Agents", technology: "AWS Bedrock + Anthropic Claude 3", notes: "Enterprise AI platform with 200k context window" },
  { category: "AI Agents", technology: "TensorFlow.js + BERT", notes: "On-device ML for semantic text enhancement" },
  { category: "AI Agents", technology: "Amazon Textract", notes: "Document analysis and OCR for regulatory compliance" },
  { category: "AI Agents", technology: "Amazon Comprehend", notes: "NLP service for sentiment analysis and entity recognition" },
  { category: "AI Agents", technology: "LangChain Framework", notes: "Orchestration layer for multi-agent AI workflows" },
  
  { category: "Data Storage", technology: "Amazon RDS PostgreSQL 15", notes: "ACID-compliant relational database with Multi-AZ deployment" },
  { category: "Data Storage", technology: "Amazon DynamoDB", notes: "NoSQL database for session management and real-time analytics" },
  { category: "Data Storage", technology: "Amazon S3", notes: "Object storage with 99.999999999% durability, lifecycle policies" },
  { category: "Data Storage", technology: "Amazon ElastiCache Redis", notes: "In-memory caching for session store and API response caching" },
  { category: "Data Storage", technology: "Drizzle ORM", notes: "Type-safe database client with migration support" },
  
  { category: "Infrastructure", technology: "AWS VPC", notes: "Isolated cloud network with public/private subnets" },
  { category: "Infrastructure", technology: "AWS ECS Fargate", notes: "Serverless container platform with auto-scaling" },
  { category: "Infrastructure", technology: "Application Load Balancer", notes: "Layer 7 load balancing with SSL termination" },
  { category: "Infrastructure", technology: "AWS CloudFront", notes: "Global CDN with edge caching and DDoS protection" },
  { category: "Infrastructure", technology: "Terraform", notes: "Infrastructure as Code for reproducible deployments" },
  
  { category: "CI/CD & Deployment", technology: "AWS CodePipeline", notes: "Fully managed CI/CD service with multi-stage pipelines" },
  { category: "CI/CD & Deployment", technology: "AWS CodeBuild", notes: "Managed build service with parallel execution" },
  { category: "CI/CD & Deployment", technology: "Amazon ECR", notes: "Container registry with vulnerability scanning" },
  { category: "CI/CD & Deployment", technology: "AWS Step Functions", notes: "Serverless workflow orchestration for complex deployments" },
  { category: "CI/CD & Deployment", technology: "GitHub Actions", notes: "CI/CD automation with extensive marketplace integrations" },
  
  { category: "Observability", technology: "Amazon CloudWatch", notes: "Unified monitoring with custom metrics and log aggregation" },
  { category: "Observability", technology: "AWS X-Ray", notes: "Distributed tracing for microservices performance analysis" },
  { category: "Observability", technology: "Amazon EventBridge", notes: "Event-driven architecture with rule-based routing" },
  { category: "Observability", technology: "Prometheus + Grafana", notes: "Time-series metrics collection and visualization" },
  { category: "Observability", technology: "ELK Stack", notes: "Elasticsearch, Logstash, Kibana for log analysis" },
  
  { category: "Security & IAM", technology: "AWS IAM", notes: "Identity and Access Management with role-based permissions" },
  { category: "Security & IAM", technology: "AWS WAF", notes: "Web Application Firewall with DDoS protection" },
  { category: "Security & IAM", technology: "Amazon Cognito", notes: "User authentication with MFA and identity federation" },
  { category: "Security & IAM", technology: "AWS Secrets Manager", notes: "Centralized secrets management with automatic rotation" },
  { category: "Security & IAM", technology: "AWS Certificate Manager", notes: "SSL/TLS certificate provisioning and management" }
];

const defaultWellArchitected: WellArchitectedPillar[] = [
  { 
    pillar: "Operational Excellence", 
    score: 4, 
    notes: "Infrastructure as Code with Terraform, automated CI/CD pipelines, comprehensive monitoring with CloudWatch and X-Ray, automated scaling policies, and standardized deployment processes. Room for improvement in automated incident response and self-healing systems.", 
    icon: "⚙️" 
  },
  { 
    pillar: "Security", 
    score: 5, 
    notes: "Defense in depth with WAF, VPC isolation, IAM role-based access, encryption at rest and in transit using AES-256, MFA for all admin access, Secrets Manager for credentials, regular security audits, and compliance with SOC 2 Type II and PCI DSS standards.", 
    icon: "🔒" 
  },
  { 
    pillar: "Reliability", 
    score: 4, 
    notes: "Multi-AZ deployment across 3 availability zones, RDS Multi-AZ for database failover, auto-scaling groups with health checks, Lambda for serverless reliability, S3 with 99.999999999% durability, and automated backup strategies. Could enhance with chaos engineering and disaster recovery testing.", 
    icon: "🛡️" 
  },
  { 
    pillar: "Performance Efficiency", 
    score: 4, 
    notes: "Serverless Lambda functions for automatic scaling, CloudFront CDN for global content delivery, ElastiCache Redis for sub-millisecond response times, optimized database queries with connection pooling, and Bedrock AI for efficient ML inference. Opportunity to implement more advanced caching strategies.", 
    icon: "⚡" 
  },
  { 
    pillar: "Cost Optimization", 
    score: 3, 
    notes: "Serverless pay-per-use pricing model, S3 intelligent tiering, reserved instances for predictable workloads, automated resource scheduling, and cost monitoring with budgets and alerts. Needs improvement in rightsizing instances and implementing more granular cost allocation tags.", 
    icon: "💰" 
  },
  { 
    pillar: "Sustainability", 
    score: 3, 
    notes: "Serverless computing reduces idle resource consumption, efficient algorithms minimize computational overhead, AWS regions powered by renewable energy, and optimized data transfer patterns. Could enhance with carbon footprint monitoring and more aggressive resource optimization.", 
    icon: "🌱" 
  }
];

export default function ProjectArchitecture() {
  const [, params] = useRoute("/projects/:id/architecture");
  const projectId = parseInt(params?.id || "0");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [editMode, setEditMode] = useState<string | null>(null);
  const [editData, setEditData] = useState<any>({});

  // Fetch project data
  const { data: project } = useQuery({
    queryKey: [`/api/projects/${projectId}`],
  });

  // Fetch architecture data
  const { data: architecture, isLoading } = useQuery({
    queryKey: [`/api/projects/${projectId}/architecture`],
  });

  // Create/Update architecture mutation
  const architectureMutation = useMutation({
    mutationFn: async (data: Partial<Architecture>) => {
      return apiRequest(`/api/projects/${projectId}/architecture`, {
        method: architecture ? 'PUT' : 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/architecture`] });
      toast({ title: "Success", description: "Architecture updated successfully" });
      setEditMode(null);
      setEditData({});
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update architecture", variant: "destructive" });
    },
  });

  const handleEdit = (section: string, currentData: any) => {
    setEditMode(section);
    setEditData(currentData);
  };

  const handleSave = () => {
    if (!editMode) return;
    
    const updates = { [editMode]: editData };
    architectureMutation.mutate(updates);
  };

  const handleCancel = () => {
    setEditMode(null);
    setEditData({});
  };

  const updateTechStackItem = (index: number, field: keyof TechStackItem, value: string) => {
    const newStack = [...(editData || defaultTechStack)];
    newStack[index] = { ...newStack[index], [field]: value };
    setEditData(newStack);
  };

  const updateWellArchitectedScore = (index: number, field: string, value: any) => {
    const newScores = [...(editData || defaultWellArchitected)];
    newScores[index] = { ...newScores[index], [field]: value };
    setEditData(newScores);
  };

  const renderMermaidDiagram = (diagramCode: string, title: string) => {
    return (
      <div className="border rounded-lg p-4 bg-gray-50">
        <h4 className="font-semibold mb-2">{title}</h4>
        <div className="bg-white p-4 rounded border">
          <pre className="text-xs text-gray-600 whitespace-pre-wrap">{diagramCode}</pre>
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  const archData = architecture || {
    overview: `The Smart SDLC Platform is an AI-powered enterprise software development lifecycle management system that transforms business requirements into deployable solutions through intelligent automation. This platform addresses the critical challenge of reducing time-to-market from months to weeks while maintaining enterprise-grade quality and regulatory compliance.

**Problem Statement**: Traditional SDLC processes are manual, error-prone, and require extensive coordination between multiple stakeholders. Investment banking and financial services organizations spend 60-70% of their development budget on repetitive tasks, requirement translation, and cross-team coordination.

**Target Users**: 
- Business Analysts (requirement gathering and analysis)
- Product Owners (strategy and prioritization) 
- Scrum Masters (team coordination and delivery)
- Architects (system design and technology decisions)
- UI/UX Designers (user experience design)
- Developers (implementation and testing)
- DevOps Engineers (deployment and infrastructure)

**Business Goals**: Reduce SDLC costs by 60%, accelerate delivery by 3x, improve quality through AI-assisted validation, ensure regulatory compliance (Basel III, MiFID II, EMIR), and enable seamless integration with existing enterprise tools.

**Non-Functional Goals**: Sub-second AI response times, 99.9% uptime SLA, horizontal scalability to support 10,000+ concurrent users, end-to-end encryption, comprehensive audit trails, and cost-effective serverless architecture.

**System Boundaries**: The platform integrates with external systems including trade repositories, regulatory bodies, market data providers, JIRA for project management, GitHub for source control, and ServiceNow for enterprise service management. Internal boundaries separate AI processing, workflow orchestration, data management, and user interface layers.`,
    systemArchitecture: `The Smart SDLC Platform employs a cloud-native, event-driven microservices architecture designed for enterprise-scale financial services operations.

**Core Modules:**

**1. AI Requirements Processor**
- Purpose: Converts natural language business requirements into structured technical specifications
- Inputs: Business requirement documents, user stories, regulatory guidelines
- Outputs: Functional/non-functional requirements, use cases, acceptance criteria
- Dependencies: AWS Bedrock (Claude 3 Sonnet), TensorFlow.js for BERT enhancement
- Integration: Event-driven processing with SQS, results stored in DynamoDB

**2. Multi-Agent Orchestration Engine**
- Purpose: Coordinates specialized AI agents for each SDLC role
- Inputs: Project context, role-specific queries, workflow state
- Outputs: Role-based recommendations, automated task execution, cross-role coordination
- Dependencies: AWS Lambda, Step Functions for workflow orchestration
- Integration: RESTful APIs, WebSocket for real-time collaboration

**3. Project Lifecycle Manager**
- Purpose: Manages 11-stage project progression from draft to production
- Inputs: Project data, approval decisions, status transitions
- Outputs: Updated project state, notifications, audit trails
- Dependencies: RDS PostgreSQL, SNS for notifications
- Integration: Event sourcing pattern with comprehensive state management

**4. Enterprise Integration Layer**
- Purpose: Seamless connectivity with existing enterprise tools
- Inputs: JIRA tickets, GitHub repositories, ServiceNow requests
- Outputs: Synchronized project data, automated deliverable creation
- Dependencies: API Gateway, Lambda functions for external integrations
- Integration: OAuth 2.0 authentication, webhook-based real-time sync

**5. Regulatory Compliance Engine**
- Purpose: Ensures adherence to financial services regulations
- Inputs: Project requirements, regulatory frameworks
- Outputs: Compliance validation, audit reports, risk assessments
- Dependencies: Amazon Textract for document processing, Comprehend for regulatory analysis
- Integration: Automated compliance checking throughout project lifecycle

**6. Real-time Analytics & Monitoring**
- Purpose: Provides insights into development velocity, quality metrics, and system performance
- Inputs: Application logs, user interactions, system metrics
- Outputs: Executive dashboards, predictive analytics, performance alerts
- Dependencies: Kinesis Data Streams, QuickSight for visualization
- Integration: CloudWatch custom metrics, X-Ray distributed tracing

**Non-Functional Requirements Implementation:**
- **Low Latency**: Redis caching layer, CDN distribution, optimized database queries
- **High Availability**: Multi-AZ deployment, auto-scaling, circuit breaker patterns
- **Security**: WAF protection, VPC isolation, encryption at rest/transit, IAM fine-grained permissions
- **Scalability**: Serverless Lambda functions, auto-scaling ECS clusters, DynamoDB on-demand pricing`,
    contextDiagram: `graph TB
    subgraph "SDLC Stakeholders"
        BA[Business Analyst<br/>Requirements & Analysis]
        PO[Product Owner<br/>Strategy & Planning]
        SM[Scrum Master<br/>Team Coordination]
        ARCH[Solution Architect<br/>Technical Design]
        DEV[Developer<br/>Implementation]
        OPS[DevOps Engineer<br/>Infrastructure]
    end
    
    subgraph "Smart SDLC Platform"
        PLATFORM[AI-Powered SDLC<br/>Management Platform]
    end
    
    subgraph "External Enterprise Systems"
        JIRA[JIRA<br/>Project Management]
        GITHUB[GitHub<br/>Source Control]
        SNOW[ServiceNow<br/>Enterprise Service Mgmt]
        CONFLUENCE[Confluence<br/>Documentation]
    end
    
    subgraph "Regulatory & Market Data"
        TR[Trade Repositories<br/>DTCC, LCH, Eurex]
        REG[Regulatory Bodies<br/>SEC, CFTC, ESMA]
        MDV[Market Data Vendors<br/>Bloomberg, Reuters]
    end
    
    subgraph "Infrastructure & Monitoring"
        AWS[AWS Cloud Services<br/>Bedrock, Lambda, RDS]
        MON[Monitoring Stack<br/>CloudWatch, Grafana]
    end
    
    BA --> PLATFORM
    PO --> PLATFORM
    SM --> PLATFORM
    ARCH --> PLATFORM
    DEV --> PLATFORM
    OPS --> PLATFORM
    
    PLATFORM <--> JIRA
    PLATFORM <--> GITHUB
    PLATFORM <--> SNOW
    PLATFORM <--> CONFLUENCE
    
    PLATFORM --> TR
    PLATFORM --> REG
    PLATFORM --> MDV
    
    PLATFORM --> AWS
    PLATFORM --> MON
    
    classDef userNode fill:#e1f5fe,stroke:#01579b,stroke-width:2px
    classDef platformNode fill:#fff3e0,stroke:#ef6c00,stroke-width:3px
    classDef externalNode fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    classDef infraNode fill:#e8f5e8,stroke:#2e7d32,stroke-width:2px
    
    class BA,PO,SM,ARCH,DEV,OPS userNode
    class PLATFORM platformNode
    class JIRA,GITHUB,SNOW,CONFLUENCE,TR,REG,MDV externalNode
    class AWS,MON infraNode`,
    containerDiagram: `graph TB
    subgraph "Client Tier"
        WEB[React Web App<br/>TypeScript + Tailwind CSS<br/>shadcn/ui Components]
        MOBILE[Progressive Web App<br/>Responsive Design<br/>Offline Capabilities]
    end
    
    subgraph "API Gateway & Load Balancing"
        ALB[Application Load Balancer<br/>SSL Termination<br/>Health Checks]
        APIGW[API Gateway<br/>Rate Limiting<br/>Authentication]
    end
    
    subgraph "Application Services"
        AUTH[Authentication Service<br/>JWT + OAuth 2.0<br/>Multi-factor Auth]
        CORE[Core SDLC API<br/>Express.js + TypeScript<br/>Business Logic]
        AI_SVC[AI Agent Service<br/>Multi-Agent Framework<br/>Claude 3 Sonnet]
        WORKFLOW[Workflow Engine<br/>State Management<br/>Event Orchestration]
        INTEGRATION[Integration Hub<br/>External API Connectors<br/>Enterprise Service Bus]
    end
    
    subgraph "AI & Machine Learning"
        BEDROCK[AWS Bedrock<br/>Claude 3 Sonnet<br/>Anthropic Models]
        TEXTRACT[Amazon Textract<br/>Document Processing<br/>OCR Capabilities]
        COMPREHEND[Amazon Comprehend<br/>NLP & Sentiment Analysis<br/>Regulatory Text Processing]
    end
    
    subgraph "Data & Storage Layer"
        RDS[(Amazon RDS<br/>PostgreSQL 15<br/>Multi-AZ Deployment)]
        DYNAMO[(DynamoDB<br/>Session Store<br/>Real-time Analytics)]
        S3_DOCS[(S3 - Documents<br/>Project Artifacts<br/>Regulatory Reports)]
        S3_STATIC[(S3 - Static Assets<br/>CDN Distribution<br/>Web Resources)]
        REDIS[(ElastiCache Redis<br/>Session Caching<br/>API Response Cache)]
    end
    
    subgraph "Event & Message Processing"
        SQS[Amazon SQS<br/>Async Task Queue<br/>Dead Letter Queues]
        SNS[Amazon SNS<br/>Notifications<br/>Multi-channel Alerts]
        KINESIS[Kinesis Data Streams<br/>Real-time Analytics<br/>Event Sourcing]
    end
    
    WEB --> ALB
    MOBILE --> ALB
    ALB --> APIGW
    APIGW --> AUTH
    APIGW --> CORE
    
    CORE --> AI_SVC
    CORE --> WORKFLOW
    CORE --> INTEGRATION
    
    AI_SVC --> BEDROCK
    AI_SVC --> TEXTRACT
    AI_SVC --> COMPREHEND
    
    CORE --> RDS
    CORE --> DYNAMO
    CORE --> REDIS
    
    WORKFLOW --> SQS
    WORKFLOW --> SNS
    
    CORE --> S3_DOCS
    WEB --> S3_STATIC
    
    AI_SVC --> KINESIS
    CORE --> KINESIS
    
    classDef clientTier fill:#e3f2fd,stroke:#1976d2,stroke-width:2px
    classDef apiTier fill:#fff3e0,stroke:#f57c00,stroke-width:2px
    classDef appTier fill:#e8f5e8,stroke:#388e3c,stroke-width:2px
    classDef aiTier fill:#fce4ec,stroke:#c2185b,stroke-width:2px
    classDef dataTier fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px
    classDef eventTier fill:#fff8e1,stroke:#fbc02d,stroke-width:2px
    
    class WEB,MOBILE clientTier
    class ALB,APIGW apiTier
    class AUTH,CORE,AI_SVC,WORKFLOW,INTEGRATION appTier
    class BEDROCK,TEXTRACT,COMPREHEND aiTier
    class RDS,DYNAMO,S3_DOCS,S3_STATIC,REDIS dataTier
    class SQS,SNS,KINESIS eventTier`,
    deploymentDiagram: `graph TB
    subgraph "AWS Region: us-east-1"
        subgraph "Availability Zone A"
            subgraph "VPC: 10.0.0.0/16"
                subgraph "Public Subnet A: 10.0.1.0/24"
                    ALB[Application Load Balancer<br/>Internet-facing<br/>SSL Termination]
                    NAT_A[NAT Gateway A<br/>Elastic IP<br/>Outbound Internet]
                end
                
                subgraph "Private Subnet A: 10.0.3.0/24"
                    ECS_A[ECS Fargate Tasks<br/>Auto Scaling Group<br/>API Services]
                    LAMBDA_A[Lambda Functions<br/>AI Processing<br/>Event Handlers]
                end
                
                subgraph "Database Subnet A: 10.0.5.0/24"
                    RDS_A[(RDS PostgreSQL<br/>Primary Instance<br/>Multi-AZ)]
                    REDIS_A[(ElastiCache Redis<br/>Primary Node<br/>Cluster Mode)]
                end
            end
        end
        
        subgraph "Availability Zone B"
            subgraph "Public Subnet B: 10.0.2.0/24"
                NAT_B[NAT Gateway B<br/>Elastic IP<br/>High Availability]
            end
            
            subgraph "Private Subnet B: 10.0.4.0/24"
                ECS_B[ECS Fargate Tasks<br/>Auto Scaling Group<br/>API Services]
                LAMBDA_B[Lambda Functions<br/>AI Processing<br/>Event Handlers]
            end
            
            subgraph "Database Subnet B: 10.0.6.0/24"
                RDS_B[(RDS PostgreSQL<br/>Standby Instance<br/>Multi-AZ)]
                REDIS_B[(ElastiCache Redis<br/>Replica Nodes<br/>Read Scaling)]
            end
        end
        
        subgraph "Managed AWS Services"
            APIGW[API Gateway<br/>RESTful APIs<br/>Rate Limiting<br/>API Keys]
            
            subgraph "AI & ML Services"
                BEDROCK[Amazon Bedrock<br/>Claude 3 Sonnet<br/>Anthropic Models]
                TEXTRACT[Amazon Textract<br/>Document Analysis<br/>OCR Processing]
                COMPREHEND[Amazon Comprehend<br/>NLP Services<br/>Entity Recognition]
            end
            
            subgraph "Data & Analytics"
                S3_DOCS[S3 - Documents<br/>Versioning Enabled<br/>Lifecycle Policies]
                S3_STATIC[S3 - Static Assets<br/>CloudFront CDN<br/>Global Distribution]
                ATHENA[Amazon Athena<br/>Serverless Queries<br/>S3 Data Lake]
                GLUE[AWS Glue<br/>Data Catalog<br/>ETL Pipelines]
                QUICKSIGHT[Amazon QuickSight<br/>Business Intelligence<br/>Executive Dashboards]
            end
            
            subgraph "Integration & Messaging"
                SQS[Amazon SQS<br/>Message Queues<br/>Dead Letter Queues]
                SNS[Amazon SNS<br/>Push Notifications<br/>Multi-Protocol]
                KINESIS[Kinesis Data Streams<br/>Real-time Processing<br/>Analytics Pipeline]
                STEP[Step Functions<br/>Workflow Orchestration<br/>State Machines]
            end
            
            subgraph "Security & Identity"
                WAF[AWS WAF<br/>Web Application Firewall<br/>DDoS Protection]
                COGNITO[Amazon Cognito<br/>User Authentication<br/>Identity Federation]
                SECRETS[Secrets Manager<br/>API Keys & Passwords<br/>Automatic Rotation]
                IAM[AWS IAM<br/>Role-based Access<br/>Fine-grained Permissions]
            end
            
            subgraph "DevOps & Monitoring"
                CODEPIPELINE[CodePipeline<br/>CI/CD Automation<br/>Multi-stage Deployment]
                CODEBUILD[CodeBuild<br/>Containerized Builds<br/>Parallel Execution]
                ECR[Elastic Container Registry<br/>Docker Images<br/>Vulnerability Scanning]
                CW[CloudWatch<br/>Metrics & Logs<br/>Custom Dashboards]
                XRAY[X-Ray<br/>Distributed Tracing<br/>Performance Analysis]
                EVENTBRIDGE[EventBridge<br/>Event-driven Architecture<br/>Rule-based Routing]
            end
        end
    end
    
    subgraph "External Integrations"
        JIRA_EXT[JIRA Cloud<br/>Project Management<br/>Issue Tracking]
        GITHUB_EXT[GitHub Enterprise<br/>Source Control<br/>CI/CD Webhooks]
        SNOW_EXT[ServiceNow<br/>ITSM Integration<br/>Change Management]
    end
    
    subgraph "Edge & CDN"
        CLOUDFRONT[CloudFront CDN<br/>Global Edge Locations<br/>Static Asset Delivery]
        ROUTE53[Route 53<br/>DNS Management<br/>Health Checks]
    end
    
    %% Internet to Edge
    ROUTE53 --> CLOUDFRONT
    CLOUDFRONT --> ALB
    ROUTE53 --> ALB
    
    %% Load Balancer to Services
    ALB --> APIGW
    APIGW --> ECS_A
    APIGW --> ECS_B
    APIGW --> LAMBDA_A
    APIGW --> LAMBDA_B
    
    %% Application to Data
    ECS_A --> RDS_A
    ECS_B --> RDS_A
    ECS_A --> REDIS_A
    ECS_B --> REDIS_B
    
    %% Application to AI Services
    LAMBDA_A --> BEDROCK
    LAMBDA_B --> BEDROCK
    LAMBDA_A --> TEXTRACT
    LAMBDA_A --> COMPREHEND
    
    %% Storage and Analytics
    ECS_A --> S3_DOCS
    ECS_B --> S3_DOCS
    CLOUDFRONT --> S3_STATIC
    ATHENA --> S3_DOCS
    GLUE --> S3_DOCS
    QUICKSIGHT --> ATHENA
    
    %% Event Processing
    ECS_A --> SQS
    ECS_A --> SNS
    ECS_A --> KINESIS
    LAMBDA_A --> SQS
    STEP --> LAMBDA_A
    EVENTBRIDGE --> STEP
    
    %% Security
    WAF --> ALB
    COGNITO --> APIGW
    IAM --> ECS_A
    IAM --> LAMBDA_A
    SECRETS --> ECS_A
    
    %% Monitoring
    ECS_A --> CW
    LAMBDA_A --> CW
    ECS_A --> XRAY
    LAMBDA_A --> XRAY
    
    %% CI/CD
    CODEPIPELINE --> CODEBUILD
    CODEBUILD --> ECR
    ECR --> ECS_A
    
    %% External Integration
    ECS_A -.-> JIRA_EXT
    ECS_A -.-> GITHUB_EXT
    ECS_A -.-> SNOW_EXT
    
    classDef azA fill:#e3f2fd,stroke:#1976d2,stroke-width:2px
    classDef azB fill:#e8f5e8,stroke:#388e3c,stroke-width:2px
    classDef managed fill:#fff3e0,stroke:#f57c00,stroke-width:2px
    classDef security fill:#ffebee,stroke:#d32f2f,stroke-width:2px
    classDef external fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px
    classDef edge fill:#fff8e1,stroke:#fbc02d,stroke-width:2px
    
    class ALB,NAT_A,ECS_A,LAMBDA_A,RDS_A,REDIS_A azA
    class NAT_B,ECS_B,LAMBDA_B,RDS_B,REDIS_B azB
    class APIGW,BEDROCK,TEXTRACT,COMPREHEND,S3_DOCS,S3_STATIC,ATHENA,GLUE,QUICKSIGHT,SQS,SNS,KINESIS,STEP,CODEPIPELINE,CODEBUILD,ECR,CW,XRAY,EVENTBRIDGE managed
    class WAF,COGNITO,SECRETS,IAM security
    class JIRA_EXT,GITHUB_EXT,SNOW_EXT external
    class CLOUDFRONT,ROUTE53 edge`,
    technologyStack: defaultTechStack,
    wellArchitectedScores: defaultWellArchitected,
    deploymentStrategy: `**CI/CD Pipeline Architecture:**

**Source Stage**: GitHub Enterprise repositories with protected main branches, requiring pull request reviews and status checks

**Build Stage**: AWS CodeBuild with containerized environments, parallel execution of:
- Unit tests (Jest/React Testing Library)
- Integration tests (Postman/Newman)
- Security scanning (Snyk, OWASP dependency check)
- Code quality analysis (SonarQube)
- Container image building and ECR push

**Deploy Stages**:
1. **Development Environment**: Automatic deployment on merge to develop branch
2. **Staging Environment**: Manual approval required, full integration testing
3. **Production Environment**: Blue-green deployment with automated rollback

**Environment Management**:
- **Development**: Single AZ, smaller instance sizes, shared RDS instance
- **Staging**: Production-like setup with synthetic data, performance testing
- **Production**: Multi-AZ, auto-scaling, separate RDS cluster with read replicas

**Deployment Strategies**:
- **API Services**: Blue-green deployment with health checks and automatic rollback
- **Lambda Functions**: Versioning with gradual traffic shifting (10% → 50% → 100%)
- **Database Changes**: Schema migrations using Flyway with rollback scripts
- **Infrastructure**: Terraform with state locking, plan review before apply

**Rollback Mechanisms**:
- Lambda alias switching for instant rollback
- Load balancer traffic shifting for application rollback
- RDS point-in-time recovery for data issues
- Infrastructure rollback via Terraform state management

**Release Windows**: Production deployments during low-traffic hours (2 AM - 6 AM EST) with 24/7 monitoring`,

    observabilityPlan: `**Monitoring & Alerting Strategy:**

**Application Performance Monitoring (APM)**:
- AWS X-Ray for distributed tracing across microservices
- Custom CloudWatch metrics for business KPIs
- Real User Monitoring (RUM) for frontend performance
- API Gateway metrics for endpoint-level monitoring

**Infrastructure Monitoring**:
- CloudWatch for AWS resource metrics and logs
- Prometheus for custom application metrics
- Grafana for unified dashboards and visualization
- AWS Personal Health Dashboard for service status

**Log Management**:
- Centralized logging with CloudWatch Logs
- Structured JSON logging with correlation IDs
- Log aggregation and analysis with ELK stack
- Log retention policies aligned with regulatory requirements

**Key Metrics & SLAs**:
- API Response Time: P95 < 500ms, P99 < 1000ms
- System Availability: 99.9% uptime (< 8.77 hours downtime/year)
- AI Model Latency: < 2 seconds for requirement processing
- Database Query Performance: < 100ms for read operations
- Error Rate: < 0.1% for critical business operations

**Alerting & Escalation**:
- **Critical Alerts**: System outages, security breaches, data corruption
  - Immediate PagerDuty notification
  - Escalation to on-call engineer within 5 minutes
  - Executive notification for prolonged outages

- **Warning Alerts**: Performance degradation, capacity thresholds
  - Slack notifications to DevOps team
  - Email to stakeholders for sustained issues

- **Info Alerts**: Deployment notifications, capacity scaling events
  - Dashboard updates and trending analysis

**Security Monitoring**:
- AWS GuardDuty for threat detection
- CloudTrail for API audit logging
- WAF logs for attack pattern analysis
- Compliance monitoring for regulatory requirements

**Business Intelligence**:
- QuickSight dashboards for executive reporting
- Real-time analytics for user behavior and system usage
- Cost optimization insights and recommendations
- Performance trending and capacity planning

**Incident Response**:
- Automated runbooks for common issues
- Chaos engineering with regular failure testing
- Post-incident reviews and system improvements
- Documentation and knowledge base maintenance`
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Architecture</h1>
          <p className="text-gray-600">{project?.name}</p>
        </div>
        <Badge variant="secondary" className="bg-blue-100 text-blue-800">
          <Layers className="h-4 w-4 mr-1" />
          Architect View
        </Badge>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Compass className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="diagrams" className="flex items-center gap-2">
            <ImageIcon className="h-4 w-4" />
            Diagrams
          </TabsTrigger>
          <TabsTrigger value="tech-stack" className="flex items-center gap-2">
            <Wrench className="h-4 w-4" />
            Tech Stack
          </TabsTrigger>
          <TabsTrigger value="well-architected" className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            AWS Well-Architected
          </TabsTrigger>
          <TabsTrigger value="deployment" className="flex items-center gap-2">
            <Rocket className="h-4 w-4" />
            Deployment
          </TabsTrigger>
          <TabsTrigger value="observability" className="flex items-center gap-2">
            <Star className="h-4 w-4" />
            Observability
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Compass className="h-5 w-5" />
                Architecture Overview
              </CardTitle>
              {editMode !== 'overview' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleEdit('overview', archData.overview)}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editMode === 'overview' ? (
                <div className="space-y-4">
                  <Textarea
                    value={editData}
                    onChange={(e) => setEditData(e.target.value)}
                    className="min-h-32"
                    placeholder="Describe the overall system architecture..."
                  />
                  <div className="flex gap-2">
                    <Button onClick={handleSave} disabled={architectureMutation.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancel}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="prose max-w-none">
                  {(archData.overview || '').split('\n\n').map((paragraph, index) => (
                    <p key={index} className="mb-4 text-gray-700">{paragraph}</p>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Layers className="h-5 w-5" />
                System Architecture
              </CardTitle>
              {editMode !== 'systemArchitecture' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleEdit('systemArchitecture', archData.systemArchitecture)}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editMode === 'systemArchitecture' ? (
                <div className="space-y-4">
                  <Textarea
                    value={editData}
                    onChange={(e) => setEditData(e.target.value)}
                    className="min-h-24"
                    placeholder="Describe the system architecture components..."
                  />
                  <div className="flex gap-2">
                    <Button onClick={handleSave} disabled={architectureMutation.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancel}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-gray-700">{archData.systemArchitecture || 'No system architecture documentation available.'}</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="diagrams" className="space-y-6">
          <div className="grid gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Context Diagram (C4 Level 1)</CardTitle>
                {editMode !== 'contextDiagram' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit('contextDiagram', archData.contextDiagram)}
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                {editMode === 'contextDiagram' ? (
                  <div className="space-y-4">
                    <Textarea
                      value={editData}
                      onChange={(e) => setEditData(e.target.value)}
                      className="min-h-48 font-mono text-sm"
                      placeholder="Enter Mermaid diagram code..."
                    />
                    <div className="flex gap-2">
                      <Button onClick={handleSave} disabled={architectureMutation.isPending}>
                        <Save className="h-4 w-4 mr-2" />
                        Save
                      </Button>
                      <Button variant="outline" onClick={handleCancel}>
                        <X className="h-4 w-4 mr-2" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div>
                    {renderMermaidDiagram(archData.contextDiagram, "System Context")}
                    <p className="mt-4 text-sm text-gray-600">
                      Shows the high-level relationship between users, external systems, and the Smart SDLC platform.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Container Diagram (C4 Level 2)</CardTitle>
                {editMode !== 'containerDiagram' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit('containerDiagram', archData.containerDiagram)}
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                {editMode === 'containerDiagram' ? (
                  <div className="space-y-4">
                    <Textarea
                      value={editData}
                      onChange={(e) => setEditData(e.target.value)}
                      className="min-h-48 font-mono text-sm"
                      placeholder="Enter Mermaid diagram code..."
                    />
                    <div className="flex gap-2">
                      <Button onClick={handleSave} disabled={architectureMutation.isPending}>
                        <Save className="h-4 w-4 mr-2" />
                        Save
                      </Button>
                      <Button variant="outline" onClick={handleCancel}>
                        <X className="h-4 w-4 mr-2" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div>
                    {renderMermaidDiagram(archData.containerDiagram, "Container Architecture")}
                    <p className="mt-4 text-sm text-gray-600">
                      Illustrates the main application containers, their technologies, and interactions.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>AWS Deployment Diagram</CardTitle>
                {editMode !== 'deploymentDiagram' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit('deploymentDiagram', archData.deploymentDiagram)}
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                {editMode === 'deploymentDiagram' ? (
                  <div className="space-y-4">
                    <Textarea
                      value={editData}
                      onChange={(e) => setEditData(e.target.value)}
                      className="min-h-48 font-mono text-sm"
                      placeholder="Enter Mermaid diagram code..."
                    />
                    <div className="flex gap-2">
                      <Button onClick={handleSave} disabled={architectureMutation.isPending}>
                        <Save className="h-4 w-4 mr-2" />
                        Save
                      </Button>
                      <Button variant="outline" onClick={handleCancel}>
                        <X className="h-4 w-4 mr-2" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div>
                    {renderMermaidDiagram(archData.deploymentDiagram, "AWS Deployment")}
                    <p className="mt-4 text-sm text-gray-600">
                      Shows the AWS infrastructure components, VPC configuration, and service deployment topology.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tech-stack" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Wrench className="h-5 w-5" />
                Technology Stack
              </CardTitle>
              {editMode !== 'technologyStack' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleEdit('technologyStack', archData.technologyStack)}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editMode === 'technologyStack' ? (
                <div className="space-y-4">
                  <div className="space-y-3">
                    {(editData || []).map((item: TechStackItem, index: number) => (
                      <div key={index} className="grid grid-cols-3 gap-3 p-3 border rounded">
                        <Input
                          value={item.category}
                          onChange={(e) => updateTechStackItem(index, 'category', e.target.value)}
                          placeholder="Category"
                        />
                        <Input
                          value={item.technology}
                          onChange={(e) => updateTechStackItem(index, 'technology', e.target.value)}
                          placeholder="Technology"
                        />
                        <Input
                          value={item.notes}
                          onChange={(e) => updateTechStackItem(index, 'notes', e.target.value)}
                          placeholder="Notes"
                        />
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleSave} disabled={architectureMutation.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancel}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {Object.entries(
                    Array.isArray(archData.technologyStack) 
                      ? archData.technologyStack.reduce((acc: any, item) => {
                          if (!acc[item.category]) acc[item.category] = [];
                          acc[item.category].push(item);
                          return acc;
                        }, {})
                      : {}
                  ).map(([category, items]: [string, any]) => (
                    <div key={category}>
                      <h3 className="font-semibold text-lg mb-2">{category}</h3>
                      <div className="space-y-2">
                        {items.map((item: TechStackItem, index: number) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded">
                            <div>
                              <span className="font-medium">{item.technology}</span>
                              <p className="text-sm text-gray-600">{item.notes}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="well-architected" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                AWS Well-Architected Framework
              </CardTitle>
              {editMode !== 'wellArchitectedScores' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleEdit('wellArchitectedScores', archData.wellArchitectedScores)}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editMode === 'wellArchitectedScores' ? (
                <div className="space-y-4">
                  <div className="space-y-3">
                    {(editData || []).map((pillar: WellArchitectedPillar, index: number) => (
                      <div key={index} className="grid grid-cols-4 gap-3 p-3 border rounded items-center">
                        <span className="font-medium">{pillar.icon} {pillar.pillar}</span>
                        <Input
                          type="number"
                          min="1"
                          max="5"
                          value={pillar.score}
                          onChange={(e) => updateWellArchitectedScore(index, 'score', parseInt(e.target.value))}
                          className="w-20"
                        />
                        <Input
                          value={pillar.notes}
                          onChange={(e) => updateWellArchitectedScore(index, 'notes', e.target.value)}
                          placeholder="Notes"
                          className="col-span-2"
                        />
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleSave} disabled={architectureMutation.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancel}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid gap-4">
                    {(archData.wellArchitectedScores || []).map((pillar, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{pillar.icon}</span>
                          <div>
                            <h3 className="font-semibold">{pillar.pillar}</h3>
                            <p className="text-sm text-gray-600">{pillar.notes}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-lg">{pillar.score}/5</span>
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-4 w-4 ${
                                  star <= pillar.score ? 'text-yellow-400 fill-current' : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="deployment" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Rocket className="h-5 w-5" />
                Deployment Strategy
              </CardTitle>
              {editMode !== 'deploymentStrategy' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleEdit('deploymentStrategy', archData.deploymentStrategy)}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editMode === 'deploymentStrategy' ? (
                <div className="space-y-4">
                  <Textarea
                    value={editData}
                    onChange={(e) => setEditData(e.target.value)}
                    className="min-h-24"
                    placeholder="Describe deployment strategy, environments, and tools..."
                  />
                  <div className="flex gap-2">
                    <Button onClick={handleSave} disabled={architectureMutation.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancel}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-gray-700">{archData.deploymentStrategy || 'No deployment strategy documentation available.'}</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="observability" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5" />
                Observability Plan
              </CardTitle>
              {editMode !== 'observabilityPlan' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleEdit('observabilityPlan', archData.observabilityPlan)}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editMode === 'observabilityPlan' ? (
                <div className="space-y-4">
                  <Textarea
                    value={editData}
                    onChange={(e) => setEditData(e.target.value)}
                    className="min-h-24"
                    placeholder="Describe monitoring, alerting, and observability strategy..."
                  />
                  <div className="flex gap-2">
                    <Button onClick={handleSave} disabled={architectureMutation.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancel}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-gray-700">{archData.observabilityPlan || 'No observability plan documentation available.'}</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}