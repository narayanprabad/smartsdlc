import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ProfileSwitcher } from "@/components/profile-switcher";
import { ProjectCard } from "@/components/project-card";
import { UseCaseModal } from "@/components/use-case-modal";
import { DeliverablesModal } from "@/components/deliverables-modal";
import { AgentInterface } from "@/components/agent-interface";
import { ArchitectDiagramEditor } from "@/components/architect-diagram-editor";
import { CreateProjectModal } from "@/components/create-project-modal";
import { ProjectManagement } from "@/components/project-management";
import { PageHeader } from "@/components/page-header";


import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Plus, Bot, Download, Search, BarChart3, Users, Settings, Key, LogOut, GitBranch } from "lucide-react";
import { logout, type User } from "@/lib/auth";
import { useLocation } from "wouter";

interface Project {
  id: number;
  name: string;
  description: string;
  status: string;
  type: string;
  startDate: string;
  teamSize: number;
  functionalUseCases: number;
  nonFunctionalUseCases: number;
  approvalStatus?: string;
  approvedAt?: string;
  sealApplicationId?: string;
  sealApplicationName?: string;
}

export default function Dashboard() {
  // All hooks must be called at the top level
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isUseCaseModalOpen, setIsUseCaseModalOpen] = useState(false);
  const [isDeliverablesModalOpen, setIsDeliverablesModalOpen] = useState(false);
  const [isCreateProjectModalOpen, setIsCreateProjectModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [showArchitectStudio, setShowArchitectStudio] = useState(false);
  const [showProjectManagement, setShowProjectManagement] = useState(false);
  const [selectedProjectForManagement, setSelectedProjectForManagement] = useState<number | null>(null);

  // Query for current user
  const { data: currentUser, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  // Query for projects
  const { data: projects = [], isLoading: projectsLoading } = useQuery({
    queryKey: ["/api/projects"],
  });

  // Approve project mutation
  const approveProjectMutation = useMutation({
    mutationFn: async (projectId: number) => {
      const response = await fetch(`/api/projects/${projectId}/approve`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error('Failed to approve project');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Success",
        description: "Project approved successfully. Deliverables are being generated and assigned to team members.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to approve project",
        variant: "destructive",
      });
    },
  });

  // Reject project mutation
  const rejectProjectMutation = useMutation({
    mutationFn: async (projectId: number) => {
      const response = await fetch(`/api/projects/${projectId}/reject`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error('Failed to reject project');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Project Rejected",
        description: "The project has been rejected and returned to draft status.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to reject project",
        variant: "destructive",
      });
    },
  });

  // Generate deliverables mutation
  const generateDeliverablesMutation = useMutation({
    mutationFn: async (projectId: number) => {
      const response = await fetch(`/api/projects/${projectId}/generate-deliverables`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error('Failed to generate deliverables');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Success",
        description: "Deliverables generated successfully and distributed to team members.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to generate deliverables",
        variant: "destructive",
      });
    },
  });

  // Submit for approval mutation
  const submitForApprovalMutation = useMutation({
    mutationFn: async (projectId: number) => {
      const response = await fetch(`/api/projects/${projectId}/submit-for-approval`, {
        method: 'POST',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to submit project for approval');
      }
      
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Project submitted for approval successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit project for approval",
        variant: "destructive",
      });
    },
  });

  // Delete project mutation (only for draft projects)
  const deleteProjectMutation = useMutation({
    mutationFn: async (projectId: number) => {
      const response = await fetch(`/api/projects/${projectId}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to delete project');
      }
      
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Draft project deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Download project data mutation
  const downloadProjectMutation = useMutation({
    mutationFn: async (projectId: number) => {
      const response = await fetch(`/api/projects/${projectId}/download`, {
        method: 'GET',
      });
      if (!response.ok) {
        throw new Error('Failed to download project data');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `project-${projectId}-data.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Project data downloaded successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to download project data",
        variant: "destructive",
      });
    },
  });

  // Show loading state if user data is not available
  if (userLoading || !currentUser) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg">Loading Smart SDLC Dashboard...</div>
      </div>
    );
  }

  const handleLogout = async () => {
    try {
      await logout();
      setLocation("/");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to logout",
        variant: "destructive",
      });
    }
  };

  const handleViewUseCases = (projectId: number) => {
    const project = (projects as Project[]).find((p: Project) => p.id === projectId);
    if (project) {
      setSelectedProject(project);
      setIsUseCaseModalOpen(true);
    }
  };

  const handleViewDeliverables = (projectId: number) => {
    const project = (projects as Project[]).find((p: Project) => p.id === projectId);
    setSelectedProject(project || null);
    setIsDeliverablesModalOpen(true);
  };

  const handleSelectProject = (projectId: number) => {
    const project = (projects as Project[]).find((p: Project) => p.id === projectId);
    setSelectedProject(project || null);
    toast({
      title: "Project Selected",
      description: `${project?.name || 'Project'} is now active in the Agent Interface. Use the Actions tab to access role-specific tools.`,
    });
  };

  const filteredProjects = (projects as Project[]).filter((project: Project) => {
    const matchesSearch = project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || project.status === statusFilter;
    const matchesType = typeFilter === "all" || project.type === typeFilter;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  // Role-specific project filtering
  const getProjectsForRole = (role: string) => {
    const allProjects = projects as Project[];
    
    switch (role) {
      case "business-analyst":
      case "product-owner":
        return {
          draftProjects: allProjects.filter(p => 
            p.approvalStatus === "draft" && p.status === "Draft" && !p.approvedAt && !p.submittedAt
          ),
          pendingApprovalProjects: allProjects.filter(p => 
            p.approvalStatus === "pending" || p.status === "Pending Review"
          ),
          underDevelopmentProjects: allProjects.filter(p => 
            p.approvalStatus === "approved" || p.status === "Approved for Development" || p.status === "Planning" || p.status === "Architecture" || 
            p.status === "Ready for Development" || p.status === "In Development" || p.status === "In Integration Test" ||
            p.status === "In UAT" || p.status === "Production Readiness"
          ),
          archivedProjects: allProjects.filter(p => 
            p.status === "Promoted to Prod" || p.status === "Archived" || p.status === "Cancelled"
          )
        };
      
      case "architect":
        return {
          underDevelopmentProjects: allProjects.filter(p => 
            p.approvalStatus === "approved" || p.status === "Approved for Development" || p.status === "Planning" || 
            p.status === "Architecture" || p.status === "Ready for Development" || p.status === "In Development" || 
            p.status === "In Integration Test" || p.status === "In UAT" || p.status === "Production Readiness"
          ),
          archivedProjects: allProjects.filter(p => 
            p.status === "completed" || p.status === "archived" || p.status === "cancelled"
          )
        };
      
      default:
        return {
          assignedProjects: allProjects.filter(p => 
            p.status === "Approved for Development" || p.status === "Planning" || p.status === "Architecture" || 
            p.status === "Ready for Development" || p.status === "In Development" || p.status === "In Integration Test"
          ),
          archivedProjects: allProjects.filter(p => 
            p.status === "completed" || p.status === "archived" || p.status === "cancelled"
          )
        };
    }
  };

  const roleProjects = getProjectsForRole(currentUser!.currentRole);

  const getSectionsForRole = (role: string) => {
    switch (role) {
      case "business-analyst":
      case "product-owner":
        return [
          {
            id: "draft",
            title: "Draft Projects",
            subtitle: "Projects not yet submitted for approval",
            projects: roleProjects.draftProjects || [],
            color: "bg-yellow-50 border-yellow-200",
            badgeColor: "bg-yellow-100 text-yellow-800",
            icon: "📝"
          },
          {
            id: "pending",
            title: "Pending Review",
            subtitle: "Projects submitted and awaiting Product Owner review",
            projects: roleProjects.pendingApprovalProjects || [],
            color: "bg-blue-50 border-blue-200",
            badgeColor: "bg-blue-100 text-blue-800",
            icon: "⏳"
          },
          {
            id: "development",
            title: "Under Development",
            subtitle: "Approved projects in development phase",
            projects: roleProjects.underDevelopmentProjects || [],
            color: "bg-green-50 border-green-200",
            badgeColor: "bg-green-100 text-green-800",
            icon: "🚀"
          },
          {
            id: "archive",
            title: "Archive",
            subtitle: "Completed and archived projects",
            projects: roleProjects.archivedProjects || [],
            color: "bg-gray-50 border-gray-200",
            badgeColor: "bg-gray-100 text-gray-800",
            icon: "📁"
          }
        ];
      
      case "architect":
        return [
          {
            id: "development",
            title: "Assigned Projects",
            subtitle: "Projects assigned to you for architecture design",
            projects: roleProjects.underDevelopmentProjects || [],
            color: "bg-green-50 border-green-200",
            badgeColor: "bg-green-100 text-green-800",
            icon: "🏗️"
          }
        ];
      
      default:
        return [
          {
            id: "assigned",
            title: "Assigned Projects",
            subtitle: "Projects assigned to you",
            projects: roleProjects.assignedProjects || [],
            color: "bg-blue-50 border-blue-200",
            badgeColor: "bg-blue-100 text-blue-800",
            icon: "💼"
          },
          {
            id: "archive",
            title: "Archive",
            subtitle: "Completed and archived projects",
            projects: roleProjects.archivedProjects || [],
            color: "bg-gray-50 border-gray-200",
            badgeColor: "bg-gray-100 text-gray-800",
            icon: "📁"
          }
        ];
    }
  };

  const sections = getSectionsForRole(currentUser!.currentRole);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Page Header */}
      <PageHeader
        title="Dashboard"
        subtitle="Manage your SDLC projects and collaborate with AI-powered agents"
        user={currentUser!}
        showCreateButton={currentUser!.currentRole === "Business Analyst"}
        onCreateClick={() => setIsCreateProjectModalOpen(true)}
      />



      <div className="container mx-auto px-6 py-6">
        {/* Controls */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search projects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="in-review">In Review</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
              <SelectItem value="development">Development</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="web-application">Web Application</SelectItem>
              <SelectItem value="mobile-app">Mobile App</SelectItem>
              <SelectItem value="api-development">API Development</SelectItem>
              <SelectItem value="data-analytics">Data Analytics</SelectItem>
            </SelectContent>
          </Select>
          {currentUser!.currentRole === "Business Analyst" && (
            <Button onClick={() => setIsCreateProjectModalOpen(true)} className="whitespace-nowrap">
              <Plus className="h-4 w-4 mr-2" />
              New Project
            </Button>
          )}
        </div>

        {/* Role-Specific Dashboard Sections */}
        {sections.length > 0 ? (
          <div className="mb-8 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">
                {currentUser!.currentRole === "business-analyst" ? "Business Analyst Dashboard" :
                 currentUser!.currentRole === "product-owner" ? "Product Owner Dashboard" :
                 currentUser!.currentRole === "architect" ? "Architect Dashboard" :
                 currentUser!.currentRole === "scrum-master" ? "Scrum Master Dashboard" :
                 currentUser!.currentRole === "developer" ? "Developer Dashboard" :
                 currentUser!.currentRole === "ui-designer" ? "UI Designer Dashboard" :
                 currentUser!.currentRole === "devops" ? "DevOps Dashboard" :
                 "Dashboard"}
              </h2>
              <div className="text-sm text-gray-500">
                Total: {sections.reduce((sum, section) => sum + section.projects.length, 0)} projects
              </div>
            </div>

            {sections.map((section) => (
              <div key={section.id} className={`border rounded-lg p-6 ${section.color}`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{section.icon}</span>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{section.title}</h3>
                      <p className="text-sm text-gray-600">{section.subtitle}</p>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-sm font-medium ${section.badgeColor}`}>
                    {section.projects.length} projects
                  </div>
                </div>
                
                {section.projects.length > 0 ? (
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {section.projects.map((project: Project) => (
                      <ProjectCard
                        key={project.id}
                        project={project}
                        onViewUseCases={handleViewUseCases}
                        onViewDeliverables={handleViewDeliverables}
                        onSelectProject={handleSelectProject}
                        onApproveProject={approveProjectMutation.mutate}
                        onRejectProject={rejectProjectMutation.mutate}
                        onDeleteProject={deleteProjectMutation.mutate}
                        onSubmitForApproval={submitForApprovalMutation.mutate}
                        onManageProject={(projectId: number) => {
                          setSelectedProjectForManagement(projectId);
                          setShowProjectManagement(true);
                        }}
                        onViewArchitecture={(projectId: number) => {
                          const proj = (projects as Project[]).find((p: Project) => p.id === projectId);
                          setSelectedProject(proj || null);
                          setShowArchitectStudio(true);
                        }}
                        currentRole={currentUser!.currentRole}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <p>No projects in this category yet.</p>
                    {section.id === "draft" && currentUser!.currentRole === "business-analyst" && (
                      <Button 
                        onClick={() => setIsCreateProjectModalOpen(true)}
                        className="mt-4"
                        variant="outline"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Create Your First Project
                      </Button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <p>No projects found. Create a new project to get started.</p>
            {currentUser!.currentRole === "business-analyst" && (
              <Button 
                onClick={() => setIsCreateProjectModalOpen(true)}
                className="mt-4"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Project
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Modals */}
      {isCreateProjectModalOpen && (
        <CreateProjectModal
          isOpen={isCreateProjectModalOpen}
          onClose={() => setIsCreateProjectModalOpen(false)}
          currentRole={currentUser!.currentRole}
        />
      )}

      {isUseCaseModalOpen && selectedProject && (
        <UseCaseModal
          isOpen={isUseCaseModalOpen}
          onClose={() => setIsUseCaseModalOpen(false)}
          project={selectedProject as any}
          currentRole={currentUser!.currentRole}
        />
      )}

      {isDeliverablesModalOpen && selectedProject && (
        <DeliverablesModal
          isOpen={isDeliverablesModalOpen}
          onClose={() => setIsDeliverablesModalOpen(false)}
          project={selectedProject as any}
          currentRole={currentUser!.currentRole}
        />
      )}

      {/* Architecture Studio Modal */}
      {showArchitectStudio && selectedProject && (
        <ArchitectDiagramEditor
          projectId={selectedProject.id}
          onClose={() => setShowArchitectStudio(false)}
        />
      )}

      {/* Project Management Modal */}
      {showProjectManagement && selectedProjectForManagement && (
        <ProjectManagement
          projectId={selectedProjectForManagement}
          onClose={() => {
            setShowProjectManagement(false);
            setSelectedProjectForManagement(null);
          }}
        />
      )}
    </div>
  );
}