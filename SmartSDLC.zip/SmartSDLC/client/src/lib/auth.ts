import { apiRequest } from "./queryClient";

export interface User {
  id: number;
  username: string;
  name: string;
  roles: string[];
  currentRole: string;
  sealApplications?: string[] | null;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface AuthResponse {
  user: User;
}

export async function login(credentials: LoginRequest): Promise<AuthResponse> {
  const response = await apiRequest("POST", "/api/auth/login", credentials);
  return response.json();
}

export async function logout(): Promise<void> {
  await apiRequest("POST", "/api/auth/logout");
}

export async function updateUserRole(userId: number, role: string): Promise<AuthResponse> {
  const response = await apiRequest("PUT", `/api/users/${userId}/role`, { role });
  return response.json();
}
