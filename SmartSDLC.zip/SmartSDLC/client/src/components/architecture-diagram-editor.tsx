import { useState, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Server, 
  Database, 
  Globe, 
  Shield, 
  Cloud, 
  Cpu, 
  HardDrive, 
  Network, 
  Monitor, 
  Smartphone,
  Users,
  Lock,
  Activity,
  GitBranch,
  Settings,
  Zap,
  FileText,
  MessageSquare,
  Search,
  BarChart3,
  Layers,
  Box,
  CircuitBoard,
  Workflow,
  Plus,
  Trash2,
  Save,
  Download,
  Upload
} from "lucide-react";

interface Component {
  id: string;
  type: string;
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  icon: any;
  category: string;
  color: string;
}

interface Connection {
  id: string;
  from: string;
  to: string;
  label?: string;
}

interface ArchitectureDiagramEditorProps {
  projectId: number;
  diagramId: string;
  isEditing: boolean;
  onSave: (components: Component[], connections: Connection[]) => void;
}

const componentLibrary = {
  compute: [
    { type: "ec2", name: "EC2 Instance", icon: Server, color: "#FF9900" },
    { type: "lambda", name: "Lambda Function", icon: Zap, color: "#FF9900" },
    { type: "ecs", name: "ECS Container", icon: Box, color: "#FF9900" },
    { type: "eks", name: "EKS Cluster", icon: Layers, color: "#FF9900" },
    { type: "fargate", name: "Fargate", icon: Cloud, color: "#FF9900" },
  ],
  storage: [
    { type: "s3", name: "S3 Bucket", icon: HardDrive, color: "#569A31" },
    { type: "rds", name: "RDS Database", icon: Database, color: "#3F48CC" },
    { type: "dynamodb", name: "DynamoDB", icon: Database, color: "#3F48CC" },
    { type: "elasticache", name: "ElastiCache", icon: CircuitBoard, color: "#C925D1" },
    { type: "efs", name: "EFS", icon: FileText, color: "#569A31" },
  ],
  networking: [
    { type: "vpc", name: "VPC", icon: Network, color: "#9D5AAE" },
    { type: "alb", name: "Application Load Balancer", icon: Activity, color: "#F58536" },
    { type: "cloudfront", name: "CloudFront", icon: Globe, color: "#9D5AAE" },
    { type: "api-gateway", name: "API Gateway", icon: GitBranch, color: "#FF4B4B" },
    { type: "route53", name: "Route 53", icon: Globe, color: "#9D5AAE" },
  ],
  security: [
    { type: "iam", name: "IAM", icon: Users, color: "#DD344C" },
    { type: "cognito", name: "Cognito", icon: Lock, color: "#DD344C" },
    { type: "waf", name: "WAF", icon: Shield, color: "#DD344C" },
    { type: "kms", name: "KMS", icon: Lock, color: "#DD344C" },
    { type: "secrets-manager", name: "Secrets Manager", icon: Lock, color: "#DD344C" },
  ],
  monitoring: [
    { type: "cloudwatch", name: "CloudWatch", icon: BarChart3, color: "#759C3E" },
    { type: "xray", name: "X-Ray", icon: Search, color: "#759C3E" },
    { type: "cloudtrail", name: "CloudTrail", icon: Activity, color: "#759C3E" },
  ],
  messaging: [
    { type: "sqs", name: "SQS", icon: MessageSquare, color: "#FF4B4B" },
    { type: "sns", name: "SNS", icon: MessageSquare, color: "#FF4B4B" },
    { type: "eventbridge", name: "EventBridge", icon: Workflow, color: "#FF4B4B" },
    { type: "kinesis", name: "Kinesis", icon: Activity, color: "#FF4B4B" },
  ],
  frontend: [
    { type: "react", name: "React App", icon: Monitor, color: "#61DAFB" },
    { type: "mobile", name: "Mobile App", icon: Smartphone, color: "#32C5FF" },
    { type: "web", name: "Web Interface", icon: Globe, color: "#4CAF50" },
  ],
  external: [
    { type: "user", name: "User", icon: Users, color: "#6B7280" },
    { type: "external-api", name: "External API", icon: Globe, color: "#6B7280" },
    { type: "payment", name: "Payment Gateway", icon: Settings, color: "#6B7280" },
    { type: "bank", name: "Banking System", icon: Settings, color: "#6B7280" },
  ]
};

export function ArchitectureDiagramEditor({ 
  projectId, 
  diagramId, 
  isEditing, 
  onSave 
}: ArchitectureDiagramEditorProps) {
  const [components, setComponents] = useState<Component[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);
  const [draggedComponent, setDraggedComponent] = useState<any>(null);
  const [connecting, setConnecting] = useState<string | null>(null);
  const canvasRef = useRef<HTMLDivElement>(null);

  const handleDragStart = (e: React.DragEvent, component: any) => {
    setDraggedComponent(component);
    e.dataTransfer.effectAllowed = "copy";
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedComponent || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newComponent: Component = {
      id: `${draggedComponent.type}-${Date.now()}`,
      type: draggedComponent.type,
      name: draggedComponent.name,
      x: Math.max(0, x - 60),
      y: Math.max(0, y - 30),
      width: 120,
      height: 60,
      icon: draggedComponent.icon,
      category: draggedComponent.category,
      color: draggedComponent.color
    };

    setComponents(prev => [...prev, newComponent]);
    setDraggedComponent(null);
  }, [draggedComponent]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
  };

  const deleteComponent = (componentId: string) => {
    setComponents(prev => prev.filter(c => c.id !== componentId));
    setConnections(prev => prev.filter(c => c.from !== componentId && c.to !== componentId));
    setSelectedComponent(null);
  };

  const startConnection = (componentId: string) => {
    if (connecting === componentId) {
      setConnecting(null);
    } else if (connecting) {
      // Create connection
      const newConnection: Connection = {
        id: `${connecting}-${componentId}`,
        from: connecting,
        to: componentId
      };
      setConnections(prev => [...prev, newConnection]);
      setConnecting(null);
    } else {
      setConnecting(componentId);
    }
  };

  const getComponentCenter = (component: Component) => ({
    x: component.x + component.width / 2,
    y: component.y + component.height / 2
  });

  const handleSave = () => {
    onSave(components, connections);
  };

  const loadSampleDiagram = () => {
    const sampleComponents: Component[] = [
      {
        id: "user-1",
        type: "user",
        name: "Trading User",
        x: 50,
        y: 100,
        width: 120,
        height: 60,
        icon: Users,
        category: "external",
        color: "#6B7280"
      },
      {
        id: "react-1",
        type: "react",
        name: "Trading Interface",
        x: 250,
        y: 100,
        width: 120,
        height: 60,
        icon: Monitor,
        category: "frontend",
        color: "#61DAFB"
      },
      {
        id: "alb-1",
        type: "alb",
        name: "Load Balancer",
        x: 450,
        y: 100,
        width: 120,
        height: 60,
        icon: Activity,
        category: "networking",
        color: "#F58536"
      },
      {
        id: "api-gateway-1",
        type: "api-gateway",
        name: "API Gateway",
        x: 650,
        y: 100,
        width: 120,
        height: 60,
        icon: GitBranch,
        category: "networking",
        color: "#FF4B4B"
      },
      {
        id: "lambda-1",
        type: "lambda",
        name: "Settlement Engine",
        x: 450,
        y: 250,
        width: 120,
        height: 60,
        icon: Zap,
        category: "compute",
        color: "#FF9900"
      },
      {
        id: "rds-1",
        type: "rds",
        name: "Transaction DB",
        x: 250,
        y: 250,
        width: 120,
        height: 60,
        icon: Database,
        category: "storage",
        color: "#3F48CC"
      },
      {
        id: "bank-1",
        type: "bank",
        name: "Central Bank API",
        x: 650,
        y: 250,
        width: 120,
        height: 60,
        icon: Settings,
        category: "external",
        color: "#6B7280"
      }
    ];

    const sampleConnections: Connection[] = [
      { id: "user-react", from: "user-1", to: "react-1" },
      { id: "react-alb", from: "react-1", to: "alb-1" },
      { id: "alb-api", from: "alb-1", to: "api-gateway-1" },
      { id: "api-lambda", from: "api-gateway-1", to: "lambda-1" },
      { id: "lambda-rds", from: "lambda-1", to: "rds-1" },
      { id: "lambda-bank", from: "lambda-1", to: "bank-1" }
    ];

    setComponents(sampleComponents);
    setConnections(sampleConnections);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div className="border-b p-4 bg-gray-50">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Architecture Diagram Editor</h3>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={loadSampleDiagram}
              className="flex items-center gap-2"
            >
              <Upload className="h-4 w-4" />
              Load Sample
            </Button>
            <Button 
              onClick={handleSave} 
              size="sm"
              className="flex items-center gap-2"
            >
              <Save className="h-4 w-4" />
              Save Diagram
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Component Library */}
        <div className="w-80 border-r bg-gray-50 overflow-y-auto">
          <div className="p-4">
            <h4 className="font-semibold mb-4">Component Library</h4>
            <Tabs defaultValue="aws" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="aws">AWS</TabsTrigger>
                <TabsTrigger value="general">General</TabsTrigger>
              </TabsList>
              
              <TabsContent value="aws" className="space-y-4">
                {Object.entries(componentLibrary).filter(([category]) => 
                  !['frontend', 'external'].includes(category)
                ).map(([category, items]) => (
                  <div key={category}>
                    <h5 className="font-medium text-sm text-gray-600 mb-2 capitalize">
                      {category}
                    </h5>
                    <div className="grid grid-cols-2 gap-2">
                      {items.map((component) => {
                        const IconComponent = component.icon;
                        return (
                          <div
                            key={component.type}
                            draggable
                            onDragStart={(e) => handleDragStart(e, { ...component, category })}
                            className="p-3 border rounded-lg cursor-move hover:bg-white transition-colors flex flex-col items-center gap-1 text-xs"
                            style={{ borderColor: component.color }}
                          >
                            <IconComponent 
                              className="h-6 w-6" 
                              style={{ color: component.color }} 
                            />
                            <span className="text-center leading-tight">{component.name}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </TabsContent>
              
              <TabsContent value="general" className="space-y-4">
                {Object.entries(componentLibrary).filter(([category]) => 
                  ['frontend', 'external'].includes(category)
                ).map(([category, items]) => (
                  <div key={category}>
                    <h5 className="font-medium text-sm text-gray-600 mb-2 capitalize">
                      {category}
                    </h5>
                    <div className="grid grid-cols-2 gap-2">
                      {items.map((component) => {
                        const IconComponent = component.icon;
                        return (
                          <div
                            key={component.type}
                            draggable
                            onDragStart={(e) => handleDragStart(e, { ...component, category })}
                            className="p-3 border rounded-lg cursor-move hover:bg-white transition-colors flex flex-col items-center gap-1 text-xs"
                            style={{ borderColor: component.color }}
                          >
                            <IconComponent 
                              className="h-6 w-6" 
                              style={{ color: component.color }} 
                            />
                            <span className="text-center leading-tight">{component.name}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Canvas */}
        <div className="flex-1 relative">
          <div
            ref={canvasRef}
            className="w-full h-full relative bg-white"
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            style={{ 
              backgroundImage: "radial-gradient(circle, #e5e7eb 1px, transparent 1px)",
              backgroundSize: "20px 20px"
            }}
          >
            {/* Connections */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
              {connections.map((connection) => {
                const fromComponent = components.find(c => c.id === connection.from);
                const toComponent = components.find(c => c.id === connection.to);
                
                if (!fromComponent || !toComponent) return null;
                
                const from = getComponentCenter(fromComponent);
                const to = getComponentCenter(toComponent);
                
                return (
                  <line
                    key={connection.id}
                    x1={from.x}
                    y1={from.y}
                    x2={to.x}
                    y2={to.y}
                    stroke="#6B7280"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />
                );
              })}
              <defs>
                <marker
                  id="arrowhead"
                  markerWidth="10"
                  markerHeight="7"
                  refX="9"
                  refY="3.5"
                  orient="auto"
                >
                  <polygon
                    points="0 0, 10 3.5, 0 7"
                    fill="#6B7280"
                  />
                </marker>
              </defs>
            </svg>

            {/* Components */}
            {components.map((component) => {
              const IconComponent = component.icon;
              return (
                <div
                  key={component.id}
                  className={`absolute border-2 rounded-lg bg-white shadow-lg cursor-pointer transition-all ${
                    selectedComponent === component.id ? 'border-blue-500 shadow-xl' : 'border-gray-300'
                  } ${connecting === component.id ? 'border-green-500' : ''}`}
                  style={{
                    left: component.x,
                    top: component.y,
                    width: component.width,
                    height: component.height,
                    zIndex: 10
                  }}
                  onClick={() => setSelectedComponent(component.id)}
                  onDoubleClick={() => startConnection(component.id)}
                >
                  <div className="h-full flex flex-col items-center justify-center p-2">
                    <IconComponent 
                      className="h-6 w-6 mb-1" 
                      style={{ color: component.color }} 
                    />
                    <span className="text-xs font-medium text-center leading-tight">
                      {component.name}
                    </span>
                  </div>
                  
                  {/* Delete button */}
                  {selectedComponent === component.id && (
                    <Button
                      size="sm"
                      variant="destructive"
                      className="absolute -top-2 -right-2 h-6 w-6 p-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteComponent(component.id);
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              );
            })}

            {/* Instructions */}
            {components.length === 0 && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <Box className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p className="text-lg font-medium mb-2">Start Building Your Architecture</p>
                  <p className="text-sm">Drag components from the library to create your diagram</p>
                  <p className="text-sm mt-2">Double-click components to connect them</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Status Bar */}
      <div className="border-t p-2 bg-gray-50 text-sm text-gray-600">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span>{components.length} components</span>
            <span>{connections.length} connections</span>
            {connecting && (
              <Badge variant="outline" className="text-green-600 border-green-600">
                Connecting mode: Double-click target component
              </Badge>
            )}
          </div>
          <div className="text-xs">
            Drag from library • Double-click to connect • Click to select
          </div>
        </div>
      </div>
    </div>
  );
}