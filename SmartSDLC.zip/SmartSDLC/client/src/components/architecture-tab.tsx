import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  FileText, 
  Layers, 
  GitBranch, 
  Cpu, 
  Shield, 
  Rocket, 
  BarChart3,
  Edit,
  Save,
  X,
  Star,
  CheckCircle,
  Plus,
  Database,
  Server,
  Cloud,
  Globe,
  Lock,
  Zap,
  Network,
  Monitor,
  Settings,
  TrendingUp,
  AlertTriangle,
  Clock,
  Users,
  Target,
  Gauge
} from "lucide-react";

interface TechStackItem {
  category: string;
  technology: string;
  notes: string;
}

interface WellArchitectedPillar {
  pillar: string;
  score: number;
  notes: string;
  icon: string;
}

interface Architecture {
  id?: number;
  projectId: number;
  overview: string;
  systemArchitecture: string;
  contextDiagram: string;
  containerDiagram: string;
  deploymentDiagram: string;
  technologyStack: TechStackItem[];
  wellArchitectedScores: WellArchitectedPillar[];
  deploymentStrategy: string;
  observabilityPlan: string;
  updatedAt: string;
}

interface ArchitectureTabProps {
  projectId: number;
}

export function ArchitectureTab({ projectId }: ArchitectureTabProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editMode, setEditMode] = useState<string | null>(null);
  const [editData, setEditData] = useState<any>('');
  const [showComponentPanel, setShowComponentPanel] = useState(false);
  const [selectedDiagramType, setSelectedDiagramType] = useState<string>('');

  // Fetch architecture data
  const { data: archData, isLoading, error } = useQuery<Architecture>({
    queryKey: [`/api/projects/${projectId}/architecture`],
    retry: false,
  });

  console.log('🔍 Architecture data:', archData);
  console.log('🔍 Has contextDiagram:', !!archData?.contextDiagram);
  console.log('🔍 Loading state:', isLoading);
  console.log('🔍 Error:', error);

  // Update architecture mutation
  const updateArchitecture = useMutation({
    mutationFn: async (data: Partial<Architecture>) => {
      const response = await fetch(`/api/projects/${projectId}/architecture`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update architecture');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/architecture`] });
      toast({ title: "Architecture updated successfully" });
      setEditMode(null);
      setEditData('');
    },
    onError: () => {
      toast({ title: "Failed to update architecture", variant: "destructive" });
    },
  });

  const handleEdit = (section: string, currentValue: any) => {
    setEditMode(section);
    setEditData(currentValue || '');
  };

  const handleSave = async () => {
    if (!editMode) return;
    
    const updateData = { [editMode]: editData };
    await updateArchitecture.mutateAsync(updateData);
  };

  const handleCancel = () => {
    setEditMode(null);
    setEditData('');
  };

  const updateTechStackItem = (index: number, field: string, value: string) => {
    const newStack = [...(editData || [])];
    newStack[index] = { ...newStack[index], [field]: value };
    setEditData(newStack);
  };

  const updateWellArchitectedScore = (index: number, field: string, value: any) => {
    const newScores = [...(editData || [])];
    newScores[index] = { ...newScores[index], [field]: value };
    setEditData(newScores);
  };

  const architectureComponents = [
    { type: 'Trading', icon: GitBranch, label: 'Trade Engine', template: 'TradeEngine[Trade Processing Engine]' },
    { type: 'Risk', icon: Shield, label: 'Risk Management', template: 'RiskMgmt[Real-time Risk Management]' },
    { type: 'Settlement', icon: Layers, label: 'Settlement Network', template: 'Settlement[Multi-jurisdiction Settlement]' },
    { type: 'Compliance', icon: Lock, label: 'Regulatory Compliance', template: 'Compliance[Basel III/MiFID II Compliance]' },
    { type: 'Database', icon: Database, label: 'Financial Database', template: 'FinDB[(High-performance Financial DB)]' },
    { type: 'Gateway', icon: Globe, label: 'API Gateway', template: 'Gateway[Secure Financial API Gateway]' },
    { type: 'Analytics', icon: BarChart3, label: 'Risk Analytics', template: 'Analytics[Real-time Risk Analytics]' },
    { type: 'Messaging', icon: Zap, label: 'Message Queue', template: 'MsgQueue[High-throughput Message Queue]' },
  ];

  const addComponentToDiagram = (component: any) => {
    if (!editData || !selectedDiagramType) return;
    
    const newComponent = `\n    ${component.template}`;
    setEditData(editData + newComponent);
    setShowComponentPanel(false);
  };

  const renderMermaidDiagram = (diagram: string, title: string, diagramType: string) => {
    const isEditing = editMode === diagramType;
    
    if (!diagram && !isEditing) {
      return <p className="text-gray-500 italic">No {title.toLowerCase()} diagram available</p>;
    }

    return (
      <div className="space-y-4">
        {isEditing ? (
          <div className="grid grid-cols-4 gap-4">
            <div className="col-span-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Mermaid Diagram Code</Label>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setSelectedDiagramType(diagramType);
                      setShowComponentPanel(true);
                    }}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Component
                  </Button>
                </div>
                <Textarea
                  value={editData}
                  onChange={(e) => setEditData(e.target.value)}
                  className="min-h-64 font-mono text-sm"
                  placeholder="Enter Mermaid diagram code..."
                />
              </div>
            </div>
            <div className="col-span-1">
              <div className="space-y-2">
                <Label>Live Preview</Label>
                <div className="bg-gray-50 p-4 rounded border min-h-64 overflow-auto">
                  <pre className="text-xs whitespace-pre-wrap">{editData}</pre>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-white border-2 border-gray-200 rounded-lg p-6 shadow-lg">
              <div className="mb-4">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">{title}</h3>
                <div className="bg-gray-50 p-6 rounded-lg border">
                  <pre className="text-xs font-mono whitespace-pre-wrap overflow-x-auto text-gray-700 leading-relaxed max-h-96 overflow-y-auto">
{diagram}
                  </pre>
                </div>
              </div>
              <div className="text-sm text-blue-600 bg-blue-50 p-3 rounded border-l-4 border-blue-500">
                💡 <strong>Mermaid Diagram:</strong> This diagram uses Mermaid syntax for visualization. Copy the code above to any Mermaid viewer for interactive rendering.
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-lg">Loading architecture documentation...</div>
      </div>
    );
  }

  if (!archData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Architecture Documentation</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">No architecture documentation found for this project.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="diagrams">Diagrams</TabsTrigger>
          <TabsTrigger value="tech-stack">Tech Stack</TabsTrigger>
          <TabsTrigger value="well-architected">Well-Architected</TabsTrigger>
          <TabsTrigger value="deployment">Deployment</TabsTrigger>
          <TabsTrigger value="observability">Observability</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-8">
          {/* Executive Summary */}
          <Card className="border-l-4 border-l-blue-600">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Target className="h-6 w-6 text-blue-600" />
                Executive Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h3 className="font-semibold text-lg mb-3">Platform Vision</h3>
                <p className="text-gray-700 leading-relaxed">
                  Enterprise-grade distributed reconciliation and settlement platform designed for high-frequency financial operations. 
                  Built on AWS cloud-native architecture with event-driven microservices, enabling real-time processing of $3.5 trillion 
                  daily trading volume across 45+ global markets with sub-5ms latency and 99.99% uptime guarantee.
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-600" />
                    Business Objectives
                  </h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      Reduce settlement risk by 85% through real-time processing
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      Achieve straight-through processing rate of 99.8%
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      Enable T+0 settlement across major asset classes
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      Ensure regulatory compliance across all jurisdictions
                    </li>
                  </ul>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-semibold flex items-center gap-2">
                    <Gauge className="h-5 w-5 text-blue-600" />
                    Technical Capabilities
                  </h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <Star className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                      150,000+ transactions per second processing capacity
                    </li>
                    <li className="flex items-start gap-2">
                      <Star className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                      Multi-region active-active deployment architecture
                    </li>
                    <li className="flex items-start gap-2">
                      <Star className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                      Event-driven architecture with Apache Kafka backbone
                    </li>
                    <li className="flex items-start gap-2">
                      <Star className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                      Advanced reconciliation engine with ML-powered matching
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Architecture Principles */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Settings className="h-6 w-6 text-purple-600" />
                Architectural Principles & Design Philosophy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-6">
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Cloud className="h-5 w-5 text-purple-600" />
                    Cloud-Native Design
                  </h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Containerized microservices architecture</li>
                    <li>• Kubernetes orchestration with auto-scaling</li>
                    <li>• Infrastructure as Code (Terraform)</li>
                    <li>• Multi-AZ deployment for high availability</li>
                  </ul>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Zap className="h-5 w-5 text-green-600" />
                    Event-Driven Architecture
                  </h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Apache Kafka as event streaming backbone</li>
                    <li>• CQRS pattern for read/write separation</li>
                    <li>• Event sourcing for complete audit trails</li>
                    <li>• Asynchronous processing for scalability</li>
                  </ul>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Shield className="h-5 w-5 text-blue-600" />
                    Security & Compliance
                  </h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Zero-trust security architecture</li>
                    <li>• End-to-end encryption at rest and in transit</li>
                    <li>• Multi-layer authentication and authorization</li>
                    <li>• Comprehensive audit logging and monitoring</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Key Metrics Dashboard */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <BarChart3 className="h-6 w-6 text-orange-600" />
                System Performance Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4 rounded-lg mb-2">
                    <div className="text-3xl font-bold">150K+</div>
                    <div className="text-sm opacity-90">TPS</div>
                  </div>
                  <div className="text-sm text-gray-600">Peak Transaction Processing</div>
                </div>
                
                <div className="text-center">
                  <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-4 rounded-lg mb-2">
                    <div className="text-3xl font-bold">&lt;5ms</div>
                    <div className="text-sm opacity-90">Latency</div>
                  </div>
                  <div className="text-sm text-gray-600">End-to-End Processing</div>
                </div>
                
                <div className="text-center">
                  <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-4 rounded-lg mb-2">
                    <div className="text-3xl font-bold">99.99%</div>
                    <div className="text-sm opacity-90">Uptime</div>
                  </div>
                  <div className="text-sm text-gray-600">Service Level Agreement</div>
                </div>
                
                <div className="text-center">
                  <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white p-4 rounded-lg mb-2">
                    <div className="text-3xl font-bold">99.8%</div>
                    <div className="text-sm opacity-90">STP</div>
                  </div>
                  <div className="text-sm text-gray-600">Straight-Through Processing</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="architecture" className="space-y-8">
          {/* High-Level Architecture Diagram */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Layers className="h-6 w-6 text-blue-600" />
                Distributed Big Data Reconciliation Engine - Solution Architecture
              </CardTitle>
              <p className="text-gray-600">Enterprise-grade architecture based on AWS Big Data best practices for financial reconciliation</p>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 p-6 rounded-lg border-2 border-dashed border-gray-300">
                <pre className="text-xs font-mono whitespace-pre-wrap overflow-x-auto text-gray-700 leading-relaxed max-h-96 overflow-y-auto">
{`graph TB
    subgraph "🌍 External Data Sources & Market Feeds"
        subgraph "Trading Venues"
            NYSE["📈 NYSE Pillar<br/>• Market Data Feed<br/>• Order Execution<br/>• Trade Confirmations<br/>• Real-time: 40GB/hour"]
            NASDAQ["💻 NASDAQ TotalView<br/>• Level 2 Market Data<br/>• ITCH Protocol<br/>• Cross/Imbalance Data<br/>• Real-time: 35GB/hour"]
            CME["📊 CME Group<br/>• Futures & Options Data<br/>• iLink 3 Protocol<br/>• Market by Order<br/>• Real-time: 60GB/hour"]
            ICE["🧊 ICE Data Services<br/>• Fixed Income Data<br/>• Energy Derivatives<br/>• Global Exchange Data<br/>• Real-time: 25GB/hour"]
        end
        
        subgraph "Prime Brokers & Custodians"
            GS["🏦 Goldman Sachs<br/>• Prime Brokerage<br/>• Securities Lending<br/>• Position Reports<br/>• Daily: 500MB reconciliation"]
            MS["📊 Morgan Stanley<br/>• Institutional Securities<br/>• Cash Management<br/>• Trade Settlement<br/>• Daily: 450MB reconciliation"]
            JPM["🏛️ JPMorgan Chase<br/>• Global Custody<br/>• Corporate Actions<br/>• FX Settlement<br/>• Daily: 600MB reconciliation"]
        end
        
        subgraph "Regulatory & Reference Data"
            DTCC["🏦 DTCC<br/>• Trade Repository<br/>• Corporate Actions<br/>• Golden Copy Data<br/>• Daily: 2GB regulatory"]
            Bloomberg["📈 Bloomberg<br/>• Reference Data<br/>• Security Master<br/>• Corporate Actions<br/>• Daily: 1.5GB updates"]
            Refinitiv["📊 Refinitiv<br/>• Pricing Data<br/>• Corporate Actions<br/>• Entity Data<br/>• Daily: 1.2GB updates"]
        end
    end
    
    subgraph "⚡ AWS Data Ingestion Layer"
        subgraph "Real-time Streaming"
            Kinesis["🌊 Amazon Kinesis Data Streams<br/>📊 Configuration:<br/>• 50 shards per stream<br/>• 1MB/sec per shard<br/>• 7-day retention<br/>• 150+ concurrent producers<br/><br/>💰 Cost: $2,500/month<br/>⚡ Latency: <200ms"]
            
            KinesisFirehose["🔥 Kinesis Data Firehose<br/>📊 Configuration:<br/>• S3 delivery every 60 seconds<br/>• 128MB buffer size<br/>• GZIP compression<br/>• Error record handling<br/><br/>💰 Cost: $1,200/month<br/>⚡ Latency: <1 minute"]
        end
        
        subgraph "Batch Processing"
            SQS["📬 Amazon SQS<br/>📊 Configuration:<br/>• FIFO queues for ordering<br/>• 14-day message retention<br/>• Dead letter queues<br/>• Batch processing (10 msgs)<br/><br/>💰 Cost: $300/month<br/>⚡ Throughput: 3,000 msgs/sec"]
            
            S3Staging["📦 S3 Staging Buckets<br/>📊 Configuration:<br/>• Multi-part upload (>100MB)<br/>• Standard-IA after 30 days<br/>• Glacier after 90 days<br/>• Cross-region replication<br/><br/>💰 Cost: $5,000/month<br/>📏 Storage: 500TB/month"]
        end
    end
    
    subgraph "🏗️ AWS Data Processing Engine"
        subgraph "Real-time Processing"
            KinesisAnalytics["📊 Kinesis Data Analytics<br/>📊 Configuration:<br/>• SQL-based stream processing<br/>• 1-minute tumbling windows<br/>• Anomaly detection models<br/>• Real-time aggregations<br/><br/>💰 Cost: $1,800/month<br/>⚡ Processing: <5 second latency"]
            
            Lambda["⚡ AWS Lambda Functions<br/>📊 Configuration:<br/>• 3008MB memory allocation<br/>• 15-minute max execution<br/>• Concurrent executions: 10,000<br/>• Event-driven triggers<br/><br/>💰 Cost: $3,500/month<br/>⚡ Invocations: 50M/month"]
        end
        
        subgraph "Big Data Processing"
            EMR["🏗️ Amazon EMR Cluster<br/>📊 Configuration:<br/>• Master: m5.2xlarge (1 node)<br/>• Core: r5.4xlarge (20 nodes)<br/>• Task: m5.xlarge (50 nodes)<br/>• Spark 3.3, Hadoop 3.3<br/>• Auto-scaling enabled<br/><br/>💰 Cost: $25,000/month<br/>⚡ Processing: 10TB/hour"]
            
            Glue["🔗 AWS Glue ETL<br/>📊 Configuration:<br/>• Python/Scala ETL jobs<br/>• Data catalog with 50K tables<br/>• Job bookmarks enabled<br/>• Max concurrent runs: 100<br/><br/>💰 Cost: $4,000/month<br/>⚡ Jobs: 2,000 runs/day"]
        end
        
        subgraph "Reconciliation Engine"
            StepFunctions["🔄 AWS Step Functions<br/>📊 Configuration:<br/>• Express workflows<br/>• Parallel processing branches<br/>• Error handling & retries<br/>• CloudWatch integration<br/><br/>💰 Cost: $800/month<br/>⚡ Executions: 1M/month"]
            
            CustomReconciliation["🎯 Custom Reconciliation Logic<br/>📊 Algorithms:<br/>• Fuzzy matching (85% accuracy)<br/>• ML-based trade matching<br/>• Exception workflow routing<br/>• SLA monitoring<br/><br/>📈 Performance:<br/>• 99.8% auto-match rate<br/>• <30 second processing<br/>• 150K trades/hour capacity"]
        end
    end
    
    subgraph "💾 AWS Data Storage Layer"
        subgraph "Data Lake"
            S3DataLake["🏞️ S3 Data Lake<br/>📊 Architecture:<br/>• Raw: 500TB (landing zone)<br/>• Processed: 200TB (curated)<br/>• Analytics: 100TB (aggregated)<br/>• Lifecycle policies enabled<br/><br/>🗂️ Partitioning:<br/>• By trade date (YYYY/MM/DD)<br/>• By asset class<br/>• By settlement status<br/><br/>💰 Cost: $15,000/month"]
            
            Athena["🔍 Amazon Athena<br/>📊 Configuration:<br/>• Presto-based SQL engine<br/>• Columnar storage (Parquet)<br/>• Partition projection<br/>• Query result caching<br/><br/>📊 Usage:<br/>• 50TB data scanned/month<br/>• 10,000 queries/day<br/>• Average query: 2.5 seconds<br/><br/>💰 Cost: $2,500/month"]
        end
        
        subgraph "Operational Databases"
            RDS["🗄️ Amazon RDS PostgreSQL<br/>📊 Configuration:<br/>• Multi-AZ deployment<br/>• db.r5.8xlarge instances<br/>• 20TB provisioned IOPS SSD<br/>• Read replicas (3 regions)<br/><br/>📊 Performance:<br/>• 40,000 IOPS capacity<br/>• 16TB database size<br/>• 99.99% availability<br/><br/>💰 Cost: $8,000/month"]
            
            DynamoDB["⚡ Amazon DynamoDB<br/>📊 Configuration:<br/>• On-demand billing mode<br/>• Global secondary indexes (5)<br/>• Point-in-time recovery<br/>• DynamoDB Streams enabled<br/><br/>📊 Performance:<br/>• 25,000 RCU/WCU<br/>• <10ms latency (p99)<br/>• Multi-region replication<br/><br/>💰 Cost: $6,000/month"]
            
            ElastiCache["🚀 Amazon ElastiCache<br/>📊 Configuration:<br/>• Redis cluster mode<br/>• cache.r6g.2xlarge (6 nodes)<br/>• Multi-AZ with failover<br/>• Encryption in transit/rest<br/><br/>📊 Performance:<br/>• 500GB memory capacity<br/>• 500,000 ops/second<br/>• <1ms latency<br/><br/>💰 Cost: $3,000/month"]
        end
    end
    
    subgraph "🎯 AWS Analytics & ML Layer"
        subgraph "Business Intelligence"
            QuickSight["📊 Amazon QuickSight<br/>📊 Features:<br/>• Real-time dashboards<br/>• SPICE in-memory engine<br/>• ML-powered insights<br/>• Embedded analytics<br/><br/>👥 Users:<br/>• 500 business users<br/>• 50 admin users<br/>• 24/7 monitoring dashboards<br/><br/>💰 Cost: $2,000/month"]
            
            Redshift["🏭 Amazon Redshift<br/>📊 Configuration:<br/>• ra3.4xlarge nodes (10)<br/>• Managed storage (500TB)<br/>• Spectrum for S3 queries<br/>• Concurrency scaling<br/><br/>📊 Performance:<br/>• Complex queries <30 seconds<br/>• 500 concurrent users<br/>• Columnar compression<br/><br/>💰 Cost: $15,000/month"]
        end
        
        subgraph "Machine Learning"
            SageMaker["🤖 Amazon SageMaker<br/>📊 ML Models:<br/>• Trade matching algorithms<br/>• Anomaly detection models<br/>• Risk scoring models<br/>• Fraud detection pipeline<br/><br/>🎯 Performance:<br/>• 95% accuracy rate<br/>• Real-time inference<br/>• A/B testing framework<br/><br/>💰 Cost: $4,500/month"]
            
            Comprehend["📝 Amazon Comprehend<br/>📊 NLP Processing:<br/>• Trade description parsing<br/>• Entity recognition<br/>• Sentiment analysis<br/>• Custom classification<br/><br/>📊 Volume:<br/>• 1M documents/month<br/>• 25 languages supported<br/>• Custom models (5)<br/><br/>💰 Cost: $1,000/month"]
        end
    end
    
    subgraph "🔐 Security & Compliance Layer"
        subgraph "Identity & Access"
            IAM["🔑 AWS IAM<br/>📊 Configuration:<br/>• Role-based access control<br/>• Multi-factor authentication<br/>• Cross-account access<br/>• Service-linked roles<br/><br/>👥 Access Management:<br/>• 1,000+ users<br/>• 50+ roles<br/>• 200+ policies<br/>• Regular access reviews"]
            
            Cognito["👤 Amazon Cognito<br/>📊 Configuration:<br/>• User pools (10,000 users)<br/>• Identity pools<br/>• SAML/OIDC federation<br/>• Advanced security features<br/><br/>🔐 Security:<br/>• MFA enforcement<br/>• Risk-based authentication<br/>• Device tracking<br/><br/>💰 Cost: $500/month"]
        end
        
        subgraph "Monitoring & Compliance"
            CloudTrail["📋 AWS CloudTrail<br/>📊 Configuration:<br/>• All regions enabled<br/>• S3 log delivery<br/>• CloudWatch integration<br/>• Insight events<br/><br/>📊 Compliance:<br/>• 100% API call logging<br/>• Immutable audit trail<br/>• Real-time monitoring<br/><br/>💰 Cost: $600/month"]
            
            Config["⚙️ AWS Config<br/>📊 Configuration:<br/>• All resource types<br/>• Compliance rules (100+)<br/>• Remediation actions<br/>• Change notifications<br/><br/>📊 Governance:<br/>• 99% compliance score<br/>• Automated remediation<br/>• Change tracking<br/><br/>💰 Cost: $1,200/month"]
        end
    end
    
    subgraph "📊 Monitoring & Observability"
        CloudWatch["📈 Amazon CloudWatch<br/>📊 Metrics & Logs:<br/>• Custom metrics (5,000+)<br/>• Log groups (500+)<br/>• Alarms (1,000+)<br/>• Dashboards (50+)<br/><br/>📊 Performance:<br/>• 99.9% data point accuracy<br/>• 1-minute resolution<br/>• 15-month retention<br/><br/>💰 Cost: $3,000/month"]
        
        XRay["🔍 AWS X-Ray<br/>📊 Distributed Tracing:<br/>• Service map visualization<br/>• Request flow analysis<br/>• Performance bottlenecks<br/>• Error root cause analysis<br/><br/>📊 Coverage:<br/>• 100% service tracing<br/>• <1% performance overhead<br/>• Real-time insights<br/><br/>💰 Cost: $800/month"]
        
        OpenSearch["🔎 Amazon OpenSearch<br/>📊 Log Analytics:<br/>• 3-node cluster (t3.medium)<br/>• 1TB storage per node<br/>• Kibana dashboards<br/>• Alerting & anomaly detection<br/><br/>📊 Performance:<br/>• 10GB daily log ingestion<br/>• <100ms search latency<br/>• 90-day retention<br/><br/>💰 Cost: $2,200/month"]
    end
    
    subgraph "📱 Client Applications & APIs"
        subgraph "Web Applications"
            ReactApp["⚛️ React Trading Dashboard<br/>📊 Features:<br/>• Real-time position monitoring<br/>• Trade reconciliation status<br/>• Exception management<br/>• Performance analytics<br/><br/>👥 Users:<br/>• 500 concurrent traders<br/>• 50 operations staff<br/>• 20 risk managers"]
            
            MobileApp["📱 Mobile Reconciliation App<br/>📊 Features:<br/>• Push notifications<br/>• Offline capabilities<br/>• Biometric authentication<br/>• Real-time alerts<br/><br/>👥 Users:<br/>• 200 mobile users<br/>• iOS/Android support<br/>• 24/7 availability"]
        end
        
        subgraph "API Layer"
            APIGateway["🌐 Amazon API Gateway<br/>📊 Configuration:<br/>• REST & WebSocket APIs<br/>• 10,000 req/sec throttling<br/>• API key management<br/>• WAF integration<br/><br/>📊 Performance:<br/>• <50ms latency (p95)<br/>• 99.99% availability<br/>• Auto-scaling enabled<br/><br/>💰 Cost: $1,500/month"]
            
            GraphQL["🔗 AWS AppSync GraphQL<br/>📊 Configuration:<br/>• Real-time subscriptions<br/>• Offline sync capabilities<br/>• Multiple data sources<br/>• Fine-grained authorization<br/><br/>📊 Performance:<br/>• 500K operations/month<br/>• Real-time updates<br/>• Cached responses<br/><br/>💰 Cost: $1,000/month"]
        end
    end
    
    %% Data Flow Connections
    NYSE --> Kinesis
    NASDAQ --> Kinesis
    CME --> Kinesis
    ICE --> Kinesis
    
    GS --> SQS
    MS --> SQS
    JPM --> SQS
    
    DTCC --> S3Staging
    Bloomberg --> S3Staging
    Refinitiv --> S3Staging
    
    Kinesis --> KinesisFirehose
    Kinesis --> KinesisAnalytics
    Kinesis --> Lambda
    
    KinesisFirehose --> S3DataLake
    SQS --> Lambda
    S3Staging --> Glue
    
    KinesisAnalytics --> ElastiCache
    Lambda --> DynamoDB
    Lambda --> StepFunctions
    
    Glue --> S3DataLake
    EMR --> S3DataLake
    StepFunctions --> CustomReconciliation
    
    S3DataLake --> Athena
    S3DataLake --> Redshift
    DynamoDB --> SageMaker
    
    Athena --> QuickSight
    Redshift --> QuickSight
    SageMaker --> CustomReconciliation
    
    ElastiCache --> APIGateway
    DynamoDB --> APIGateway
    RDS --> APIGateway
    
    APIGateway --> ReactApp
    APIGateway --> MobileApp
    GraphQL --> ReactApp
    
    %% Monitoring Connections
    CloudWatch --> XRay
    CloudTrail --> OpenSearch
    Config --> CloudWatch
    
    %% Styling
    classDef external fill:#e3f2fd,stroke:#1976d2,stroke-width:2px,color:#000
    classDef ingestion fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px,color:#000
    classDef processing fill:#fff3e0,stroke:#f57c00,stroke-width:2px,color:#000
    classDef storage fill:#e8f5e8,stroke:#388e3c,stroke-width:2px,color:#000
    classDef analytics fill:#fce4ec,stroke:#c2185b,stroke-width:2px,color:#000
    classDef security fill:#fff8e1,stroke:#fbc02d,stroke-width:2px,color:#000
    classDef monitoring fill:#f1f8e9,stroke:#689f38,stroke-width:2px,color:#000
    classDef client fill:#ffebee,stroke:#d32f2f,stroke-width:2px,color:#000
    
    class NYSE,NASDAQ,CME,ICE,GS,MS,JPM,DTCC,Bloomberg,Refinitiv external
    class Kinesis,KinesisFirehose,SQS,S3Staging ingestion
    class KinesisAnalytics,Lambda,EMR,Glue,StepFunctions,CustomReconciliation processing
    class S3DataLake,Athena,RDS,DynamoDB,ElastiCache storage
    class QuickSight,Redshift,SageMaker,Comprehend analytics
    class IAM,Cognito,CloudTrail,Config security
    class CloudWatch,XRay,OpenSearch monitoring
    class ReactApp,MobileApp,APIGateway,GraphQL client`}
                </pre>
              </div>
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                <h4 className="font-semibold text-blue-800 mb-2">Architecture Highlights</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <strong>Real-time Processing:</strong> Apache Kafka streams with sub-second latency for critical trade matching and reconciliation workflows.
                  </div>
                  <div>
                    <strong>Scalable Storage:</strong> 500TB+ data lake with intelligent tiering and lifecycle management for cost optimization.
                  </div>
                  <div>
                    <strong>ML-Powered Matching:</strong> Advanced algorithms achieving 99.8% straight-through processing with fuzzy matching capabilities.
                  </div>
                  <div>
                    <strong>Global Compliance:</strong> Multi-jurisdiction regulatory reporting with real-time audit trails and immutable logs.
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="data-flow" className="space-y-8">
          {/* Data Processing Pipeline */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <GitBranch className="h-6 w-6 text-green-600" />
                Enterprise Data Processing Pipeline
              </CardTitle>
              <p className="text-gray-600">End-to-end data flow for reconciliation and settlement processing</p>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Pipeline Stages */}
              <div className="grid grid-cols-5 gap-4">
                <div className="text-center">
                  <div className="bg-blue-100 p-4 rounded-lg mb-2">
                    <Globe className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                    <div className="font-semibold text-sm">Data Ingestion</div>
                  </div>
                  <div className="text-xs text-gray-600">160GB/hour from 150+ sources</div>
                </div>
                
                <div className="text-center">
                  <div className="bg-green-100 p-4 rounded-lg mb-2">
                    <Zap className="h-8 w-8 text-green-600 mx-auto mb-2" />
                    <div className="font-semibold text-sm">Stream Processing</div>
                  </div>
                  <div className="text-xs text-gray-600">Real-time validation & enrichment</div>
                </div>
                
                <div className="text-center">
                  <div className="bg-purple-100 p-4 rounded-lg mb-2">
                    <Cpu className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                    <div className="font-semibold text-sm">Reconciliation</div>
                  </div>
                  <div className="text-xs text-gray-600">ML-powered matching algorithms</div>
                </div>
                
                <div className="text-center">
                  <div className="bg-orange-100 p-4 rounded-lg mb-2">
                    <Database className="h-8 w-8 text-orange-600 mx-auto mb-2" />
                    <div className="font-semibold text-sm">Data Lake Storage</div>
                  </div>
                  <div className="text-xs text-gray-600">Partitioned for analytics</div>
                </div>
                
                <div className="text-center">
                  <div className="bg-red-100 p-4 rounded-lg mb-2">
                    <BarChart3 className="h-8 w-8 text-red-600 mx-auto mb-2" />
                    <div className="font-semibold text-sm">Analytics & BI</div>
                  </div>
                  <div className="text-xs text-gray-600">Real-time dashboards</div>
                </div>
              </div>
              
              {/* Detailed Flow Description */}
              <div className="bg-gray-50 p-6 rounded-lg">
                <h4 className="font-semibold mb-4">Data Processing Flow Details</h4>
                <div className="space-y-4">
                  <div className="border-l-4 border-blue-500 pl-4">
                    <h5 className="font-medium text-blue-700">1. Multi-Source Data Ingestion</h5>
                    <p className="text-sm text-gray-600 mt-1">
                      Real-time ingestion from trading venues (NYSE, NASDAQ, CME), prime brokers (Goldman Sachs, Morgan Stanley), 
                      and reference data providers (Bloomberg, Refinitiv) using Kinesis Data Streams with 50 shards per stream, 
                      achieving 160GB/hour throughput with sub-200ms latency.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-green-500 pl-4">
                    <h5 className="font-medium text-green-700">2. Stream Processing & Validation</h5>
                    <p className="text-sm text-gray-600 mt-1">
                      Kinesis Data Analytics performs real-time validation, data enrichment, and preliminary matching using 
                      SQL-based stream processing with 1-minute tumbling windows. Lambda functions handle complex business 
                      logic and route data to appropriate downstream systems.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-purple-500 pl-4">
                    <h5 className="font-medium text-purple-700">3. Advanced Reconciliation Engine</h5>
                    <p className="text-sm text-gray-600 mt-1">
                      Custom reconciliation algorithms deployed on EMR clusters process 150K+ trades per hour using machine 
                      learning models for fuzzy matching, achieving 99.8% straight-through processing rate with automated 
                      exception handling workflows.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-orange-500 pl-4">
                    <h5 className="font-medium text-orange-700">4. Intelligent Data Lake Storage</h5>
                    <p className="text-sm text-gray-600 mt-1">
                      500TB+ S3 data lake with intelligent partitioning by trade date, asset class, and settlement status. 
                      Automated lifecycle policies transition data to IA and Glacier storage classes, optimizing costs while 
                      maintaining query performance through Athena and Redshift.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-red-500 pl-4">
                    <h5 className="font-medium text-red-700">5. Real-time Analytics & Reporting</h5>
                    <p className="text-sm text-gray-600 mt-1">
                      QuickSight provides real-time dashboards for 500+ business users with SPICE in-memory engine. 
                      Redshift analytics warehouse enables complex queries on historical data with Spectrum for S3 queries, 
                      supporting regulatory reporting and business intelligence.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="microservices" className="space-y-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Cpu className="h-5 w-5" />
                Technology Stack
              </CardTitle>
              {editMode !== 'technologyStack' && (
                <Button variant="outline" size="sm" onClick={() => handleEdit('technologyStack', archData.technologyStack)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editMode === 'technologyStack' ? (
                <div className="space-y-4">
                  <div className="space-y-3">
                    {(editData || []).map((item: TechStackItem, index: number) => (
                      <div key={index} className="grid grid-cols-3 gap-3 p-3 border rounded">
                        <Input
                          value={item.category}
                          onChange={(e) => updateTechStackItem(index, 'category', e.target.value)}
                          placeholder="Category"
                        />
                        <Input
                          value={item.technology}
                          onChange={(e) => updateTechStackItem(index, 'technology', e.target.value)}
                          placeholder="Technology"
                        />
                        <Input
                          value={item.notes}
                          onChange={(e) => updateTechStackItem(index, 'notes', e.target.value)}
                          placeholder="Notes"
                        />
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleSave} disabled={updateArchitecture.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancel}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {Object.entries(
                    Array.isArray(archData.technologyStack) 
                      ? archData.technologyStack.reduce((acc: any, item) => {
                          if (!acc[item.category]) acc[item.category] = [];
                          acc[item.category].push(item);
                          return acc;
                        }, {})
                      : {}
                  ).map(([category, items]: [string, any]) => (
                    <div key={category}>
                      <h3 className="font-semibold text-lg mb-2">{category}</h3>
                      <div className="space-y-2">
                        {items.map((item: TechStackItem, index: number) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded">
                            <div>
                              <span className="font-medium">{item.technology}</span>
                              <p className="text-sm text-gray-600">{item.notes}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="well-architected" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                AWS Well-Architected Framework
              </CardTitle>
              {editMode !== 'wellArchitectedScores' && (
                <Button variant="outline" size="sm" onClick={() => handleEdit('wellArchitectedScores', archData.wellArchitectedScores)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editMode === 'wellArchitectedScores' ? (
                <div className="space-y-4">
                  <div className="space-y-3">
                    {(editData || []).map((pillar: WellArchitectedPillar, index: number) => (
                      <div key={index} className="grid grid-cols-4 gap-3 p-3 border rounded items-center">
                        <span className="font-medium">{pillar.icon} {pillar.pillar}</span>
                        <Input
                          type="number"
                          min="1"
                          max="100"
                          value={pillar.score}
                          onChange={(e) => updateWellArchitectedScore(index, 'score', parseInt(e.target.value))}
                          className="w-20"
                        />
                        <Input
                          value={pillar.notes}
                          onChange={(e) => updateWellArchitectedScore(index, 'notes', e.target.value)}
                          placeholder="Notes"
                          className="col-span-2"
                        />
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleSave} disabled={updateArchitecture.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancel}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid gap-4">
                    {(archData.wellArchitectedScores || []).map((pillar, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{pillar.icon}</span>
                          <div>
                            <h3 className="font-semibold">{pillar.pillar}</h3>
                            <p className="text-sm text-gray-600">{pillar.notes}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-lg">{pillar.score}/100</span>
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-4 w-4 ${
                                  star <= Math.ceil(pillar.score / 20) ? 'text-yellow-400 fill-current' : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="deployment" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Rocket className="h-5 w-5" />
                Deployment Strategy
              </CardTitle>
              {editMode !== 'deploymentStrategy' && (
                <Button variant="outline" size="sm" onClick={() => handleEdit('deploymentStrategy', archData.deploymentStrategy)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editMode === 'deploymentStrategy' ? (
                <div className="space-y-4">
                  <Textarea
                    value={editData}
                    onChange={(e) => setEditData(e.target.value)}
                    className="min-h-24"
                    placeholder="Describe deployment strategy, environments, and tools..."
                  />
                  <div className="flex gap-2">
                    <Button onClick={handleSave} disabled={updateArchitecture.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancel}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-gray-700">{archData.deploymentStrategy || 'No deployment strategy documentation available.'}</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="observability" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Observability Plan
              </CardTitle>
              {editMode !== 'observabilityPlan' && (
                <Button variant="outline" size="sm" onClick={() => handleEdit('observabilityPlan', archData.observabilityPlan)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editMode === 'observabilityPlan' ? (
                <div className="space-y-4">
                  <Textarea
                    value={editData}
                    onChange={(e) => setEditData(e.target.value)}
                    className="min-h-24"
                    placeholder="Describe monitoring, alerting, and observability strategy..."
                  />
                  <div className="flex gap-2">
                    <Button onClick={handleSave} disabled={updateArchitecture.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancel}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-gray-700">{archData.observabilityPlan || 'No observability plan documentation available.'}</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Component Addition Panel */}
      {showComponentPanel && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Add Architecture Component</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowComponentPanel(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {architectureComponents.map((component, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="flex flex-col items-center gap-2 h-20"
                  onClick={() => addComponentToDiagram(component)}
                >
                  <component.icon className="h-6 w-6" />
                  <span className="text-sm">{component.label}</span>
                </Button>
              ))}
            </div>
            <div className="mt-4 p-3 bg-gray-50 rounded">
              <p className="text-sm text-gray-600">
                Click a component to add it to your {selectedDiagramType} diagram. You can then customize the Mermaid code as needed.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}