import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Layers, 
  Save, 
  Zap, 
  Database, 
  Shield, 
  Server, 
  Settings,
  Plus,
  Eye,
  Trash2
} from "lucide-react";

interface DiagramComponent {
  id: string;
  type: 'frontend' | 'backend' | 'database' | 'api' | 'security' | 'cache' | 'queue';
  name: string;
  description: string;
  technology: string;
  position: { x: number; y: number };
  connections?: string[];
}

interface ArchitectureDiagram {
  id: string;
  projectId: number;
  name: string;
  type: 'system' | 'deployment' | 'security' | 'data-flow';
  components: DiagramComponent[];
  notes: string;
}

interface ArchitectDiagramEditorProps {
  projectId: number;
  onClose: () => void;
}

export function ArchitectDiagramEditor({ projectId, onClose }: ArchitectDiagramEditorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedComponent, setSelectedComponent] = useState<DiagramComponent | null>(null);
  
  const [diagram, setDiagram] = useState<ArchitectureDiagram>({
    id: `diagram-${Date.now()}`,
    projectId,
    name: "Financial Reporting Architecture",
    type: "system",
    components: [],
    notes: ""
  });

  // Auto-generate Well-Architected framework architecture on component mount
  useEffect(() => {
    // Generate immediately when architect opens the studio
    setTimeout(() => generateArchitectureMutation.mutate(), 100);
  }, [projectId]);

  // Enhanced AWS component templates with VPC and networking
  const componentTemplates = {
    frontend: {
      type: 'frontend' as const,
      name: 'Frontend App',
      description: 'User interface layer',
      technology: 'React + TypeScript',
      icon: <Server className="h-4 w-4" />
    },
    backend: {
      type: 'backend' as const,
      name: 'Backend Service',
      description: 'Business logic layer',
      technology: 'AWS Lambda',
      icon: <Server className="h-4 w-4" />
    },
    database: {
      type: 'database' as const,
      name: 'Database',
      description: 'Data storage layer',
      technology: 'AWS RDS',
      icon: <Database className="h-4 w-4" />
    },
    api: {
      type: 'api' as const,
      name: 'API Gateway',
      description: 'API management layer',
      technology: 'AWS API Gateway',
      icon: <Zap className="h-4 w-4" />
    },
    security: {
      type: 'security' as const,
      name: 'Security Service',
      description: 'Authentication & Authorization',
      technology: 'AWS Cognito',
      icon: <Shield className="h-4 w-4" />
    },
    cache: {
      type: 'cache' as const,
      name: 'Cache Layer',
      description: 'High-performance caching',
      technology: 'AWS ElastiCache',
      icon: <Layers className="h-4 w-4" />
    },
    queue: {
      type: 'queue' as const,
      name: 'Message Queue',
      description: 'Event streaming',
      technology: 'AWS Kinesis',
      icon: <Zap className="h-4 w-4" />
    },
    'public-vpc': {
      type: 'security' as const,
      name: 'Public VPC',
      description: 'Internet-facing network layer',
      technology: 'AWS VPC + Internet Gateway',
      icon: <Shield className="h-4 w-4" />
    },
    'private-vpc': {
      type: 'security' as const,
      name: 'Private VPC',
      description: 'Isolated network layer',
      technology: 'AWS VPC + NAT Gateway',
      icon: <Shield className="h-4 w-4" />
    },
    'load-balancer': {
      type: 'api' as const,
      name: 'Load Balancer',
      description: 'Traffic distribution',
      technology: 'AWS ALB/NLB',
      icon: <Zap className="h-4 w-4" />
    },
    'nat-gateway': {
      type: 'api' as const,
      name: 'NAT Gateway',
      description: 'Outbound internet access',
      technology: 'AWS NAT Gateway',
      icon: <Zap className="h-4 w-4" />
    },
    'internet-gateway': {
      type: 'api' as const,
      name: 'Internet Gateway',
      description: 'Internet connectivity',
      technology: 'AWS Internet Gateway',
      icon: <Zap className="h-4 w-4" />
    },
    'lambda': {
      type: 'backend' as const,
      name: 'Lambda Function',
      description: 'Serverless compute',
      technology: 'AWS Lambda',
      icon: <Server className="h-4 w-4" />
    },
    's3': {
      type: 'database' as const,
      name: 'S3 Bucket',
      description: 'Object storage',
      technology: 'AWS S3',
      icon: <Database className="h-4 w-4" />
    },
    'cloudfront': {
      type: 'api' as const,
      name: 'CloudFront CDN',
      description: 'Content delivery network',
      technology: 'AWS CloudFront',
      icon: <Zap className="h-4 w-4" />
    }
  };

  // Generate intelligent financial reporting architecture
  const generateArchitectureMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch('/api/agents/architect/design', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ projectId })
      });
      
      if (!res.ok) throw new Error('Architecture generation failed');
      return res.json();
    },
    onSuccess: (data) => {
      // Generate simple, elegant settlement & EMIR reporting architecture
      const reportingComponents: DiagramComponent[] = [
        // External Systems Zone (80-260 x 120-380)
        {
          id: 'trading-systems',
          type: 'frontend',
          name: 'Trading Systems',
          description: 'FIX/OMS platforms',
          technology: 'Trading Engines',
          position: { x: 90, y: 140 },
          connections: ['message-gateway']
        },
        {
          id: 'counterparties',
          type: 'frontend',
          name: 'Counterparties',
          description: 'Banks & CCPs',
          technology: 'SWIFT/ISO 20022',
          position: { x: 90, y: 280 },
          connections: ['message-gateway']
        },
        
        // Message Gateway Zone (380-560 x 200-320)
        {
          id: 'message-gateway',
          type: 'api',
          name: 'Message Gateway',
          description: 'FIX/SWIFT processing',
          technology: 'API Gateway',
          position: { x: 420, y: 230 },
          connections: ['trade-capture', 'settlement-engine']
        },
        
        // Settlement Processing Zone (680-860 x 120-530)
        {
          id: 'trade-capture',
          type: 'backend',
          name: 'Trade Capture',
          description: 'Trade booking & validation',
          technology: 'Lambda Functions',
          position: { x: 700, y: 140 },
          connections: ['position-keeper', 'trade-store']
        },
        {
          id: 'settlement-engine',
          type: 'backend',
          name: 'Settlement Engine',
          description: 'Netting & settlement processing',
          technology: 'Lambda + SQS',
          position: { x: 700, y: 280 },
          connections: ['payment-rails', 'trade-store']
        },
        {
          id: 'emir-reporter',
          type: 'backend',
          name: 'EMIR Reporter',
          description: 'Trade repository reporting',
          technology: 'Scheduled Lambda',
          position: { x: 700, y: 420 },
          connections: ['regulatory-gateway', 'trade-store']
        },
        
        // Position & Payments Zone (980-1160 x 120-530)
        {
          id: 'position-keeper',
          type: 'backend',
          name: 'Position Keeper',
          description: 'Real-time position tracking',
          technology: 'DynamoDB',
          position: { x: 1000, y: 140 },
          connections: ['risk-monitor']
        },
        {
          id: 'payment-rails',
          type: 'backend',
          name: 'Payment Rails',
          description: 'RTGS/TARGET2 connectivity',
          technology: 'Lambda + External APIs',
          position: { x: 1000, y: 280 },
          connections: []
        },
        {
          id: 'regulatory-gateway',
          type: 'api',
          name: 'Regulatory Gateway',
          description: 'ESMA/FCA submission',
          technology: 'External API Gateway',
          position: { x: 1000, y: 420 },
          connections: []
        },
        
        // Data Storage Zone (380-860 x 580-680)
        {
          id: 'trade-store',
          type: 'database',
          name: 'Trade Repository',
          description: 'All trade & settlement data',
          technology: 'RDS PostgreSQL',
          position: { x: 420, y: 610 },
          connections: []
        },
        {
          id: 'reference-data',
          type: 'database',
          name: 'Reference Data',
          description: 'Counterparty & instrument master',
          technology: 'DynamoDB',
          position: { x: 720, y: 610 },
          connections: []
        },
        
        // Risk & Alerts Zone (1280-1460 x 200-440)
        {
          id: 'risk-monitor',
          type: 'backend',
          name: 'Risk Monitor',
          description: 'Real-time risk calculations',
          technology: 'Kinesis + CloudWatch',
          position: { x: 1300, y: 220 },
          connections: ['alerts']
        },
        {
          id: 'alerts',
          type: 'queue',
          name: 'Alert System',
          description: 'Operational & risk alerts',
          technology: 'SNS + Email',
          position: { x: 1300, y: 360 },
          connections: []
        }
      ];

      setDiagram(prev => ({
        ...prev,
        components: reportingComponents,
        notes: `**Settlement & EMIR Reporting Platform**

Simple, elegant architecture for trade settlement and regulatory reporting with core financial components.

**Core Settlement Functions:**
• Trade Capture: FIX/SWIFT message processing and trade booking
• Settlement Engine: Multilateral netting and settlement processing  
• Position Keeper: Real-time position tracking across all instruments
• Payment Rails: RTGS/TARGET2 connectivity for cash settlement

**Regulatory Reporting:**
• EMIR Reporter: Automated trade repository submission to ESMA
• Regulatory Gateway: Secure API connectivity to regulatory authorities
• Trade Repository: Complete audit trail for all transactions

**Data Architecture:**
• Trade Store: PostgreSQL for transactional data and settlement history
• Reference Data: DynamoDB for counterparty and instrument master data
• Risk Monitor: Real-time position and exposure monitoring

**Key Data Flows:**
1. **Trade Processing**: Trading Systems → Message Gateway → Trade Capture → Trade Store
2. **Settlement**: Settlement Engine → Payment Rails → External Settlement Systems
3. **Regulatory**: Trade Store → EMIR Reporter → Regulatory Gateway → ESMA/FCA
4. **Risk Management**: Position Keeper → Risk Monitor → Alert System

**Compliance Features:**
• Real-time EMIR trade reporting within regulatory deadlines
• Complete audit trail for regulatory examinations
• Position limits and risk monitoring with automated alerts
• Secure connectivity to regulatory reporting hubs`
      }));

      toast({
        title: "Reporting Architecture Generated",
        description: "Created intelligent AWS-based financial reporting architecture with 16 connected components",
      });
    }
  });

  // Save diagram
  const saveDiagramMutation = useMutation({
    mutationFn: async () => {
      const savedDiagram = { ...diagram, projectId };
      localStorage.setItem(`architecture-${projectId}`, JSON.stringify(savedDiagram));
      return savedDiagram;
    },
    onSuccess: () => {
      toast({
        title: "Diagram Saved",
        description: "Architecture diagram has been saved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['architecture', projectId] });
    }
  });

  const addComponent = (templateKey: keyof typeof componentTemplates) => {
    const template = componentTemplates[templateKey];
    const newComponent: DiagramComponent = {
      id: `${template.type}-${Date.now()}`,
      ...template,
      position: { x: 200 + Math.random() * 300, y: 150 + Math.random() * 300 }
    };
    
    setDiagram(prev => ({
      ...prev,
      components: [...prev.components, newComponent]
    }));
  };

  const removeComponent = (componentId: string) => {
    setDiagram(prev => ({
      ...prev,
      components: prev.components.filter(c => c.id !== componentId)
    }));
    setSelectedComponent(null);
  };

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-0 z-50">
      <div className="bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full h-full max-w-none flex flex-col border border-white/20">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200/50 bg-gradient-to-r from-orange-50 to-purple-50">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-purple-600 flex items-center justify-center">
              <Layers className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                Financial Reporting Architecture
              </h2>
              <p className="text-sm text-gray-600">AWS-based intelligent reporting system design</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Button
              className="bg-gradient-to-r from-purple-600 to-orange-600 hover:from-purple-700 hover:to-orange-700 text-white shadow-lg hover:shadow-xl transition-all duration-200"
              onClick={() => generateArchitectureMutation.mutate()}
              disabled={generateArchitectureMutation.isPending}
            >
              <Zap className="h-4 w-4 mr-2" />
              {generateArchitectureMutation.isPending ? 'Generating...' : 'Generate Architecture'}
            </Button>
            <Button
              variant="outline"
              className="border-gray-300 hover:bg-gray-50 shadow-sm hover:shadow-md transition-all duration-200"
              onClick={() => saveDiagramMutation.mutate()}
              disabled={saveDiagramMutation.isPending}
            >
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
            <Button 
              variant="ghost" 
              className="hover:bg-red-50 hover:text-red-600 transition-all duration-200"
              onClick={onClose}
            >
              ✕
            </Button>
          </div>
        </div>

        <div className="flex-1 flex">
          {/* Left Sidebar - Component Library */}
          <div className="w-72 bg-gradient-to-b from-gray-50 to-white border-r border-gray-200/60 p-6 space-y-6">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                  <Plus className="h-3 w-3 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900">AWS Components</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {Object.entries(componentTemplates).map(([key, template]) => (
                  <div
                    key={key}
                    className="group relative p-4 rounded-xl border border-gray-200 hover:border-purple-300 hover:shadow-lg transition-all duration-200 cursor-pointer bg-white hover:bg-gradient-to-br hover:from-white hover:to-purple-50"
                    onClick={() => addComponent(key as keyof typeof componentTemplates)}
                  >
                    <div className="flex flex-col items-center space-y-2">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-200 ${
                        key === 'frontend' ? 'bg-blue-100 text-blue-600 group-hover:bg-blue-200' :
                        key === 'backend' ? 'bg-green-100 text-green-600 group-hover:bg-green-200' :
                        key === 'database' ? 'bg-purple-100 text-purple-600 group-hover:bg-purple-200' :
                        key === 'api' ? 'bg-orange-100 text-orange-600 group-hover:bg-orange-200' :
                        key === 'security' ? 'bg-red-100 text-red-600 group-hover:bg-red-200' :
                        key === 'cache' ? 'bg-yellow-100 text-yellow-600 group-hover:bg-yellow-200' :
                        'bg-indigo-100 text-indigo-600 group-hover:bg-indigo-200'
                      }`}>
                        {template.icon}
                      </div>
                      <span className="text-xs font-medium text-gray-700 text-center leading-tight">
                        {template.name}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
              <div className="flex items-center space-x-2 mb-3">
                <Settings className="h-4 w-4 text-gray-600" />
                <h3 className="font-semibold text-gray-900">Diagram Settings</h3>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-gray-700 mb-1 block">Name</label>
                  <Input
                    placeholder="Enter diagram name..."
                    value={diagram.name}
                    onChange={(e) => setDiagram(prev => ({ ...prev, name: e.target.value }))}
                    className="border-gray-300 focus:border-purple-500 focus:ring-purple-500 rounded-lg"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-700 mb-1 block">Type</label>
                  <Select
                    value={diagram.type}
                    onValueChange={(value: any) => setDiagram(prev => ({ ...prev, type: value }))}
                  >
                    <SelectTrigger className="border-gray-300 focus:border-purple-500 focus:ring-purple-500 rounded-lg">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="system">📊 Reporting Architecture</SelectItem>
                      <SelectItem value="deployment">🚀 Deployment Diagram</SelectItem>
                      <SelectItem value="security">🔒 Security Architecture</SelectItem>
                      <SelectItem value="data-flow">📈 Data Flow Diagram</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {selectedComponent && (
              <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <Eye className="h-4 w-4 text-purple-600" />
                    <h3 className="font-semibold text-gray-900">Component Properties</h3>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {selectedComponent.type}
                  </Badge>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-medium text-gray-700 mb-1 block">Name</label>
                    <Input
                      placeholder="Component name..."
                      value={selectedComponent.name}
                      onChange={(e) => {
                        const updated = { ...selectedComponent, name: e.target.value };
                        setSelectedComponent(updated);
                        setDiagram(prev => ({
                          ...prev,
                          components: prev.components.map(c => 
                            c.id === selectedComponent.id ? updated : c
                          )
                        }));
                      }}
                      className="border-gray-300 focus:border-purple-500 focus:ring-purple-500 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-gray-700 mb-1 block">Technology</label>
                    <Input
                      placeholder="Technology stack..."
                      value={selectedComponent.technology}
                      onChange={(e) => {
                        const updated = { ...selectedComponent, technology: e.target.value };
                        setSelectedComponent(updated);
                        setDiagram(prev => ({
                          ...prev,
                          components: prev.components.map(c => 
                            c.id === selectedComponent.id ? updated : c
                          )
                        }));
                      }}
                      className="border-gray-300 focus:border-purple-500 focus:ring-purple-500 rounded-lg"
                    />
                  </div>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => removeComponent(selectedComponent.id)}
                    className="w-full bg-red-500 hover:bg-red-600 rounded-lg"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Remove Component
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Main Canvas with Side Panel */}
          <div className="flex-1 flex">
            {/* Architecture Canvas */}
            <div className="flex-1 bg-gradient-to-br from-gray-50 via-white to-purple-50/30 relative overflow-auto">
              {/* Grid background */}
              <div className="absolute inset-0" 
                   style={{
                     backgroundImage: `
                       radial-gradient(circle at 1px 1px, rgba(156, 163, 175, 0.3) 1px, transparent 0),
                       linear-gradient(rgba(156, 163, 175, 0.1) 1px, transparent 1px),
                       linear-gradient(90deg, rgba(156, 163, 175, 0.1) 1px, transparent 1px)
                     `,
                     backgroundSize: '40px 40px, 40px 40px, 40px 40px'
                   }} 
              />
              
              {/* Connection Lines */}
              <svg className="absolute inset-0 z-5 pointer-events-none" style={{ width: '100%', height: '100%' }}>
                <defs>
                  <marker id="arrowhead" markerWidth="10" markerHeight="7" 
                          refX="9" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#6b7280" />
                  </marker>
                </defs>
                {diagram.components.map((component) => 
                  component.connections?.map((targetId) => {
                    const target = diagram.components.find(c => c.id === targetId);
                    if (!target) return null;
                    
                    const startX = component.position.x + 96;
                    const startY = component.position.y + 64;
                    const endX = target.position.x + 96;
                    const endY = target.position.y + 64;
                    
                    return (
                      <line
                        key={`${component.id}-${targetId}`}
                        x1={startX + 32}
                        y1={startY + 32}
                        x2={endX + 32}
                        y2={endY + 32}
                        stroke="#6b7280"
                        strokeWidth="2"
                        markerEnd="url(#arrowhead)"
                        opacity="0.6"
                      />
                    );
                  }) || []
                )}
              </svg>
              
              {/* Settlement Architecture Zones */}
              <svg className="absolute inset-0 z-0 pointer-events-none" style={{ width: '100%', height: '100%' }}>
                {/* External Trading Systems */}
                <rect
                  x="80"
                  y="120"
                  width="180"
                  height="260"
                  fill="none"
                  stroke="#94A3B8"
                  strokeWidth="2"
                  strokeDasharray="10,5"
                  rx="12"
                />
                <text x="90" y="110" className="text-sm font-semibold fill-gray-600">External Systems</text>

                {/* Message Processing */}
                <rect
                  x="380"
                  y="200"
                  width="180"
                  height="120"
                  fill="rgba(251, 191, 36, 0.1)"
                  stroke="#F59E0B"
                  strokeWidth="2"
                  rx="12"
                />
                <text x="390" y="190" className="text-sm font-semibold fill-amber-600">Message Gateway</text>

                {/* Core Settlement Processing */}
                <rect
                  x="680"
                  y="120"
                  width="180"
                  height="410"
                  fill="rgba(34, 197, 94, 0.08)"
                  stroke="#22C55E"
                  strokeWidth="3"
                  rx="12"
                />
                <text x="690" y="110" className="text-sm font-semibold fill-green-600">Settlement Processing</text>

                {/* Position & Payments */}
                <rect
                  x="980"
                  y="120"
                  width="180"
                  height="410"
                  fill="rgba(239, 68, 68, 0.08)"
                  stroke="#EF4444"
                  strokeWidth="3"
                  rx="12"
                />
                <text x="990" y="110" className="text-sm font-semibold fill-red-600">Position & Payments</text>

                {/* Data Storage */}
                <rect
                  x="380"
                  y="580"
                  width="480"
                  height="100"
                  fill="rgba(147, 51, 234, 0.08)"
                  stroke="#9333EA"
                  strokeWidth="3"
                  rx="12"
                />
                <text x="390" y="570" className="text-sm font-semibold fill-purple-600">Data Storage</text>

                {/* Risk & Monitoring */}
                <rect
                  x="1280"
                  y="200"
                  width="180"
                  height="240"
                  fill="rgba(59, 130, 246, 0.08)"
                  stroke="#3B82F6"
                  strokeWidth="3"
                  rx="12"
                />
                <text x="1290" y="190" className="text-sm font-semibold fill-blue-600">Risk & Alerts</text>
              </svg>

              {/* Components */}
              <div className="relative z-10 p-8">
                {diagram.components.map((component) => (
                  <div
                    key={component.id}
                    className={`absolute w-48 h-32 rounded-2xl border-2 p-4 cursor-pointer transition-all duration-300 hover:shadow-2xl hover:scale-105 transform group ${
                      selectedComponent?.id === component.id 
                        ? 'ring-4 ring-purple-500/50 shadow-2xl scale-105 bg-white' 
                        : 'bg-white/90 backdrop-blur-sm hover:bg-white shadow-lg'
                    }`}
                    style={{
                      left: component.position.x,
                      top: component.position.y,
                      borderColor: selectedComponent?.id === component.id ? '#8b5cf6' : '#e5e7eb'
                    }}
                    onClick={() => setSelectedComponent(component)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                        component.type === 'frontend' ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white' :
                        component.type === 'backend' ? 'bg-gradient-to-br from-green-500 to-green-600 text-white' :
                        component.type === 'database' ? 'bg-gradient-to-br from-purple-500 to-purple-600 text-white' :
                        component.type === 'api' ? 'bg-gradient-to-br from-orange-500 to-orange-600 text-white' :
                        component.type === 'security' ? 'bg-gradient-to-br from-red-500 to-red-600 text-white' :
                        component.type === 'cache' ? 'bg-gradient-to-br from-yellow-500 to-yellow-600 text-white' :
                        'bg-gradient-to-br from-indigo-500 to-indigo-600 text-white'
                      }`}>
                        {componentTemplates[component.type]?.icon}
                      </div>
                      <Badge 
                        variant="outline" 
                        className="text-xs bg-white/80 backdrop-blur-sm border-gray-300"
                      >
                        {component.type}
                      </Badge>
                    </div>
                    <h4 className="font-semibold text-sm text-gray-900 truncate mb-1">
                      {component.name}
                    </h4>
                    <p className="text-xs text-gray-600 truncate leading-relaxed">
                      {component.technology}
                    </p>
                  </div>
                ))}

                {diagram.components.length === 0 && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center max-w-lg">
                      <div className="w-32 h-32 mx-auto mb-8 rounded-3xl bg-gradient-to-br from-purple-100 to-orange-100 flex items-center justify-center">
                        <Layers className="h-16 w-16 text-purple-600" />
                      </div>
                      <h3 className="text-3xl font-bold text-gray-900 mb-4">
                        Financial Reporting Architecture
                      </h3>
                      <p className="text-gray-600 mb-8 leading-relaxed text-lg">
                        Generate intelligent AWS-based reporting architecture optimized for EMIR and MiFID II compliance with real-time data processing.
                      </p>
                      <Button 
                        onClick={() => generateArchitectureMutation.mutate()}
                        className="bg-gradient-to-r from-purple-600 to-orange-600 hover:from-purple-700 hover:to-orange-700 text-white px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 text-lg font-semibold"
                        disabled={generateArchitectureMutation.isPending}
                      >
                        <Zap className="h-6 w-6 mr-3" />
                        {generateArchitectureMutation.isPending ? 'Generating Architecture...' : 'Generate Smart Architecture'}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Editable Architecture Description Panel */}
            {diagram.components.length > 0 && (
              <div className="w-96 bg-white border-l border-gray-200 p-6 overflow-y-auto">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-gray-900">Architecture Overview</h3>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => saveDiagramMutation.mutate()}
                    disabled={saveDiagramMutation.isPending}
                    className="text-xs"
                  >
                    <Save className="h-3 w-3 mr-1" />
                    Save
                  </Button>
                </div>
                
                {/* Editable Description */}
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">Description</label>
                    <Textarea
                      value={diagram.notes}
                      onChange={(e) => setDiagram(prev => ({ ...prev, notes: e.target.value }))}
                      placeholder="Describe your architecture, design principles, data flow, and compliance features..."
                      className="min-h-64 border-gray-300 focus:border-orange-500 focus:ring-orange-500 text-sm leading-relaxed"
                    />
                  </div>
                  
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                    <h4 className="font-semibold text-orange-900 mb-2">AI Architecture Tips</h4>
                    <ul className="text-sm text-orange-800 space-y-1">
                      <li>• Describe key design principles and patterns</li>
                      <li>• Explain data flow between components</li>
                      <li>• Highlight security and compliance features</li>
                      <li>• Document scaling and performance strategies</li>
                      <li>• Include disaster recovery considerations</li>
                    </ul>
                  </div>
                </div>
                
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <h4 className="font-semibold text-gray-900 mb-3">Component Summary</h4>
                  <div className="space-y-2">
                    {[
                      { type: 'frontend', count: diagram.components.filter(c => c.type === 'frontend').length, label: 'Frontend Apps', color: 'bg-blue-500' },
                      { type: 'backend', count: diagram.components.filter(c => c.type === 'backend').length, label: 'Services', color: 'bg-green-500' },
                      { type: 'database', count: diagram.components.filter(c => c.type === 'database').length, label: 'Data Stores', color: 'bg-purple-500' },
                      { type: 'api', count: diagram.components.filter(c => c.type === 'api').length, label: 'APIs/Gateways', color: 'bg-orange-500' },
                      { type: 'security', count: diagram.components.filter(c => c.type === 'security').length, label: 'Security', color: 'bg-red-500' },
                      { type: 'queue', count: diagram.components.filter(c => c.type === 'queue').length, label: 'Messaging', color: 'bg-indigo-500' }
                    ].filter(item => item.count > 0).map((item) => (
                      <div key={item.type} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded ${item.color}`}></div>
                          <span className="text-sm text-gray-700">{item.label}</span>
                        </div>
                        <span className="text-sm font-medium text-gray-900">{item.count}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between text-sm font-medium">
                      <span className="text-gray-700">Total Components</span>
                      <span className="text-gray-900">{diagram.components.length}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}