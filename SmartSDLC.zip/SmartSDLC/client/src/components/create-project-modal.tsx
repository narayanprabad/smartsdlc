import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Bot, Sparkles, FileText, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { createProjectSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface CreateProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: string;
}

interface AIProjectPlan {
  projectPlan: string;
  useCases: Array<{
    title: string;
    description: string;
    type: "functional" | "non-functional";
    priority: string;
  }>;
  recommendations: string[];
}

export function CreateProjectModal({ isOpen, onClose, currentRole }: CreateProjectModalProps) {
  const [step, setStep] = useState<"form" | "ai-analysis" | "review">("form");
  const [aiPlan, setAiPlan] = useState<AIProjectPlan | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm({
    resolver: zodResolver(createProjectSchema),
    defaultValues: {
      name: "",
      description: "",
      type: "",
      teamSize: 1,
      startDate: new Date().toISOString().split('T')[0],
    },
  });

  // AI Project Generation Mutation
  const aiGenerateMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/ai/create-project", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          description: data.description,
          projectType: data.type,
          currentRole: currentRole
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to generate AI project plan");
      }

      return response.json();
    },
    onSuccess: (data) => {
      setAiPlan(data);
      setStep("review");
    },
    onError: (error: any) => {
      toast({
        title: "AI Generation Failed",
        description: error.message || "Failed to generate project plan",
        variant: "destructive",
      });
    },
  });

  // Project Creation Mutation
  const createProjectMutation = useMutation({
    mutationFn: async (projectData: any) => {
      const response = await apiRequest("POST", "/api/projects", {
        ...projectData,
        approvalStatus: "pending",
        createdAt: new Date().toISOString(),
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Project Created",
        description: `${data.name} has been created and sent for approval`,
      });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create project",
        variant: "destructive",
      });
    },
  });

  const handleGenerateWithAI = () => {
    const formData = form.getValues();
    if (!formData.description || !formData.type) {
      toast({
        title: "Missing Information",
        description: "Please provide project description and type",
        variant: "destructive",
      });
      return;
    }
    setStep("ai-analysis");
    aiGenerateMutation.mutate(formData);
  };

  const handleCreateProject = () => {
    const formData = form.getValues();
    createProjectMutation.mutate(formData);
  };

  const handleCreateWithAI = async () => {
    if (!aiPlan) return;
    
    const formData = form.getValues();
    
    // First create the project
    try {
      const projectResponse = await apiRequest("POST", "/api/projects", {
        ...formData,
        approvalStatus: "pending",
        createdAt: new Date().toISOString(),
      });
      const project = await projectResponse.json();

      // Then create use cases from AI suggestions
      if (aiPlan.useCases && project.id) {
        const useCasePromises = aiPlan.useCases.map((uc, index) => 
          apiRequest("POST", "/api/use-cases", {
            projectId: project.id,
            ucId: `${uc.type === "functional" ? "UC" : "NF"}-${String(index + 1).padStart(3, "0")}`,
            title: uc.title,
            description: uc.description,
            type: uc.type,
            priority: uc.priority,
            status: "Draft",
            actor: uc.type === "functional" ? "User" : null,
            category: uc.type === "non-functional" ? "Performance" : null,
            updatedAt: "just now"
          })
        );

        await Promise.all(useCasePromises);
      }

      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "AI-Enhanced Project Created",
        description: `${project.name} created with ${aiPlan.useCases.length} AI-generated use cases`,
      });
      onClose();
      resetForm();
    } catch (error: any) {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create project",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    form.reset();
    setStep("form");
    setAiPlan(null);
  };

  const handleClose = () => {
    onClose();
    resetForm();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>
            {step === "form" && "Create New Project"}
            {step === "ai-analysis" && "AI Analysis in Progress"}
            {step === "review" && "Review AI-Generated Plan"}
          </DialogTitle>
        </DialogHeader>

        <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
          {step === "form" && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Project Name</Label>
                  <Input
                    id="name"
                    {...form.register("name")}
                    placeholder="Enter project name"
                    className="mt-1"
                  />
                  {form.formState.errors.name && (
                    <p className="text-sm text-red-600 mt-1">{form.formState.errors.name.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="type">Project Type</Label>
                  <Select onValueChange={(value) => form.setValue("type", value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select project type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Web Application">Web Application</SelectItem>
                      <SelectItem value="Mobile App">Mobile App</SelectItem>
                      <SelectItem value="API Development">API Development</SelectItem>
                      <SelectItem value="Data Analytics">Data Analytics</SelectItem>
                      <SelectItem value="Enterprise Software">Enterprise Software</SelectItem>
                      <SelectItem value="E-commerce Platform">E-commerce Platform</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.type && (
                    <p className="text-sm text-red-600 mt-1">{form.formState.errors.type.message}</p>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="description">Project Description</Label>
                <Textarea
                  id="description"
                  {...form.register("description")}
                  placeholder="Describe your project requirements, goals, and key features..."
                  className="mt-1 min-h-[120px]"
                />
                {form.formState.errors.description && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.description.message}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="teamSize">Team Size</Label>
                  <Input
                    id="teamSize"
                    type="number"
                    min="1"
                    {...form.register("teamSize", { valueAsNumber: true })}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input
                    id="startDate"
                    type="date"
                    {...form.register("startDate")}
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={handleClose}>
                  Cancel
                </Button>
                <div className="space-x-2">
                  <Button 
                    variant="outline" 
                    onClick={handleCreateProject}
                    disabled={createProjectMutation.isPending}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Create Basic Project
                  </Button>
                  <Button 
                    onClick={handleGenerateWithAI}
                    disabled={aiGenerateMutation.isPending}
                    className="bg-gradient-to-r from-purple-500 to-blue-500"
                  >
                    <Bot className="h-4 w-4 mr-2" />
                    Generate with AI
                  </Button>
                </div>
              </div>
            </div>
          )}

          {step === "ai-analysis" && (
            <div className="flex flex-col items-center justify-center py-12 space-y-4">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center animate-pulse">
                <Bot className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold">AI Analysis in Progress</h3>
              <p className="text-gray-600 text-center max-w-md">
                AWS Bedrock is analyzing your project requirements and generating comprehensive use cases, 
                technical recommendations, and implementation guidance.
              </p>
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Clock className="h-4 w-4" />
                <span>This may take a few moments...</span>
              </div>
            </div>
          )}

          {step === "review" && aiPlan && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Sparkles className="h-5 w-5 mr-2 text-purple-500" />
                    AI-Generated Project Plan
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="whitespace-pre-wrap text-sm bg-gray-50 p-4 rounded-lg">
                    {aiPlan.projectPlan}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Generated Use Cases ({aiPlan.useCases.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {aiPlan.useCases.map((useCase, index) => (
                      <div key={index} className="border rounded-lg p-3">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-medium">{useCase.title}</h4>
                          <div className="flex space-x-2">
                            <Badge variant={useCase.type === "functional" ? "default" : "secondary"}>
                              {useCase.type}
                            </Badge>
                            <Badge variant="outline">{useCase.priority} Priority</Badge>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600">{useCase.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Technical Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {aiPlan.recommendations.map((rec, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">{rec}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={() => setStep("form")}>
                  Back to Edit
                </Button>
                <div className="space-x-2">
                  <Button variant="outline" onClick={handleCreateProject}>
                    Create Without AI Features
                  </Button>
                  <Button 
                    onClick={handleCreateWithAI}
                    className="bg-gradient-to-r from-purple-500 to-blue-500"
                  >
                    <Bot className="h-4 w-4 mr-2" />
                    Create with AI Plan
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}