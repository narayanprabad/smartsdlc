import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { Plus, Edit3, Target, TrendingUp, AlertTriangle } from "lucide-react";

interface ProductBacklogItem {
  id: number;
  projectId: number;
  title: string;
  description: string;
  userStory: string;
  acceptanceCriteria: string;
  priority: "Critical" | "High" | "Medium" | "Low";
  storyPoints: number | null;
  tags: string[];
  businessValue: "High" | "Medium" | "Low";
  risk: "High" | "Medium" | "Low";
  status: string;
  assignedTo: string | null;
  sprint: string | null;
  scrumStatus: string | null;
  createdById: number;
  createdAt: string;
  updatedAt: string;
}

const backlogItemSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  userStory: z.string().min(1, "User story is required"),
  acceptanceCriteria: z.string().min(1, "Acceptance criteria is required"),
  priority: z.enum(["Critical", "High", "Medium", "Low"]),
  storyPoints: z.number().nullable(),
  businessValue: z.enum(["High", "Medium", "Low"]),
  risk: z.enum(["High", "Medium", "Low"]),
  status: z.string().default("To Do"),
  tags: z.array(z.string()).default([]),
});

interface ProductBacklogProps {
  projectId: number;
}

export function ProductBacklog({ projectId }: ProductBacklogProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ProductBacklogItem | null>(null);
  const queryClient = useQueryClient();

  const { data: backlogItems = [], isLoading } = useQuery({
    queryKey: ["/api/projects", projectId, "backlog"],
    queryFn: () => fetch(`/api/projects/${projectId}/backlog`).then(res => res.json()),
  });

  const createItemMutation = useMutation({
    mutationFn: (data: any) => apiRequest(`/api/projects/${projectId}/backlog`, { method: "POST", body: data }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "backlog"] });
      setIsAddDialogOpen(false);
    },
  });

  const updateItemMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => 
      apiRequest(`/api/backlog/${id}`, { method: "PUT", body: data }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "backlog"] });
      setEditingItem(null);
    },
  });

  const form = useForm({
    resolver: zodResolver(backlogItemSchema),
    defaultValues: {
      title: "",
      description: "",
      userStory: "",
      acceptanceCriteria: "",
      priority: "Medium" as const,
      storyPoints: null,
      businessValue: "Medium" as const,
      risk: "Medium" as const,
      status: "To Do",
      tags: [],
    },
  });

  const onSubmit = (data: any) => {
    if (editingItem) {
      updateItemMutation.mutate({ id: editingItem.id, data });
    } else {
      createItemMutation.mutate(data);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Critical": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "High": return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200";
      case "Medium": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "Low": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
    }
  };

  const getValueColor = (value: string) => {
    switch (value) {
      case "High": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "Medium": return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200";
      case "Low": return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
        <div className="h-32 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
        <div className="h-32 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Product Backlog</h2>
          <p className="text-gray-600 dark:text-gray-400">
            {backlogItems.length} items • Manage user stories and requirements
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add Item
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add Backlog Item</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Enter item title" />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="userStory"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>User Story</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="As a [user], I want [goal] so that [benefit]" />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="Detailed description" />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="acceptanceCriteria"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Acceptance Criteria</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="Given... When... Then..." />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="priority"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Priority</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select priority" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Critical">Critical</SelectItem>
                            <SelectItem value="High">High</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="Low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="storyPoints"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Story Points</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            {...field} 
                            onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : null)}
                            placeholder="1, 2, 3, 5, 8..." 
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="businessValue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Value</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select value" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="High">High</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="Low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="risk"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Risk</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select risk" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="High">High</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="Low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createItemMutation.isPending}>
                    {createItemMutation.isPending ? "Adding..." : "Add Item"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {backlogItems.map((item: ProductBacklogItem) => (
          <Card key={item.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <CardTitle className="text-lg mb-2">{item.title}</CardTitle>
                  <div className="flex flex-wrap gap-2 mb-3">
                    <Badge className={getPriorityColor(item.priority)}>
                      <AlertTriangle className="w-3 h-3 mr-1" />
                      {item.priority}
                    </Badge>
                    <Badge className={getValueColor(item.businessValue)}>
                      <TrendingUp className="w-3 h-3 mr-1" />
                      {item.businessValue} Value
                    </Badge>
                    <Badge variant="secondary">
                      <Target className="w-3 h-3 mr-1" />
                      {item.storyPoints || "0"} SP
                    </Badge>
                    <Badge variant="outline">{item.status}</Badge>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setEditingItem(item);
                    form.reset({
                      title: item.title,
                      description: item.description,
                      userStory: item.userStory,
                      acceptanceCriteria: item.acceptanceCriteria,
                      priority: item.priority,
                      storyPoints: item.storyPoints,
                      businessValue: item.businessValue,
                      risk: item.risk,
                      status: item.status,
                      tags: item.tags,
                    });
                  }}
                >
                  <Edit3 className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <h4 className="font-medium text-sm text-gray-900 dark:text-gray-100 mb-1">User Story</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{item.userStory}</p>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-gray-900 dark:text-gray-100 mb-1">Description</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{item.description}</p>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-gray-900 dark:text-gray-100 mb-1">Acceptance Criteria</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 whitespace-pre-wrap">
                    {item.acceptanceCriteria}
                  </p>
                </div>
                {item.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {item.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingItem} onOpenChange={() => setEditingItem(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Backlog Item</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {/* Same form fields as add dialog */}
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter item title" />
                    </FormControl>
                  </FormItem>
                )}
              />
              {/* Additional form fields would go here */}
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setEditingItem(null)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={updateItemMutation.isPending}>
                  {updateItemMutation.isPending ? "Updating..." : "Update Item"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}