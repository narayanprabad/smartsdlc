import { useState, useEffect } from "react";
import * as React from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Calendar,
  Clock,
  User,
  Target,
  Play,
  Plus,
  BarChart3,
  Filter,
  ArrowRight,
  CheckCircle,
  AlertCircle,
  Users,
  Zap
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface BacklogItem {
  id: number;
  projectId: number;
  title: string;
  description: string;
  userStory: string;
  acceptanceCriteria: string;
  priority: "Critical" | "High" | "Medium" | "Low";
  storyPoints: number;
  tags: string[];
  businessValue: "High" | "Medium" | "Low";
  risk: "High" | "Medium" | "Low";
  status: string;
  assignedTo: number | null;
  sprint: string | null;
  scrumStatus: "To Do" | "In Progress" | "Review" | "Done" | null;
}

interface SprintBacklogItem {
  id: number;
  sprintId: string;
  productBacklogId: number;
  title: string;
  description: string;
  storyPoints: number;
  status: "Backlog" | "To Do" | "In Progress" | "Review" | "Done";
  assignedTo: string | null;
  priority: "Critical" | "High" | "Medium" | "Low";
  tags: string[];
  createdAt: string;
}

interface Sprint {
  id: string;
  name: string;
  goal: string;
  startDate: string;
  endDate: string;
  status: "Planning" | "Active" | "Completed";
  capacity: number;
  commitment: number;
  items: BacklogItem[];
  sprintBacklog: SprintBacklogItem[];
}

interface SprintPlanningProps {
  projectId: number;
  userRole: string;
}

export function SprintPlanning({ projectId, userRole }: SprintPlanningProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("planning");
  const [filterPriority, setFilterPriority] = useState<string>("all");
  const [newSprintOpen, setNewSprintOpen] = useState(false);
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [sprintBacklogItems, setSprintBacklogItems] = useState<SprintBacklogItem[]>([]);
  const [sprints, setSprints] = useState<Sprint[]>([
    {
      id: "sprint-1",
      name: "Sprint 1 - Core Foundation",
      goal: "Establish core trade capture and settlement infrastructure",
      startDate: "2025-06-24",
      endDate: "2025-07-07",
      status: "Active",
      capacity: 40,
      commitment: 0,
      items: [],
      sprintBacklog: []
    },
    {
      id: "sprint-2", 
      name: "Sprint 2 - Integration Layer",
      goal: "Build EMIR reporting and reconciliation features",
      startDate: "2025-07-08",
      endDate: "2025-07-21",
      status: "Planning",
      capacity: 45,
      commitment: 0,
      items: [],
      sprintBacklog: []
    }
  ]);

  // Fetch product backlog
  const { data: backlogItems = [], isLoading: backlogLoading } = useQuery<BacklogItem[]>({
    queryKey: [`/api/projects/${projectId}/backlog`],
  });

  // Auto-convert product backlog to sprint-ready items when data loads
  const convertToSprintItems = (items: BacklogItem[]): SprintBacklogItem[] => {
    return items.map(item => ({
      id: item.id,
      sprintId: "",
      productBacklogId: item.id,
      title: item.title,
      description: item.description,
      storyPoints: calculateAutoStoryPoints(item),
      status: "Backlog" as const,
      assignedTo: null,
      priority: item.priority,
      tags: item.tags,
      createdAt: new Date().toISOString(),
    }));
  };

  // Update sprint backlog items when product backlog changes
  useEffect(() => {
    if (backlogItems.length > 0) {
      const convertedItems = convertToSprintItems(backlogItems);
      setSprintBacklogItems(convertedItems);
    }
  }, [backlogItems]);



  const createSprintMutation = useMutation({
    mutationFn: async (sprintData: Partial<Sprint>) => {
      // In real app, this would call the API
      return sprintData;
    },
    onSuccess: (newSprint) => {
      setSprints(prev => [...prev, { ...newSprint, id: `sprint-${Date.now()}`, items: [], sprintBacklog: [] } as Sprint]);
      setNewSprintOpen(false);
      toast({
        title: "Sprint Created",
        description: "New sprint has been successfully created",
      });
    },
  });

  const createSprintBacklogItemMutation = useMutation({
    mutationFn: async ({ productBacklogItem, sprintId }: { productBacklogItem: BacklogItem; sprintId: string }) => {
      // Auto-calculate story points based on complexity
      const autoStoryPoints = calculateAutoStoryPoints(productBacklogItem);
      
      const sprintBacklogItem: SprintBacklogItem = {
        id: Date.now(),
        sprintId,
        productBacklogId: productBacklogItem.id,
        title: productBacklogItem.title,
        description: productBacklogItem.description,
        storyPoints: autoStoryPoints,
        status: "To Do",
        assignedTo: null,
        priority: productBacklogItem.priority,
        tags: productBacklogItem.tags,
        createdAt: new Date().toISOString(),
      };
      
      return sprintBacklogItem;
    },
    onSuccess: (newSprintBacklogItem) => {
      setSprints(prev => prev.map(sprint => {
        if (sprint.id === newSprintBacklogItem.sprintId) {
          return {
            ...sprint,
            sprintBacklog: [...sprint.sprintBacklog, newSprintBacklogItem],
            commitment: sprint.commitment + newSprintBacklogItem.storyPoints
          };
        }
        return sprint;
      }));
      
      toast({
        title: "Sprint Backlog Item Created",
        description: `${newSprintBacklogItem.title} added with ${newSprintBacklogItem.storyPoints} story points`,
      });
    },
  });

  const moveSprintBacklogItemMutation = useMutation({
    mutationFn: async ({ itemId, newStatus }: { itemId: number; newStatus: "To Do" | "In Progress" | "Review" | "Done" }) => {
      return { itemId, newStatus };
    },
    onSuccess: ({ itemId, newStatus }) => {
      setSprints(prev => prev.map(sprint => ({
        ...sprint,
        sprintBacklog: sprint.sprintBacklog.map(item => 
          item.id === itemId ? { ...item, status: newStatus } : item
        )
      })));
      
      toast({
        title: "Item Moved",
        description: `Item moved to ${newStatus}`,
      });
    },
  });

  // Auto-calculate story points based on item complexity
  const calculateAutoStoryPoints = (item: BacklogItem): number => {
    let points = 1;
    
    // Base points from original story points
    points = item.storyPoints || 3;
    
    // Adjust based on priority
    switch (item.priority) {
      case "Critical": points += 2; break;
      case "High": points += 1; break;
      case "Medium": break;
      case "Low": points -= 1; break;
    }
    
    // Adjust based on complexity indicators in title/description
    const text = (item.title + " " + item.description).toLowerCase();
    if (text.includes("integration") || text.includes("api")) points += 2;
    if (text.includes("ui") || text.includes("interface")) points += 1;
    if (text.includes("database") || text.includes("storage")) points += 2;
    if (text.includes("security") || text.includes("authentication")) points += 3;
    if (text.includes("reporting") || text.includes("analytics")) points += 2;
    
    // Ensure minimum of 1 and maximum of 13 (Fibonacci sequence)
    return Math.max(1, Math.min(13, points));
  };

  const addToSprintMutation = useMutation({
    mutationFn: async ({ sprintId, itemIds }: { sprintId: string; itemIds: number[] }) => {
      // In real app, this would call the API
      return { sprintId, itemIds };
    },
    onSuccess: ({ sprintId, itemIds }) => {
      setSprints(prev => prev.map(sprint => {
        if (sprint.id === sprintId) {
          const newItems = backlogItems.filter(item => itemIds.includes(item.id));
          const totalPoints = newItems.reduce((sum, item) => sum + item.storyPoints, 0);
          return {
            ...sprint,
            items: [...sprint.items, ...newItems],
            commitment: sprint.commitment + totalPoints
          };
        }
        return sprint;
      }));
      setSelectedItems([]);
      toast({
        title: "Items Added to Sprint",
        description: `${itemIds.length} items added successfully`,
      });
    },
  });

  const filteredBacklog = backlogItems.filter(item => {
    if (filterPriority === "all") return true;
    return item.priority === filterPriority;
  }).filter(item => !sprints.some(sprint => sprint.items.some(sprintItem => sprintItem.id === item.id)));

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Critical": return "bg-red-100 text-red-800 border-red-200";
      case "High": return "bg-orange-100 text-orange-800 border-orange-200";
      case "Medium": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Low": return "bg-green-100 text-green-800 border-green-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getBusinessValueColor = (value: string) => {
    switch (value) {
      case "High": return "bg-green-100 text-green-800";
      case "Medium": return "bg-yellow-100 text-yellow-800";
      case "Low": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (userRole !== 'scrum-master') {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>Sprint planning features are available for Scrum Masters only.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="border-purple-200 shadow-sm">
        <CardHeader className="bg-purple-50 border-b border-purple-200">
          <CardTitle className="text-lg font-semibold text-purple-900 flex items-center gap-2">
            <Target className="h-5 w-5" />
            Sprint Planning & Backlog Management
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 bg-purple-100 p-1 rounded-lg">
              <TabsTrigger 
                value="planning" 
                className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm"
              >
                <Calendar className="h-4 w-4" />
                Sprint Planning ({sprintBacklogItems.length} stories)
              </TabsTrigger>
              <TabsTrigger 
                value="board" 
                className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm"
              >
                <Users className="h-4 w-4" />
                Active Sprint Board
              </TabsTrigger>
            </TabsList>

            {/* Sprint Planning Tab - New Streamlined Layout */}
            <TabsContent value="planning" className="space-y-4">
              <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg p-4 mb-4">
                <h3 className="font-semibold text-purple-900 mb-2 flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Sprint Planning Workspace - All Product Backlog Auto-Converted
                </h3>
                <p className="text-sm text-purple-700">
                  All {sprintBacklogItems.length} product backlog items have been automatically converted to manageable sprint stories with calculated story points. Drag items from the left pane to active sprints on the right.
                </p>
              </div>

              {/* Two-Pane Layout */}
              <div className="grid grid-cols-5 gap-6 min-h-[700px]">
                {/* Left Pane - Sprint Backlog Items */}
                <div className="col-span-2">
                  <Card className="h-full">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <BarChart3 className="h-5 w-5" />
                        Sprint Stories ({sprintBacklogItems.filter(item => item.status === "Backlog").length})
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Select value={filterPriority} onValueChange={setFilterPriority}>
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All</SelectItem>
                            <SelectItem value="Critical">Critical</SelectItem>
                            <SelectItem value="High">High</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="Low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setFilterPriority("Critical")}
                          className="text-xs"
                        >
                          <Zap className="h-3 w-3 mr-1" />
                          High Impact
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="max-h-[600px] overflow-y-auto space-y-3">
                      {sprintBacklogItems
                        .filter(item => item.status === "Backlog")
                        .filter(item => filterPriority === "all" || item.priority === filterPriority)
                        .map((item) => {
                          const isHighImpact = item.priority === "Critical" || item.priority === "High";
                          
                          return (
                            <div
                              key={item.id}
                              className={`border rounded-lg p-3 cursor-grab hover:shadow-md transition-all ${
                                isHighImpact 
                                  ? 'border-orange-300 bg-gradient-to-r from-orange-50 to-red-50' 
                                  : 'border-gray-200 bg-white hover:border-purple-300'
                              }`}
                              draggable
                              onDragStart={(e) => {
                                e.dataTransfer.setData('text/plain', item.id.toString());
                                e.dataTransfer.setData('application/json', JSON.stringify(item));
                              }}
                            >
                              <div className="flex items-start justify-between mb-2">
                                <h4 className="font-medium text-sm text-gray-900 flex-1 pr-2">{item.title}</h4>
                                <div className="flex items-center gap-1">
                                  {isHighImpact && (
                                    <Badge className="bg-red-100 text-red-700 text-xs px-1 py-0">
                                      HIGH
                                    </Badge>
                                  )}
                                  <Badge variant="outline" className="text-xs px-1 py-0">
                                    {item.storyPoints} pts
                                  </Badge>
                                </div>
                              </div>
                              
                              <div className="flex items-center justify-between text-xs">
                                <Badge className={getPriorityColor(item.priority)} variant="outline">
                                  {item.priority}
                                </Badge>
                                <div className="flex items-center gap-1">
                                  {item.tags.slice(0, 2).map((tag) => (
                                    <Badge key={tag} variant="secondary" className="text-xs px-1 py-0">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                              
                              {/* Drag Handle */}
                              <div className="mt-2 flex items-center justify-center">
                                <div className="flex gap-1 text-gray-400">
                                  <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                  <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                  <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                    </CardContent>
                  </Card>
                </div>

                {/* Right Pane - Active Sprints */}
                <div className="col-span-3">
                  <Card className="h-full">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Calendar className="h-5 w-5" />
                        Active Sprints
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {sprints.map((sprint) => (
                        <div
                          key={sprint.id}
                          className="border-2 border-dashed border-blue-300 rounded-lg p-4 hover:border-blue-400 transition-colors"
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => {
                            e.preventDefault();
                            try {
                              const itemId = parseInt(e.dataTransfer.getData('text/plain'));
                              const itemData = e.dataTransfer.getData('application/json');
                              
                              if (itemId && itemData) {
                                const item = JSON.parse(itemData);
                                // Move item to this sprint
                                setSprintBacklogItems(prev => prev.map(prevItem => 
                                  prevItem.id === itemId 
                                    ? { ...prevItem, sprintId: sprint.id, status: "To Do" as const }
                                    : prevItem
                                ));
                                
                                // Update sprint commitment
                                setSprints(prev => prev.map(prevSprint => 
                                  prevSprint.id === sprint.id 
                                    ? { ...prevSprint, commitment: prevSprint.commitment + item.storyPoints }
                                    : prevSprint
                                ));
                                
                                toast({
                                  title: "Item Added to Sprint",
                                  description: `${item.title} added to ${sprint.name}`,
                                });
                              }
                            } catch (error) {
                              console.error('Drop error:', error);
                            }
                          }}
                        >
                          <div className="flex justify-between items-center mb-3">
                            <div>
                              <h4 className="font-semibold text-blue-900">{sprint.name}</h4>
                              <p className="text-sm text-blue-700">{sprint.goal}</p>
                            </div>
                            <Badge 
                              variant="outline" 
                              className={sprint.status === "Active" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}
                            >
                              {sprint.status}
                            </Badge>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-4 text-sm text-blue-600 mb-3">
                            <span>Capacity: {sprint.capacity} pts</span>
                            <span>Committed: {sprint.commitment} pts</span>
                            <span>Available: {sprint.capacity - sprint.commitment} pts</span>
                          </div>
                          
                          {/* Sprint Items */}
                          <div className="space-y-2">
                            {sprintBacklogItems
                              .filter(item => item.sprintId === sprint.id)
                              .map(item => (
                                <div key={item.id} className="bg-white border rounded p-3 hover:shadow-md transition-shadow">
                                  <div className="flex justify-between items-start mb-2">
                                    <span className="text-sm font-medium text-gray-900 flex-1 pr-2">{item.title}</span>
                                    <div className="flex items-center gap-2">
                                      <Badge variant="outline" className="text-xs">
                                        {item.status}
                                      </Badge>
                                      <input
                                        type="number"
                                        value={item.storyPoints}
                                        onChange={(e) => {
                                          const newPoints = parseInt(e.target.value) || 0;
                                          const oldPoints = item.storyPoints;
                                          
                                          setSprintBacklogItems(prev => prev.map(prevItem => 
                                            prevItem.id === item.id 
                                              ? { ...prevItem, storyPoints: newPoints }
                                              : prevItem
                                          ));
                                          
                                          // Update sprint commitment
                                          setSprints(prev => prev.map(prevSprint => 
                                            prevSprint.id === sprint.id 
                                              ? { ...prevSprint, commitment: prevSprint.commitment - oldPoints + newPoints }
                                              : prevSprint
                                          ));
                                        }}
                                        className="w-12 text-xs border rounded px-1 py-0.5 text-center"
                                        min="1"
                                        max="20"
                                      />
                                      <span className="text-xs text-gray-500">pts</span>
                                    </div>
                                  </div>
                                  <div className="flex items-center justify-between text-xs">
                                    <Badge variant="outline" className={getPriorityColor(item.priority)}>
                                      {item.priority}
                                    </Badge>
                                    <div className="flex items-center gap-1">
                                      {item.tags.slice(0, 2).map((tag) => (
                                        <Badge key={tag} variant="secondary" className="text-xs px-1 py-0">
                                          {tag}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                              ))}
                          </div>
                          
                          {sprintBacklogItems.filter(item => item.sprintId === sprint.id).length === 0 && (
                            <div className="text-center text-gray-500 py-4">
                              <div className="text-2xl mb-2">⬇️</div>
                              <p className="text-sm">Drop sprint stories here</p>
                            </div>
                          )}
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* Sprint Planning Tab */}
            <TabsContent value="sprints" className="space-y-4">
              {/* Drag and Drop Zone */}
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-dashed border-blue-300 rounded-lg p-6 mb-6">
                <div className="text-center">
                  <div className="flex items-center justify-center mb-3">
                    <Target className="h-8 w-8 text-blue-600 mr-2" />
                    <h3 className="text-lg font-semibold text-blue-900">Quick Sprint Assignment</h3>
                  </div>
                  <p className="text-blue-700 mb-4">
                    Drag product backlog items here to automatically create sprint backlog items with intelligent story point calculation
                  </p>
                  
                  <div 
                    className="border-2 border-dashed border-blue-400 rounded-lg p-8 bg-blue-50 hover:bg-blue-100 transition-colors"
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      try {
                        const itemData = e.dataTransfer.getData('application/json');
                        const item = JSON.parse(itemData);
                        
                        // Find active sprint or use first sprint
                        const activeSprint = sprints.find(s => s.status === "Active") || sprints[0];
                        if (activeSprint && item) {
                          createSprintBacklogItemMutation.mutate({ 
                            productBacklogItem: item, 
                            sprintId: activeSprint.id 
                          });
                        }
                      } catch (error) {
                        console.error('Drop error:', error);
                        toast({
                          title: "Drop Error",
                          description: "Unable to process dropped item",
                          variant: "destructive",
                        });
                      }
                    }}
                  >
                    <div className="flex flex-col items-center">
                      <ArrowRight className="h-12 w-12 text-blue-500 mb-2" />
                      <p className="text-blue-800 font-medium">Drop Product Backlog Items Here</p>
                      <p className="text-sm text-blue-600 mt-1">Auto-assigns to active sprint with calculated story points</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Sprint Management</h3>
                <Dialog open={newSprintOpen} onOpenChange={setNewSprintOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-purple-600 hover:bg-purple-700">
                      <Plus className="h-4 w-4 mr-2" />
                      Create New Sprint
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Create New Sprint</DialogTitle>
                      <DialogDescription>
                        Set up a new sprint with goals and timeline.
                      </DialogDescription>
                    </DialogHeader>
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        const formData = new FormData(e.currentTarget);
                        createSprintMutation.mutate({
                          name: formData.get('name') as string,
                          goal: formData.get('goal') as string,
                          startDate: formData.get('startDate') as string,
                          endDate: formData.get('endDate') as string,
                          capacity: parseInt(formData.get('capacity') as string),
                          status: "Planning" as const,
                          commitment: 0,
                        });
                      }}
                      className="space-y-4"
                    >
                      <div>
                        <Label htmlFor="name">Sprint Name</Label>
                        <Input name="name" placeholder="Sprint 2 - Core Features" required />
                      </div>
                      <div>
                        <Label htmlFor="goal">Sprint Goal</Label>
                        <Textarea name="goal" placeholder="What will this sprint accomplish?" required />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="startDate">Start Date</Label>
                          <Input name="startDate" type="date" required />
                        </div>
                        <div>
                          <Label htmlFor="endDate">End Date</Label>
                          <Input name="endDate" type="date" required />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="capacity">Team Capacity (Story Points)</Label>
                        <Input name="capacity" type="number" placeholder="40" required />
                      </div>
                      <DialogFooter>
                        <Button type="submit" disabled={createSprintMutation.isPending}>
                          {createSprintMutation.isPending ? "Creating..." : "Create Sprint"}
                        </Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid gap-4">
                {sprints.map((sprint) => (
                  <Card key={sprint.id} className="border-purple-200">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{sprint.name}</CardTitle>
                        <Badge 
                          variant="outline" 
                          className={
                            sprint.status === "Active" ? "bg-green-100 text-green-800" :
                            sprint.status === "Planning" ? "bg-yellow-100 text-yellow-800" :
                            "bg-gray-100 text-gray-800"
                          }
                        >
                          {sprint.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{sprint.goal}</p>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-purple-600" />
                          <div>
                            <p className="text-xs text-gray-500">Duration</p>
                            <p className="text-sm font-medium">
                              {new Date(sprint.startDate).toLocaleDateString()} - {new Date(sprint.endDate).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Target className="h-4 w-4 text-green-600" />
                          <div>
                            <p className="text-xs text-gray-500">Capacity</p>
                            <p className="text-sm font-medium">{sprint.capacity} points</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Zap className="h-4 w-4 text-blue-600" />
                          <div>
                            <p className="text-xs text-gray-500">Committed</p>
                            <p className="text-sm font-medium">{sprint.commitment} points</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <BarChart3 className="h-4 w-4 text-orange-600" />
                          <div>
                            <p className="text-xs text-gray-500">Items</p>
                            <p className="text-sm font-medium">{sprint.items.length} stories</p>
                          </div>
                        </div>
                      </div>

                      {sprint.items.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-medium text-sm">Sprint Backlog:</h4>
                          {sprint.items.map((item) => (
                            <div key={item.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                              <span className="text-sm">{item.title}</span>
                              <Badge variant="outline" className="text-xs">
                                {item.storyPoints} pts
                              </Badge>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Sprint Board Tab */}
            <TabsContent value="board" className="space-y-4">
              <div className="mb-4">
                <h3 className="text-lg font-semibold mb-2">Active Sprint Board</h3>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  {sprints.filter(s => s.status === "Active").map(sprint => (
                    <div key={sprint.id} className="flex items-center gap-2">
                      <Badge variant="outline" className="bg-green-100 text-green-800">
                        {sprint.name}
                      </Badge>
                      <span>{sprint.sprintBacklog.length} items</span>
                      <span>•</span>
                      <span>{sprint.commitment}/{sprint.capacity} points</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4">
                {(["To Do", "In Progress", "Review", "Done"] as const).map((status) => {
                  const statusItems = sprints
                    .filter(s => s.status === "Active")
                    .flatMap(s => s.sprintBacklog.filter(item => item.status === status));
                  
                  return (
                    <Card key={status} className="min-h-[500px]">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {status === "To Do" && <AlertCircle className="h-4 w-4 text-gray-500" />}
                            {status === "In Progress" && <Clock className="h-4 w-4 text-blue-500" />}
                            {status === "Review" && <User className="h-4 w-4 text-orange-500" />}
                            {status === "Done" && <CheckCircle className="h-4 w-4 text-green-500" />}
                            {status}
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            {statusItems.length}
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {statusItems.length > 0 ? (
                          statusItems.map((item) => (
                            <div
                              key={item.id}
                              className="p-3 bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                              draggable
                              onDragStart={(e) => {
                                e.dataTransfer.setData('text/plain', item.id.toString());
                              }}
                            >
                              <div className="flex items-start justify-between mb-2">
                                <h4 className="font-medium text-sm text-gray-900 line-clamp-2">
                                  {item.title}
                                </h4>
                                <Badge className={getPriorityColor(item.priority)} variant="outline" size="sm">
                                  {item.priority}
                                </Badge>
                              </div>
                              
                              <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                                {item.description}
                              </p>
                              
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1">
                                  {item.tags.slice(0, 2).map((tag) => (
                                    <Badge key={tag} variant="secondary" className="text-xs px-1 py-0">
                                      {tag}
                                    </Badge>
                                  ))}
                                  {item.tags.length > 2 && (
                                    <span className="text-xs text-gray-400">+{item.tags.length - 2}</span>
                                  )}
                                </div>
                                <Badge variant="outline" className="bg-blue-50 text-blue-700 text-xs">
                                  {item.storyPoints} pts
                                </Badge>
                              </div>
                              
                              {item.assignedTo && (
                                <div className="mt-2 flex items-center gap-1 text-xs text-gray-500">
                                  <User className="h-3 w-3" />
                                  {item.assignedTo}
                                </div>
                              )}
                              
                              <div className="mt-2 flex items-center gap-2">
                                {status !== "Done" && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="text-xs h-6 px-2"
                                    onClick={() => {
                                      const nextStatus = 
                                        status === "To Do" ? "In Progress" :
                                        status === "In Progress" ? "Review" :
                                        "Done";
                                      moveSprintBacklogItemMutation.mutate({ 
                                        itemId: item.id, 
                                        newStatus: nextStatus as any 
                                      });
                                    }}
                                  >
                                    <ArrowRight className="h-3 w-3 mr-1" />
                                    Move to {
                                      status === "To Do" ? "In Progress" :
                                      status === "In Progress" ? "Review" :
                                      "Done"
                                    }
                                  </Button>
                                )}
                                {status !== "To Do" && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="text-xs h-6 px-2 text-gray-500"
                                    onClick={() => {
                                      const prevStatus = 
                                        status === "In Progress" ? "To Do" :
                                        status === "Review" ? "In Progress" :
                                        "Review";
                                      moveSprintBacklogItemMutation.mutate({ 
                                        itemId: item.id, 
                                        newStatus: prevStatus as any 
                                      });
                                    }}
                                  >
                                    ← Back
                                  </Button>
                                )}
                              </div>
                            </div>
                          ))
                        ) : (
                          <div
                            className="text-xs text-gray-400 text-center py-8 border-2 border-dashed border-gray-200 rounded-lg hover:border-gray-300 hover:bg-gray-50 transition-colors"
                            onDragOver={(e) => e.preventDefault()}
                            onDrop={(e) => {
                              e.preventDefault();
                              try {
                                // Try to get sprint backlog item ID first
                                const itemId = e.dataTransfer.getData('text/plain');
                                if (itemId && !isNaN(parseInt(itemId))) {
                                  moveSprintBacklogItemMutation.mutate({ 
                                    itemId: parseInt(itemId), 
                                    newStatus: status 
                                  });
                                  return;
                                }
                                
                                // Otherwise try to get product backlog item and create sprint item
                                const itemData = e.dataTransfer.getData('application/json');
                                if (itemData) {
                                  const item = JSON.parse(itemData);
                                  const activeSprint = sprints.find(s => s.status === "Active") || sprints[0];
                                  if (activeSprint && item) {
                                    createSprintBacklogItemMutation.mutate({ 
                                      productBacklogItem: item, 
                                      sprintId: activeSprint.id 
                                    });
                                  }
                                }
                              } catch (error) {
                                console.error('Drop error:', error);
                              }
                            }}
                          >
                            Drop sprint items here to change status
                            <br />
                            Or drop product backlog items to create sprint items
                            <br />
                            No items in {status.toLowerCase()}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
              
              {/* Sprint Summary */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Sprint Progress Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {sprints.filter(s => s.status === "Active").map(sprint => {
                    const totalItems = sprint.sprintBacklog.length;
                    const doneItems = sprint.sprintBacklog.filter(item => item.status === "Done").length;
                    const inProgressItems = sprint.sprintBacklog.filter(item => item.status === "In Progress").length;
                    const reviewItems = sprint.sprintBacklog.filter(item => item.status === "Review").length;
                    const todoItems = sprint.sprintBacklog.filter(item => item.status === "To Do").length;
                    
                    const completionRate = totalItems > 0 ? Math.round((doneItems / totalItems) * 100) : 0;
                    
                    return (
                      <div key={sprint.id} className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{sprint.name}</h4>
                          <div className="flex items-center gap-4 text-sm">
                            <span>Progress: {completionRate}%</span>
                            <span>Items: {totalItems}</span>
                            <span>Points: {sprint.commitment}/{sprint.capacity}</span>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-4 gap-4 text-center">
                          <div className="p-3 bg-gray-50 rounded-lg">
                            <div className="text-2xl font-bold text-gray-600">{todoItems}</div>
                            <div className="text-xs text-gray-500">To Do</div>
                          </div>
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">{inProgressItems}</div>
                            <div className="text-xs text-blue-500">In Progress</div>
                          </div>
                          <div className="p-3 bg-orange-50 rounded-lg">
                            <div className="text-2xl font-bold text-orange-600">{reviewItems}</div>
                            <div className="text-xs text-orange-500">Review</div>
                          </div>
                          <div className="p-3 bg-green-50 rounded-lg">
                            <div className="text-2xl font-bold text-green-600">{doneItems}</div>
                            <div className="text-xs text-green-500">Done</div>
                          </div>
                        </div>
                        
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-500 h-2 rounded-full transition-all duration-300" 
                            style={{ width: `${completionRate}%` }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}