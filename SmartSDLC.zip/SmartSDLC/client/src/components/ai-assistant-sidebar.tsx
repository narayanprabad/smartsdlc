import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Bot, 
  Send, 
  User, 
  Sparkles, 
  MessageSquare,
  ChevronRight,
  X
} from "lucide-react";

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  suggestions?: string[];
}

interface AIAssistantSidebarProps {
  userRole: string;
  context?: string;
  isOpen: boolean;
  onToggle: () => void;
}

export function AIAssistantSidebar({ userRole, context, isOpen, onToggle }: AIAssistantSidebarProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: `Hello! I'm your AI assistant specialized for ${userRole} tasks. I can help you with project analysis, requirements gathering, architecture decisions, and workflow optimization. What would you like to work on today?`,
      sender: 'ai',
      timestamp: new Date(),
      suggestions: [
        "Analyze project requirements",
        "Generate architecture recommendations", 
        "Create user stories",
        "Review compliance requirements"
      ]
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const getRoleSpecificPrompts = (role: string) => {
    switch (role) {
      case 'Business Analyst':
        return [
          "Help me analyze business requirements",
          "Generate functional specifications",
          "Create use case diagrams",
          "Review stakeholder needs"
        ];
      case 'Product Owner':
        return [
          "Prioritize product backlog",
          "Define acceptance criteria", 
          "Review user stories",
          "Plan sprint objectives"
        ];
      case 'Architect':
        return [
          "Design system architecture",
          "Review technical decisions",
          "Assess scalability options",
          "Create deployment strategy"
        ];
      case 'Scrum Master':
        return [
          "Plan sprint ceremonies",
          "Remove team blockers",
          "Track velocity metrics",
          "Facilitate retrospectives"
        ];
      case 'UI Designer':
        return [
          "Create user interface mockups",
          "Design user experience flows",
          "Review accessibility standards",
          "Generate style guidelines"
        ];
      case 'Developer':
        return [
          "Review code architecture",
          "Generate implementation plans",
          "Assess technical debt",
          "Create testing strategies"
        ];
      case 'DevOps':
        return [
          "Design CI/CD pipelines",
          "Plan infrastructure setup",
          "Configure monitoring",
          "Optimize deployment process"
        ];
      default:
        return [
          "Analyze project requirements",
          "Generate recommendations",
          "Review best practices",
          "Plan next steps"
        ];
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsLoading(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: generateAIResponse(inputMessage, userRole),
        sender: 'ai',
        timestamp: new Date(),
        suggestions: getRoleSpecificPrompts(userRole).slice(0, 3)
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsLoading(false);
    }, 1500);
  };

  const generateAIResponse = (message: string, role: string): string => {
    // Intelligent response generation based on role and message
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('architecture') || lowerMessage.includes('design')) {
      return `As an AI assistant for ${role}, I recommend implementing a microservices architecture with API-first design. This approach provides scalability, maintainability, and enables parallel development. Key considerations include service decomposition, data consistency patterns, and inter-service communication protocols.`;
    }
    
    if (lowerMessage.includes('requirements') || lowerMessage.includes('analysis')) {
      return `For requirements analysis, I suggest following a structured approach: 1) Stakeholder interviews to gather business needs, 2) User story mapping to understand workflows, 3) Technical constraint analysis, 4) Risk assessment and mitigation planning. This ensures comprehensive coverage of functional and non-functional requirements.`;
    }
    
    if (lowerMessage.includes('sprint') || lowerMessage.includes('planning')) {
      return `Sprint planning should focus on deliverable value and team capacity. I recommend: 1) Review and refine the product backlog, 2) Estimate story points using planning poker, 3) Identify dependencies and risks, 4) Set clear sprint goals and success criteria. Consider team velocity and historical data for realistic planning.`;
    }
    
    if (lowerMessage.includes('user') || lowerMessage.includes('story')) {
      return `User stories should follow the format: "As a [user type], I want [functionality] so that [benefit]." Include clear acceptance criteria, definition of done, and story points. Consider edge cases, error handling, and user experience flows. Prioritize based on business value and technical dependencies.`;
    }
    
    return `I understand you're working on "${message}". As your AI assistant specialized in ${role} workflows, I can help you break this down into actionable steps, identify best practices, and provide relevant templates or frameworks. What specific aspect would you like to focus on first?`;
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputMessage(suggestion);
  };

  if (!isOpen) {
    return (
      <div className="fixed right-0 top-1/2 -translate-y-1/2 z-50">
        <Button
          onClick={onToggle}
          variant="default"
          size="sm"
          className="rounded-l-lg rounded-r-none bg-blue-600 hover:bg-blue-700 text-white shadow-lg"
        >
          <Bot className="w-4 h-4 mr-1" />
          AI Assistant
          <ChevronRight className="w-3 h-3 ml-1" />
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed right-0 top-0 h-full w-80 bg-white border-l border-gray-200 shadow-xl z-40 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">AI Assistant</h3>
            <p className="text-xs text-gray-600">{userRole} Specialist</p>
          </div>
        </div>
        <Button 
          onClick={onToggle}
          variant="ghost" 
          size="sm"
          className="h-8 w-8 p-0"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>

      {/* Role Badge */}
      <div className="p-3 bg-gray-50 border-b">
        <Badge variant="secondary" className="w-full justify-center bg-blue-100 text-blue-800">
          <Bot className="w-3 h-3 mr-1" />
          Optimized for {userRole}
        </Badge>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                message.sender === 'user' 
                  ? 'bg-blue-500' 
                  : 'bg-gradient-to-br from-purple-500 to-blue-600'
              }`}>
                {message.sender === 'user' ? (
                  <User className="w-3 h-3 text-white" />
                ) : (
                  <Bot className="w-3 h-3 text-white" />
                )}
              </div>
              <div className={`flex-1 ${message.sender === 'user' ? 'text-right' : 'text-left'}`}>
                <div className={`inline-block max-w-[85%] p-3 rounded-lg text-sm ${
                  message.sender === 'user'
                    ? 'bg-blue-500 text-white rounded-tr-none'
                    : 'bg-gray-100 text-gray-900 rounded-tl-none'
                }`}>
                  {message.content}
                </div>
                {message.suggestions && (
                  <div className="mt-2 space-y-1">
                    <p className="text-xs text-gray-500 mb-1">Suggested actions:</p>
                    {message.suggestions.map((suggestion, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        size="sm"
                        onClick={() => handleSuggestionClick(suggestion)}
                        className="h-auto p-2 text-xs text-left justify-start bg-white hover:bg-blue-50 border border-gray-200 rounded-md w-full"
                      >
                        <MessageSquare className="w-3 h-3 mr-1 flex-shrink-0" />
                        <span className="truncate">{suggestion}</span>
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex gap-3">
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
                <Bot className="w-3 h-3 text-white" />
              </div>
              <div className="flex-1">
                <div className="bg-gray-100 p-3 rounded-lg rounded-tl-none">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t border-gray-200 bg-gray-50">
        <div className="flex gap-2">
          <Textarea
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder={`Ask your AI assistant for ${userRole} guidance...`}
            className="flex-1 min-h-[40px] max-h-[100px] resize-none text-sm"
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
          />
          <Button
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || isLoading}
            size="sm"
            className="h-10 w-10 p-0 bg-blue-600 hover:bg-blue-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          Press Enter to send, Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}