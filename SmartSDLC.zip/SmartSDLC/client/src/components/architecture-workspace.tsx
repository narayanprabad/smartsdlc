import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  Layers,
  Database,
  Server,
  Globe,
  Shield,
  Zap,
  Network,
  Settings,
  CheckCircle,
  Edit3,
  Save,
  Eye,
  Cpu,
  Cloud,
  Lock,
  Monitor,
  Workflow,
  GitBranch,
  Container,
  Activity
} from "lucide-react";

interface Architecture {
  id: number;
  projectId: number;
  systemOverview: string;
  architecturalPrinciples: string;
  componentDiagram: string;
  dataFlow: string;
  technologyStack: {
    frontend: string[];
    backend: string[];
    database: string[];
    infrastructure: string[];
    security: string[];
  };
  securityArchitecture: string;
  deploymentStrategy: string;
  scalabilityConsiderations: string;
  integrationPoints: string;
  riskAssessment: string;
  status: "draft" | "finalized";
  createdById: number;
  assignedArchitectId: number;
  createdAt: string;
  updatedAt: string;
}

interface ArchitectureWorkspaceProps {
  projectId: number;
  userRole: string;
}

export function ArchitectureWorkspace({ projectId, userRole }: ArchitectureWorkspaceProps) {
  const [editMode, setEditMode] = useState(false);
  const [editedData, setEditedData] = useState<Partial<Architecture>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: architecture, isLoading } = useQuery({
    queryKey: [`/api/projects/${projectId}/architecture`],
    enabled: !!projectId,
  });

  const updateMutation = useMutation({
    mutationFn: async (data: Partial<Architecture>) => {
      const response = await fetch(`/api/projects/${projectId}/architecture`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to update architecture");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/architecture`] });
      setEditMode(false);
      setEditedData({});
      toast({
        title: "Architecture Updated",
        description: "Your architecture changes have been saved successfully.",
      });
    },
    onError: (error) => {
      console.error("Error updating architecture:", error);
      toast({
        title: "Update Failed",
        description: "Failed to save architecture changes. Please try again.",
        variant: "destructive",
      });
    },
  });

  const finalizeMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/projects/${projectId}/architecture/finalize`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Failed to finalize architecture");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/architecture`] });
      toast({
        title: "Architecture Finalized",
        description: "Architecture has been finalized and is now available to other roles.",
      });
    },
  });

  useEffect(() => {
    if (architecture && Object.keys(editedData).length === 0) {
      setEditedData(architecture);
    }
  }, [architecture, editedData]);

  const handleSave = () => {
    updateMutation.mutate(editedData);
  };

  const handleFinalize = () => {
    finalizeMutation.mutate();
  };

  const canEdit = userRole === "architect";
  const isFinalized = architecture?.status === "finalized";
  const currentData = editMode ? editedData : architecture;
  
  // Default architecture data for display
  const defaultArchitecture = {
    systemOverview: "AI-generated enterprise-grade system architecture optimized for financial services compliance and scalability with microservices design patterns.",
    architecturalPrinciples: "Microservices architecture with event-driven design, domain-driven development, CQRS pattern implementation, and comprehensive security layers.",
    riskAssessment: "Identified risks: service dependencies, data consistency, security vulnerabilities. Mitigation: circuit breakers, distributed tracing, security scanning, and disaster recovery.",
    componentDiagram: "Frontend Layer (React SPA) → API Gateway → Authentication Service → Core Business Services → Data Access Layer → Database Cluster → External Integrations",
    dataFlow: "Client Request → Load Balancer → API Gateway → JWT Validation → Business Logic Processing → Database Operations → Response Aggregation → Client Response",
    technologyStack: {
      frontend: ["React 18", "TypeScript", "Tailwind CSS", "Redux Toolkit"],
      backend: ["Node.js", "Express.js", "TypeScript", "GraphQL"],
      database: ["PostgreSQL 15", "Redis 7", "TimescaleDB"],
      infrastructure: ["Docker", "Kubernetes", "AWS EKS", "Terraform"],
      security: ["OAuth 2.0", "JWT", "HTTPS/TLS 1.3", "Rate Limiting", "RBAC"]
    },
    securityArchitecture: "Multi-layered security with zero-trust architecture, end-to-end encryption, comprehensive audit logging, and regulatory compliance frameworks.",
    integrationPoints: "REST APIs, GraphQL endpoints, message queues, webhook systems, and real-time WebSocket connections.",
    deploymentStrategy: "Blue-green deployment with automated CI/CD pipelines, canary releases, and comprehensive monitoring.",
    scalabilityConsiderations: "Horizontal auto-scaling, event-driven microservices, distributed caching, database sharding, and CDN integration for global performance."
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-600 rounded-lg">
                <Layers className="h-6 w-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-2xl font-bold text-gray-900">
                  System Architecture Design
                </CardTitle>
                <p className="text-gray-600 mt-1">
                  AI-powered enterprise architecture with advanced compliance and scalability
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge 
                variant={isFinalized ? "default" : "secondary"}
                className={isFinalized ? "bg-green-600" : "bg-yellow-500"}
              >
                {isFinalized ? (
                  <>
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Finalized
                  </>
                ) : (
                  <>
                    <Edit3 className="h-3 w-3 mr-1" />
                    Draft
                  </>
                )}
              </Badge>
              {canEdit && !isFinalized && (
                <div className="flex gap-2">
                  {editMode ? (
                    <>
                      <Button
                        onClick={handleSave}
                        disabled={updateMutation.isPending}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        Save Changes
                      </Button>
                      <Button
                        onClick={() => setEditMode(false)}
                        variant="outline"
                      >
                        Cancel
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button
                        onClick={() => setEditMode(true)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Edit3 className="h-4 w-4 mr-2" />
                        Edit Architecture
                      </Button>
                      <Button
                        onClick={handleFinalize}
                        disabled={finalizeMutation.isPending}
                        variant="outline"
                        className="border-green-600 text-green-600 hover:bg-green-50"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Finalize
                      </Button>
                    </>
                  )}
                </div>
              )}
              {!canEdit && (
                <Badge variant="outline" className="text-gray-600">
                  <Eye className="h-3 w-3 mr-1" />
                  View Only
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Architecture Visualization Dashboard */}
      <div className="grid lg:grid-cols-4 gap-6">
        {/* System Health Metrics */}
        <Card className="border border-green-200 bg-green-50">
          <CardContent className="p-4 text-center">
            <Activity className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-green-700">99.9%</div>
            <div className="text-sm text-green-600">System Reliability</div>
          </CardContent>
        </Card>

        <Card className="border border-blue-200 bg-blue-50">
          <CardContent className="p-4 text-center">
            <Zap className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-blue-700">200ms</div>
            <div className="text-sm text-blue-600">Response Time</div>
          </CardContent>
        </Card>

        <Card className="border border-purple-200 bg-purple-50">
          <CardContent className="p-4 text-center">
            <Shield className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-purple-700">A+</div>
            <div className="text-sm text-purple-600">Security Grade</div>
          </CardContent>
        </Card>

        <Card className="border border-orange-200 bg-orange-50">
          <CardContent className="p-4 text-center">
            <Cloud className="h-8 w-8 text-orange-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-orange-700">Auto</div>
            <div className="text-sm text-orange-600">Scaling</div>
          </CardContent>
        </Card>
      </div>

      {/* Architecture Content */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Layers className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="diagram" className="flex items-center gap-2">
            <Network className="h-4 w-4" />
            Architecture
          </TabsTrigger>
          <TabsTrigger value="technology" className="flex items-center gap-2">
            <Cpu className="h-4 w-4" />
            Tech Stack
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Lock className="h-4 w-4" />
            Security
          </TabsTrigger>
          <TabsTrigger value="deployment" className="flex items-center gap-2">
            <Container className="h-4 w-4" />
            Deployment
          </TabsTrigger>
        </TabsList>

        {/* System Overview */}
        <TabsContent value="overview">
          <div className="grid gap-6">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-gray-50 to-blue-50 border-b">
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-5 w-5" />
                  System Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={editedData.systemOverview || ""}
                    onChange={(e) => setEditedData({ ...editedData, systemOverview: e.target.value })}
                    rows={4}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {currentData?.systemOverview || defaultArchitecture.systemOverview}
                  </p>
                )}
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 border-b">
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Architectural Principles
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={editedData.architecturalPrinciples || ""}
                    onChange={(e) => setEditedData({ ...editedData, architecturalPrinciples: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {currentData?.architecturalPrinciples || defaultArchitecture.architecturalPrinciples}
                  </p>
                )}
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-yellow-50 to-orange-50 border-b">
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Risk Assessment & Mitigation
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={editedData.riskAssessment || ""}
                    onChange={(e) => setEditedData({ ...editedData, riskAssessment: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {currentData?.riskAssessment || defaultArchitecture.riskAssessment}
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Architecture Diagram */}
        <TabsContent value="diagram">
          <div className="grid gap-6">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b">
                <CardTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5" />
                  System Architecture Diagram
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                {/* Beautiful Architecture Visualization */}
                <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-8 rounded-xl border-2 border-blue-200">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
                    {/* Frontend Layer */}
                    <div className="text-center space-y-4">
                      <div className="bg-gradient-to-br from-green-400 to-green-600 p-6 rounded-xl shadow-lg">
                        <Globe className="h-12 w-12 text-white mx-auto mb-3" />
                        <h3 className="text-white font-bold text-lg">Frontend Layer</h3>
                        <p className="text-green-100 text-sm">React SPA</p>
                      </div>
                      <div className="space-y-2">
                        <Badge className="bg-green-100 text-green-800">React 18</Badge>
                        <Badge className="bg-green-100 text-green-800">TypeScript</Badge>
                        <Badge className="bg-green-100 text-green-800">Tailwind CSS</Badge>
                      </div>
                    </div>

                    {/* API Gateway & Services */}
                    <div className="text-center space-y-4">
                      <div className="bg-gradient-to-br from-blue-500 to-blue-700 p-6 rounded-xl shadow-lg">
                        <Server className="h-12 w-12 text-white mx-auto mb-3" />
                        <h3 className="text-white font-bold text-lg">API Gateway</h3>
                        <p className="text-blue-100 text-sm">Microservices</p>
                      </div>
                      <div className="space-y-2">
                        <Badge className="bg-blue-100 text-blue-800">Node.js</Badge>
                        <Badge className="bg-blue-100 text-blue-800">Express.js</Badge>
                        <Badge className="bg-blue-100 text-blue-800">GraphQL</Badge>
                      </div>
                    </div>

                    {/* Database Layer */}
                    <div className="text-center space-y-4">
                      <div className="bg-gradient-to-br from-purple-500 to-purple-700 p-6 rounded-xl shadow-lg">
                        <Database className="h-12 w-12 text-white mx-auto mb-3" />
                        <h3 className="text-white font-bold text-lg">Data Layer</h3>
                        <p className="text-purple-100 text-sm">Database Cluster</p>
                      </div>
                      <div className="space-y-2">
                        <Badge className="bg-purple-100 text-purple-800">PostgreSQL 15</Badge>
                        <Badge className="bg-purple-100 text-purple-800">Redis 7</Badge>
                        <Badge className="bg-purple-100 text-purple-800">TimescaleDB</Badge>
                      </div>
                    </div>
                  </div>

                  {/* Data Flow Arrows */}
                  <div className="flex justify-center items-center mt-8 space-x-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <div className="w-8 h-0.5 bg-gradient-to-r from-green-500 to-blue-500"></div>
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <div className="w-8 h-0.5 bg-gradient-to-r from-blue-500 to-purple-500"></div>
                      <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                    </div>
                  </div>
                </div>

                {/* Component Flow Description */}
                <div className="mt-6">
                  {editMode ? (
                    <Textarea
                      value={editedData.componentDiagram || ""}
                      onChange={(e) => setEditedData({ ...editedData, componentDiagram: e.target.value })}
                      rows={3}
                      className="text-base"
                      placeholder="Describe the component architecture flow..."
                    />
                  ) : (
                    <p className="text-gray-700 text-center leading-relaxed">
                      {architecture?.componentDiagram}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 border-b">
                <CardTitle className="flex items-center gap-2">
                  <Workflow className="h-5 w-5" />
                  Data Flow Architecture
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={editedData.dataFlow || ""}
                    onChange={(e) => setEditedData({ ...editedData, dataFlow: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {architecture?.dataFlow}
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Technology Stack */}
        <TabsContent value="technology">
          <Card className="border-0 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-green-50 to-teal-50 border-b">
              <CardTitle className="flex items-center gap-2">
                <Cpu className="h-5 w-5" />
                Technology Stack & Components
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {architecture?.technologyStack && (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Object.entries(architecture.technologyStack).map(([category, technologies]) => (
                    <div key={category} className="space-y-3">
                      <h3 className="font-bold text-lg capitalize text-gray-800 flex items-center gap-2">
                        {category === 'frontend' && <Globe className="h-5 w-5 text-green-600" />}
                        {category === 'backend' && <Server className="h-5 w-5 text-blue-600" />}
                        {category === 'database' && <Database className="h-5 w-5 text-purple-600" />}
                        {category === 'infrastructure' && <Cloud className="h-5 w-5 text-orange-600" />}
                        {category === 'security' && <Shield className="h-5 w-5 text-red-600" />}
                        {category}
                      </h3>
                      <div className="space-y-2">
                        {(technologies as string[]).map((tech: string, index: number) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className={`block w-fit ${
                              category === 'frontend' ? 'border-green-300 text-green-700 bg-green-50' :
                              category === 'backend' ? 'border-blue-300 text-blue-700 bg-blue-50' :
                              category === 'database' ? 'border-purple-300 text-purple-700 bg-purple-50' :
                              category === 'infrastructure' ? 'border-orange-300 text-orange-700 bg-orange-50' :
                              'border-red-300 text-red-700 bg-red-50'
                            }`}
                          >
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security */}
        <TabsContent value="security">
          <div className="grid gap-6">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-red-50 to-pink-50 border-b">
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Security Architecture
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={editedData.securityArchitecture || ""}
                    onChange={(e) => setEditedData({ ...editedData, securityArchitecture: e.target.value })}
                    rows={4}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {architecture?.securityArchitecture}
                  </p>
                )}
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b">
                <CardTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5" />
                  Integration Points
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={editedData.integrationPoints || ""}
                    onChange={(e) => setEditedData({ ...editedData, integrationPoints: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {architecture?.integrationPoints}
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Deployment */}
        <TabsContent value="deployment">
          <div className="grid gap-6">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-orange-50 to-yellow-50 border-b">
                <CardTitle className="flex items-center gap-2">
                  <Container className="h-5 w-5" />
                  Deployment Strategy
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={editedData.deploymentStrategy || ""}
                    onChange={(e) => setEditedData({ ...editedData, deploymentStrategy: e.target.value })}
                    rows={4}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {architecture?.deploymentStrategy}
                  </p>
                )}
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-teal-50 to-green-50 border-b">
                <CardTitle className="flex items-center gap-2">
                  <GitBranch className="h-5 w-5" />
                  Scalability Considerations
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={editedData.scalabilityConsiderations || ""}
                    onChange={(e) => setEditedData({ ...editedData, scalabilityConsiderations: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {architecture?.scalabilityConsiderations}
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}