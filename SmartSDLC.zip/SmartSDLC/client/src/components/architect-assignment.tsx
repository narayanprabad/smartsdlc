import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  UserCheck, 
  Building, 
  Code, 
  Database, 
  Shield, 
  Zap,
  CheckCircle,
  Clock
} from "lucide-react";

interface Project {
  id: number;
  name: string;
  description: string;
  status: string;
  approvalStatus: string;
  boardType?: string;
  managedByScrumMasterId?: number;
  assignedArchitectId?: number;
}

interface Architect {
  id: number;
  name: string;
  role: string;
}

interface ArchitectAssignmentProps {
  project: Project;
  userRole: string;
}

export function ArchitectAssignment({ project, userRole }: ArchitectAssignmentProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedArchitect, setSelectedArchitect] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: architects = [] } = useQuery({
    queryKey: ["/api/architects"],
    queryFn: () => fetch("/api/architects").then(res => res.json()),
  });

  const assignArchitectMutation = useMutation({
    mutationFn: (architectId: number) => 
      apiRequest(`/api/projects/${project.id}/assign-architect`, {
        method: "POST",
        body: { architectId }
      }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setIsDialogOpen(false);
      setSelectedArchitect("");
      toast({
        title: "Architect Assigned",
        description: data.message,
      });
    },
    onError: (error) => {
      toast({
        title: "Assignment Failed",
        description: "Failed to assign architect to project",
        variant: "destructive",
      });
    },
  });

  const handleAssignArchitect = () => {
    if (!selectedArchitect) {
      toast({
        title: "Selection Required",
        description: "Please select an architect",
        variant: "destructive",
      });
      return;
    }
    assignArchitectMutation.mutate(parseInt(selectedArchitect));
  };

  // Only show for projects with Scrum board setup and appropriate roles
  if (!project.boardType || project.approvalStatus !== "approved") {
    return null;
  }

  // Show for Product Owner or Admin roles
  if (!["product-owner", "admin", "scrum-master"].includes(userRole)) {
    return null;
  }

  const getArchitectInfo = (architectId: number) => {
    return architects.find((arch: Architect) => arch.id === architectId);
  };

  const assignedArchitect = project.assignedArchitectId ? getArchitectInfo(project.assignedArchitectId) : null;

  return (
    <Card className="mt-4">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building className="w-5 h-5 text-purple-600" />
            <CardTitle>System Architecture Assignment</CardTitle>
          </div>
          {assignedArchitect && (
            <Badge variant="secondary" className="flex items-center gap-1">
              <UserCheck className="w-3 h-3" />
              Architect Assigned
            </Badge>
          )}
        </div>
        <CardDescription>
          Assign system architect for technical design and implementation guidance
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {assignedArchitect ? (
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                <Avatar className="h-12 w-12">
                  <AvatarImage src="/placeholder-avatar.jpg" />
                  <AvatarFallback className="bg-purple-100 text-purple-700">
                    {assignedArchitect.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">
                    {assignedArchitect.name}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Lead System Architect
                  </p>
                  <div className="flex items-center gap-1 mt-1">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-green-600 dark:text-green-400">
                      Available for project architecture
                    </span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="font-medium flex items-center gap-2">
                    <Code className="w-4 h-4" />
                    Architecture Responsibilities
                  </h4>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>• System design and technology selection</li>
                    <li>• Technical architecture documentation</li>
                    <li>• Integration patterns and APIs</li>
                    <li>• Performance and scalability planning</li>
                  </ul>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-medium flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Quality Assurance
                  </h4>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>• Security architecture review</li>
                    <li>• Code quality standards</li>
                    <li>• Best practices enforcement</li>
                    <li>• Technical risk assessment</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                <Zap className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-blue-700 dark:text-blue-300">
                  Project is now available in architect's project queue for technical design phase
                </span>
              </div>

              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full">
                    Reassign Architect
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Reassign System Architect</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Select New Architect</label>
                      <Select value={selectedArchitect} onValueChange={setSelectedArchitect}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose an architect" />
                        </SelectTrigger>
                        <SelectContent>
                          {architects.map((architect: Architect) => (
                            <SelectItem key={architect.id} value={architect.id.toString()}>
                              <div className="flex items-center gap-2">
                                <Avatar className="h-6 w-6">
                                  <AvatarFallback className="text-xs">
                                    {architect.name.split(' ').map(n => n[0]).join('')}
                                  </AvatarFallback>
                                </Avatar>
                                {architect.name}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleAssignArchitect}
                        disabled={assignArchitectMutation.isPending || !selectedArchitect}
                      >
                        {assignArchitectMutation.isPending ? "Reassigning..." : "Reassign"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2 p-3 bg-amber-50 dark:bg-amber-950 rounded-lg border border-amber-200 dark:border-amber-800">
                <Clock className="w-4 h-4 text-amber-600" />
                <span className="text-sm text-amber-700 dark:text-amber-300">
                  Project requires architect assignment before technical design can begin
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="space-y-3">
                  <h4 className="font-medium flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    Technical Leadership
                  </h4>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>• Microservices architecture design</li>
                    <li>• Database schema optimization</li>
                    <li>• API gateway configuration</li>
                    <li>• Cloud infrastructure planning</li>
                  </ul>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-medium flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Enterprise Standards
                  </h4>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>• Security compliance (SOX, PCI)</li>
                    <li>• Regulatory requirements</li>
                    <li>• Performance benchmarks</li>
                    <li>• Disaster recovery planning</li>
                  </ul>
                </div>
              </div>
              
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full flex items-center gap-2">
                    <UserCheck className="w-4 h-4" />
                    Assign System Architect
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Assign System Architect</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Select an experienced architect to lead the technical design and implementation strategy for this project.
                    </p>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Available Architects</label>
                      <Select value={selectedArchitect} onValueChange={setSelectedArchitect}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose an architect" />
                        </SelectTrigger>
                        <SelectContent>
                          {architects.map((architect: Architect) => (
                            <SelectItem key={architect.id} value={architect.id.toString()}>
                              <div className="flex items-center gap-2">
                                <Avatar className="h-6 w-6">
                                  <AvatarFallback className="text-xs bg-purple-100 text-purple-700">
                                    {architect.name.split(' ').map(n => n[0]).join('')}
                                  </AvatarFallback>
                                </Avatar>
                                {architect.name}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleAssignArchitect}
                        disabled={assignArchitectMutation.isPending || !selectedArchitect}
                      >
                        {assignArchitectMutation.isPending ? "Assigning..." : "Assign Architect"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}