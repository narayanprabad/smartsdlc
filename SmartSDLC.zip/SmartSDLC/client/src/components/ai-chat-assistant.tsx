import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Brain, 
  CheckCircle, 
  Send, 
  User,
  Bot,
  Lightbulb,
  Target,
  FileText,
  Clock,
  GripVertical,
  Users,
  BarChart3,
  Layers,
  Palette,
  Code,
  Settings
} from "lucide-react";

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIChatAssistantProps {
  userRole: string;
}

export function AIChatAssistant({ userRole }: AIChatAssistantProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const getRoleSpecificGreeting = (role: string) => {
    const greetings: Record<string, string> = {
      "Business Analyst": "Hello! I'm your specialized AI assistant for Business Analysis. I can help you create EMIR compliance projects, analyze functional requirements, document stakeholder needs, and ensure regulatory compliance. Ready to streamline your analysis workflow?",
      "Product Owner": "Hello! I'm your AI assistant for Product Management. I can help you prioritize backlogs, approve projects, create user stories, and plan sprint deliverables. Let's maximize your product's business value together.",
      "Scrum Master": "Hello! I'm your AI assistant for Agile facilitation. I can help you setup Kanban boards, plan ceremonies, track velocity, and remove blockers. Ready to boost your team's productivity?",
      "Architect": "Hello! I'm your AI assistant for System Architecture. I can help you design microservices, create integration diagrams, define technology stacks, and plan scalable deployments. Let's build robust architectures together.",
      "UI Designer": "Hello! I'm your AI assistant for UI/UX Design. I can help you create wireframes, design responsive layouts, develop design systems, and prototype user flows. Ready to craft exceptional user experiences?",
      "Developer": "Hello! I'm your AI assistant for Software Development. I can help you review architecture, estimate story points, plan implementations, and debug issues. Let's build high-quality code together.",
      "DevOps": "Hello! I'm your AI assistant for DevOps Engineering. I can help you design CI/CD pipelines, configure containers, setup monitoring, and automate infrastructure. Ready to optimize your deployment workflows?"
    };
    return greetings[role] || greetings["Business Analyst"];
  };

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: getRoleSpecificGreeting(userRole),
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isResizing, setIsResizing] = useState(false);

  // AI Project Creation Mutation
  const createAIProjectMutation = useMutation({
    mutationFn: async (description: string) => {
      const response = await fetch('/api/ai/create-project', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          description, 
          currentRole: userRole.toLowerCase().replace(' ', '-') 
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to create AI project');
      }
      
      return await response.json();
    },
    onSuccess: (data: any) => {
      // Add AI response showing the created project
      let content = `✅ Successfully created project: "${data.project.name}"\n\n📋 Generated Requirements:\n• ${data.functionalRequirements.length} functional requirements\n• ${data.nonFunctionalRequirements.length} non-functional requirements\n• ${data.useCasesCreated} use cases created`;
      
      if (data.autoApproved) {
        content += `\n\n🚀 Auto-Approved: This technical project has been automatically approved for development and deliverables have been created.\n• ${data.deliverables?.length || 0} deliverables created\n• ${data.userStoriesCreated || 0} user stories generated\n• Jira project: ${data.jiraProjectKey || 'Created'}`;
      } else {
        content += `\n\nThe project is now ready for Product Owner approval. You can view it in your dashboard.`;
      }
      
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: content,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      
      // Invalidate projects cache to refresh dashboard
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      
      toast({
        title: "Project Created",
        description: `Successfully created "${data.project.name}" with detailed requirements`,
      });
    },
    onError: (error: any) => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: `❌ Sorry, I encountered an error creating the project: ${error.message}\n\nPlease try again or provide more specific details about your project requirements.`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      
      toast({
        title: "Error",
        description: "Failed to create project with AI assistance",
        variant: "destructive"
      });
    }
  });

  const getRoleSpecificQuickActions = (role: string) => {
    const roleActions: Record<string, Array<{text: string, icon: any}>> = {
      "Business Analyst": [
        { text: "Create project from specification", icon: Brain },
        { text: "Generate functional requirements analysis", icon: BarChart3 },
        { text: "Document stakeholder requirements", icon: Users },
        { text: "Review compliance requirements", icon: Target },
        { text: "Define acceptance criteria templates", icon: CheckCircle }
      ],
      "Product Owner": [
        { text: "Approve pending project submissions", icon: CheckCircle },
        { text: "Prioritize product backlog by business value", icon: Target },
        { text: "Create epic-level user stories", icon: FileText },
        { text: "Define sprint goals and deliverables", icon: Lightbulb },
        { text: "Review team capacity planning", icon: BarChart3 }
      ],
      "Scrum Master": [
        { text: "Setup Kanban board for new project", icon: Users },
        { text: "Schedule sprint planning ceremony", icon: Clock },
        { text: "Track team velocity and burndown", icon: BarChart3 },
        { text: "Facilitate daily standup meeting", icon: Target },
        { text: "Identify and resolve blockers", icon: Settings }
      ],
      "Architect": [
        { text: "Design microservices architecture", icon: Layers },
        { text: "Create system integration diagrams", icon: FileText },
        { text: "Define technology stack recommendations", icon: Settings },
        { text: "Review API design patterns", icon: Target },
        { text: "Plan deployment and scaling strategy", icon: Brain }
      ],
      "UI Designer": [
        { text: "Create user interface wireframes", icon: Palette },
        { text: "Design responsive layouts", icon: Target },
        { text: "Develop design system components", icon: CheckCircle },
        { text: "Prototype user interaction flows", icon: Lightbulb },
        { text: "Conduct accessibility review", icon: Users }
      ],
      "Developer": [
        { text: "Review technical architecture decisions", icon: Code },
        { text: "Estimate development story points", icon: BarChart3 },
        { text: "Plan API implementation strategy", icon: Target },
        { text: "Setup development environment", icon: Settings },
        { text: "Debug performance issues", icon: Layers }
      ],
      "DevOps": [
        { text: "Design CI/CD pipeline architecture", icon: Settings },
        { text: "Configure containerization strategy", icon: Target },
        { text: "Setup monitoring and alerting", icon: BarChart3 },
        { text: "Plan infrastructure automation", icon: Layers },
        { text: "Review security compliance", icon: Brain }
      ]
    };
    
    return roleActions[role] || roleActions["Business Analyst"];
  };

  const quickActions = getRoleSpecificQuickActions(userRole);

  const detectProjectCreationIntent = (message: string): boolean => {
    const lowerMessage = message.toLowerCase();
    
    // Enhanced project creation patterns
    const projectPatterns = [
      /create\s+(new\s+)?(.+\s+)?(project|platform|system|application)/,
      /build\s+(new\s+)?(.+\s+)?(project|platform|system|application)/,
      /develop\s+(new\s+)?(.+\s+)?(project|platform|system|application)/,
      /design\s+(new\s+)?(.+\s+)?(project|platform|system|application)/,
      /(new|create)\s+(.+\s+)?(compliance|settlement|trade|delivery|platform|system)/,
      /from\s+specification/,
      /project.*from.*spec/,
      /compliance.*project/,
      /reporting.*project/
    ];
    
    const isProjectCreation = projectPatterns.some(pattern => pattern.test(lowerMessage));
    console.log(`🔍 Project creation detection for "${message}": ${isProjectCreation}`);
    return isProjectCreation;
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);

    // Check if user wants to create a project
    console.log(`🔍 User role: "${userRole}", Project intent: ${detectProjectCreationIntent(inputMessage)}`);
    if (detectProjectCreationIntent(inputMessage) && (userRole === "Business Analyst" || userRole === "business-analyst")) {
      console.log("✅ Triggering AI project creation");
      // Add loading message
      const loadingMessage: Message = {
        id: (Date.now() + 0.5).toString(),
        type: 'assistant',
        content: '🤖 Analyzing your requirements and creating a comprehensive project with AWS Bedrock AI...\n\nGenerating:\n• Functional requirements\n• Non-functional requirements\n• Use cases\n• Compliance mapping\n\nThis may take a moment...',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, loadingMessage]);
      
      // Trigger AI project creation
      console.log("🚀 Calling createAIProjectMutation.mutate with:", inputMessage);
      createAIProjectMutation.mutate(inputMessage);
    } else {
      // Regular AI response for other queries
      setTimeout(() => {
        const aiResponse: Message = {
          id: (Date.now() + 1).toString(),
          type: 'assistant',
          content: getRoleSpecificResponse(inputMessage, userRole),
          timestamp: new Date()
        };
        setMessages(prev => [...prev, aiResponse]);
      }, 1000);
    }

    setInputMessage('');
  };

  const getRoleSpecificResponse = (message: string, role: string): string => {
    const responses: Record<string, string> = {
      "Business Analyst": `As a Business Analyst, I can help you with: "${message}". I recommend analyzing stakeholder requirements, documenting functional specifications, and ensuring regulatory compliance. Would you like me to create a detailed project with comprehensive requirements?`,
      "Product Owner": `From a Product Owner perspective on: "${message}". I suggest prioritizing this based on business value, creating user stories, and planning sprint deliverables. This aligns with our product roadmap goals.`,
      "Scrum Master": `For Agile facilitation regarding: "${message}". I recommend breaking this into sprint-sized tasks, identifying dependencies, and planning team ceremonies. Let's ensure smooth delivery with proper velocity tracking.`,
      "Architect": `From an architectural standpoint on: "${message}". I suggest designing scalable solutions, defining integration patterns, and selecting appropriate technology stacks. Let's create a robust system architecture.`,
      "UI Designer": `For user experience design on: "${message}". I recommend creating user flows, designing intuitive interfaces, and ensuring accessibility. Let's craft exceptional user experiences.`,
      "Developer": `From a development perspective on: "${message}". I suggest reviewing technical requirements, estimating effort, and planning implementation approach. Let's build high-quality, maintainable code.`,
      "DevOps": `For DevOps engineering on: "${message}". I recommend designing CI/CD pipelines, planning infrastructure, and implementing monitoring. Let's automate and optimize your deployment workflows.`
    };
    
    return responses[role] || responses["Business Analyst"];
  };

  const handleQuickAction = (action: string) => {
    setInputMessage(action);
  };

  const handleMouseDown = () => {
    setIsResizing(true);
  };

  const handleMouseUp = () => {
    setIsResizing(false);
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <CardHeader className="pb-4 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Brain className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <CardTitle className="text-lg">AI Assistant</CardTitle>
              <p className="text-sm text-gray-500">{userRole} Support</p>
            </div>
          </div>
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            <CheckCircle className="h-3 w-3 mr-1" />
            Online
          </Badge>
        </div>
      </CardHeader>

      {/* Quick Actions */}
      <div className="p-4 border-b bg-gray-50">
        <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
          <Lightbulb className="h-4 w-4 text-yellow-500" />
          Quick Actions
        </h4>
        <div className="grid grid-cols-2 gap-2">
          {quickActions.map((action, index) => {
            const IconComponent = action.icon;
            return (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="text-xs justify-start h-8"
                onClick={() => handleQuickAction(action.text)}
              >
                <IconComponent className="h-3 w-3 mr-1" />
                {action.text}
              </Button>
            );
          })}
        </div>
      </div>

      {/* Chat Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.type === 'assistant' && (
                <div className="p-2 bg-blue-100 rounded-full">
                  <Bot className="h-4 w-4 text-blue-600" />
                </div>
              )}
              <div className={`max-w-[80%] ${message.type === 'user' ? 'order-first' : ''}`}>
                <div
                  className={`p-3 rounded-lg ${
                    message.type === 'user'
                      ? 'bg-blue-600 text-white ml-auto'
                      : 'bg-gray-100 text-gray-900'
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
                <div className="flex items-center gap-1 mt-1 text-xs text-gray-500">
                  <Clock className="h-3 w-3" />
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
              {message.type === 'user' && (
                <div className="p-2 bg-gray-200 rounded-full">
                  <User className="h-4 w-4 text-gray-600" />
                </div>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Message Input - Resizable Text Area */}
      <div className="p-4 border-t bg-white">
        <div className="flex gap-2 items-end">
          <div className="flex-1">
            <textarea
              placeholder="Describe your requirements or ask for assistance..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
              className="w-full min-h-[80px] max-h-[200px] p-3 border border-gray-300 rounded-lg resize-y focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={3}
              style={{ resize: 'vertical' }}
            />
          </div>
          <Button 
            onClick={handleSendMessage} 
            size="sm" 
            className="px-4 h-10 self-end"
            disabled={!inputMessage.trim()}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        <div className="mt-3 text-xs text-gray-500 flex items-center gap-1">
          <FileText className="h-3 w-3" />
          Powered by AI • Ready to assist with {userRole.toLowerCase()} workflows
        </div>
      </div>
    </div>
  );
}