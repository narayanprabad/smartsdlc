import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  Settings,
  Calendar,
  Users,
  GitBranch,
  ChevronRight,
  Plus,
  Eye,
  Clock,
  BarChart3,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Zap,
  List,
  Target,
  Play
} from "lucide-react";

interface ProjectManagementProps {
  projectId: number;
  onClose: () => void;
}

interface Deliverable {
  id: number;
  name: string;
  description: string;
  type: string;
  priority: string;
  status: string;
  assignedTo?: string;
  jiraEpicKey?: string;
  acceptanceCriteria: string;
  storyPoints: number;
}

interface Sprint {
  id: string;
  name: string;
  goal: string;
  startDate: string;
  endDate: string;
  status: 'planning' | 'active' | 'completed';
  deliverables: string[];
  velocity: number;
}

interface JiraSummary {
  projectKey: string;
  totalEpics: number;
  totalStories: number;
  completedStories: number;
  inProgressStories: number;
}

export function ProjectManagement({ projectId, onClose }: ProjectManagementProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedDeliverables, setSelectedDeliverables] = useState<number[]>([]);
  const [newSprintName, setNewSprintName] = useState("");
  const [newSprintGoal, setNewSprintGoal] = useState("");

  // Fetch project data
  const { data: project } = useQuery({
    queryKey: [`/api/projects/${projectId}`],
    enabled: !!projectId
  });

  // Fetch deliverables
  const { data: deliverables = [] } = useQuery<Deliverable[]>({
    queryKey: [`/api/projects/${projectId}/deliverables`],
    enabled: !!projectId
  });

  // Fetch sprints (mock data for now)
  const [sprints, setSprints] = useState<Sprint[]>([
    {
      id: "sprint-1",
      name: "Sprint 1: Foundation Setup",
      goal: "Establish core infrastructure and authentication",
      startDate: "2025-06-23",
      endDate: "2025-07-06",
      status: "active",
      deliverables: ["1", "2"],
      velocity: 23
    },
    {
      id: "sprint-2",
      name: "Sprint 2: Core Features",
      goal: "Implement reporting engine and data processing",
      startDate: "2025-07-07",
      endDate: "2025-07-20",
      status: "planning",
      deliverables: ["3", "4"],
      velocity: 0
    }
  ]);

  // Fetch Jira summary
  const { data: jiraSummary } = useQuery({
    queryKey: [`/api/projects/${projectId}/jira-summary`],
    queryFn: async () => {
      const res = await fetch(`/api/projects/${projectId}/jira-summary`, {
        credentials: 'include'
      });
      if (!res.ok) throw new Error('Failed to fetch Jira summary');
      return res.json();
    },
    enabled: !!projectId
  });

  // Create sprint mutation
  const createSprintMutation = useMutation({
    mutationFn: async (sprintData: { name: string; goal: string; deliverableIds: number[] }) => {
      const res = await fetch(`/api/projects/${projectId}/sprints`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(sprintData)
      });
      if (!res.ok) throw new Error('Failed to create sprint');
      return res.json();
    },
    onSuccess: (newSprint) => {
      setSprints(prev => [...prev, newSprint]);
      setNewSprintName("");
      setNewSprintGoal("");
      setSelectedDeliverables([]);
      toast({
        title: "Sprint Created",
        description: `${newSprint.name} has been created successfully`,
      });
    }
  });

  // AI-powered sprint planning
  const aiSprintPlanningMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch('/api/agents/scrum-master/plan-sprint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ projectId, deliverables: selectedDeliverables })
      });
      if (!res.ok) throw new Error('AI sprint planning failed');
      return res.json();
    },
    onSuccess: (data) => {
      setNewSprintName(data.sprintName || "");
      setNewSprintGoal(data.sprintGoal || "");
      toast({
        title: "AI Sprint Plan Generated",
        description: "Smart sprint planning recommendations have been generated",
      });
    }
  });

  const handleCreateSprint = () => {
    if (!newSprintName || !newSprintGoal || selectedDeliverables.length === 0) {
      toast({
        title: "Validation Error",
        description: "Please fill in sprint name, goal, and select deliverables",
        variant: "destructive"
      });
      return;
    }

    createSprintMutation.mutate({
      name: newSprintName,
      goal: newSprintGoal,
      deliverableIds: selectedDeliverables
    });
  };

  const toggleDeliverableSelection = (deliverableId: number) => {
    setSelectedDeliverables(prev => 
      prev.includes(deliverableId) 
        ? prev.filter(id => id !== deliverableId)
        : [...prev, deliverableId]
    );
  };

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-0 z-50">
      <div className="bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full h-full max-w-none flex flex-col border border-white/20">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200/50 bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
              <Settings className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                Project Management AI
              </h2>
              <p className="text-sm text-gray-600">{(project as any)?.name || 'Loading...'} - Scrum Master Dashboard</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Button
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg hover:shadow-xl transition-all duration-200"
              onClick={() => aiSprintPlanningMutation.mutate()}
              disabled={aiSprintPlanningMutation.isPending}
            >
              <Zap className="h-4 w-4 mr-2" />
              {aiSprintPlanningMutation.isPending ? 'Planning...' : 'AI Sprint Planning'}
            </Button>
            <Button 
              variant="ghost" 
              className="hover:bg-red-50 hover:text-red-600 transition-all duration-200"
              onClick={onClose}
            >
              ✕
            </Button>
          </div>
        </div>

        <div className="flex-1 p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
            <TabsList className="bg-gray-100 rounded-xl p-1 w-fit">
              <TabsTrigger 
                value="overview" 
                className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg px-6 py-2 font-medium transition-all duration-200"
              >
                <BarChart3 className="h-4 w-4 mr-2" />
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="backlog" 
                className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg px-6 py-2 font-medium transition-all duration-200"
              >
                <List className="h-4 w-4 mr-2" />
                Backlog
              </TabsTrigger>
              <TabsTrigger 
                value="sprints" 
                className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg px-6 py-2 font-medium transition-all duration-200"
              >
                <Target className="h-4 w-4 mr-2" />
                Sprints
              </TabsTrigger>
              <TabsTrigger 
                value="jira" 
                className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg px-6 py-2 font-medium transition-all duration-200"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Jira Integration
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="flex-1 mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
                {/* Project Stats */}
                <div className="space-y-6">
                  <Card className="border-gray-200/60 shadow-sm">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg font-semibold flex items-center">
                        <BarChart3 className="h-5 w-5 mr-2 text-blue-600" />
                        Project Health
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Total Deliverables</span>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          {deliverables.length}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Active Sprints</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          {sprints.filter(s => s.status === 'active').length}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Team Velocity</span>
                        <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                          {sprints.find(s => s.status === 'active')?.velocity || 0} SP
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-gray-200/60 shadow-sm">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg font-semibold flex items-center">
                        <Calendar className="h-5 w-5 mr-2 text-orange-600" />
                        Sprint Timeline
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {sprints.slice(0, 3).map((sprint) => (
                          <div key={sprint.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center space-x-3">
                              <div className={`w-3 h-3 rounded-full ${
                                sprint.status === 'active' ? 'bg-green-500' :
                                sprint.status === 'completed' ? 'bg-blue-500' : 'bg-gray-400'
                              }`} />
                              <div>
                                <p className="text-sm font-medium text-gray-900">{sprint.name}</p>
                                <p className="text-xs text-gray-500">{sprint.startDate} - {sprint.endDate}</p>
                              </div>
                            </div>
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${
                                sprint.status === 'active' ? 'bg-green-50 text-green-700 border-green-200' :
                                sprint.status === 'completed' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                                'bg-gray-50 text-gray-700 border-gray-200'
                              }`}
                            >
                              {sprint.status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Active Sprint Details */}
                <div className="lg:col-span-2">
                  <Card className="border-gray-200/60 shadow-sm h-full">
                    <CardHeader className="pb-4">
                      <CardTitle className="text-xl font-semibold flex items-center">
                        <Play className="h-5 w-5 mr-2 text-green-600" />
                        Active Sprint: {sprints.find(s => s.status === 'active')?.name || 'No Active Sprint'}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {sprints.find(s => s.status === 'active') ? (
                        <div className="space-y-6">
                          <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-xl">
                            <h4 className="font-semibold text-gray-900 mb-2">Sprint Goal</h4>
                            <p className="text-gray-700 leading-relaxed">
                              {sprints.find(s => s.status === 'active')?.goal}
                            </p>
                          </div>

                          <div>
                            <h4 className="font-semibold text-gray-900 mb-3">Sprint Progress</h4>
                            <div className="space-y-3">
                              {deliverables.slice(0, 4).map((deliverable) => (
                                <div key={deliverable.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                                  <div className="flex items-center space-x-3">
                                    <div className={`w-4 h-4 rounded ${
                                      deliverable.status === 'completed' ? 'bg-green-500' :
                                      deliverable.status === 'in-progress' ? 'bg-blue-500' : 'bg-gray-300'
                                    }`} />
                                    <div>
                                      <p className="text-sm font-medium text-gray-900">{deliverable.name}</p>
                                      <p className="text-xs text-gray-500">{deliverable.type} • {deliverable.storyPoints} SP</p>
                                    </div>
                                  </div>
                                  <Badge 
                                    variant="outline"
                                    className={`text-xs ${
                                      deliverable.status === 'completed' ? 'bg-green-50 text-green-700 border-green-200' :
                                      deliverable.status === 'in-progress' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                                      'bg-gray-50 text-gray-700 border-gray-200'
                                    }`}
                                  >
                                    {deliverable.status}
                                  </Badge>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-12">
                          <div className="w-24 h-24 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                            <Target className="h-12 w-12 text-blue-600" />
                          </div>
                          <h3 className="text-xl font-semibold text-gray-900 mb-2">No Active Sprint</h3>
                          <p className="text-gray-600 mb-4">Create your first sprint to start managing project deliverables</p>
                          <Button 
                            onClick={() => setActiveTab("sprints")}
                            className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
                          >
                            Create Sprint
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="backlog" className="flex-1 mt-6">
              <Card className="border-gray-200/60 shadow-sm h-full">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl font-semibold flex items-center justify-between">
                    <div className="flex items-center">
                      <List className="h-5 w-5 mr-2 text-purple-600" />
                      Product Backlog
                    </div>
                    <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                      {deliverables.length} items
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {deliverables.map((deliverable) => (
                      <div 
                        key={deliverable.id} 
                        className={`p-4 border rounded-xl transition-all duration-200 hover:shadow-md cursor-pointer ${
                          selectedDeliverables.includes(deliverable.id) 
                            ? 'border-blue-300 bg-blue-50' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => toggleDeliverableSelection(deliverable.id)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <input 
                              type="checkbox" 
                              checked={selectedDeliverables.includes(deliverable.id)}
                              onChange={() => {}}
                              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            />
                            <div>
                              <h4 className="font-semibold text-gray-900">{deliverable.name}</h4>
                              <p className="text-sm text-gray-600 mt-1">{deliverable.description}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge 
                              variant="outline"
                              className={`text-xs ${
                                deliverable.priority === 'Critical' ? 'bg-red-50 text-red-700 border-red-200' :
                                deliverable.priority === 'High' ? 'bg-orange-50 text-orange-700 border-orange-200' :
                                deliverable.priority === 'Medium' ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                                'bg-gray-50 text-gray-700 border-gray-200'
                              }`}
                            >
                              {deliverable.priority}
                            </Badge>
                            <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                              {deliverable.storyPoints} SP
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sprints" className="flex-1 mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
                {/* Create Sprint */}
                <Card className="border-gray-200/60 shadow-sm">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-xl font-semibold flex items-center">
                      <Plus className="h-5 w-5 mr-2 text-green-600" />
                      Create New Sprint
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">Sprint Name</label>
                      <Input
                        placeholder="Enter sprint name..."
                        value={newSprintName}
                        onChange={(e) => setNewSprintName(e.target.value)}
                        className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">Sprint Goal</label>
                      <Textarea
                        placeholder="What is the main objective of this sprint?"
                        value={newSprintGoal}
                        onChange={(e) => setNewSprintGoal(e.target.value)}
                        className="border-gray-300 focus:border-blue-500 focus:ring-blue-500 min-h-20"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">
                        Selected Deliverables ({selectedDeliverables.length})
                      </label>
                      <div className="text-xs text-gray-500 mb-2">
                        Go to Backlog tab to select deliverables for this sprint
                      </div>
                      {selectedDeliverables.length > 0 && (
                        <div className="space-y-1">
                          {selectedDeliverables.map(id => {
                            const deliverable = deliverables.find(d => d.id === id);
                            return deliverable ? (
                              <div key={id} className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded">
                                {deliverable.name}
                              </div>
                            ) : null;
                          })}
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={handleCreateSprint}
                        disabled={createSprintMutation.isPending}
                        className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                      >
                        {createSprintMutation.isPending ? 'Creating...' : 'Create Sprint'}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => aiSprintPlanningMutation.mutate()}
                        disabled={aiSprintPlanningMutation.isPending}
                        className="text-blue-600 border-blue-200 hover:bg-blue-50"
                      >
                        <Zap className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Sprint List */}
                <Card className="border-gray-200/60 shadow-sm">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-xl font-semibold flex items-center">
                      <Calendar className="h-5 w-5 mr-2 text-blue-600" />
                      Sprint History
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {sprints.map((sprint) => (
                        <div key={sprint.id} className="border border-gray-200 rounded-xl p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <div className={`w-4 h-4 rounded-full ${
                                sprint.status === 'active' ? 'bg-green-500' :
                                sprint.status === 'completed' ? 'bg-blue-500' : 'bg-gray-400'
                              }`} />
                              <h4 className="font-semibold text-gray-900">{sprint.name}</h4>
                            </div>
                            <Badge 
                              variant="outline"
                              className={`text-xs ${
                                sprint.status === 'active' ? 'bg-green-50 text-green-700 border-green-200' :
                                sprint.status === 'completed' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                                'bg-gray-50 text-gray-700 border-gray-200'
                              }`}
                            >
                              {sprint.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{sprint.goal}</p>
                          <div className="flex items-center justify-between text-xs text-gray-500">
                            <span>{sprint.startDate} - {sprint.endDate}</span>
                            <span>{sprint.velocity} SP</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="jira" className="flex-1 mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
                {/* Jira Summary */}
                <Card className="border-gray-200/60 shadow-sm">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-xl font-semibold flex items-center">
                      <ExternalLink className="h-5 w-5 mr-2 text-blue-600" />
                      Jira Integration Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {jiraSummary ? (
                      <div className="space-y-4">
                        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                          <div className="flex items-center space-x-2 mb-2">
                            <CheckCircle className="h-5 w-5 text-green-600" />
                            <h4 className="font-semibold text-green-900">Connected to Jira</h4>
                          </div>
                          <p className="text-sm text-green-700">
                            Project Key: <span className="font-mono">{jiraSummary.projectKey}</span>
                          </p>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-blue-50 p-4 rounded-lg text-center">
                            <div className="text-2xl font-bold text-blue-900">{jiraSummary.totalEpics}</div>
                            <div className="text-sm text-blue-700">Total Epics</div>
                          </div>
                          <div className="bg-purple-50 p-4 rounded-lg text-center">
                            <div className="text-2xl font-bold text-purple-900">{jiraSummary.totalStories}</div>
                            <div className="text-sm text-purple-700">User Stories</div>
                          </div>
                          <div className="bg-green-50 p-4 rounded-lg text-center">
                            <div className="text-2xl font-bold text-green-900">{jiraSummary.completedStories}</div>
                            <div className="text-sm text-green-700">Completed</div>
                          </div>
                          <div className="bg-orange-50 p-4 rounded-lg text-center">
                            <div className="text-2xl font-bold text-orange-900">{jiraSummary.inProgressStories}</div>
                            <div className="text-sm text-orange-700">In Progress</div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                          <ExternalLink className="h-8 w-8 text-blue-600" />
                        </div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">Jira Integration</h3>
                        <p className="text-gray-600 mb-4">Connect to view project status and manage deliverables</p>
                        <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                          Connect to Jira
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Deliverable Hierarchy */}
                <Card className="border-gray-200/60 shadow-sm">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-xl font-semibold flex items-center">
                      <GitBranch className="h-5 w-5 mr-2 text-purple-600" />
                      Deliverable Hierarchy
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="text-sm text-gray-600 mb-4">
                        Organized by deliverable type and priority
                      </div>
                      {['Frontend Development', 'Backend APIs', 'Infrastructure'].map((category, index) => (
                        <div key={category} className="border border-gray-200 rounded-lg p-3">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium text-gray-900">{category}</h4>
                            <Badge variant="outline" className="text-xs">
                              {deliverables.filter(d => d.type === category.toLowerCase().replace(' ', '-')).length}
                            </Badge>
                          </div>
                          <div className="space-y-2">
                            {deliverables
                              .filter(d => d.type === category.toLowerCase().replace(' ', '-'))
                              .slice(0, 2)
                              .map((deliverable) => (
                                <div key={deliverable.id} className="flex items-center justify-between text-sm">
                                  <span className="text-gray-700 truncate">{deliverable.name}</span>
                                  <div className="flex items-center space-x-2">
                                    {deliverable.jiraEpicKey && (
                                      <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                                        {deliverable.jiraEpicKey}
                                      </Badge>
                                    )}
                                    <span className="text-gray-500">{deliverable.storyPoints} SP</span>
                                  </div>
                                </div>
                              ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}