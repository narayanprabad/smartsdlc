import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Brain, 
  CheckCircle, 
  Lightbulb, 
  Target, 
  Zap,
  Shield,
  Code,
  Settings,
  ChevronDown,
  ChevronUp
} from "lucide-react";

interface AIAssistantWidgetProps {
  userRole: string;
}

export function AIAssistantWidget({ userRole }: AIAssistantWidgetProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const getAgentConfig = (role: string) => {
    const configs = {
      "Business Analyst": {
        title: "Business Analyst AI Agent",
        description: "AI-powered assistant for business analyst workflows",
        capabilities: [
          "Requirements Analysis",
          "Stakeholder Management", 
          "Process Modeling",
          "Business Case Development"
        ],
        quickActions: [
          "Analyze business requirements",
          "Create process documentation",
          "Review stakeholder feedback",
          "Validate business objectives"
        ],
        color: "bg-blue-50 text-blue-700 border-blue-200"
      },
      "Product Owner": {
        title: "Product Owner AI Agent",
        description: "AI-powered assistant for product owner workflows",
        capabilities: [
          "Product Strategy",
          "Backlog Management",
          "User Story Creation", 
          "Acceptance Criteria"
        ],
        quickActions: [
          "Prioritize product backlog",
          "Define user stories",
          "Review acceptance criteria",
          "Plan product roadmap"
        ],
        color: "bg-green-50 text-green-700 border-green-200"
      },
      "Architect": {
        title: "Architect AI Agent", 
        description: "AI-powered assistant for architect workflows",
        capabilities: [
          "System Design",
          "Technology Selection",
          "Performance Optimization",
          "Security Architecture"
        ],
        quickActions: [
          "Design system architecture",
          "Define technical standards", 
          "Review integration patterns",
          "Validate scalability requirements"
        ],
        color: "bg-purple-50 text-purple-700 border-purple-200"
      },
      "Scrum Master": {
        title: "Scrum Master AI Agent",
        description: "AI-powered assistant for scrum master workflows", 
        capabilities: [
          "Sprint Planning",
          "Team Coaching",
          "Process Improvement",
          "Impediment Resolution"
        ],
        quickActions: [
          "Plan sprint activities",
          "Facilitate team meetings",
          "Track sprint progress",
          "Remove team blockers"
        ],
        color: "bg-orange-50 text-orange-700 border-orange-200"
      },
      "Developer": {
        title: "Developer AI Agent",
        description: "AI-powered assistant for developer workflows",
        capabilities: [
          "Code Review",
          "Technical Implementation",
          "Testing Strategy",
          "Performance Optimization"
        ],
        quickActions: [
          "Review code quality",
          "Generate unit tests",
          "Optimize performance",
          "Debug technical issues"
        ],
        color: "bg-indigo-50 text-indigo-700 border-indigo-200"
      },
      "UI Designer": {
        title: "UI Designer AI Agent",
        description: "AI-powered assistant for UI designer workflows",
        capabilities: [
          "User Experience Design",
          "Interface Prototyping", 
          "Accessibility Review",
          "Design System Management"
        ],
        quickActions: [
          "Create UI mockups",
          "Review user experience",
          "Validate accessibility",
          "Update design system"
        ],
        color: "bg-pink-50 text-pink-700 border-pink-200"
      },
      "DevOps": {
        title: "DevOps AI Agent",
        description: "AI-powered assistant for DevOps workflows",
        capabilities: [
          "Infrastructure Management",
          "CI/CD Pipeline",
          "Monitoring & Alerting",
          "Security Compliance"
        ],
        quickActions: [
          "Configure infrastructure",
          "Set up CI/CD pipeline",
          "Monitor system health",
          "Ensure security compliance"
        ],
        color: "bg-teal-50 text-teal-700 border-teal-200"
      }
    };

    return configs[role] || configs["Business Analyst"];
  };

  const agentConfig = getAgentConfig(userRole);

  return (
    <div className="fixed bottom-4 right-4 w-80 z-50">
      <Card className="shadow-lg border-2">
        <CardHeader 
          className="pb-3 cursor-pointer"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-blue-600" />
              <CardTitle className="text-sm">AI Agent Assistant</CardTitle>
            </div>
            {isExpanded ? (
              <ChevronDown className="h-4 w-4 text-gray-500" />
            ) : (
              <ChevronUp className="h-4 w-4 text-gray-500" />
            )}
          </div>
        </CardHeader>

        {isExpanded && (
          <CardContent className="pt-0">
            <div className={`p-3 rounded-lg border mb-4 ${agentConfig.color}`}>
              <div className="flex items-center gap-2 mb-1">
                <Zap className="h-4 w-4" />
                <span className="font-medium text-sm">{agentConfig.title}</span>
                <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Active
                </Badge>
              </div>
              <p className="text-xs opacity-90">{agentConfig.description}</p>
            </div>

            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-4 h-8">
                <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
                <TabsTrigger value="tasks" className="text-xs">Tasks</TabsTrigger>
                <TabsTrigger value="insights" className="text-xs">Insights</TabsTrigger>
                <TabsTrigger value="actions" className="text-xs">Actions</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-3">
                <div>
                  <h4 className="font-medium text-sm mb-2 flex items-center gap-1">
                    <Target className="h-4 w-4" />
                    Core Capabilities
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    {agentConfig.capabilities.map((capability, index) => (
                      <div key={index} className="flex items-center gap-1">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                        <span className="text-xs text-gray-700">{capability}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="tasks" className="mt-3">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 p-2 bg-blue-50 rounded border">
                    <Brain className="h-4 w-4 text-blue-600" />
                    <span className="text-xs font-medium">AI Assistant</span>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-800 text-xs">
                      Ready
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-600">
                    Your AI agent is ready to assist with {userRole.toLowerCase()} tasks and workflows.
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="insights" className="mt-3">
                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                    <Lightbulb className="h-4 w-4 text-yellow-500 mt-0.5" />
                    <div>
                      <p className="text-xs font-medium">Smart Recommendations</p>
                      <p className="text-xs text-gray-600">AI-powered insights based on your current project context</p>
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 p-2 bg-gray-50 rounded">
                    Analyzing project data to provide personalized recommendations...
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="actions" className="mt-3">
                <div>
                  <h4 className="font-medium text-sm mb-2">Quick Actions</h4>
                  <div className="space-y-1">
                    {agentConfig.quickActions.map((action, index) => (
                      <button
                        key={index}
                        className="w-full text-left p-2 text-xs bg-gray-50 hover:bg-gray-100 rounded flex items-center gap-2"
                      >
                        <Zap className="h-3 w-3" />
                        {action}
                      </button>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        )}
      </Card>
    </div>
  );
}