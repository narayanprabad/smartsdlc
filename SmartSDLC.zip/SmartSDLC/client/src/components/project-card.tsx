import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Users, Eye, Trash2, CheckCircle, XCircle, Clock, Play } from "lucide-react";

interface Project {
  id: number;
  name: string;
  description: string;
  status: string;
  startDate: string;
  teamSize: number;
  functionalUseCases: number;
  nonFunctionalUseCases: number;
  approvalStatus?: string;
  approvedAt?: string;
}

interface ProjectCardProps {
  project: Project;
  onViewUseCases: (projectId: number) => void;
  onDeleteProject?: (projectId: number) => void;
  onApproveProject?: (projectId: number) => void;
  onRejectProject?: (projectId: number) => void;
  onSubmitForApproval?: (projectId: number) => void;
  onCreateTasks?: (projectId: number) => void;
  currentRole: string;
}

const statusColors = {
  Active: "bg-green-50 text-green-700 border-green-200",
  Planning: "bg-yellow-50 text-yellow-700 border-yellow-200", 
  Development: "bg-blue-50 text-blue-700 border-blue-200",
  "On Hold": "bg-gray-50 text-gray-700 border-gray-200",
  Completed: "bg-purple-50 text-purple-700 border-purple-200",
  draft: "bg-gray-50 text-gray-600 border-gray-200",
};

export function ProjectCard({ 
  project, 
  onViewUseCases, 
  onDeleteProject, 
  onApproveProject,
  onRejectProject,
  onSubmitForApproval,
  onCreateTasks,
  currentRole 
}: ProjectCardProps) {
  
  const getApprovalStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };
  return (
    <Card className="bg-white border border-gray-200 hover:shadow-lg transition-all duration-200">
      <CardContent className="p-6">
        {/* Header */}
        <div className="mb-4">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            {project.name}
          </h3>
          <div className="flex gap-2 mb-2">
            <Badge
              variant="outline"
              className={`text-xs px-2 py-1 rounded border ${
                statusColors[project.status as keyof typeof statusColors] ||
                statusColors.draft
              }`}
            >
              {project.status}
            </Badge>
            {project.approvalStatus && (
              <Badge
                variant="outline"
                className={`text-xs px-2 py-1 rounded border ${getApprovalStatusColor(project.approvalStatus)}`}
              >
                {project.approvalStatus === 'pending' ? 'Pending Approval' : 
                 project.approvalStatus === 'approved' ? 'Approved' : 'Rejected'}
              </Badge>
            )}
          </div>
        </div>

        {/* Description */}
        <p className="text-gray-600 text-xs leading-tight mb-4 min-h-[2.5rem] line-clamp-3">
          {project.description}
        </p>

        {/* Metadata */}
        <div className="flex items-center gap-4 mb-3 text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            <span>{project.startDate}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            <span>Owner</span>
          </div>
        </div>

        {/* Progress */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-gray-700 font-medium">Progress</span>
            <span className="text-xs text-gray-500">0%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-1.5">
            <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: "0%" }}></div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-2">
          <div className="flex gap-2">
            <Button
              onClick={(e) => {
                e.stopPropagation();
                onViewUseCases(project.id);
              }}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Eye className="h-4 w-4 mr-2" />
              View Details
            </Button>
            {onDeleteProject && (
              <Button
                variant="outline"
                size="icon"
                className="text-red-500 hover:text-red-600 hover:bg-red-50"
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm('Are you sure you want to delete this project?')) {
                    onDeleteProject(project.id);
                  }
                }}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Workflow Actions */}
          {currentRole === 'business-analyst' && project.approvalStatus === 'pending' && onSubmitForApproval && (
            <Button
              variant="outline"
              className="w-full text-green-600 border-green-200 hover:bg-green-50"
              onClick={(e) => {
                e.stopPropagation();
                onSubmitForApproval(project.id);
              }}
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Submit for Approval
            </Button>
          )}

          {currentRole === 'product-owner' && project.approvalStatus === 'pending' && (
            <div className="flex gap-2">
              {onApproveProject && (
                <Button
                  variant="outline"
                  className="flex-1 text-green-600 border-green-200 hover:bg-green-50"
                  onClick={(e) => {
                    e.stopPropagation();
                    onApproveProject(project.id);
                  }}
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Approve
                </Button>
              )}
              {onRejectProject && (
                <Button
                  variant="outline"
                  className="flex-1 text-red-600 border-red-200 hover:bg-red-50"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRejectProject(project.id);
                  }}
                >
                  <XCircle className="h-4 w-4 mr-1" />
                  Reject
                </Button>
              )}
            </div>
          )}

          {currentRole === 'product-owner' && project.approvalStatus === 'approved' && onCreateTasks && (
            <Button
              variant="outline"
              className="w-full text-blue-600 border-blue-200 hover:bg-blue-50"
              onClick={(e) => {
                e.stopPropagation();
                if (confirm('Create development tasks for this project?')) {
                  onCreateTasks(project.id);
                }
              }}
            >
              <Play className="h-4 w-4 mr-2" />
              Create Tasks
            </Button>
          )}

          {project.status === 'Development' && currentRole !== 'business-analyst' && currentRole !== 'product-owner' && (
            <div className="text-center py-2">
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                <Clock className="h-3 w-3 mr-1" />
                Development in Progress
              </Badge>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
