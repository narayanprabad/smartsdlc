import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Users, Eye, Trash2, CheckCircle, XCircle, Clock, Play, Package, Zap, Settings, Layers } from "lucide-react";
import { BoardManagement } from "./board-management";
import { ArchitectAssignment } from "./architect-assignment";
import { useLocation } from "wouter";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useState } from "react";

interface Project {
  id: number;
  name: string;
  description: string;
  status: string;
  startDate: string;
  teamSize: number;
  functionalUseCases: number;
  nonFunctionalUseCases: number;
  approvalStatus?: string;
  approvedAt?: string;
  sealApplicationId?: string;
  sealApplicationName?: string;
}

interface ProjectCardProps {
  project: Project;
  onViewUseCases: (projectId: number) => void;
  onViewDeliverables?: (projectId: number) => void;
  onSelectProject?: (projectId: number) => void;
  onDeleteProject?: (projectId: number) => void;
  onApproveProject?: (projectId: number) => void;
  onRejectProject?: (projectId: number) => void;
  onSubmitForApproval?: (projectId: number) => void;
  onManageProject?: (projectId: number) => void;
  onViewArchitecture?: (projectId: number) => void;
  onGenerateDeliverables?: (projectId: number) => void;

  currentRole: string;
  userRole?: string;
  isSelected?: boolean;
  isApproving?: boolean;
  isRejecting?: boolean;
  isDeleting?: boolean;
  onManageWithAI?: (projectId: number) => void;
  onArchitectWithAI?: (projectId: number) => void;
}

const statusColors = {
  Active: "bg-green-50 text-green-700 border-green-200",
  Planning: "bg-yellow-50 text-yellow-700 border-yellow-200", 
  Development: "bg-blue-50 text-blue-700 border-blue-200",
  "On Hold": "bg-gray-50 text-gray-700 border-gray-200",
  Completed: "bg-purple-50 text-purple-700 border-purple-200",
  draft: "bg-orange-50 text-orange-700 border-orange-200",
  in_review: "bg-yellow-50 text-yellow-700 border-yellow-200",
};

export function ProjectCard({ 
  project, 
  onViewUseCases, 
  onViewDeliverables,
  onSelectProject,
  onDeleteProject, 
  onApproveProject,
  onRejectProject,
  onSubmitForApproval,
  currentRole,
  isSelected = false,
  onManageWithAI,
  onArchitectWithAI
}: ProjectCardProps) {
  const [, setLocation] = useLocation();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  
  const getApprovalStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleDeleteConfirm = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (onDeleteProject) {
      onDeleteProject(project.id);
    }
    setDeleteDialogOpen(false);
  };
  const handleCardClick = () => {
    setLocation(`/projects/${project.id}`);
  };

  return (
    <Card 
      className="bg-white border border-gray-200 hover:shadow-lg transition-all duration-200 min-h-[280px] flex flex-col cursor-pointer"
      onClick={handleCardClick}
    >
      <CardContent className="p-4 flex-1 flex flex-col relative">
        {/* Delete Button - Top Right Corner for Draft Projects Only */}
        {(project.approvalStatus === 'draft' || project.status === 'Draft') && onDeleteProject && (
          <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="absolute top-0 right-0 text-red-500 hover:text-red-600 hover:bg-red-50 w-8 h-8 z-10"
                onClick={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  setDeleteDialogOpen(true);
                }}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="max-w-md">
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2">
                  <Trash2 className="h-5 w-5 text-red-500" />
                  Delete Project
                </AlertDialogTitle>
                <AlertDialogDescription className="text-gray-600">
                  Are you sure you want to delete "{project.name}"? This action cannot be undone and will permanently remove all project data including use cases and requirements.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="border-gray-200 hover:bg-gray-50">
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteConfirm(e);
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  Delete Project
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}

        {/* Header */}
        <div className="mb-3">
          <h3 className="text-lg font-semibold text-gray-900 mb-2 pr-10 leading-tight">
            {project.name}
          </h3>
          <div className="flex gap-2">
            <Badge
              variant="outline"
              className={`text-xs px-2 py-1 rounded border ${
                project.approvalStatus === 'pending' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' :
                project.approvalStatus === 'approved' ? 'bg-green-100 text-green-800 border-green-200' :
                project.approvalStatus === 'rejected' ? 'bg-red-100 text-red-800 border-red-200' :
                'bg-orange-100 text-orange-800 border-orange-200'
              }`}
            >
              {project.approvalStatus === 'pending' ? 'Pending Review' : 
               project.approvalStatus === 'approved' ? 'Approved' : 
               project.approvalStatus === 'rejected' ? 'Rejected' : 'Draft'}
            </Badge>
            {project.sealApplicationName && (
              <Badge variant="outline" className="text-xs px-2 py-1 bg-blue-50 text-blue-700 border-blue-200">
                <Package className="h-3 w-3 mr-1" />
                {project.sealApplicationId}: {project.sealApplicationName.split(':')[1]?.trim() || project.sealApplicationName}
              </Badge>
            )}
          </div>
        </div>

        {/* Description */}
        <div className="flex-1">
          <p className="text-gray-600 text-sm leading-relaxed mb-3 line-clamp-2">
            {project.description}
          </p>

          {/* Key Metrics */}
          <div className="grid grid-cols-2 gap-2 mb-3">
            <div className="bg-blue-50 rounded-lg p-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs text-blue-600 font-medium">Functional</span>
                <span className="text-lg font-bold text-blue-700">{project.functionalUseCases || 0}</span>
              </div>
              <span className="text-xs text-blue-500">Use Cases</span>
            </div>
            <div className="bg-purple-50 rounded-lg p-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs text-purple-600 font-medium">Non-Functional</span>
                <span className="text-lg font-bold text-purple-700">{project.nonFunctionalUseCases || 0}</span>
              </div>
              <span className="text-xs text-purple-500">Requirements</span>
            </div>
          </div>

          {/* Project ID & Created Date */}
          <div className="flex items-center justify-between">
            <div className="text-xs text-gray-500">
              ID: #{project.id}
            </div>
            <div className="text-xs text-gray-400">
              Created: {new Date(project.startDate).toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric', 
                year: 'numeric' 
              })}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-2 mt-auto">

          {/* Role-based Workflow Actions */}
          
          {/* Business Analyst: Can submit draft projects for approval */}
          {currentRole === 'business-analyst' && 
           project.approvalStatus === 'draft' && 
           project.status === 'Draft' && 
           !project.submittedAt &&
           !project.approvedAt &&
           onSubmitForApproval && (
            <Button
              variant="outline"
              className="w-full text-green-600 border-green-200 hover:bg-green-50"
              onClick={(e) => {
                e.stopPropagation();
                onSubmitForApproval(project.id);
              }}
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Submit for Review
            </Button>
          )}



          {/* Business Analyst: Read-only for pending projects - removed redundant status display */}

          {/* Product Owner: Can approve or reject pending projects */}
          {currentRole === 'product-owner' && project.approvalStatus === 'pending' && (
            <div className="grid grid-cols-2 gap-2">
              {onApproveProject && (
                <Button
                  variant="outline"
                  size="sm"
                  className="text-green-600 border-green-200 hover:bg-green-50 text-xs"
                  onClick={(e) => {
                    e.stopPropagation();
                    onApproveProject(project.id);
                  }}
                >
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Approve
                </Button>
              )}
              {onRejectProject && (
                <Button
                  variant="outline"
                  size="sm"
                  className="text-red-600 border-red-200 hover:bg-red-50 text-xs"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRejectProject(project.id);
                  }}
                >
                  <XCircle className="h-3 w-3 mr-1" />
                  Needs Work
                </Button>
              )}
            </div>
          )}

          {/* Clean interface without unnecessary progress indicators */}
        </div>
      </CardContent>


    </Card>
  );
}
