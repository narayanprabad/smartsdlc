import { useState, useRef, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Bot, ChevronDown, ChevronUp, Sparkles, User } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ChatMessage {
  id: string;
  type: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface AIChatProps {
  currentRole: string;
  projectId?: number;
}

export function AIChat({ currentRole, projectId }: AIChatProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [description, setDescription] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isOnline] = useState(true);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const getRoleSpecificPrompts = () => {
    switch (currentRole) {
      case "business-analyst":
        return [
          "Create project from requirements",
          "Generate functional use cases", 
          "Analyze business requirements",
          "Validate requirement completeness"
        ];
      case "product-owner":
        return [
          "Define product roadmap",
          "Prioritize feature backlog",
          "Create user stories",
          "Review acceptance criteria"
        ];
      case "architect":
        return [
          "Design system architecture",
          "Define technical standards",
          "Review integration patterns",
          "Validate scalability requirements"
        ];
      case "developer":
        return [
          "Generate code templates",
          "Review implementation approach",
          "Suggest best practices",
          "Optimize performance"
        ];
      default:
        return [
          "Help me create a new project",
          "Analyze project requirements",
          "Generate use cases",
          "Suggest technical architecture"
        ];
    }
  };

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify({
          message,
          currentRole,
          projectId
        })
      });
      
      if (!res.ok) {
        throw new Error(`Failed to process request: ${res.statusText}`);
      }
      
      return res.json();
    },
    mutationKey: ["ai-chat"],
    onSuccess: (data) => {
      // Add user message
      const userMessage: ChatMessage = {
        id: Date.now().toString() + "-user",
        type: "user",
        content: description,
        timestamp: new Date()
      };
      
      // Add assistant response
      const assistantMessage: ChatMessage = {
        id: Date.now().toString() + "-assistant", 
        type: "assistant",
        content: data.response || "Project created successfully",
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, userMessage, assistantMessage]);
      
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Success",
        description: "AI processing completed successfully",
      });
      setDescription("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to process request",
        variant: "destructive",
      });
    }
  });

  const handleSuggestionClick = (suggestion: string) => {
    setDescription(suggestion);
  };

  const handleProcess = () => {
    if (!description.trim()) return;
    chatMutation.mutate(description);
  };

  return (
    <Card className="w-80 flex flex-col shadow-lg border border-gray-200">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
              <Bot className="h-3 w-3 text-white" />
            </div>
            <span className="text-sm font-semibold">AI Assistant</span>
            <Badge variant={isOnline ? "default" : "secondary"} className="text-xs">
              {isOnline ? "AWS Connected" : "Offline"}
            </Badge>
          </div>
          <Badge variant="outline" className="text-xs">
            {chatMutation.isPending ? "Processing..." : "Ready"}
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        {/* Chat Messages */}
        {messages.length > 0 && (
          <div className="flex-1 max-h-96">
            <div className="p-3 border-b bg-gray-50">
              <div className="text-xs font-medium text-gray-700">Conversation History</div>
            </div>
            <ScrollArea className="h-80 p-3" ref={scrollAreaRef}>
              <div className="space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className="flex items-start space-x-2">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.type === "user" 
                        ? "bg-blue-100" 
                        : "bg-gradient-to-r from-purple-500 to-blue-500"
                    }`}>
                      {message.type === "user" ? (
                        <User className="h-3 w-3 text-blue-600" />
                      ) : (
                        <Bot className="h-3 w-3 text-white" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs text-gray-500 mb-1">
                        {message.type === "user" ? "You" : "AI Assistant"} • {
                          message.timestamp.toLocaleTimeString([], { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })
                        }
                      </div>
                      <div className="text-sm text-gray-800 leading-relaxed break-words whitespace-pre-wrap">
                        {message.content}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <Separator />
          </div>
        )}

        {/* Quick Actions */}
        <div className="p-3 border-t bg-gray-50">
          <div className="text-xs font-medium text-gray-700 mb-2">Quick Actions</div>
          <div className="flex flex-wrap gap-1">
            {getRoleSpecificPrompts().map((prompt, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="text-xs h-6 px-2 py-0"
                onClick={() => handleSuggestionClick(prompt)}
              >
                <Sparkles className="h-2 w-2 mr-1" />
                {prompt}
              </Button>
            ))}
          </div>
        </div>

        {/* Expandable Description Box */}
        <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
          <CollapsibleTrigger asChild>
            <Button 
              variant="ghost" 
              className="w-full justify-between p-3 text-left font-normal"
            >
              <span className="text-sm text-gray-600">
                {description ? "Edit Description" : "Add Description"}
              </span>
              {isExpanded ? (
                <ChevronUp className="h-4 w-4" />
              ) : (
                <ChevronDown className="h-4 w-4" />
              )}
            </Button>
          </CollapsibleTrigger>
          
          <CollapsibleContent className="p-3 pt-0">
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your requirements or ask for assistance..."
              className="min-h-[120px] text-sm"
              rows={6}
            />
            <div className="flex gap-2 mt-2">
              <Button 
                size="sm" 
                className="flex-1"
                onClick={handleProcess}
                disabled={!description.trim() || chatMutation.isPending}
              >
                {chatMutation.isPending ? "Processing..." : "Process"}
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => setDescription("")}
                disabled={chatMutation.isPending}
              >
                Clear
              </Button>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
}