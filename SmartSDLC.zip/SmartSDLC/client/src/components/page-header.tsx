import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ProfileSwitcher } from "@/components/profile-switcher";
import { Link } from "wouter";
import { 
  Home, 
  Plus, 
  Bell, 
  Settings, 
  User,
  ChevronDown
} from "lucide-react";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  user: {
    name: string;
    currentRole: string;
    roles: string[];
    sealApplications?: string[] | null;
  };
  showCreateButton?: boolean;
  onCreateClick?: () => void;
  breadcrumbs?: Array<{
    label: string;
    href?: string;
  }>;
}

export function PageHeader({ 
  title, 
  subtitle, 
  user, 
  showCreateButton = false, 
  onCreateClick,
  breadcrumbs = []
}: PageHeaderProps) {
  return (
    <div className="border-b bg-white">
      <div className="px-6 py-4">
        {/* Top Navigation */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-6">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">S</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Smart SDLC</span>
            </Link>
            
            <nav className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
                <Home className="h-4 w-4" />
                Dashboard
              </Link>
              <span className="text-gray-300">|</span>
              <span className="text-gray-600">Projects</span>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            {/* SEAL Applications Access */}
            {user.sealApplications && user.sealApplications.length > 0 && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg px-3 py-2">
                <div className="text-xs font-semibold text-blue-900 mb-1">SEAL Access</div>
                <div className="flex flex-wrap gap-1">
                  {user.sealApplications.map((app: string, index: number) => (
                    <span key={index} className="text-xs text-blue-700 bg-white px-2 py-1 rounded border">
                      {app}
                    </span>
                  ))}
                </div>
              </div>
            )}
            
            <Button variant="ghost" size="sm">
              <Bell className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
            
            {/* Profile Switcher */}
            <ProfileSwitcher user={user} />
          </div>
        </div>

        {/* Breadcrumbs */}
        {breadcrumbs.length > 0 && (
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
            {breadcrumbs.map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                {item.href ? (
                  <Link href={item.href} className="hover:text-gray-700">
                    {item.label}
                  </Link>
                ) : (
                  <span className="text-gray-900">{item.label}</span>
                )}
                {index < breadcrumbs.length - 1 && (
                  <span className="text-gray-300">/</span>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Page Title */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
            {subtitle && (
              <p className="text-gray-600 mt-1">{subtitle}</p>
            )}
          </div>
          
          {showCreateButton && (
            <Button onClick={onCreateClick} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Create Project
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}