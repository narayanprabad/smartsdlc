import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings, 
  Kanban, 
  Timer, 
  Users, 
  Target, 
  BarChart3, 
  Zap,
  Calendar,
  TrendingUp 
} from "lucide-react";

interface Project {
  id: number;
  name: string;
  description: string;
  status: string;
  approvalStatus: string;
  boardType?: string;
  managedByScrumMasterId?: number;
}

interface BoardManagementProps {
  project: Project;
  userRole: string;
}

export function BoardManagement({ project, userRole }: BoardManagementProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedBoardType, setSelectedBoardType] = useState<string>(project.boardType || "");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const setBoardTypeMutation = useMutation({
    mutationFn: (boardType: string) => 
      apiRequest(`/api/projects/${project.id}/manage-board`, {
        method: "POST",
        body: { boardType }
      }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setIsDialogOpen(false);
      toast({
        title: "Board Type Set",
        description: data.message,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to set board type",
        variant: "destructive",
      });
    },
  });

  const handleSetBoardType = () => {
    if (!selectedBoardType) {
      toast({
        title: "Selection Required",
        description: "Please select a board type",
        variant: "destructive",
      });
      return;
    }
    setBoardTypeMutation.mutate(selectedBoardType);
  };

  // Only show for Scrum Master role and approved projects
  if (userRole !== "scrum-master" || project.approvalStatus !== "approved") {
    return null;
  }

  const boardTypeInfo = {
    kanban: {
      title: "Kanban Board",
      description: "Continuous flow-based approach for ongoing work management",
      features: [
        "Visual workflow management",
        "Work-in-progress limits",
        "Continuous delivery",
        "Pull-based system",
        "Flexible prioritization"
      ],
      benefits: [
        "Faster delivery cycles",
        "Improved flow efficiency",
        "Better bottleneck identification",
        "Reduced context switching"
      ],
      icon: <Kanban className="w-5 h-5" />,
      color: "bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800"
    },
    scrum: {
      title: "Scrum Board",
      description: "Sprint-based iterative approach with time-boxed development cycles",
      features: [
        "Sprint planning & execution",
        "Daily standups",
        "Sprint reviews & retrospectives",
        "Product backlog management",
        "Velocity tracking"
      ],
      benefits: [
        "Predictable delivery timelines",
        "Regular stakeholder feedback",
        "Team collaboration focus",
        "Continuous improvement"
      ],
      icon: <Timer className="w-5 h-5" />,
      color: "bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800"
    }
  };

  return (
    <Card className="mt-4">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            <CardTitle>Scrum Master Board Management</CardTitle>
          </div>
          {project.boardType && (
            <Badge variant="secondary" className="flex items-center gap-1">
              {project.boardType === "kanban" ? <Kanban className="w-3 h-3" /> : <Timer className="w-3 h-3" />}
              {project.boardType.charAt(0).toUpperCase() + project.boardType.slice(1)} Board
            </Badge>
          )}
        </div>
        <CardDescription>
          Configure project board type for optimal team workflow management
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {project.boardType ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
                <Target className="w-4 h-4" />
                Project is set to use <strong>{project.boardType.charAt(0).toUpperCase() + project.boardType.slice(1)}</strong> methodology
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Team Coordination
                  </h4>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    {project.boardType === "kanban" ? (
                      <ul className="space-y-1">
                        <li>• Work pulled from backlog as capacity allows</li>
                        <li>• Daily flow reviews and blockers discussion</li>
                        <li>• Continuous delivery and deployment</li>
                      </ul>
                    ) : (
                      <ul className="space-y-1">
                        <li>• Sprint planning every 2-3 weeks</li>
                        <li>• Daily standup meetings</li>
                        <li>• Sprint review and retrospective</li>
                      </ul>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    Success Metrics
                  </h4>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    {project.boardType === "kanban" ? (
                      <ul className="space-y-1">
                        <li>• Lead time optimization</li>
                        <li>• Throughput measurement</li>
                        <li>• WIP limit adherence</li>
                      </ul>
                    ) : (
                      <ul className="space-y-1">
                        <li>• Sprint velocity tracking</li>
                        <li>• Story point completion</li>
                        <li>• Team satisfaction metrics</li>
                      </ul>
                    )}
                  </div>
                </div>
              </div>

              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full">
                    Change Board Type
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl">
                  <DialogHeader>
                    <DialogTitle>Select Board Management Type</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-6">
                    <RadioGroup value={selectedBoardType} onValueChange={setSelectedBoardType}>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(boardTypeInfo).map(([type, info]) => (
                          <div key={type} className={`relative border rounded-lg p-4 cursor-pointer transition-colors hover:bg-gray-50 dark:hover:bg-gray-800 ${info.color}`}>
                            <Label htmlFor={type} className="cursor-pointer">
                              <div className="flex items-center space-x-2 mb-3">
                                <RadioGroupItem value={type} id={type} />
                                <div className="flex items-center gap-2">
                                  {info.icon}
                                  <span className="font-semibold">{info.title}</span>
                                </div>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                                {info.description}
                              </p>
                              
                              <div className="space-y-3">
                                <div>
                                  <h4 className="text-sm font-medium mb-2 flex items-center gap-1">
                                    <Zap className="w-3 h-3" />
                                    Key Features
                                  </h4>
                                  <ul className="text-xs space-y-1 text-gray-600 dark:text-gray-400">
                                    {info.features.map((feature, index) => (
                                      <li key={index}>• {feature}</li>
                                    ))}
                                  </ul>
                                </div>
                                
                                <div>
                                  <h4 className="text-sm font-medium mb-2 flex items-center gap-1">
                                    <TrendingUp className="w-3 h-3" />
                                    Benefits
                                  </h4>
                                  <ul className="text-xs space-y-1 text-gray-600 dark:text-gray-400">
                                    {info.benefits.map((benefit, index) => (
                                      <li key={index}>• {benefit}</li>
                                    ))}
                                  </ul>
                                </div>
                              </div>
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                    
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleSetBoardType}
                        disabled={setBoardTypeMutation.isPending || !selectedBoardType}
                      >
                        {setBoardTypeMutation.isPending ? "Setting..." : "Set Board Type"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-sm text-amber-600 dark:text-amber-400">
                <Calendar className="w-4 h-4" />
                No board type configured. Click below to set up team workflow.
              </div>
              
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full flex items-center gap-2">
                    <Settings className="w-4 h-4" />
                    Manage with Scrum
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl">
                  <DialogHeader>
                    <DialogTitle>Choose Board Management Approach</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-6">
                    <RadioGroup value={selectedBoardType} onValueChange={setSelectedBoardType}>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(boardTypeInfo).map(([type, info]) => (
                          <div key={type} className={`relative border rounded-lg p-4 cursor-pointer transition-colors hover:bg-gray-50 dark:hover:bg-gray-800 ${info.color}`}>
                            <Label htmlFor={type} className="cursor-pointer">
                              <div className="flex items-center space-x-2 mb-3">
                                <RadioGroupItem value={type} id={type} />
                                <div className="flex items-center gap-2">
                                  {info.icon}
                                  <span className="font-semibold">{info.title}</span>
                                </div>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                                {info.description}
                              </p>
                              
                              <div className="space-y-3">
                                <div>
                                  <h4 className="text-sm font-medium mb-2 flex items-center gap-1">
                                    <Zap className="w-3 h-3" />
                                    Key Features
                                  </h4>
                                  <ul className="text-xs space-y-1 text-gray-600 dark:text-gray-400">
                                    {info.features.map((feature, index) => (
                                      <li key={index}>• {feature}</li>
                                    ))}
                                  </ul>
                                </div>
                                
                                <div>
                                  <h4 className="text-sm font-medium mb-2 flex items-center gap-1">
                                    <TrendingUp className="w-3 h-3" />
                                    Benefits
                                  </h4>
                                  <ul className="text-xs space-y-1 text-gray-600 dark:text-gray-400">
                                    {info.benefits.map((benefit, index) => (
                                      <li key={index}>• {benefit}</li>
                                    ))}
                                  </ul>
                                </div>
                              </div>
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                    
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleSetBoardType}
                        disabled={setBoardTypeMutation.isPending || !selectedBoardType}
                      >
                        {setBoardTypeMutation.isPending ? "Setting..." : "Set Board Type"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}