import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { ArchitectDiagramEditor } from "./architect-diagram-editor";
import { 
  Brain, 
  FileText, 
  CheckCircle, 
  Users, 
  Layers, 
  Palette, 
  Code, 
  Server,
  Zap,
  TrendingUp,
  Clock,
  Target,
  AlertTriangle
} from "lucide-react";

interface AgentInterfaceProps {
  currentRole: string;
  projectId?: number;
}

interface AgentTask {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed';
  priority: 'low' | 'medium' | 'high' | 'critical';
  estimatedTime: string;
  aiRecommendation?: string;
}

interface AgentInsight {
  type: 'recommendation' | 'warning' | 'opportunity';
  title: string;
  description: string;
  action?: string;
}

export function AgentInterface({ currentRole, projectId }: AgentInterfaceProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const [showDiagramEditor, setShowDiagramEditor] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Agent-specific configuration
  const getAgentConfig = () => {
    switch (currentRole) {
      case 'business-analyst':
        return {
          name: "Business Analyst AI Agent",
          icon: <FileText className="h-6 w-6" />,
          color: "text-blue-600",
          bgColor: "bg-blue-50",
          borderColor: "border-blue-200",
          capabilities: [
            "Requirements Analysis",
            "Stakeholder Communication",
            "Process Documentation",
            "Regulatory Compliance"
          ]
        };
      case 'product-owner':
        return {
          name: "Product Owner AI Agent",
          icon: <CheckCircle className="h-6 w-6" />,
          color: "text-green-600",
          bgColor: "bg-green-50",
          borderColor: "border-green-200",
          capabilities: [
            "Project Evaluation",
            "Priority Management",
            "ROI Analysis",
            "Stakeholder Alignment"
          ]
        };
      case 'scrum-master':
        return {
          name: "Scrum Master AI Agent",
          icon: <Users className="h-6 w-6" />,
          color: "text-purple-600",
          bgColor: "bg-purple-50",
          borderColor: "border-purple-200",
          capabilities: [
            "Sprint Planning",
            "Team Coordination",
            "Risk Management",
            "Process Optimization"
          ]
        };
      case 'architect':
        return {
          name: "Architect AI Agent",
          icon: <Layers className="h-6 w-6" />,
          color: "text-orange-600",
          bgColor: "bg-orange-50",
          borderColor: "border-orange-200",
          capabilities: [
            "System Design",
            "Technology Selection",
            "Performance Optimization",
            "Security Architecture"
          ]
        };
      case 'ui-designer':
        return {
          name: "UI Designer AI Agent",
          icon: <Palette className="h-6 w-6" />,
          color: "text-pink-600",
          bgColor: "bg-pink-50",
          borderColor: "border-pink-200",
          capabilities: [
            "UI/UX Design",
            "Wireframe Generation",
            "User Flow Analysis",
            "Accessibility Design"
          ]
        };
      case 'developer':
        return {
          name: "Developer AI Agent",
          icon: <Code className="h-6 w-6" />,
          color: "text-indigo-600",
          bgColor: "bg-indigo-50",
          borderColor: "border-indigo-200",
          capabilities: [
            "Code Generation",
            "Architecture Implementation",
            "Testing Strategy",
            "Performance Optimization"
          ]
        };
      case 'devops':
        return {
          name: "DevOps AI Agent",
          icon: <Server className="h-6 w-6" />,
          color: "text-red-600",
          bgColor: "bg-red-50",
          borderColor: "border-red-200",
          capabilities: [
            "Infrastructure Design",
            "CI/CD Pipeline",
            "Monitoring Setup",
            "Security Implementation"
          ]
        };
      default:
        return {
          name: "AI Agent",
          icon: <Brain className="h-6 w-6" />,
          color: "text-gray-600",
          bgColor: "bg-gray-50",
          borderColor: "border-gray-200",
          capabilities: ["General AI Assistance"]
        };
    }
  };

  const agentConfig = getAgentConfig();

  // Simulated agent tasks based on role
  const getAgentTasks = (): AgentTask[] => {
    switch (currentRole) {
      case 'business-analyst':
        return [
          {
            id: '1',
            title: 'Analyze Project Requirements',
            description: 'Process and structure incoming project requirements into functional and non-functional specifications',
            status: 'pending',
            priority: 'high',
            estimatedTime: '2-3 hours',
            aiRecommendation: 'Focus on regulatory compliance aspects for financial services'
          },
          {
            id: '2',
            title: 'Generate Use Cases',
            description: 'Create detailed use cases with actors, scenarios, and acceptance criteria',
            status: 'in_progress',
            priority: 'medium',
            estimatedTime: '1-2 hours'
          }
        ];
      case 'product-owner':
        return [
          {
            id: '1',
            title: 'Evaluate Project Proposals',
            description: 'Review and assess incoming project proposals for business value and feasibility',
            status: 'pending',
            priority: 'critical',
            estimatedTime: '1 hour',
            aiRecommendation: 'Consider market timing and competitive advantage'
          }
        ];
      case 'scrum-master':
        return [
          {
            id: '1',
            title: 'Create Sprint Plan',
            description: 'Generate comprehensive sprint planning with team assignments and dependencies',
            status: 'pending',
            priority: 'high',
            estimatedTime: '2 hours'
          }
        ];
      default:
        return [];
    }
  };

  const getAgentInsights = (): AgentInsight[] => {
    switch (currentRole) {
      case 'business-analyst':
        return [
          {
            type: 'recommendation',
            title: 'Focus on Compliance',
            description: 'Current project requirements show strong alignment with MiFID II regulations',
            action: 'Include detailed compliance mapping'
          },
          {
            type: 'opportunity',
            title: 'Process Automation',
            description: 'Identified 3 manual processes that could be automated',
            action: 'Add automation requirements'
          }
        ];
      case 'product-owner':
        return [
          {
            type: 'recommendation',
            title: 'High ROI Potential',
            description: 'Project shows 300% ROI over 24 months with current scope',
            action: 'Fast-track approval recommended'
          }
        ];
      default:
        return [];
    }
  };

  // Agent action mutations
  const executeAgentAction = useMutation({
    mutationFn: async ({ action, projectId }: { action: string; projectId?: number }) => {
      const endpoint = `/api/agents/${currentRole}/${action}`;
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ projectId })
      });
      
      if (!res.ok) throw new Error('Agent action failed');
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Agent Action Completed",
        description: `${agentConfig.name} has completed the requested action`,
      });
      queryClient.invalidateQueries({ queryKey: ['agent-data'] });
    }
  });

  const tasks = getAgentTasks();
  const insights = getAgentInsights();

  return (
    <div className="space-y-6">
      {/* Agent Header */}
      <Card className={`${agentConfig.borderColor} border-2`}>
        <CardHeader className={agentConfig.bgColor}>
          <div className="flex items-center space-x-3">
            <div className={`${agentConfig.color} p-2 bg-white rounded-lg`}>
              {agentConfig.icon}
            </div>
            <div>
              <CardTitle className={`${agentConfig.color} text-lg font-semibold`}>
                {agentConfig.name}
              </CardTitle>
              <p className="text-sm text-gray-600">
                AI-powered assistant for {currentRole.replace('-', ' ')} workflows
              </p>
            </div>
            <div className="ml-auto">
              <Badge variant="outline" className={`${agentConfig.color} ${agentConfig.borderColor}`}>
                <Zap className="h-3 w-3 mr-1" />
                Active
              </Badge>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Agent Interface Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
          <TabsTrigger value="actions">Actions</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Agent Capabilities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="h-5 w-5 mr-2" />
                Core Capabilities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {agentConfig.capabilities.map((capability, index) => (
                  <div key={index} className="flex items-center space-x-2 p-2 rounded-lg bg-gray-50">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium">{capability}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Current Project Context */}
          {projectId && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="h-5 w-5 mr-2" />
                  Current Project Context
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Project ID:</span>
                    <Badge variant="outline">{projectId}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">AI Analysis:</span>
                    <Badge variant="secondary" className="text-green-600">
                      Ready
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="tasks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Active Tasks
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {tasks.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No active tasks. Create a new project to begin.
                </div>
              ) : (
                tasks.map((task) => (
                  <div key={task.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h4 className="font-medium">{task.title}</h4>
                        <p className="text-sm text-gray-600">{task.description}</p>
                      </div>
                      <Badge 
                        variant={task.priority === 'critical' ? 'destructive' : 
                                task.priority === 'high' ? 'default' : 'secondary'}
                      >
                        {task.priority}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {task.estimatedTime}
                      </span>
                      <Badge variant="outline" className={
                        task.status === 'completed' ? 'text-green-600' :
                        task.status === 'in_progress' ? 'text-blue-600' : 'text-gray-600'
                      }>
                        {task.status.replace('_', ' ')}
                      </Badge>
                    </div>

                    {task.aiRecommendation && (
                      <div className="bg-blue-50 border border-blue-200 rounded p-3">
                        <div className="flex items-start space-x-2">
                          <Brain className="h-4 w-4 text-blue-600 mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-blue-800">AI Recommendation</p>
                            <p className="text-sm text-blue-700">{task.aiRecommendation}</p>
                          </div>
                        </div>
                      </div>
                    )}

                    <Button 
                      variant="outline" 
                      size="sm"
                      className="w-full"
                      onClick={() => executeAgentAction.mutate({ 
                        action: task.title.toLowerCase().replace(/\s+/g, '-'),
                        projectId 
                      })}
                      disabled={executeAgentAction.isPending}
                    >
                      {executeAgentAction.isPending ? 'Processing...' : 'Execute with AI'}
                    </Button>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" />
                AI Insights & Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {insights.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No insights available. Start working on a project to get AI recommendations.
                </div>
              ) : (
                insights.map((insight, index) => (
                  <div key={index} className={`border rounded-lg p-4 ${
                    insight.type === 'warning' ? 'border-yellow-200 bg-yellow-50' :
                    insight.type === 'recommendation' ? 'border-blue-200 bg-blue-50' :
                    'border-green-200 bg-green-50'
                  }`}>
                    <div className="flex items-start space-x-3">
                      <div className={`p-1 rounded ${
                        insight.type === 'warning' ? 'text-yellow-600' :
                        insight.type === 'recommendation' ? 'text-blue-600' :
                        'text-green-600'
                      }`}>
                        {insight.type === 'warning' ? <AlertTriangle className="h-5 w-5" /> :
                         insight.type === 'recommendation' ? <Brain className="h-5 w-5" /> :
                         <TrendingUp className="h-5 w-5" />}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{insight.title}</h4>
                        <p className="text-sm text-gray-600 mt-1">{insight.description}</p>
                        {insight.action && (
                          <Button variant="outline" size="sm" className="mt-2">
                            {insight.action}
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="actions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="h-5 w-5 mr-2" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {currentRole === 'business-analyst' && (
                <>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => executeAgentAction.mutate({ action: 'analyze', projectId })}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Analyze Requirements
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => executeAgentAction.mutate({ action: 'generate-use-cases', projectId })}
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Generate Use Cases
                  </Button>
                </>
              )}

              {currentRole === 'product-owner' && (
                <>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => executeAgentAction.mutate({ action: 'evaluate', projectId })}
                  >
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Evaluate Project
                  </Button>
                </>
              )}

              {currentRole === 'scrum-master' && (
                <>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => executeAgentAction.mutate({ action: 'plan', projectId })}
                  >
                    <Users className="h-4 w-4 mr-2" />
                    Create Sprint Plan
                  </Button>
                </>
              )}

              {currentRole === 'architect' && (
                <>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => executeAgentAction.mutate({ action: 'design', projectId })}
                  >
                    <Layers className="h-4 w-4 mr-2" />
                    Generate Architecture
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => {
                      console.log('Create Diagrams clicked, projectId:', projectId);
                      console.log('Setting showDiagramEditor to true');
                      setShowDiagramEditor(true);
                    }}
                    disabled={!projectId}
                  >
                    <Layers className="h-4 w-4 mr-2" />
                    Create Architecture Diagrams
                  </Button>
                  {!projectId && (
                    <p className="text-xs text-gray-500 mt-1">
                      Select a project using "Work with Agent" to enable diagram creation
                    </p>
                  )}
                </>
              )}

              {currentRole === 'ui-designer' && (
                <>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => executeAgentAction.mutate({ action: 'design', projectId })}
                  >
                    <Palette className="h-4 w-4 mr-2" />
                    Create UI Design
                  </Button>
                </>
              )}

              {currentRole === 'developer' && (
                <>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => executeAgentAction.mutate({ action: 'guide', projectId })}
                  >
                    <Code className="h-4 w-4 mr-2" />
                    Get Development Guide
                  </Button>
                </>
              )}

              {currentRole === 'devops' && (
                <>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => executeAgentAction.mutate({ action: 'deploy', projectId })}
                  >
                    <Server className="h-4 w-4 mr-2" />
                    Plan Deployment
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Architect Diagram Editor Modal */}
      {showDiagramEditor && (
        <div>
          {console.log('Rendering ArchitectDiagramEditor, showDiagramEditor:', showDiagramEditor)}
          <ArchitectDiagramEditor
            projectId={projectId || 1}
            onClose={() => {
              console.log('Closing diagram editor');
              setShowDiagramEditor(false);
            }}
          />
        </div>
      )}
    </div>
  );
}