import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Bot, FileDown, Clock, User, CheckCircle, Edit, Save, X, Trash2, Send, Target, Shield, Zap, Globe, Settings, Award, Star, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface UseCase {
  id: number;
  projectId: number;
  ucId: string;
  title: string;
  description: string;
  type: "functional" | "non-functional";
  priority: string;
  status: string;
  actor?: string;
  category?: string;
  updatedAt: string;
}

interface Project {
  id: number;
  name: string;
}

interface UseCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project | null;
  currentRole: string;
}

const priorityColors = {
  Critical: "bg-red-100 text-red-800",
  High: "bg-green-100 text-green-800",
  Medium: "bg-yellow-100 text-yellow-800",
  Low: "bg-gray-100 text-gray-800",
};

const statusColors = {
  Approved: "text-green-600",
  "In Review": "text-yellow-600",
  Draft: "text-gray-600",
};

function UseCaseCard({ useCase, onEdit, onDelete, onSubmitForApproval, currentRole }: { 
  useCase: UseCase; 
  onEdit: (useCase: UseCase) => void;
  onDelete: (id: number) => void;
  onSubmitForApproval: (id: number) => void;
  currentRole: string;
}) {
  const [isExpanded, setIsExpanded] = useState(false);

  // Enhanced type-specific styling for visual appeal
  const getTypeIcon = () => {
    return useCase.type === 'functional' ? <Target className="h-5 w-5" /> : <Shield className="h-5 w-5" />;
  };

  const getTypeColor = () => {
    return useCase.type === 'functional' 
      ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white" 
      : "bg-gradient-to-r from-green-500 to-teal-600 text-white";
  };

  return (
    <Card className="hover:shadow-xl transition-all duration-300 w-full border-l-4 border-l-blue-500 bg-gradient-to-r from-white to-gray-50">
      <CardContent className="p-6">
        <div className="space-y-6">
          {/* Enhanced Header Section with Visual Hierarchy */}
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-3 mb-2">
                <div className={`p-2 rounded-lg ${getTypeColor()}`}>
                  {getTypeIcon()}
                </div>
                <div className="flex-1">
                  <h4 className="text-xl font-bold text-gray-900 break-words leading-tight">{useCase.title}</h4>
                  <div className="flex items-center space-x-2 mt-1">
                    <p className="text-sm font-medium text-blue-600">{useCase.ucId}</p>
                    <Badge className="text-xs px-2 py-1 bg-blue-100 text-blue-800">
                      {useCase.type === 'functional' ? 'Functional' : 'Non-Functional'}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col items-end space-y-2 ml-4">
              <Badge
                className={`flex items-center space-x-1 px-3 py-1 ${
                  priorityColors[useCase.priority as keyof typeof priorityColors] ||
                  "bg-gray-100 text-gray-800"
                }`}
              >
                <Star className="h-3 w-3" />
                <span>{useCase.priority} Priority</span>
              </Badge>
              <Badge variant="outline" className={`flex items-center space-x-1 px-3 py-1 ${statusColors[useCase.status as keyof typeof statusColors] || "text-gray-600"}`}>
                <CheckCircle className="h-3 w-3" />
                <span>{useCase.status}</span>
              </Badge>
            </div>
          </div>

          {/* Enhanced Description with Professional Formatting */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-l-4 border-l-blue-500 rounded-r-lg p-6">
            <div className="flex items-center space-x-2 mb-4">
              <TrendingUp className="h-5 w-5 text-blue-600" />
              <h5 className="text-lg font-semibold text-gray-900">Detailed Requirements</h5>
            </div>
            <div className="prose prose-base max-w-none">
              <div className="text-gray-800 leading-relaxed whitespace-pre-wrap font-medium">
                {useCase.description}
              </div>
            </div>
          </div>
          
          {/* Enhanced Metadata Section with Premium Styling */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-6 bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl px-6 border border-gray-200">
            {useCase.actor && (
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <User className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <span className="font-semibold text-gray-900 block">Primary Actor</span>
                  <span className="text-blue-700 font-medium">{useCase.actor}</span>
                </div>
              </div>
            )}
            {useCase.category && (
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Settings className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <span className="font-semibold text-gray-900 block">Category</span>
                  <span className="text-green-700 font-medium">{useCase.category}</span>
                </div>
              </div>
            )}
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Clock className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <span className="font-semibold text-gray-900 block">Last Updated</span>
                <span className="text-gray-800">{new Date(useCase.updatedAt).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
          

        </div>
      </CardContent>
    </Card>
  );
}

export function UseCaseModal({ isOpen, onClose, project, currentRole }: UseCaseModalProps) {
  const [activeTab, setActiveTab] = useState("functional");
  const [editingUseCase, setEditingUseCase] = useState<UseCase | null>(null);
  const [isAddingUseCase, setIsAddingUseCase] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: useCases = [], isLoading } = useQuery({
    queryKey: ["/api/projects", project?.id, "use-cases"],
    queryFn: async () => {
      if (!project) return [];
      const response = await fetch(`/api/projects/${project.id}/use-cases`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch use cases");
      return response.json();
    },
    enabled: isOpen && !!project,
  });

  const functionalUseCases = useCases.filter((uc: UseCase) => uc.type === "functional");
  const nonFunctionalUseCases = useCases.filter((uc: UseCase) => uc.type === "non-functional");

  // Mutations for use case operations
  const updateUseCaseMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<UseCase> }) => {
      const response = await fetch(`/api/use-cases/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update use case');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", project?.id, "use-cases"] });
      toast({ title: "Use case updated successfully" });
      setEditingUseCase(null);
    },
  });

  const deleteUseCaseMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/use-cases/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to delete use case');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", project?.id, "use-cases"] });
      toast({ title: "Use case deleted successfully" });
    },
  });

  const submitForApprovalMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/use-cases/${id}/submit`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to submit for approval');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", project?.id, "use-cases"] });
      toast({ title: "Use case submitted for approval" });
    },
  });

  const handleEdit = (useCase: UseCase) => {
    setEditingUseCase(useCase);
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this use case?')) {
      deleteUseCaseMutation.mutate(id);
    }
  };

  const handleSubmitForApproval = (id: number) => {
    submitForApprovalMutation.mutate(id);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[95vh] overflow-hidden">
        <DialogHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-t-lg">
          <DialogTitle>
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-white/20 rounded-lg">
                <Award className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white">Enterprise Requirements Portfolio</h3>
                <p className="text-blue-100 mt-1 font-medium">{project?.name}</p>
                <p className="text-blue-200 text-sm mt-1">Comprehensive Functional & Non-Functional Specifications</p>
              </div>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mb-4">
          {(currentRole === "business-analyst" || currentRole === "product-owner") && (
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-900">Project Management</h3>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    toast({
                      title: "Edit Project",
                      description: "Project editing functionality will be available in the next update",
                    });
                  }}
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Edit Project
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-green-600 hover:text-green-700"
                  onClick={() => {
                    toast({
                      title: "Project Saved",
                      description: `"${project?.name}" has been saved successfully`,
                    });
                  }}
                >
                  <Save className="h-4 w-4 mr-1" />
                  Save Project
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-blue-600 hover:text-blue-700"
                  onClick={() => {
                    if (confirm(`Submit "${project?.name}" for approval? This will notify approvers to review the project.`)) {
                      toast({
                        title: "Project Submitted",
                        description: `"${project?.name}" has been submitted for approval`,
                      });
                    }
                  }}
                >
                  <Send className="h-4 w-4 mr-1" />
                  Submit for Approval
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-red-600 hover:text-red-700"
                  onClick={() => {
                    if (confirm(`Are you sure you want to delete "${project?.name}"? This action cannot be undone and will remove all associated use cases.`)) {
                      toast({
                        title: "Project Deleted",
                        description: `"${project?.name}" has been deleted`,
                      });
                      onClose();
                    }
                  }}
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete Project
                </Button>
              </div>
            </div>
          )}
        </div>

        <div className="overflow-y-auto max-h-[calc(95vh-200px)]">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 bg-gradient-to-r from-blue-100 to-purple-100 p-1 rounded-lg">
              <TabsTrigger value="functional" className="flex items-center space-x-2 data-[state=active]:bg-white data-[state=active]:shadow-md">
                <Target className="h-4 w-4" />
                <span>Functional Use Cases ({functionalUseCases.length})</span>
              </TabsTrigger>
              <TabsTrigger value="non-functional" className="flex items-center space-x-2 data-[state=active]:bg-white data-[state=active]:shadow-md">
                <Shield className="h-4 w-4" />
                <span>Non-Functional Requirements ({nonFunctionalUseCases.length})</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="functional" className="mt-6">
              <div className="space-y-4">
                {isLoading ? (
                  <div className="text-center py-8 text-gray-500">Loading use cases...</div>
                ) : functionalUseCases.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No functional use cases found</div>
                ) : (
                  functionalUseCases.map((useCase: UseCase) => (
                    <UseCaseCard 
                      key={useCase.id} 
                      useCase={useCase} 
                      onEdit={handleEdit}
                      onDelete={handleDelete}
                      onSubmitForApproval={handleSubmitForApproval}
                      currentRole={currentRole}
                    />
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="non-functional" className="mt-6">
              <div className="space-y-4">
                {isLoading ? (
                  <div className="text-center py-8 text-gray-500">Loading use cases...</div>
                ) : nonFunctionalUseCases.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No non-functional use cases found</div>
                ) : (
                  nonFunctionalUseCases.map((useCase: UseCase) => (
                    <UseCaseCard 
                      key={useCase.id} 
                      useCase={useCase} 
                      onEdit={handleEdit}
                      onDelete={handleDelete}
                      onSubmitForApproval={handleSubmitForApproval}
                      currentRole={currentRole}
                    />
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex items-center space-x-4">
            <Button className="flex items-center bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg">
              <Plus className="h-4 w-4 mr-2" />
              Add Use Case
            </Button>
            <Button variant="outline" className="flex items-center border-blue-300 text-blue-700 hover:bg-blue-50">
              <Bot className="h-4 w-4 mr-2" />
              AI Suggestions
            </Button>
          </div>
          <Button variant="outline" className="flex items-center border-green-300 text-green-700 hover:bg-green-50">
            <FileDown className="h-4 w-4 mr-2" />
            Export Requirements
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
