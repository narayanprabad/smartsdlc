import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Bot, FileDown, Clock, User, CheckCircle, Edit, Save, X, Trash2, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface UseCase {
  id: number;
  projectId: number;
  ucId: string;
  title: string;
  description: string;
  type: "functional" | "non-functional";
  priority: string;
  status: string;
  actor?: string;
  category?: string;
  updatedAt: string;
}

interface Project {
  id: number;
  name: string;
}

interface UseCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project | null;
  currentRole: string;
}

const priorityColors = {
  Critical: "bg-red-100 text-red-800",
  High: "bg-green-100 text-green-800",
  Medium: "bg-yellow-100 text-yellow-800",
  Low: "bg-gray-100 text-gray-800",
};

const statusColors = {
  Approved: "text-green-600",
  "In Review": "text-yellow-600",
  Draft: "text-gray-600",
};

function UseCaseCard({ useCase, onEdit, onDelete, onSubmitForApproval, currentRole }: { 
  useCase: UseCase; 
  onEdit: (useCase: UseCase) => void;
  onDelete: (id: number) => void;
  onSubmitForApproval: (id: number) => void;
  currentRole: string;
}) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <Card className="hover:shadow-md transition-shadow duration-200 w-full">
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Header Section */}
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <h4 className="text-lg font-semibold text-gray-900 break-words">{useCase.title}</h4>
              <p className="text-sm text-gray-500 mt-1">{useCase.ucId}</p>
            </div>
            <div className="flex flex-col items-end space-y-2 ml-4">
              <Badge
                className={
                  priorityColors[useCase.priority as keyof typeof priorityColors] ||
                  "bg-gray-100 text-gray-800"
                }
              >
                {useCase.priority} Priority
              </Badge>
              <Badge variant="outline" className={statusColors[useCase.status as keyof typeof statusColors] || "text-gray-600"}>
                {useCase.status}
              </Badge>
            </div>
          </div>

          {/* Description - Always Visible */}
          <div className="border-l-4 border-blue-100 pl-4">
            <p className="text-sm text-gray-700 leading-relaxed">{useCase.description}</p>
          </div>
          
          {/* Detailed Information - Always Visible Now */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-3 bg-gray-50 rounded-lg px-4">
            {useCase.actor && (
              <div className="flex items-center text-sm text-gray-600">
                <User className="h-4 w-4 mr-2 text-blue-500" />
                <div>
                  <span className="font-medium block">Actor</span>
                  <span className="text-gray-800">{useCase.actor}</span>
                </div>
              </div>
            )}
            {useCase.category && (
              <div className="flex items-center text-sm text-gray-600">
                <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                <div>
                  <span className="font-medium block">Category</span>
                  <span className="text-gray-800">{useCase.category}</span>
                </div>
              </div>
            )}
            <div className="flex items-center text-sm text-gray-600">
              <Clock className="h-4 w-4 mr-2 text-orange-500" />
              <div>
                <span className="font-medium block">Updated</span>
                <span className="text-gray-800">{new Date(useCase.updatedAt).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
          

        </div>
      </CardContent>
    </Card>
  );
}

export function UseCaseModal({ isOpen, onClose, project, currentRole }: UseCaseModalProps) {
  const [activeTab, setActiveTab] = useState("functional");
  const [editingUseCase, setEditingUseCase] = useState<UseCase | null>(null);
  const [isAddingUseCase, setIsAddingUseCase] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: useCases = [], isLoading } = useQuery({
    queryKey: ["/api/projects", project?.id, "use-cases"],
    queryFn: async () => {
      if (!project) return [];
      const response = await fetch(`/api/projects/${project.id}/use-cases`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch use cases");
      return response.json();
    },
    enabled: isOpen && !!project,
  });

  const functionalUseCases = useCases.filter((uc: UseCase) => uc.type === "functional");
  const nonFunctionalUseCases = useCases.filter((uc: UseCase) => uc.type === "non-functional");

  // Mutations for use case operations
  const updateUseCaseMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<UseCase> }) => {
      const response = await fetch(`/api/use-cases/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update use case');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", project?.id, "use-cases"] });
      toast({ title: "Use case updated successfully" });
      setEditingUseCase(null);
    },
  });

  const deleteUseCaseMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/use-cases/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to delete use case');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", project?.id, "use-cases"] });
      toast({ title: "Use case deleted successfully" });
    },
  });

  const submitForApprovalMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/use-cases/${id}/submit`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to submit for approval');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", project?.id, "use-cases"] });
      toast({ title: "Use case submitted for approval" });
    },
  });

  const handleEdit = (useCase: UseCase) => {
    setEditingUseCase(useCase);
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this use case?')) {
      deleteUseCaseMutation.mutate(id);
    }
  };

  const handleSubmitForApproval = (id: number) => {
    submitForApprovalMutation.mutate(id);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Use Cases</h3>
              <p className="text-sm text-gray-600 mt-1">{project?.name}</p>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mb-4">
          {(currentRole === "business-analyst" || currentRole === "product-owner") && (
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-900">Project Management</h3>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    toast({
                      title: "Edit Project",
                      description: "Project editing functionality will be available in the next update",
                    });
                  }}
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Edit Project
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-green-600 hover:text-green-700"
                  onClick={() => {
                    toast({
                      title: "Project Saved",
                      description: `"${project?.name}" has been saved successfully`,
                    });
                  }}
                >
                  <Save className="h-4 w-4 mr-1" />
                  Save Project
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-blue-600 hover:text-blue-700"
                  onClick={() => {
                    if (confirm(`Submit "${project?.name}" for approval? This will notify approvers to review the project.`)) {
                      toast({
                        title: "Project Submitted",
                        description: `"${project?.name}" has been submitted for approval`,
                      });
                    }
                  }}
                >
                  <Send className="h-4 w-4 mr-1" />
                  Submit for Approval
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-red-600 hover:text-red-700"
                  onClick={() => {
                    if (confirm(`Are you sure you want to delete "${project?.name}"? This action cannot be undone and will remove all associated use cases.`)) {
                      toast({
                        title: "Project Deleted",
                        description: `"${project?.name}" has been deleted`,
                      });
                      onClose();
                    }
                  }}
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete Project
                </Button>
              </div>
            </div>
          )}
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-200px)]">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="functional">
                Functional Use Cases ({functionalUseCases.length})
              </TabsTrigger>
              <TabsTrigger value="non-functional">
                Non-Functional Use Cases ({nonFunctionalUseCases.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="functional" className="mt-6">
              <div className="space-y-4">
                {isLoading ? (
                  <div className="text-center py-8 text-gray-500">Loading use cases...</div>
                ) : functionalUseCases.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No functional use cases found</div>
                ) : (
                  functionalUseCases.map((useCase: UseCase) => (
                    <UseCaseCard 
                      key={useCase.id} 
                      useCase={useCase} 
                      onEdit={handleEdit}
                      onDelete={handleDelete}
                      onSubmitForApproval={handleSubmitForApproval}
                      currentRole={currentRole}
                    />
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="non-functional" className="mt-6">
              <div className="space-y-4">
                {isLoading ? (
                  <div className="text-center py-8 text-gray-500">Loading use cases...</div>
                ) : nonFunctionalUseCases.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No non-functional use cases found</div>
                ) : (
                  nonFunctionalUseCases.map((useCase: UseCase) => (
                    <UseCaseCard 
                      key={useCase.id} 
                      useCase={useCase} 
                      onEdit={handleEdit}
                      onDelete={handleDelete}
                      onSubmitForApproval={handleSubmitForApproval}
                      currentRole={currentRole}
                    />
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex items-center space-x-4">
            <Button className="flex items-center">
              <Plus className="h-4 w-4 mr-2" />
              Add Use Case
            </Button>
            <Button variant="outline" className="flex items-center">
              <Bot className="h-4 w-4 mr-2" />
              AI Suggestions
            </Button>
          </div>
          <Button variant="outline" className="flex items-center">
            <FileDown className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
