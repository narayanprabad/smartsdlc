import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArchitectureDiagramEditor } from "./architecture-diagram-editor";
import { 
  FileText, 
  Edit3, 
  CheckCircle, 
  Plus, 
  Trash2, 
  Cpu, 
  Database, 
  Shield, 
  Network, 
  Settings,
  Activity,
  Palette
} from "lucide-react";

interface ArchitectureWorkspaceProps {
  projectId: number;
  userRole: string;
}

interface ArchitectureDiagram {
  id: string;
  title: string;
  description: string;
  svg: string;
}

export function ArchitectureWorkspace({ projectId, userRole }: ArchitectureWorkspaceProps) {
  const [editMode, setEditMode] = useState(false);
  const [editedData, setEditedData] = useState({});
  const [diagrams, setDiagrams] = useState<ArchitectureDiagram[]>([
    {
      id: "1",
      title: "System Overview",
      description: "High-level system architecture overview",
      svg: `<svg viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg">
        <rect width="800" height="600" fill="#f8fafc"/>
        <rect x="50" y="100" width="120" height="80" fill="#3b82f6" rx="8"/>
        <text x="110" y="145" font-family="Arial" font-size="12" fill="white" text-anchor="middle">Frontend</text>
        <rect x="250" y="100" width="120" height="80" fill="#10b981" rx="8"/>
        <text x="310" y="145" font-family="Arial" font-size="12" fill="white" text-anchor="middle">API Gateway</text>
        <rect x="450" y="100" width="120" height="80" fill="#f59e0b" rx="8"/>
        <text x="510" y="145" font-family="Arial" font-size="12" fill="white" text-anchor="middle">Services</text>
        <rect x="650" y="100" width="120" height="80" fill="#ef4444" rx="8"/>
        <text x="710" y="145" font-family="Arial" font-size="12" fill="white" text-anchor="middle">Database</text>
        <line x1="170" y1="140" x2="250" y2="140" stroke="#374151" stroke-width="2" marker-end="url(#arrowhead)"/>
        <line x1="370" y1="140" x2="450" y2="140" stroke="#374151" stroke-width="2" marker-end="url(#arrowhead)"/>
        <line x1="570" y1="140" x2="650" y2="140" stroke="#374151" stroke-width="2" marker-end="url(#arrowhead)"/>
        <defs>
          <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
            <polygon points="0 0, 10 3.5, 0 7" fill="#374151"/>
          </marker>
        </defs>
      </svg>`
    },
    {
      id: "2", 
      title: "Data Flow",
      description: "Data flow and processing pipeline",
      svg: `<svg viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg">
        <rect width="800" height="600" fill="#f8fafc"/>
        <circle cx="100" cy="300" r="40" fill="#8b5cf6"/>
        <text x="100" y="305" font-family="Arial" font-size="10" fill="white" text-anchor="middle">Input</text>
        <rect x="200" y="260" width="80" height="80" fill="#06b6d4" rx="8"/>
        <text x="240" y="305" font-family="Arial" font-size="10" fill="white" text-anchor="middle">Process</text>
        <circle cx="400" cy="300" r="40" fill="#10b981"/>
        <text x="400" y="305" font-family="Arial" font-size="10" fill="white" text-anchor="middle">Store</text>
        <rect x="520" y="260" width="80" height="80" fill="#f59e0b" rx="8"/>
        <text x="560" y="305" font-family="Arial" font-size="10" fill="white" text-anchor="middle">Output</text>
        <line x1="140" y1="300" x2="200" y2="300" stroke="#374151" stroke-width="2" marker-end="url(#arrowhead)"/>
        <line x1="280" y1="300" x2="360" y2="300" stroke="#374151" stroke-width="2" marker-end="url(#arrowhead)"/>
        <line x1="440" y1="300" x2="520" y2="300" stroke="#374151" stroke-width="2" marker-end="url(#arrowhead)"/>
        <defs>
          <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
            <polygon points="0 0, 10 3.5, 0 7" fill="#374151"/>
          </marker>
        </defs>
      </svg>`
    }
  ]);
  const [showAddDiagram, setShowAddDiagram] = useState(false);
  const [newDiagramTitle, setNewDiagramTitle] = useState("");

  const canEdit = userRole === "Architect" || userRole === "Admin";

  const addDiagram = () => {
    if (!newDiagramTitle.trim()) return;
    
    const newDiagram: ArchitectureDiagram = {
      id: Date.now().toString(),
      title: newDiagramTitle,
      description: `Custom architecture diagram: ${newDiagramTitle}`,
      svg: `<svg viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg">
        <rect width="800" height="600" fill="#f8fafc"/>
        <text x="400" y="300" font-family="Arial" font-size="24" fill="#374151" text-anchor="middle">${newDiagramTitle}</text>
        <text x="400" y="340" font-family="Arial" font-size="14" fill="#6b7280" text-anchor="middle">Custom diagram - Click to edit</text>
      </svg>`
    };
    
    setDiagrams([...diagrams, newDiagram]);
    setNewDiagramTitle("");
    setShowAddDiagram(false);
  };

  const removeDiagram = (diagramId: string) => {
    setDiagrams(diagrams.filter(d => d.id !== diagramId));
  };
  
  // Project-specific architecture data
  const getProjectArchitecture = (projectId: number) => {
    const architectures: Record<number, any> = {
      1: {
        systemOverview: "Global Clearing and Settlement Platform with real-time trade processing, multi-currency support, and regulatory compliance for JPMC operations across 40+ countries.",
        architecturalPrinciples: "Event-driven microservices with CQRS pattern, domain-driven design for financial instruments, real-time stream processing, and compliance-first security architecture.",
        riskAssessment: "Identified risks: settlement failures, currency volatility, regulatory changes, data breaches. Mitigation: redundant settlement paths, hedging mechanisms, automated compliance checks, end-to-end encryption.",
        componentDiagram: "Trading Interface → API Gateway → Settlement Engine → Risk Management → Clearing House APIs → Central Bank Systems → Regulatory Reporting",
        dataFlow: "Trade Order → Validation → Risk Check → Settlement Queue → Multi-Party Clearing → Central Bank Confirmation → Trade Confirmation → Regulatory Filing",
        technologyStack: {
          frontend: ["React 18", "TypeScript", "Material-UI", "Redux Toolkit"],
          backend: ["Java Spring Boot", "Apache Kafka", "Redis", "GraphQL"],
          database: ["PostgreSQL 15", "TimescaleDB", "MongoDB", "Apache Cassandra"],
          infrastructure: ["AWS EKS", "Docker", "Terraform", "Istio Service Mesh"],
          security: ["OAuth 2.0", "mTLS", "HSM Integration", "Zero Trust Network"]
        },
        securityArchitecture: "Zero-trust architecture with HSM-backed encryption, multi-factor authentication, continuous security monitoring, and real-time fraud detection.",
        integrationPoints: "SWIFT Network, FIX Protocol, Central Bank APIs, Regulatory Reporting Systems, Risk Management Platforms, and Real-time Market Data Feeds.",
        deploymentStrategy: "Multi-region active-active deployment with automated failover, blue-green releases, and comprehensive disaster recovery across AWS regions.",
        scalabilityConsiderations: "Auto-scaling based on trading volume, distributed caching for market data, database sharding by currency pairs, and CDN for global latency optimization."
      }
    };
    
    // Default architecture for other projects
    const defaultArch = {
      systemOverview: `Project-specific system architecture for Project ${projectId} with enterprise-grade scalability and security requirements.`,
      architecturalPrinciples: "Microservices architecture with domain-driven design, event sourcing, and comprehensive monitoring.",
      riskAssessment: "Risk assessment and mitigation strategies tailored to project requirements and business objectives.",
      componentDiagram: "Frontend → API Gateway → Business Services → Data Layer → External Integrations",
      dataFlow: "User Request → Authentication → Business Logic → Data Processing → Response",
      technologyStack: {
        frontend: ["React 18", "TypeScript", "Tailwind CSS"],
        backend: ["Node.js", "Express.js", "TypeScript"],
        database: ["PostgreSQL", "Redis"],
        infrastructure: ["Docker", "Kubernetes", "AWS"],
        security: ["OAuth 2.0", "JWT", "HTTPS/TLS"]
      },
      securityArchitecture: "Multi-layered security with authentication, authorization, encryption, and audit logging.",
      integrationPoints: "REST APIs, message queues, webhook systems, and third-party service integrations.",
      deploymentStrategy: "CI/CD pipeline with automated testing, staging environments, and production deployment.",
      scalabilityConsiderations: "Horizontal scaling, load balancing, caching strategies, and performance optimization."
    };
    
    return architectures[projectId] || defaultArch;
  };

  const defaultArchitecture = getProjectArchitecture(projectId);

  const handleToggleEdit = () => {
    if (editMode) {
      // Save changes here when backend is ready
      setEditMode(false);
    } else {
      setEditedData(defaultArchitecture);
      setEditMode(true);
    }
  };

  const handleSaveDiagram = (components: any[], connections: any[]) => {
    console.log("Saving diagram:", { components, connections });
    // Here you would save to backend
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Architecture Workspace</h2>
          <p className="text-gray-600 mt-1">Project-specific architecture for Project {projectId}</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            <CheckCircle className="h-3 w-3 mr-1" />
            Draft
          </Badge>
          {canEdit && (
            <Button onClick={handleToggleEdit} className="flex items-center gap-2">
              <Edit3 className="h-4 w-4" />
              {editMode ? "Save Changes" : "Edit Architecture"}
            </Button>
          )}
        </div>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Architecture Overview</TabsTrigger>
          <TabsTrigger value="diagrams">Visual Diagrams</TabsTrigger>
          <TabsTrigger value="editor">Diagram Editor</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          {/* Architecture Overview */}
          <div className="grid gap-6">
            {/* System Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <FileText className="h-5 w-5" />
                  System Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={(editedData as any).systemOverview || defaultArchitecture.systemOverview}
                    onChange={(e) => setEditedData({ ...editedData, systemOverview: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {defaultArchitecture.systemOverview}
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Architectural Principles */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Cpu className="h-5 w-5" />
                  Architectural Principles
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={(editedData as any).architecturalPrinciples || defaultArchitecture.architecturalPrinciples}
                    onChange={(e) => setEditedData({ ...editedData, architecturalPrinciples: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {defaultArchitecture.architecturalPrinciples}
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Risk Assessment */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Shield className="h-5 w-5" />
                  Risk Assessment
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={(editedData as any).riskAssessment || defaultArchitecture.riskAssessment}
                    onChange={(e) => setEditedData({ ...editedData, riskAssessment: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {defaultArchitecture.riskAssessment}
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Technology Stack */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Database className="h-5 w-5" />
                  Technology Stack
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid gap-4">
                  {Object.entries(defaultArchitecture.technologyStack).map(([category, technologies]) => (
                    <div key={category}>
                      <h4 className="font-semibold text-gray-900 mb-2 capitalize">{category}</h4>
                      <div className="flex flex-wrap gap-2">
                        {(technologies as string[]).map((tech, index) => (
                          <Badge key={index} variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Security Architecture */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Shield className="h-5 w-5" />
                  Security Architecture
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={(editedData as any).securityArchitecture || defaultArchitecture.securityArchitecture}
                    onChange={(e) => setEditedData({ ...editedData, securityArchitecture: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {defaultArchitecture.securityArchitecture}
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Integration Points */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Network className="h-5 w-5" />
                  Integration Points
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={(editedData as any).integrationPoints || defaultArchitecture.integrationPoints}
                    onChange={(e) => setEditedData({ ...editedData, integrationPoints: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {defaultArchitecture.integrationPoints}
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Deployment Strategy */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Settings className="h-5 w-5" />
                  Deployment Strategy
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={(editedData as any).deploymentStrategy || defaultArchitecture.deploymentStrategy}
                    onChange={(e) => setEditedData({ ...editedData, deploymentStrategy: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {defaultArchitecture.deploymentStrategy}
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Scalability Considerations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Activity className="h-5 w-5" />
                  Scalability Considerations
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {editMode ? (
                  <Textarea
                    value={(editedData as any).scalabilityConsiderations || defaultArchitecture.scalabilityConsiderations}
                    onChange={(e) => setEditedData({ ...editedData, scalabilityConsiderations: e.target.value })}
                    rows={3}
                    className="text-base"
                  />
                ) : (
                  <p className="text-gray-700 leading-relaxed text-base">
                    {defaultArchitecture.scalabilityConsiderations}
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="diagrams" className="space-y-6">
          {/* Diagram Management */}
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Architecture Diagrams</h3>
            {canEdit && (
              <Button 
                onClick={() => setShowAddDiagram(true)} 
                className="flex items-center gap-2"
                size="sm"
              >
                <Plus className="h-4 w-4" />
                Add Diagram
              </Button>
            )}
          </div>

          {/* Add Diagram Form */}
          {showAddDiagram && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Input
                    placeholder="Diagram title..."
                    value={newDiagramTitle}
                    onChange={(e) => setNewDiagramTitle(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={addDiagram} size="sm">Add</Button>
                  <Button 
                    onClick={() => setShowAddDiagram(false)} 
                    variant="outline" 
                    size="sm"
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Diagrams Grid */}
          <div className="grid gap-6 md:grid-cols-2">
            {diagrams.map((diagram) => (
              <Card key={diagram.id} className="relative">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{diagram.title}</CardTitle>
                      <p className="text-sm text-gray-600 mt-1">{diagram.description}</p>
                    </div>
                    {canEdit && (
                      <Button
                        onClick={() => removeDiagram(diagram.id)}
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <div 
                    className="w-full h-64 border rounded-lg overflow-hidden bg-gray-50"
                    dangerouslySetInnerHTML={{ __html: diagram.svg }}
                  />
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="editor" className="space-y-6">
          <Card className="h-[800px]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5" />
                Visual Architecture Editor
              </CardTitle>
            </CardHeader>
            <CardContent className="h-full p-0">
              <ArchitectureDiagramEditor
                projectId={projectId}
                diagramId="main"
                isEditing={canEdit}
                onSave={handleSaveDiagram}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}