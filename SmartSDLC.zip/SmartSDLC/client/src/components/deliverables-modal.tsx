import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { ExternalLink, Users, GitBranch, CheckCircle, Clock, User } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface Deliverable {
  id: number;
  projectId: number;
  name: string;
  description: string;
  status: string;
  assignedTo: string | null;
  assignedBy: number | null;
  jiraProjectKey: string | null;
  jiraEpicKey: string | null;
  createdAt: string;
  updatedAt: string;
}

interface UserStory {
  id: number;
  deliverableId: number;
  useCaseId: number;
  title: string;
  description: string;
  acceptanceCriteria: string;
  storyPoints: number | null;
  priority: string;
  status: string;
  jiraIssueKey: string | null;
  assignedTo: string | null;
  createdAt: string;
  updatedAt: string;
}

interface Project {
  id: number;
  name: string;
  approvalStatus: string;
}

interface DeliverablesModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project | null;
  currentRole: string;
}

function DeliverableCard({ 
  deliverable, 
  userStories, 
  onAssign, 
  currentRole 
}: { 
  deliverable: Deliverable; 
  userStories: UserStory[];
  onAssign: (deliverableId: number, assignedTo: string) => void;
  currentRole: string;
}) {
  const [selectedRole, setSelectedRole] = useState<string>("");
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "planning": return "bg-yellow-100 text-yellow-800";
      case "in_progress": return "bg-blue-100 text-blue-800";
      case "completed": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "critical": return "bg-red-100 text-red-800";
      case "high": return "bg-orange-100 text-orange-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const totalStoryPoints = userStories.reduce((sum, story) => sum + (story.storyPoints || 0), 0);
  const completedStoryPoints = userStories
    .filter(story => story.status === "completed")
    .reduce((sum, story) => sum + (story.storyPoints || 0), 0);
  const progressPercentage = totalStoryPoints > 0 ? (completedStoryPoints / totalStoryPoints) * 100 : 0;

  return (
    <Card className="mb-4">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              <GitBranch className="h-5 w-5" />
              {deliverable.name}
              {deliverable.jiraEpicKey && (
                <Badge variant="outline" className="ml-2">
                  <ExternalLink className="h-3 w-3 mr-1" />
                  {deliverable.jiraEpicKey}
                </Badge>
              )}
            </CardTitle>
            <CardDescription className="mt-1">
              {deliverable.description}
            </CardDescription>
          </div>
          <div className="flex flex-col items-end gap-2">
            <Badge className={getStatusColor(deliverable.status)}>
              {deliverable.status === "planning" && <Clock className="h-3 w-3 mr-1" />}
              {deliverable.status === "completed" && <CheckCircle className="h-3 w-3 mr-1" />}
              {deliverable.status.replace("_", " ").toUpperCase()}
            </Badge>
            {deliverable.assignedTo && (
              <Badge variant="secondary">
                <User className="h-3 w-3 mr-1" />
                {deliverable.assignedTo.replace("-", " ").toUpperCase()}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Progress ({completedStoryPoints}/{totalStoryPoints} story points)</span>
              <span className="text-sm text-gray-500">{Math.round(progressPercentage)}%</span>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </div>

          {currentRole === "scrum-master" && deliverable.status === "planning" && (
            <div className="flex gap-2">
              <Select value={selectedRole} onValueChange={setSelectedRole}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Assign to role..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="architect">Architect</SelectItem>
                  <SelectItem value="ui-designer">UI Designer</SelectItem>
                  <SelectItem value="developer">Developer</SelectItem>
                </SelectContent>
              </Select>
              <Button 
                onClick={() => selectedRole && onAssign(deliverable.id, selectedRole)}
                disabled={!selectedRole}
              >
                Assign
              </Button>
            </div>
          )}

          <div>
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <Users className="h-4 w-4" />
              User Stories ({userStories.length})
            </h4>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {userStories.map((story) => (
                <div key={story.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <div className="flex-1">
                    <div className="font-medium text-sm">{story.title}</div>
                    <div className="text-xs text-gray-500 flex items-center gap-2">
                      <Badge className={getPriorityColor(story.priority)} variant="outline">
                        {story.priority}
                      </Badge>
                      {story.storyPoints && (
                        <span>{story.storyPoints} pts</span>
                      )}
                      {story.jiraIssueKey && (
                        <Badge variant="outline" className="text-xs">
                          <ExternalLink className="h-2 w-2 mr-1" />
                          {story.jiraIssueKey}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <Badge className={getStatusColor(story.status)} variant="outline">
                    {story.status}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function DeliverablesModal({ isOpen, onClose, project, currentRole }: DeliverablesModalProps) {
  const [selectedTab, setSelectedTab] = useState("deliverables");
  const queryClient = useQueryClient();

  const { data: deliverables = [], isLoading: deliverablesLoading } = useQuery({
    queryKey: ['/api/projects', project?.id, 'deliverables'],
    enabled: !!project?.id && isOpen,
  });

  const { data: jiraSummary, isLoading: jiraLoading } = useQuery({
    queryKey: ['/api/jira/summary'],
    enabled: isOpen && currentRole === "scrum-master",
  });

  const userStoriesQueries = useQuery({
    queryKey: ['user-stories', deliverables.map(d => d.id)],
    queryFn: async () => {
      const stories = {};
      for (const deliverable of deliverables) {
        const response = await fetch(`/api/deliverables/${deliverable.id}/stories`);
        if (response.ok) {
          stories[deliverable.id] = await response.json();
        } else {
          stories[deliverable.id] = [];
        }
      }
      return stories;
    },
    enabled: deliverables.length > 0 && isOpen,
  });

  const assignMutation = useMutation({
    mutationFn: async ({ deliverableId, assignedTo }: { deliverableId: number; assignedTo: string }) => {
      return apiRequest(`/api/deliverables/${deliverableId}/assign`, {
        method: "POST",
        body: JSON.stringify({ assignedTo }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project?.id, 'deliverables'] });
      queryClient.invalidateQueries({ queryKey: ['/api/jira/summary'] });
    },
  });

  const handleAssign = (deliverableId: number, assignedTo: string) => {
    assignMutation.mutate({ deliverableId, assignedTo });
  };

  if (!project) return null;

  const totalDeliverables = deliverables.length;
  const completedDeliverables = deliverables.filter(d => d.status === "completed").length;
  const inProgressDeliverables = deliverables.filter(d => d.status === "in_progress").length;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitBranch className="h-5 w-5" />
            {project.name} - Deliverables & Jira Integration
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold">{totalDeliverables}</div>
                <div className="text-sm text-gray-500">Total Deliverables</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-blue-600">{inProgressDeliverables}</div>
                <div className="text-sm text-gray-500">In Progress</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-green-600">{completedDeliverables}</div>
                <div className="text-sm text-gray-500">Completed</div>
              </CardContent>
            </Card>
          </div>

          <Tabs value={selectedTab} onValueChange={setSelectedTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="deliverables">Deliverables & User Stories</TabsTrigger>
              <TabsTrigger value="jira">Jira Integration Status</TabsTrigger>
            </TabsList>

            <TabsContent value="deliverables" className="space-y-4">
              {deliverablesLoading ? (
                <div className="text-center py-8">Loading deliverables...</div>
              ) : deliverables.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No deliverables available. Project needs to be approved first.
                </div>
              ) : (
                <div>
                  {deliverables.map((deliverable) => (
                    <DeliverableCard
                      key={deliverable.id}
                      deliverable={deliverable}
                      userStories={userStoriesQueries.data?.[deliverable.id] || []}
                      onAssign={handleAssign}
                      currentRole={currentRole}
                    />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="jira" className="space-y-4">
              {currentRole !== "scrum-master" ? (
                <div className="text-center py-8 text-gray-500">
                  Jira integration view is only available for Scrum Masters.
                </div>
              ) : jiraLoading ? (
                <div className="text-center py-8">Loading Jira integration status...</div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-3">Jira Projects</h3>
                    <div className="space-y-2">
                      {jiraSummary?.projects?.map((project) => (
                        <Card key={project.key}>
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <div className="font-medium">{project.name}</div>
                                <div className="text-sm text-gray-500">Project Key: {project.key}</div>
                              </div>
                              <Badge variant="outline">
                                <ExternalLink className="h-3 w-3 mr-1" />
                                {project.projectTypeKey}
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="font-semibold mb-3">Jira Epics</h3>
                    <div className="space-y-2">
                      {jiraSummary?.epics?.map((epic) => (
                        <Card key={epic.key}>
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <div className="font-medium">{epic.summary}</div>
                                <div className="text-sm text-gray-500">{epic.key}</div>
                              </div>
                              <div className="flex gap-2">
                                <Badge className={getStatusColor(epic.status)}>
                                  {epic.status}
                                </Badge>
                                {epic.assignee && (
                                  <Badge variant="secondary">
                                    <User className="h-3 w-3 mr-1" />
                                    {epic.assignee}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="font-semibold mb-3">User Stories ({jiraSummary?.issues?.length || 0})</h3>
                    <div className="text-sm text-gray-600 mb-2">
                      Total story points: {jiraSummary?.issues?.reduce((sum, issue) => sum + (issue.storyPoints || 0), 0) || 0}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-60 overflow-y-auto">
                      {jiraSummary?.issues?.map((issue) => (
                        <Card key={issue.key} className="p-3">
                          <div className="space-y-1">
                            <div className="font-medium text-sm">{issue.summary}</div>
                            <div className="flex items-center gap-2 text-xs">
                              <Badge variant="outline">{issue.key}</Badge>
                              {issue.storyPoints && (
                                <span className="text-gray-500">{issue.storyPoints} pts</span>
                              )}
                              <Badge className={getStatusColor(issue.status)} variant="outline">
                                {issue.status}
                              </Badge>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function getStatusColor(status: string) {
  switch (status.toLowerCase()) {
    case "planning": 
    case "to do": 
      return "bg-yellow-100 text-yellow-800";
    case "in_progress": 
    case "in progress": 
      return "bg-blue-100 text-blue-800";
    case "completed": 
    case "done": 
      return "bg-green-100 text-green-800";
    default: 
      return "bg-gray-100 text-gray-800";
  }
}