
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AIChatAssistant } from "@/components/ai-chat-assistant";
import { useAuth } from "@/hooks/useAuth";
import Home from "@/pages/home";
import Dashboard from "@/pages/dashboard";
import ProjectDetails from "@/pages/project-details";
import ProjectArchitecture from "@/pages/project-architecture";
import NotFound from "@/pages/not-found";
import { PanelGroup, Panel, PanelResizeHandle } from "react-resizable-panels";

function Router() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Switch>
          <Route path="/" component={Home} />
          <Route component={NotFound} />
        </Switch>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gray-50">
      <PanelGroup direction="horizontal">
        {/* Main Content Panel */}
        <Panel defaultSize={75} minSize={50}>
          <div className="h-full overflow-auto">
            <Switch>
              <Route path="/" component={Dashboard} />
              <Route path="/dashboard" component={Dashboard} />
              <Route path="/projects/:id" component={ProjectDetails} />
              <Route path="/projects/:id/architecture" component={ProjectArchitecture} />
              <Route component={NotFound} />
            </Switch>
          </div>
        </Panel>
        
        {/* Resizable Handle */}
        <PanelResizeHandle className="w-2 bg-gray-300 hover:bg-blue-500 transition-colors cursor-col-resize flex items-center justify-center">
          <div className="w-1 h-8 bg-gray-600 rounded"></div>
        </PanelResizeHandle>
        
        {/* AI Assistant Panel */}
        <Panel defaultSize={25} minSize={20} maxSize={40}>
          <div className="h-full bg-white border-l border-gray-200 shadow-lg">
            <AIChatAssistant userRole={(user as any).currentRole || 'Business Analyst'} />
          </div>
        </Panel>
      </PanelGroup>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
