# Smart SDLC Platform - replit.md

## Overview

The Smart SDLC Platform is a comprehensive AI-powered enterprise software development lifecycle management system with multi-agent architecture. Each SDLC role is enhanced with context-aware AI assistants that automate workflows, collaborate with stakeholders, and provide intelligent recommendations throughout the development process. The system targets investment banking and financial services organizations to reduce SDLC costs by 60% and accelerate project delivery by 3x through intelligent automation and role-based AI collaboration.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type-safe development
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack Query v5 for server state and React hooks for local state
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Components**: Radix UI primitives with custom styling for accessibility and consistency

### Backend Architecture
- **Runtime**: Node.js 20 with Express.js framework
- **Language**: TypeScript for full-stack type safety
- **Data Storage**: File-based JSON storage for zero-dependency persistence
- **Session Management**: In-memory session handling with role-based access control
- **API Design**: RESTful endpoints with comprehensive validation using Zod schemas

### AI Integration
- **Primary AI Service**: AWS Bedrock with Claude 3 Sonnet model
- **Enhancement**: TensorFlow.js Node for BERT semantic enhancement
- **Use Cases**: Project requirement generation, business analysis, and regulatory compliance mapping
- **Optimization**: Intelligent caching for fast-track EMIR projects

## Technology Stack

### Frontend Architecture
- **React 18** with TypeScript for type-safe development
- **Tailwind CSS** + **shadcn/ui** component library with Radix UI primitives
- **Wouter** for lightweight client-side routing
- **TanStack Query v5** for server state management
- **Vite** for fast development and optimized builds

### Backend Architecture
- **Node.js 20** with Express.js framework
- **TypeScript** for full-stack type safety
- **File-based JSON storage** for zero-dependency persistence
- **Session management** with role-based access control
- **Zod schemas** for comprehensive API validation

### AI & Intelligence Layer
- **AWS Bedrock** with Claude 3 Sonnet model for primary AI services
- **TensorFlow.js Node** with BERT for semantic enhancement
- **7 Specialized AI Agents** for each SDLC role with contextual assistance
- **Intelligent caching** for fast-track EMIR projects

### Enterprise Architecture Components
- **Microservices**: Java Spring Boot, Python FastAPI, C# .NET Core
- **Databases**: PostgreSQL 15 + TimescaleDB, ClickHouse, MongoDB
- **Caching & Messaging**: Redis 7 Cluster, Apache Kafka + Zookeeper
- **Security**: OAuth 2.0 + JWT, multi-factor authentication
- **API Management**: Kong, NGINX + HAProxy, AWS API Gateway
- **Monitoring**: Prometheus + Grafana, ELK Stack, Jaeger + OpenTelemetry

### Key Components

### Multi-Agent AI Architecture
- **7 Specialized AI Agents**: Each SDLC role enhanced with context-aware AI assistants
- **Role-Based Intelligence**: Business Analyst, Product Owner, Scrum Master, Architect, UI Designer, Developer, and DevOps agents
- **Contextual Assistance**: AI agents provide role-specific recommendations, task automation, and workflow guidance
- **Intelligent Collaboration**: Cross-role coordination through AI-powered handoffs and dependency management

### Authentication & Authorization
- **Role-Based Access Control**: Support for 7 primary SDLC roles with AI agent enhancement
- **Session Management**: Secure session handling with role switching capabilities
- **Permission System**: Role-specific UI and functionality access with AI assistant integration

### Project Management
- **Project Types**: Web applications, mobile apps, API development, data analytics, and financial services platforms
- **Status Tracking**: Draft, Planning, Development, On Hold, Completed, In Review
- **Approval Workflow**: Business Analyst creation → Product Owner approval/rejection flow
- **Fast-Track Templates**: Pre-configured EMIR reporting and reconciliation projects

### AI-Powered Features
- **Multi-Agent Intelligence**: 7 specialized AI agents providing role-specific assistance and automation
- **Requirement Generation**: Automated creation of 8-12 functional and 5-7 non-functional requirements
- **Regulatory Compliance**: Automatic mapping to Basel III, MiFID II, and EMIR regulations
- **Project Analysis**: Real-time business requirement validation and completeness checking
- **Use Case Creation**: Intelligent suggestion of user stories and acceptance criteria
- **Agent Coordination**: Cross-role workflow automation and intelligent handoffs

### Use Case Management
- **Comprehensive Tracking**: Functional and non-functional requirements with detailed specifications
- **Priority Management**: Critical, High, Medium, Low priority classification
- **Status Workflow**: Draft → In Review → Approved progression
- **Regulatory Integration**: Automatic compliance validation and audit trail creation

## Data Flow

### Project Creation Flow
1. **User Input**: Business Analyst provides project description via AI Chat or Create Project form
2. **AI Processing**: AWS Bedrock analyzes requirements and generates comprehensive project plan
3. **BERT Enhancement**: TensorFlow.js applies semantic analysis for financial domain refinement
4. **Storage**: Project and use cases saved to file-based JSON storage
5. **Workflow Initiation**: Project enters draft status awaiting approval

### Approval Workflow
1. **Submission**: Business Analyst submits project for approval
2. **Review**: Product Owner receives notification and reviews project details
3. **Decision**: Approve for development or request modifications
4. **Status Update**: Real-time status propagation across all stakeholders
5. **Audit Trail**: Complete history tracking for compliance purposes

### AI Chat Integration
1. **Role Detection**: System identifies user role and provides appropriate prompts
2. **Context Analysis**: Natural language processing of user requirements
3. **AI Generation**: AWS Bedrock creates detailed project specifications
4. **Fast-Track Logic**: EMIR projects use cached templates for sub-second response
5. **Response Enhancement**: BERT refinement for financial terminology accuracy

## External Dependencies

### Cloud Services
- **AWS Bedrock**: Primary AI service for requirement generation and analysis
- **AWS Region**: us-east-1 for optimal performance and compliance

### Development Dependencies
- **Radix UI**: Accessible component primitives for consistent user experience
- **Framer Motion**: Animation library for smooth transitions and interactions
- **React Hook Form**: High-performance form handling with validation
- **Date-fns**: Date manipulation and formatting utilities

### Build and Development Tools
- **ESBuild**: Ultra-fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer for cross-browser compatibility
- **TypeScript**: Static type checking across frontend and backend
- **Drizzle ORM**: Database toolkit prepared for future PostgreSQL integration

## Deployment Strategy

### Environment Configuration
- **Development**: File-based storage with hot module replacement via Vite
- **Production**: Optimized builds with static asset serving via Express
- **Scaling**: Prepared for database migration using Drizzle ORM configuration

### Platform Support
- **Primary**: Replit deployment with autoscale capability
- **Alternative**: AWS EC2 or Windows server deployment guides available
- **Port Configuration**: Application runs on port 5000 with external port 80 mapping

### Security Considerations
- **Environment Variables**: AWS credentials and configuration via environment variables
- **CORS Protection**: Cross-origin request security middleware
- **Input Validation**: Comprehensive Zod schema validation for all API endpoints
- **Session Security**: Secure cookie handling and session management

## Changelog

- June 20, 2025: Implemented comprehensive multi-agent AI architecture with 7 specialized AI assistants for each SDLC role
- June 19, 2025: Enhanced approval workflow with automatic Jira deliverable generation and Scrum Master assignment capabilities
- June 17, 2025: Initial setup with AWS Bedrock integration and role-based access control

## Recent Changes

- **Comprehensive Architecture Tab**: Implemented extensive architecture documentation with 6 major sections including architecture overview, system architecture, C4 model diagrams, technology stack, AWS Well-Architected Framework compliance, and deployment strategy
- **Advanced Architecture Diagrams**: Added Context Diagram (C4 Level 1), Container Diagram (C4 Level 2), and detailed AWS Deployment Diagram with Mermaid syntax support for visualization and editing
- **Enterprise Technology Stack**: Detailed categorization of 40+ technologies across Frontend, Backend/API, AI Agents, Data Storage, Infrastructure, CI/CD, Observability, and Security layers with rationale for each choice
- **AWS Well-Architected Integration**: Complete scorecard implementation for all 6 pillars (Operational Excellence, Security, Reliability, Performance Efficiency, Cost Optimization, Sustainability) with detailed justifications
- **Product Owner Auto-Approval Flow**: Direct project creation for Product Owners with automatic approval for technical projects (migrations, infrastructure, deployments) bypassing Business Analyst review
- **Product Owner Approval Flow**: When Product Owner clicks "Approve", projects automatically move to "Approved for Development" status and appear in Development section with clear product catalog visibility
- **Enterprise SDLC Integration**: Projects are now active in Scrum Master view after Product Owner approval, enabling proper development phase management
- **11-Stage Project Lifecycle**: Implemented comprehensive project status workflow: Draft → Pending Review → Approved for Development/Needs Work → Planning → Architecture → Ready for Development → In Development → In Integration Test → In UAT → Production Readiness → Promoted to Prod
- **Multi-Agent Framework**: Created specialized AI agents for Business Analyst, Product Owner, Scrum Master, Architect, UI Designer, Developer, and DevOps roles

## User Preferences

Preferred communication style: Simple, everyday language.