# Smart SDLC - Local Development

## Quick Start

1. **Download the entire project**
2. **Extract to your desired folder**
3. **Run the batch file:**
   ```cmd
   start-local-dev.bat
   ```
4. **Open:** http://localhost:5000

## Manual Setup

If you prefer manual setup:

```cmd
# Install dependencies
npm install

# Set environment variables
set NODE_ENV=development
set PORT=5000
set AWS_ACCESS_KEY_ID=your_aws_access_key_here
set AWS_SECRET_ACCESS_KEY=your_aws_secret_key_here
set AWS_REGION=us-east-1

# Run development server
npx tsx server/index.ts
```

## Features

- **AI-powered Business Analyst Dashboard**
- **Real-time Chat with AWS Bedrock integration**
- **Project Management with dynamic updates**
- **ServiceNow integration capabilities**
- **File-based storage (no database required)**

## Requirements

- Node.js 18+ (tested with Node.js 20)
- Valid AWS credentials for Bedrock AI features

## AWS Configuration

Edit the AWS credentials in `start-local-dev.bat` or set them manually:
- AWS_ACCESS_KEY_ID
- AWS_SECRET_ACCESS_KEY  
- AWS_REGION (default: us-east-1)

## Port Configuration

The application runs on port 5000 by default. You can change this by modifying the PORT variable in:
- `start-local-dev.bat`
- Or set `PORT=your_port` environment variable

## Development Mode

The application runs in development mode with:
- Hot reload enabled
- Detailed error logging
- Full TypeScript support
- Vite development server for frontend assets