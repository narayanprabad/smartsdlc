import { formatDistanceToNow } from "date-fns";
import { Bot, User } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import type { ChatMessage } from "@shared/schema";

interface MessageProps {
  message: ChatMessage;
}

export default function Message({ message }: MessageProps) {
  const isUser = message.role === "user";
  const isAssistant = message.role === "assistant";

  if (isUser) {
    return (
      <div className="flex items-start space-x-3 justify-end">
        <div className="flex-1 text-right">
          <Card className="inline-block bg-primary text-primary-foreground max-w-xs">
            <CardContent className="p-3">
              <p className="text-sm">{message.content}</p>
            </CardContent>
          </Card>
          <p className="text-xs text-slate-500 mt-1">
            {formatDistanceToNow(new Date(message.createdAt), { addSuffix: true })}
          </p>
        </div>
        <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
          <User className="w-3 h-3 text-primary" />
        </div>
      </div>
    );
  }

  if (isAssistant) {
    return (
      <div className="flex items-start space-x-3">
        <div className="w-6 h-6 bg-violet-100 rounded-full flex items-center justify-center flex-shrink-0">
          <Bot className="w-3 h-3 text-violet-600" />
        </div>
        <div className="flex-1">
          <Card className="bg-slate-100">
            <CardContent className="p-3">
              <p className="text-sm text-slate-900 whitespace-pre-wrap">{message.content}</p>
            </CardContent>
          </Card>
          <p className="text-xs text-slate-500 mt-1">
            {formatDistanceToNow(new Date(message.createdAt), { addSuffix: true })}
          </p>
        </div>
      </div>
    );
  }

  return null;
}
