import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bot, Settings, Send } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import Message from "./message";
import { useChat } from "@/hooks/use-chat";
import type { ChatMessage } from "@shared/schema";

interface ChatPanelProps {
  projectId: number;
}

export default function ChatPanel({ projectId }: ChatPanelProps) {
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { data: chatHistory = [] } = useQuery<ChatMessage[]>({
    queryKey: [`/api/projects/${projectId}/chat`],
  });

  const { messages, isConnected, sendMessage, isLoading } = useChat(projectId, chatHistory);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (message.trim() && !isLoading) {
      sendMessage(message);
      setMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const quickActions = [
    "Generate Use Cases",
    "Analyze Requirements", 
    "Create Documentation"
  ];

  return (
    <div className="w-96 bg-white border-l border-slate-200 flex flex-col">
      {/* Chat Header */}
      <CardHeader className="p-4 border-b border-slate-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-purple-600 rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">AI Assistant</h3>
              <div className="flex items-center space-x-1">
                <div className={`w-2 h-2 rounded-full ${isConnected ? "bg-emerald-500" : "bg-red-500"}`} />
                <p className={`text-xs ${isConnected ? "text-emerald-600" : "text-red-600"}`}>
                  {isConnected ? "Online" : "Offline"} • AWS Bedrock
                </p>
              </div>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-slate-600 p-2">
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-violet-100 rounded-full flex items-center justify-center flex-shrink-0">
              <Bot className="w-3 h-3 text-violet-600" />
            </div>
            <div className="flex-1">
              <Card className="bg-slate-100">
                <CardContent className="p-3">
                  <p className="text-sm text-slate-900">
                    Hi! I'm your AI assistant for SDLC automation. I can help you:
                  </p>
                  <ul className="text-sm text-slate-700 mt-2 space-y-1">
                    <li>• Generate use cases from requirements</li>
                    <li>• Analyze and categorize requirements</li>
                    <li>• Create documentation templates</li>
                    <li>• Suggest workflow improvements</li>
                  </ul>
                </CardContent>
              </Card>
              <p className="text-xs text-slate-500 mt-1">Just now</p>
            </div>
          </div>
        ) : (
          messages.map((msg) => (
            <Message key={msg.id} message={msg} />
          ))
        )}

        {/* Loading indicator */}
        {isLoading && (
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-violet-100 rounded-full flex items-center justify-center flex-shrink-0">
              <Bot className="w-3 h-3 text-violet-600" />
            </div>
            <div className="flex-1">
              <Card className="bg-slate-100">
                <CardContent className="p-3">
                  <div className="flex items-center space-x-2">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" />
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: "0.2s" }} />
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: "0.4s" }} />
                    </div>
                    <span className="text-xs text-slate-600">AI is analyzing...</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="p-4 border-t border-slate-200">
        <div className="flex items-end space-x-2">
          <div className="flex-1">
            <Textarea
              placeholder="Describe your requirement or ask for help..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              className="resize-none bg-slate-50 border border-slate-200 min-h-[60px]"
              disabled={!isConnected || isLoading}
            />
          </div>
          <Button
            onClick={handleSendMessage}
            disabled={!message.trim() || !isConnected || isLoading}
            className="flex-shrink-0"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-2 mt-3">
          {quickActions.map((action) => (
            <Badge
              key={action}
              variant="secondary"
              className="cursor-pointer hover:bg-slate-200 transition-colors text-xs bg-slate-100 text-slate-700"
              onClick={() => setMessage(action)}
            >
              {action}
            </Badge>
          ))}
        </div>
      </div>
    </div>
  );
}
