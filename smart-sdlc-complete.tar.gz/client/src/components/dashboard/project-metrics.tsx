import { FileText, Map, TrendingUp, Bot } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import type { Requirement, AiActivity } from "@shared/schema";

interface ProjectMetricsProps {
  projectId: number;
  requirements: Requirement[];
  aiActivities: AiActivity[];
}

export default function ProjectMetrics({ requirements, aiActivities }: ProjectMetricsProps) {
  const completedRequirements = requirements.filter(req => req.status === "completed").length;
  const aiGeneratedUseCases = aiActivities.filter(activity => 
    activity.type === "use_case_generation"
  ).reduce((total, activity) => {
    return total + (activity.metadata?.useCasesCount || 0);
  }, 0);

  const todayActivities = aiActivities.filter(activity => {
    const today = new Date();
    const activityDate = new Date(activity.createdAt);
    return activityDate.toDateString() === today.toDateString();
  }).length;

  const metrics = [
    {
      title: "Total Requirements",
      value: requirements.length,
      icon: FileText,
      iconColor: "text-blue-600",
      iconBg: "bg-blue-100",
      change: "+3 this week",
      changeColor: "text-emerald-600",
    },
    {
      title: "Use Cases Generated",
      value: aiGeneratedUseCases,
      icon: Map,
      iconColor: "text-violet-600",
      iconBg: "bg-violet-100",
      change: `AI Generated: ${aiGeneratedUseCases}`,
      changeColor: "text-emerald-600",
    },
    {
      title: "Workflow Progress",
      value: `${Math.round((completedRequirements / Math.max(requirements.length, 1)) * 100)}%`,
      icon: TrendingUp,
      iconColor: "text-emerald-600",
      iconBg: "bg-emerald-100",
      change: `${completedRequirements} of ${requirements.length} complete`,
      changeColor: "text-slate-600",
    },
    {
      title: "AI Interactions",
      value: aiActivities.length,
      icon: Bot,
      iconColor: "text-amber-600",
      iconBg: "bg-amber-100",
      change: `+${todayActivities} today`,
      changeColor: "text-emerald-600",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metrics.map((metric, index) => {
        const Icon = metric.icon;
        return (
          <Card key={index} className="border border-slate-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">{metric.title}</p>
                  <p className="text-3xl font-bold text-slate-900 mt-2">{metric.value}</p>
                </div>
                <div className={`w-12 h-12 ${metric.iconBg} rounded-lg flex items-center justify-center`}>
                  <Icon className={`${metric.iconColor} w-6 h-6`} />
                </div>
              </div>
              <div className="flex items-center mt-4 text-sm">
                <span className={`font-medium ${metric.changeColor}`}>{metric.change}</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
