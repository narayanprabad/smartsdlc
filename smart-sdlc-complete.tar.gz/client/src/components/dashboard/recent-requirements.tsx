import { formatDistanceToNow } from "date-fns";
import { ChevronRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Requirement } from "@shared/schema";

interface RecentRequirementsProps {
  requirements: Requirement[];
}

export default function RecentRequirements({ requirements }: RecentRequirementsProps) {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-700";
      case "medium":
        return "bg-amber-100 text-amber-700";
      case "low":
        return "bg-blue-100 text-blue-700";
      default:
        return "bg-slate-100 text-slate-700";
    }
  };

  const getPriorityDot = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500";
      case "medium":
        return "bg-amber-500";
      case "low":
        return "bg-blue-500";
      default:
        return "bg-slate-500";
    }
  };

  const recentRequirements = requirements.slice(0, 3);

  return (
    <Card className="border border-slate-200">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-slate-900">
            Recent Requirements
          </CardTitle>
          <Button variant="ghost" className="text-primary hover:text-primary/80">
            View All <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentRequirements.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <p>No requirements found</p>
              <p className="text-sm mt-1">Create your first requirement to get started</p>
            </div>
          ) : (
            recentRequirements.map((requirement) => (
              <div
                key={requirement.id}
                className="flex items-start space-x-3 p-3 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
              >
                <div className={`w-2 h-2 ${getPriorityDot(requirement.priority)} rounded-full mt-2 flex-shrink-0`} />
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-slate-900 truncate">{requirement.title}</h4>
                  <p className="text-sm text-slate-600 mt-1 line-clamp-2">{requirement.description}</p>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-slate-500">
                    <Badge variant="secondary" className={getPriorityColor(requirement.priority)}>
                      {requirement.priority.charAt(0).toUpperCase() + requirement.priority.slice(1)} Priority
                    </Badge>
                    <span>
                      {requirement.assigneeId ? `Assigned to: User ${requirement.assigneeId}` : "Unassigned"}
                    </span>
                    <span>{formatDistanceToNow(new Date(requirement.createdAt), { addSuffix: true })}</span>
                  </div>
                </div>
                <Button variant="ghost" size="sm" className="text-slate-400 hover:text-slate-600 p-1">
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
