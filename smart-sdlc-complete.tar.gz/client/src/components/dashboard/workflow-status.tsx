import { Check, Cog, Clock, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import type { Project } from "@shared/schema";

interface WorkflowStatusProps {
  project?: Project;
}

export default function WorkflowStatus({ project }: WorkflowStatusProps) {
  const phases = [
    {
      id: "requirements",
      title: "Requirements Gathering",
      description: "24 requirements documented, 18 use cases generated",
      status: "complete",
      progress: 100,
      icon: Check,
      iconColor: "text-emerald-600",
      iconBg: "bg-emerald-100",
    },
    {
      id: "design",
      title: "System Design",
      description: "Architecture diagrams and technical specifications",
      status: "in_progress",
      progress: 65,
      icon: Cog,
      iconColor: "text-blue-600",
      iconBg: "bg-blue-100",
    },
    {
      id: "implementation",
      title: "Implementation",
      description: "Development phase - starts after design approval",
      status: "pending",
      progress: 0,
      icon: Clock,
      iconColor: "text-slate-400",
      iconBg: "bg-slate-200",
    },
  ];

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "complete":
        return { label: "Complete", color: "text-emerald-600" };
      case "in_progress":
        return { label: "In Progress", color: "text-blue-600" };
      case "pending":
        return { label: "Pending", color: "text-slate-500" };
      default:
        return { label: "Unknown", color: "text-slate-500" };
    }
  };

  const getProgressColor = (status: string) => {
    switch (status) {
      case "complete":
        return "bg-emerald-500";
      case "in_progress":
        return "bg-blue-500";
      case "pending":
        return "bg-slate-300";
      default:
        return "bg-slate-300";
    }
  };

  return (
    <Card className="border border-slate-200 mb-8">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-slate-900">
            SDLC Workflow Status
          </CardTitle>
          <Button variant="ghost" className="text-primary hover:text-primary/80">
            View Details <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {phases.map((phase) => {
            const Icon = phase.icon;
            const statusInfo = getStatusLabel(phase.status);
            const progressColor = getProgressColor(phase.status);
            const isActive = phase.status === "in_progress";
            
            return (
              <div 
                key={phase.id}
                className={`flex items-center space-x-4 p-4 rounded-lg transition-all ${
                  phase.status === "pending" ? "bg-slate-50 opacity-60" : "bg-slate-50"
                }`}
              >
                <div className={`w-10 h-10 ${phase.iconBg} rounded-full flex items-center justify-center flex-shrink-0`}>
                  <Icon className={`${phase.iconColor} w-5 h-5 ${isActive ? "animate-spin" : ""}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-medium text-slate-900">{phase.title}</h4>
                    <span className={`text-sm font-medium ${statusInfo.color}`}>
                      {statusInfo.label}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">{phase.description}</p>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${progressColor}`}
                      style={{ width: `${phase.progress}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
