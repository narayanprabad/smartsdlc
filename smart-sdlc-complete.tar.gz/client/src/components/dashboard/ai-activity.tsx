import { formatDistanceToNow } from "date-fns";
import { Bot, Sparkles, FileText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { AiActivity } from "@shared/schema";

interface AiActivityProps {
  activities: AiActivity[];
}

export default function AiActivity({ activities }: AiActivityProps) {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "use_case_generation":
        return Bot;
      case "requirement_analysis":
        return Sparkles;
      case "documentation":
        return FileText;
      default:
        return Bot;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case "use_case_generation":
        return {
          bg: "bg-violet-50",
          iconBg: "bg-violet-100",
          iconColor: "text-violet-600",
          badgeColor: "bg-violet-100 text-violet-700",
        };
      case "requirement_analysis":
        return {
          bg: "bg-blue-50",
          iconBg: "bg-blue-100",
          iconColor: "text-blue-600",
          badgeColor: "bg-blue-100 text-blue-700",
        };
      case "documentation":
        return {
          bg: "bg-emerald-50",
          iconBg: "bg-emerald-100",
          iconColor: "text-emerald-600",
          badgeColor: "bg-emerald-100 text-emerald-700",
        };
      default:
        return {
          bg: "bg-slate-50",
          iconBg: "bg-slate-100",
          iconColor: "text-slate-600",
          badgeColor: "bg-slate-100 text-slate-700",
        };
    }
  };

  const getActivityLabel = (type: string) => {
    switch (type) {
      case "use_case_generation":
        return "AWS Bedrock";
      case "requirement_analysis":
        return "Analysis";
      case "documentation":
        return "Documentation";
      default:
        return "AI";
    }
  };

  const recentActivities = activities.slice(0, 3);

  return (
    <Card className="border border-slate-200">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-slate-900">AI Activity</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            <span className="text-sm text-emerald-600 font-medium">Active</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentActivities.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <Bot className="w-12 h-12 mx-auto mb-4 text-slate-300" />
              <p>No AI activity yet</p>
              <p className="text-sm mt-1">Start a conversation to see AI interactions</p>
            </div>
          ) : (
            recentActivities.map((activity) => {
              const Icon = getActivityIcon(activity.type);
              const colors = getActivityColor(activity.type);
              const label = getActivityLabel(activity.type);

              return (
                <div key={activity.id} className={`flex items-start space-x-3 p-3 ${colors.bg} rounded-lg`}>
                  <div className={`w-8 h-8 ${colors.iconBg} rounded-full flex items-center justify-center flex-shrink-0`}>
                    <Icon className={`${colors.iconColor} w-4 h-4`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-slate-900 capitalize">
                      {activity.type.replace("_", " ")}
                    </h4>
                    <p className="text-sm text-slate-600 mt-1">{activity.description}</p>
                    <div className="flex items-center space-x-2 mt-2">
                      <Badge variant="secondary" className={`text-xs ${colors.badgeColor}`}>
                        {label}
                      </Badge>
                      <span className="text-xs text-slate-500">
                        {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
