import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { User, LogOut, Settings, Building2, Users, Briefcase } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { User as UserType } from "@shared/schema";

interface SmartHeaderProps {
  onLogout?: () => void;
}

export default function SmartHeader({ onLogout }: SmartHeaderProps) {
  const { data: user } = useQuery<UserType>({
    queryKey: ["/api/users/1"],
  });

  const getRoleDisplayName = (role: string) => {
    switch (role) {
      case "business_analyst":
        return "Business Analyst";
      case "business_user":
        return "Business User";
      default:
        return role.charAt(0).toUpperCase() + role.slice(1);
    }
  };

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case "business_analyst":
        return "default";
      case "business_user":
        return "secondary";
      default:
        return "outline";
    }
  };

  return (
    <header className="border-b bg-white dark:bg-gray-900 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Smart SDLC Logo */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">S</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">Smart SDLC</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">Enterprise Lifecycle Management</p>
            </div>
          </div>
        </div>

        {/* User Profile */}
        {user && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-auto px-3 space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.profileImage || undefined} alt={user.username} />
                  <AvatarFallback className="bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300">
                    {user.initials}
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col items-start">
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    {user.username}
                  </span>
                  <div className="flex items-center space-x-1">
                    <Badge variant={getRoleBadgeVariant(user.role)} className="text-xs px-1 py-0">
                      {getRoleDisplayName(user.role)}
                    </Badge>
                  </div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-64" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-2">
                  <p className="text-sm font-medium leading-none">{user.username}</p>
                  <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                  <div className="flex items-center space-x-2 pt-1">
                    <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                      <Users className="h-3 w-3" />
                      <span>{user.servicenowGroup}</span>
                    </div>
                  </div>
                  {user.department && (
                    <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                      <Building2 className="h-3 w-3" />
                      <span>{user.department}</span>
                    </div>
                  )}
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuGroup>
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Briefcase className="mr-2 h-4 w-4" />
                  <span>ServiceNow Dashboard</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
              </DropdownMenuGroup>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
    </header>
  );
}