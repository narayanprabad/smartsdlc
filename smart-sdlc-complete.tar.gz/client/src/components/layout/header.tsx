import { Bell, Settings } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface HeaderProps {
  currentRole: string;
  onRoleChange: (role: string) => void;
}

export default function Header({ currentRole, onRoleChange }: HeaderProps) {
  const roleLabels = {
    pm: "Product Manager",
    developer: "Developer",
    qa: "QA Engineer",
    stakeholder: "Stakeholder",
  };

  return (
    <header className="bg-white border-b border-slate-200 fixed top-0 left-0 right-0 z-50">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-violet-600 rounded-lg flex items-center justify-center">
                <i className="fas fa-rocket text-white text-sm"></i>
              </div>
              <h1 className="text-xl font-semibold text-slate-900">SmartSDLC</h1>
            </div>
            
            {/* Role Switcher */}
            <div className="flex items-center space-x-2 ml-8">
              <span className="text-sm text-slate-600">Role:</span>
              <Select value={currentRole} onValueChange={onRoleChange}>
                <SelectTrigger className="w-[180px] bg-slate-100 border-0">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pm">Product Manager</SelectItem>
                  <SelectItem value="developer">Developer</SelectItem>
                  <SelectItem value="qa">QA Engineer</SelectItem>
                  <SelectItem value="stakeholder">Stakeholder</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* AI Status Indicator */}
            <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse mr-2"></div>
              AWS Bedrock Connected
            </Badge>
            
            {/* Notifications */}
            <button className="relative p-2 text-slate-400 hover:text-slate-600 transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                3
              </span>
            </button>
            
            {/* User Profile */}
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">JD</span>
              </div>
              <div className="text-sm">
                <div className="font-medium text-slate-900">John Doe</div>
                <div className="text-slate-500">john@company.com</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
