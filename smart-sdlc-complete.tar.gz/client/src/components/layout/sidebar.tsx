import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { 
  ChartLine, 
  MessageCircle, 
  FileText, 
  Map, 
  Workflow, 
  Calendar, 
  Download,
  Sparkles
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Project, Requirement, UseCase } from "@shared/schema";

interface SidebarProps {
  selectedProjectId: number;
}

export default function Sidebar({ selectedProjectId }: SidebarProps) {
  const [location] = useLocation();

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: requirements = [] } = useQuery<Requirement[]>({
    queryKey: [`/api/projects/${selectedProjectId}/requirements`],
  });

  const { data: useCases = [] } = useQuery<UseCase[]>({
    queryKey: [`/api/projects/${selectedProjectId}/use-cases`],
  });

  const currentProject = projects.find(p => p.id === selectedProjectId);

  const navigationItems = [
    {
      path: "/dashboard",
      icon: ChartLine,
      label: "Dashboard",
      count: null,
    },
    {
      path: "/chat",
      icon: MessageCircle,
      label: "AI Chat",
      count: null,
      badge: "AI",
      badgeVariant: "secondary" as const,
    },
    {
      path: "/requirements",
      icon: FileText,
      label: "Requirements",
      count: requirements.length,
    },
    {
      path: "/use-cases",
      icon: Map,
      label: "Use Cases",
      count: useCases.length,
    },
    {
      path: "/workflows",
      icon: Workflow,
      label: "Workflows",
      count: null,
    },
    {
      path: "/timeline",
      icon: Calendar,
      label: "Timeline",
      count: null,
    },
    {
      path: "/export",
      icon: Download,
      label: "Export",
      count: null,
    },
  ];

  return (
    <nav className="w-64 bg-white border-r border-slate-200 flex flex-col">
      <div className="p-4">
        {/* Project Selector */}
        <div className="mb-6">
          <label className="block text-xs font-medium text-slate-500 uppercase tracking-wide mb-2">
            Current Project
          </label>
          <Select value={selectedProjectId.toString()}>
            <SelectTrigger className="w-full bg-slate-50 border border-slate-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Navigation Menu */}
        <nav className="space-y-1">
          {navigationItems.map((item) => {
            const isActive = location === item.path || (item.path === "/dashboard" && location === "/");
            const Icon = item.icon;
            
            return (
              <Link key={item.path} href={item.path}>
                <div className={`flex items-center space-x-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                  isActive 
                    ? "bg-primary/10 text-primary" 
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                }`}>
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {item.badge && (
                    <Badge 
                      variant={item.badgeVariant} 
                      className="ml-auto bg-violet-100 text-violet-700 text-xs"
                    >
                      {item.badge}
                    </Badge>
                  )}
                  {item.count !== null && (
                    <Badge variant="secondary" className="ml-auto bg-slate-100 text-slate-600 text-xs">
                      {item.count}
                    </Badge>
                  )}
                </div>
              </Link>
            );
          })}
        </nav>
      </div>
      
      {/* Quick Actions */}
      <div className="mt-auto p-4 border-t border-slate-200">
        <Button className="w-full bg-gradient-to-r from-primary to-violet-600 hover:from-primary/90 hover:to-violet-600/90">
          <Sparkles className="w-4 h-4 mr-2" />
          Generate Use Cases
        </Button>
      </div>
    </nav>
  );
}
