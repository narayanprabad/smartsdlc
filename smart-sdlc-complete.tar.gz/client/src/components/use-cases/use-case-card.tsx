import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bot, User, Plus, Download } from "lucide-react";
import type { UseCase } from "@shared/schema";

interface UseCaseCardProps {
  useCase: UseCase;
  onAddToProject?: () => void;
  onExport?: () => void;
}

export default function UseCaseCard({ useCase, onAddToProject, onExport }: UseCaseCardProps) {
  return (
    <Card className="border border-slate-200 hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <CardTitle className="text-sm font-medium text-slate-900">
            {useCase.title}
          </CardTitle>
          <Badge variant={useCase.isAiGenerated ? "secondary" : "outline"} className="ml-2">
            {useCase.isAiGenerated ? (
              <>
                <Bot className="w-3 h-3 mr-1" />
                AI Generated
              </>
            ) : (
              <>
                <User className="w-3 h-3 mr-1" />
                Manual
              </>
            )}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div>
            <p className="text-xs font-medium text-slate-600 uppercase tracking-wide">Actor</p>
            <p className="text-sm text-slate-900 mt-1">{useCase.actor}</p>
          </div>

          <div>
            <p className="text-xs font-medium text-slate-600 uppercase tracking-wide">Description</p>
            <p className="text-sm text-slate-700 mt-1 line-clamp-2">{useCase.description}</p>
          </div>

          {useCase.preconditions && (
            <div>
              <p className="text-xs font-medium text-slate-600 uppercase tracking-wide">Preconditions</p>
              <p className="text-sm text-slate-700 mt-1">{useCase.preconditions}</p>
            </div>
          )}

          <div>
            <p className="text-xs font-medium text-slate-600 uppercase tracking-wide">Steps</p>
            <ol className="text-sm text-slate-700 mt-1 space-y-1">
              {useCase.steps.slice(0, 3).map((step, index) => (
                <li key={index} className="flex">
                  <span className="text-slate-500 mr-2">{index + 1}.</span>
                  <span className="flex-1">{step}</span>
                </li>
              ))}
              {useCase.steps.length > 3 && (
                <li className="text-slate-500 text-xs">
                  +{useCase.steps.length - 3} more steps...
                </li>
              )}
            </ol>
          </div>

          {useCase.postconditions && (
            <div>
              <p className="text-xs font-medium text-slate-600 uppercase tracking-wide">Postconditions</p>
              <p className="text-sm text-slate-700 mt-1">{useCase.postconditions}</p>
            </div>
          )}
        </div>

        {(onAddToProject || onExport) && (
          <div className="flex items-center space-x-2 mt-4 pt-3 border-t border-slate-200">
            {onAddToProject && (
              <Button size="sm" variant="default" onClick={onAddToProject}>
                <Plus className="w-3 h-3 mr-1" />
                Add to Project
              </Button>
            )}
            {onExport && (
              <Button size="sm" variant="outline" onClick={onExport}>
                <Download className="w-3 h-3 mr-1" />
                Export
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
