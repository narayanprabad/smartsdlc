import { useState, useEffect, useCallback } from "react";
import { io, type Socket } from "socket.io-client";
import type { ChatMessage } from "@shared/schema";

export function useChat(projectId: number, initialMessages: ChatMessage[] = []) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [isLoading, setIsLoading] = useState(false);

  // Load chat history when projectId changes
  useEffect(() => {
    const loadChatHistory = async () => {
      try {
        const response = await fetch(`/api/projects/${projectId}/chat`);
        if (response.ok) {
          const chatHistory = await response.json();
          setMessages(chatHistory);
        }
      } catch (error) {
        console.error("Failed to load chat history:", error);
      }
    };

    loadChatHistory();
  }, [projectId]);

  useEffect(() => {
    const newSocket = io({
      transports: ["websocket", "polling"],
    });

    newSocket.on("connect", () => {
      setIsConnected(true);
      newSocket.emit("join-project", projectId);
    });

    newSocket.on("disconnect", () => {
      setIsConnected(false);
    });

    newSocket.on("new-message", (message: ChatMessage) => {
      setMessages((prev) => [...prev, message]);
      if (message.role === "assistant") {
        setIsLoading(false);
      }
    });

    newSocket.on("project-created", () => {
      // Reload chat history when a new project is created
      const loadChatHistory = async () => {
        try {
          const response = await fetch(`/api/projects/${projectId}/chat`);
          if (response.ok) {
            const chatHistory = await response.json();
            setMessages(chatHistory);
          }
        } catch (error) {
          console.error("Failed to reload chat history:", error);
        }
      };
      loadChatHistory();
    });

    newSocket.on("chat-error", (error: { message: string }) => {
      console.error("Chat error:", error.message);
      setIsLoading(false);
    });

    setSocket(newSocket);

    return () => {
      newSocket.close();
    };
  }, [projectId]);

  const sendMessage = useCallback((content: string) => {
    if (socket && isConnected && content.trim()) {
      setIsLoading(true);
      socket.emit("send-message", {
        content,
        projectId,
        userId: 1, // Default user for now
      });
    }
  }, [socket, isConnected, projectId]);

  return {
    messages,
    isConnected,
    sendMessage,
    isLoading,
  };
}
