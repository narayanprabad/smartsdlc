import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import ProjectMetrics from "@/components/dashboard/project-metrics";
import WorkflowStatus from "@/components/dashboard/workflow-status";
import RecentRequirements from "@/components/dashboard/recent-requirements";
import AiActivity from "@/components/dashboard/ai-activity";
import ChatPanel from "@/components/chat/chat-panel";
import { Button } from "@/components/ui/button";
import { Download, Plus } from "lucide-react";
import type { Project, Requirement, AiActivity as AiActivityType } from "@shared/schema";

export default function Dashboard() {
  const [selectedProjectId] = useState(1); // Default project for now
  const [currentUserRole, setCurrentUserRole] = useState("pm");

  const { data: project } = useQuery<Project>({
    queryKey: [`/api/projects/${selectedProjectId}`],
  });

  const { data: requirements = [] } = useQuery<Requirement[]>({
    queryKey: [`/api/projects/${selectedProjectId}/requirements`],
  });

  const { data: aiActivities = [] } = useQuery<AiActivityType[]>({
    queryKey: [`/api/projects/${selectedProjectId}/ai-activities`],
  });

  const handleRoleChange = (role: string) => {
    setCurrentUserRole(role);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header currentRole={currentUserRole} onRoleChange={handleRoleChange} />
      
      <div className="flex h-screen pt-20">
        <Sidebar selectedProjectId={selectedProjectId} />
        
        {/* Main Content */}
        <main className="flex-1 overflow-hidden flex">
          <div className="flex-1 overflow-y-auto">
            <div className="p-6">
              {/* Page Header */}
              <div className="mb-8">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">Project Dashboard</h2>
                    <p className="text-slate-600 mt-1">
                      {project?.name || "Loading..."} - Sprint 3
                    </p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Button variant="outline" className="flex items-center space-x-2">
                      <Download className="w-4 h-4" />
                      <span>Export Reports</span>
                    </Button>
                    <Button className="flex items-center space-x-2">
                      <Plus className="w-4 h-4" />
                      <span>New Requirement</span>
                    </Button>
                  </div>
                </div>
              </div>

              {/* Key Metrics */}
              <ProjectMetrics 
                projectId={selectedProjectId}
                requirements={requirements}
                aiActivities={aiActivities}
              />

              {/* Workflow Status */}
              <WorkflowStatus project={project} />

              {/* Bottom Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <RecentRequirements requirements={requirements} />
                <AiActivity activities={aiActivities} />
              </div>
            </div>
          </div>

          {/* Chat Panel */}
          <ChatPanel projectId={selectedProjectId} />
        </main>
      </div>
    </div>
  );
}
