import { useState, useEffect, useRef } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, FileText, Bot, Upload, Send, Trash2, Users, Building, Plus } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import type { Project, UseCase } from "@shared/schema";
import { useChat } from "@/hooks/use-chat";
import SmartHeader from "@/components/layout/smart-header";
import SubmitProjectDialog from "@/components/project/submit-project-dialog";
import io from "socket.io-client";

export default function BusinessAnalyst() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [message, setMessage] = useState("");
  const queryClient = useQueryClient();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const createProject = useMutation({
    mutationFn: async (projectData: { name: string; description: string }) => {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(projectData),
      });
      if (!response.ok) {
        throw new Error("Failed to create project");
      }
      return response.json();
    },
    onSuccess: (newProject) => {
      // Update the cache with the new project
      queryClient.setQueryData(["/api/projects"], (oldProjects: any[]) => {
        return [...(oldProjects || []), newProject];
      });
      // Set the new project as selected to show its details
      setSelectedProject(newProject);
    },
    onError: (error) => {
      console.error("Failed to create project:", error);
    },
  });

  // Set up socket connection for real-time project updates
  useEffect(() => {
    const socket = io();
    
    socket.on("project-created", () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
    });

    return () => {
      socket.disconnect();
    };
  }, [queryClient]);

  const { data: useCases = [] } = useQuery<UseCase[]>({
    queryKey: [`/api/projects/${selectedProject?.id}/use-cases`],
    enabled: !!selectedProject,
  });

  const { messages, isConnected, sendMessage, isLoading } = useChat(selectedProject?.id || 1, []);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (message.trim() && !isLoading) {
      sendMessage(message);
      setMessage("");
    }
  };

  const handleDeleteProject = async (projectId: number) => {
    try {
      const response = await fetch(`/api/projects/${projectId}`, {
        method: "DELETE",
      });
      if (response.ok) {
        queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
        if (selectedProject?.id === projectId) {
          setSelectedProject(null);
        }
      }
    } catch (error) {
      console.error("Failed to delete project:", error);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (selectedProject) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        {/* Header */}
        <div className="bg-white border-b shadow-sm">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                onClick={() => setSelectedProject(null)}
                className="flex items-center space-x-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Projects</span>
              </Button>
              <div className="h-6 w-px bg-slate-300" />
              <div>
                <h1 className="text-2xl font-bold text-slate-900">{selectedProject.name}</h1>
                <p className="text-slate-600">{selectedProject.description}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100vh-120px)]">
          {/* Use Cases Section */}
          <div className="flex flex-col">
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Use Cases</h2>
              <p className="text-slate-600">AI-generated use cases for this project</p>
            </div>
            
            <div className="flex-1 overflow-y-auto space-y-4">
              {useCases.length === 0 ? (
                <Card className="border-dashed border-2 border-slate-200">
                  <CardContent className="p-8 text-center">
                    <FileText className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-slate-900 mb-2">No Use Cases Yet</h3>
                    <p className="text-slate-600 mb-4">Use the AI Assistant to generate use cases for this project</p>
                    <Button onClick={() => setMessage("Generate use cases for " + selectedProject.name)}>
                      Generate Use Cases
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                useCases.map((useCase) => (
                  <Card key={useCase.id} className="border border-slate-200 hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-base font-medium text-slate-900">
                          {useCase.title}
                        </CardTitle>
                        {useCase.isAiGenerated && (
                          <Badge variant="secondary" className="bg-violet-100 text-violet-700">
                            <Bot className="w-3 h-3 mr-1" />
                            AI Generated
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    
                    <CardContent className="pt-0">
                      <div className="space-y-3">
                        <div>
                          <p className="text-xs font-medium text-slate-600 uppercase tracking-wide">Actor</p>
                          <p className="text-sm text-slate-900 mt-1">{useCase.actor}</p>
                        </div>

                        <div>
                          <p className="text-xs font-medium text-slate-600 uppercase tracking-wide">Description</p>
                          <p className="text-sm text-slate-700 mt-1">{useCase.description}</p>
                        </div>

                        <div>
                          <p className="text-xs font-medium text-slate-600 uppercase tracking-wide">Steps</p>
                          <ol className="text-sm text-slate-700 mt-1 space-y-1">
                            {useCase.steps.slice(0, 3).map((step, index) => (
                              <li key={index} className="flex">
                                <span className="text-slate-500 mr-2">{index + 1}.</span>
                                <span className="flex-1">{step}</span>
                              </li>
                            ))}
                            {useCase.steps.length > 3 && (
                              <li className="text-slate-500 text-xs">
                                +{useCase.steps.length - 3} more steps...
                              </li>
                            )}
                          </ol>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>

          {/* AI Assistant Section */}
          <div className="flex flex-col">
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-slate-900 mb-2">AI Assistant</h2>
              <p className="text-slate-600">Get help with requirements and use case generation</p>
            </div>
            
            <Card className="flex-1 flex flex-col border-0 shadow-lg">
              {/* Chat Header */}
              <CardHeader className="pb-4 border-b bg-gradient-to-r from-violet-500 to-purple-600 text-white rounded-t-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-semibold">AI Assistant</h3>
                    <div className="flex items-center space-x-1">
                      <div className={`w-2 h-2 rounded-full ${isConnected ? "bg-green-300" : "bg-red-300"}`} />
                      <p className="text-sm opacity-90">
                        {isConnected ? "Online" : "Offline"} • AWS Bedrock
                      </p>
                    </div>
                  </div>
                </div>
              </CardHeader>

              {/* Chat Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
                {messages.length === 0 ? (
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-violet-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="w-4 h-4 text-violet-600" />
                    </div>
                    <div className="flex-1">
                      <Card className="bg-white border-violet-200">
                        <CardContent className="p-4">
                          <p className="text-sm text-slate-900 mb-2">
                            Hi! I'm your AI assistant for {selectedProject.name}. I can help you:
                          </p>
                          <ul className="text-sm text-slate-700 space-y-1">
                            <li>• Generate use cases from requirements</li>
                            <li>• Analyze project requirements</li>
                            <li>• Create documentation</li>
                            <li>• Answer questions about the project</li>
                            <li>• <strong>Create project from URL</strong> - Type "create project from this URL: [your-url]"</li>
                          </ul>
                          <div className="mt-3 p-2 bg-violet-50 rounded border border-violet-200">
                            <p className="text-xs text-violet-700">
                              💡 <strong>Tip:</strong> Send a message like "create project from this URL: https://example.com" 
                              to automatically generate a new project with requirements and use cases!
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                ) : (
                  messages.map((msg) => (
                    <div key={msg.id} className={`flex items-start space-x-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                      {msg.role === 'assistant' && (
                        <div className="w-8 h-8 bg-violet-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <Bot className="w-4 h-4 text-violet-600" />
                        </div>
                      )}
                      <div className={`flex-1 ${msg.role === 'user' ? 'text-right' : ''}`}>
                        <Card className={msg.role === 'user' ? 'bg-violet-500 text-white max-w-xs ml-auto' : 'bg-white'}>
                          <CardContent className="p-3">
                            <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  ))
                )}

                {isLoading && (
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-violet-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="w-4 h-4 text-violet-600" />
                    </div>
                    <Card className="bg-white">
                      <CardContent className="p-3">
                        <div className="flex items-center space-x-2">
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" />
                            <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: "0.2s" }} />
                            <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: "0.4s" }} />
                          </div>
                          <span className="text-xs text-slate-600">AI is thinking...</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>

              {/* Chat Input */}
              <div className="p-4 border-t bg-white rounded-b-lg">
                <div className="flex items-end space-x-3">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-shrink-0"
                    disabled={!isConnected}
                  >
                    <Upload className="w-4 h-4" />
                  </Button>
                  <div className="flex-1">
                    <Textarea
                      placeholder="Ask about requirements, generate use cases, or upload files..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      className="resize-none min-h-[60px] border-slate-200 focus:border-violet-400 focus:ring-violet-400"
                      disabled={!isConnected || isLoading}
                    />
                  </div>
                  <Button
                    onClick={handleSendMessage}
                    disabled={!message.trim() || !isConnected || isLoading}
                    className="flex-shrink-0 bg-violet-500 hover:bg-violet-600"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Projects Grid View with AI Assistant
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <SmartHeader />

      <div className="max-w-7xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Projects Section */}
        <div className="lg:col-span-2">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-semibold text-slate-900 mb-2">Projects</h2>
                <p className="text-slate-600">Select a project to view and manage its use cases</p>
              </div>
              <Button
                onClick={() => {
                  const name = prompt("Enter project name:");
                  if (name) {
                    const description = prompt("Enter project description:");
                    createProject.mutate({
                      name,
                      description: description || ""
                    });
                  }
                }}
                className="bg-violet-600 hover:bg-violet-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Project
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {projects.map((project) => {
              const getStatusColor = (phase: string) => {
                switch (phase) {
                  case 'completed': return 'bg-green-100 text-green-700';
                  case 'pending review': return 'bg-yellow-100 text-yellow-700';
                  case 'development': return 'bg-blue-100 text-blue-700';
                  case 'draft': return 'bg-gray-100 text-gray-700';
                  default: return 'bg-slate-100 text-slate-700';
                }
              };

              const isSelected = selectedProject?.id === project.id;
              const isNewProject = (project as Project).id > 11; // Highlight projects created after initial ones

              return (
                <Card 
                  key={project.id} 
                  className={`cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105 border-0 shadow-md ${
                    isSelected 
                      ? "ring-2 ring-violet-500 shadow-lg border-violet-200" 
                      : isNewProject
                      ? "ring-2 ring-green-400 shadow-lg animate-pulse"
                      : ""
                  }`}
                  onClick={() => setSelectedProject(project)}
                >
                  <CardHeader className="pb-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className={`text-lg font-semibold mb-2 ${
                          isSelected ? "text-violet-700" : "text-slate-900"
                        }`}>
                          {project.name}
                          {isNewProject && (
                            <Badge variant="secondary" className="ml-2 bg-green-100 text-green-800 text-xs animate-pulse">
                              NEW
                            </Badge>
                          )}
                        </CardTitle>
                        <Badge variant="secondary" className={getStatusColor(project.phase)}>
                          {project.phase}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-2">
                        {project.phase === 'draft' && (
                          <>
                            <SubmitProjectDialog project={project}>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => e.stopPropagation()}
                                className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                              >
                                <Send className="w-4 h-4" />
                              </Button>
                            </SubmitProjectDialog>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteProject(project.id);
                              }}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                        {project.assignedGroup && (
                          <div className="flex items-center space-x-1 text-xs text-slate-500">
                            <Building className="w-3 h-3" />
                            <span>{project.assignedGroup}</span>
                          </div>
                        )}
                        <div className="text-right">
                          <div className="text-2xl font-bold text-violet-600">{project.progress}%</div>
                          <div className="text-xs text-slate-500">Complete</div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    <p className="text-slate-600 mb-4 line-clamp-2">{project.description}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <FileText className="w-4 h-4 text-slate-400" />
                        <span className="text-sm text-slate-600">Use Cases</span>
                      </div>
                      <Button variant="ghost" size="sm" className="text-violet-600 hover:text-violet-700">
                        View Details →
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* AI Assistant Section */}
        <div className="lg:col-span-1">
          <div className="mb-6">
            <h2 className="text-2xl font-semibold text-slate-900 mb-2">AI Assistant</h2>
            <p className="text-slate-600">Get help with project planning and requirements</p>
          </div>
          
          <Card className="h-[600px] flex flex-col border-0 shadow-lg">
            {/* Chat Header */}
            <CardHeader className="pb-4 border-b bg-gradient-to-r from-violet-500 to-purple-600 text-white rounded-t-lg">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-semibold">AI Assistant</h3>
                  <div className="flex items-center space-x-1">
                    <div className={`w-2 h-2 rounded-full ${isConnected ? "bg-green-300" : "bg-red-300"}`} />
                    <p className="text-sm opacity-90">
                      {isConnected ? "Online" : "Offline"} • AWS Bedrock
                    </p>
                  </div>
                </div>
              </div>
            </CardHeader>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
              {messages.length === 0 ? (
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-violet-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-violet-600" />
                  </div>
                  <div className="flex-1">
                    <Card className="bg-white border-violet-200">
                      <CardContent className="p-4">
                        <p className="text-sm text-slate-900 mb-2">
                          Hi! I'm your AI assistant. I can help you:
                        </p>
                        <ul className="text-sm text-slate-700 space-y-1">
                          <li>• Analyze project requirements</li>
                          <li>• Generate use cases</li>
                          <li>• Create project documentation</li>
                          <li>• Review compliance requirements</li>
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              ) : (
                messages.map((msg) => (
                  <div key={msg.id} className={`flex items-start space-x-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                    {msg.role === 'assistant' && (
                      <div className="w-8 h-8 bg-violet-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <Bot className="w-4 h-4 text-violet-600" />
                      </div>
                    )}
                    <div className={`flex-1 ${msg.role === 'user' ? 'text-right' : ''}`}>
                      <Card className={msg.role === 'user' ? 'bg-violet-500 text-white max-w-xs ml-auto' : 'bg-white'}>
                        <CardContent className="p-3">
                          <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                ))
              )}
              
              {/* Scroll anchor */}
              <div ref={messagesEndRef} />

              {isLoading && (
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-violet-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-violet-600" />
                  </div>
                  <Card className="bg-white">
                    <CardContent className="p-3">
                      <div className="flex items-center space-x-2">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" />
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: "0.2s" }} />
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: "0.4s" }} />
                        </div>
                        <span className="text-xs text-slate-600">AI is thinking...</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>

            {/* Chat Input */}
            <div className="p-4 border-t bg-white rounded-b-lg">
              <div className="flex items-end space-x-3">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-shrink-0"
                  disabled={!isConnected}
                >
                  <Upload className="w-4 h-4" />
                </Button>
                <div className="flex-1">
                  <Textarea
                    placeholder="Ask about projects, generate requirements, or create use cases..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="resize-none min-h-[60px] border-slate-200 focus:border-violet-400 focus:ring-violet-400"
                    disabled={!isConnected || isLoading}
                  />
                </div>
                <Button
                  onClick={handleSendMessage}
                  disabled={!message.trim() || !isConnected || isLoading}
                  className="flex-shrink-0 bg-violet-500 hover:bg-violet-600"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}