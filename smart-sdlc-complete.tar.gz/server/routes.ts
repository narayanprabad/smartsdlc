import type { Express } from "express";
import { createServer, type Server } from "http";
import { Server as SocketServer } from "socket.io";
import { storage } from "./file-storage";
import { 
  insertProjectSchema, 
  insertRequirementSchema, 
  insertUseCaseSchema,
  insertChatMessageSchema,
  insertAiActivitySchema 
} from "@shared/schema";
import { z } from "zod";

// AWS Bedrock integration
import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";
import axios from "axios";
import * as cheerio from "cheerio";

const bedrockClient = new BedrockRuntimeClient({
  region: process.env.AWS_REGION || "us-east-1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "",
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const io = new SocketServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  // Users routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Projects routes
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjectsByUser(1); // Using default user for now
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      // Set default ownerId if not provided
      if (!projectData.ownerId) {
        projectData.ownerId = 1;
      }
      const project = await storage.createProject(projectData);
      res.status(201).json(project);
    } catch (error) {
      console.error("Project creation error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create project", error: error.message });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const deleted = await storage.deleteProject(projectId);
      
      if (!deleted) {
        return res.status(400).json({ message: "Project not found or cannot be deleted (only draft projects can be deleted)" });
      }
      
      res.json({ message: "Project deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Submit project for review
  app.post("/api/projects/:id/submit", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const { assignedGroup, notes } = req.body;
      
      const project = await storage.getProject(projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      // Only allow submission of draft projects
      if (project.phase !== "draft") {
        return res.status(400).json({ 
          message: "Only draft projects can be submitted for review" 
        });
      }
      
      const updatedProject = await storage.updateProject(projectId, {
        phase: "pending review",
        assignedGroup,
        submittedAt: new Date(),
      });
      
      if (updatedProject) {
        // Log the submission activity
        await storage.createAiActivity({
          type: "project_submitted",
          description: `Project submitted to ${assignedGroup} for review${notes ? `: ${notes}` : ''}`,
          projectId,
          userId: 1,
          metadata: { assignedGroup, notes },
        });
        
        res.json(updatedProject);
      } else {
        res.status(404).json({ message: "Project not found" });
      }
    } catch (error) {
      console.error("Error submitting project:", error);
      res.status(500).json({ message: "Failed to submit project" });
    }
  });

  // Requirements routes
  app.get("/api/projects/:projectId/requirements", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const requirements = await storage.getRequirementsByProject(projectId);
      res.json(requirements);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch requirements" });
    }
  });

  app.post("/api/projects/:projectId/requirements", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const requirementData = insertRequirementSchema.parse(req.body);
      requirementData.projectId = projectId;
      const requirement = await storage.createRequirement(requirementData);
      res.status(201).json(requirement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid requirement data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create requirement" });
    }
  });

  // Use cases routes
  app.get("/api/projects/:projectId/use-cases", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const useCases = await storage.getUseCasesByProject(projectId);
      res.json(useCases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch use cases" });
    }
  });

  app.get("/api/requirements/:requirementId/use-cases", async (req, res) => {
    try {
      const requirementId = parseInt(req.params.requirementId);
      const useCases = await storage.getUseCasesByRequirement(requirementId);
      res.json(useCases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch use cases" });
    }
  });

  // Chat messages routes
  app.get("/api/projects/:projectId/chat", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const messages = await storage.getChatMessagesByProject(projectId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  // AI Activities routes
  app.get("/api/projects/:projectId/ai-activities", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const activities = await storage.getAiActivitiesByProject(projectId);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch AI activities" });
    }
  });

  // AI Generate Use Cases endpoint
  app.post("/api/ai/generate-use-cases", async (req, res) => {
    try {
      const { requirementId, requirementText } = req.body;
      
      if (!requirementText) {
        return res.status(400).json({ message: "Requirement text is required" });
      }

      // Prepare the prompt for AWS Bedrock
      const prompt = `Generate 3-5 detailed use cases for the following software requirement:

Requirement: ${requirementText}

For each use case, provide:
1. Title (format: UC-XXX: Short Title)
2. Actor (who performs the action)
3. Description (brief summary)
4. Preconditions (what must be true before)
5. Main Steps (numbered list of actions)
6. Postconditions (what is true after)

Format the response as a JSON array with this structure:
[
  {
    "title": "UC-001: Example Title",
    "actor": "End User",
    "description": "Brief description of what the use case achieves",
    "preconditions": "User must be logged in",
    "steps": ["Step 1", "Step 2", "Step 3"],
    "postconditions": "System state after completion"
  }
]

Ensure the use cases are practical, specific, and cover different scenarios.`;

      // Call AWS Bedrock
      const command = new InvokeModelCommand({
        modelId: "anthropic.claude-3-haiku-20240307-v1:0",
        contentType: "application/json",
        accept: "application/json",
        body: JSON.stringify({
          anthropic_version: "bedrock-2023-05-31",
          max_tokens: 2000,
          temperature: 0.3,
          messages: [
            {
              role: "user",
              content: prompt
            }
          ]
        }),
      });

      const response = await bedrockClient.send(command);
      const responseBody = JSON.parse(new TextDecoder().decode(response.body));
      
      let useCasesData;
      try {
        // Extract JSON from the response content
        const content = responseBody.content[0].text;
        const jsonMatch = content.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          useCasesData = JSON.parse(jsonMatch[0]);
        } else {
          throw new Error("No valid JSON found in response");
        }
      } catch (parseError) {
        return res.status(500).json({ 
          message: "Failed to parse AI response", 
          details: responseBody.content?.[0]?.text || "No content available"
        });
      }

      // Save use cases to storage if requirementId is provided
      const savedUseCases = [];
      if (requirementId) {
        for (const useCaseData of useCasesData) {
          const useCase = await storage.createUseCase({
            title: useCaseData.title,
            description: useCaseData.description,
            actor: useCaseData.actor,
            preconditions: useCaseData.preconditions || null,
            steps: useCaseData.steps,
            postconditions: useCaseData.postconditions || null,
            requirementId: parseInt(requirementId),
            isAiGenerated: true,
          });
          savedUseCases.push(useCase);
        }

        // Log AI activity
        const requirement = await storage.getRequirement(parseInt(requirementId));
        if (requirement) {
          await storage.createAiActivity({
            type: "use_case_generation",
            description: `Generated ${savedUseCases.length} use cases from "${requirement.title}" requirement`,
            projectId: requirement.projectId,
            userId: 1,
            metadata: { requirementId: parseInt(requirementId), useCasesCount: savedUseCases.length },
          });
        }
      }

      res.json({
        useCases: requirementId ? savedUseCases : useCasesData,
        message: `Generated ${useCasesData.length} use cases successfully`,
      });

    } catch (error) {
      console.error("AI generation error:", error);
      res.status(500).json({ 
        message: "Failed to generate use cases", 
        details: error.message 
      });
    }
  });

  // Web scraping and project generation endpoint
  app.post("/api/projects/create-from-url", async (req, res) => {
    try {
      const { url } = req.body;
      
      if (!url) {
        return res.status(400).json({ error: "URL is required" });
      }

      // Scrape web content with better headers
      const response = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
          'Accept-Encoding': 'gzip, deflate',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1'
        },
        timeout: 15000,
        maxRedirects: 5,
        validateStatus: function (status) {
          return status >= 200 && status < 400; // Accept redirects
        }
      });

      const $ = cheerio.load(response.data);
      
      // Extract main content (remove scripts, styles, navigation)
      $('script, style, nav, header, footer, .sidebar, .advertisement').remove();
      
      // Get main text content
      const title = $('title').text() || $('h1').first().text() || 'Untitled';
      const content = $('article, .content, main, .post-content').text() || $('body').text();
      
      // Clean and truncate content for AI processing
      const cleanContent = content
        .replace(/\s+/g, ' ')
        .replace(/\n+/g, '\n')
        .trim()
        .substring(0, 8000); // Limit content size for AI processing

      // Generate project analysis using AWS Bedrock
      const analysisPrompt = `
Analyze the following technical article and create a software project based on its content. Extract key requirements and generate use cases.

Article Title: ${title}
Article Content: ${cleanContent}

Please provide a JSON response with the following structure:
{
  "project": {
    "name": "Project name based on the article",
    "description": "Brief description of the project",
    "phase": "design",
    "progress": 25
  },
  "requirements": [
    {
      "title": "Requirement title",
      "description": "Detailed requirement description",
      "priority": "high|medium|low",
      "status": "planning"
    }
  ],
  "useCases": [
    {
      "title": "Use case title",
      "description": "What this use case accomplishes",
      "actor": "Who performs this action",
      "preconditions": "What must be true before this use case",
      "steps": ["Step 1", "Step 2", "Step 3"],
      "postconditions": "What is true after completion"
    }
  ]
}

Focus on creating 3-5 realistic requirements and 4-6 comprehensive use cases that cover both functional and non-functional aspects of the system described in the article.
      `;

      const command = new InvokeModelCommand({
        modelId: "anthropic.claude-3-haiku-20240307-v1:0",
        contentType: "application/json",
        accept: "application/json",
        body: JSON.stringify({
          anthropic_version: "bedrock-2023-05-31",
          max_tokens: 4000,
          temperature: 0.3,
          messages: [
            {
              role: "user",
              content: analysisPrompt
            }
          ]
        }),
      });

      const bedrockResponse = await bedrockClient.send(command);
      const responseBody = JSON.parse(new TextDecoder().decode(bedrockResponse.body));
      const aiContent = responseBody.content[0].text.trim();

      // Parse AI response
      let analysisResult;
      try {
        // Extract JSON from AI response
        const jsonMatch = aiContent.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          analysisResult = JSON.parse(jsonMatch[0]);
        } else {
          throw new Error("No JSON found in AI response");
        }
      } catch (parseError) {
        console.error("Failed to parse AI response:", aiContent);
        return res.status(500).json({ error: "Failed to parse AI analysis" });
      }

      // Create project
      const project = await storage.createProject({
        name: analysisResult.project.name,
        description: analysisResult.project.description,
        phase: analysisResult.project.phase || "design",
        progress: analysisResult.project.progress || 25,
        ownerId: 1 // Default user
      });

      // Create requirements
      const requirements = [];
      for (const req of analysisResult.requirements || []) {
        const requirement = await storage.createRequirement({
          title: req.title,
          description: req.description,
          priority: req.priority || "medium",
          status: req.status || "planning",
          projectId: project.id,
          assigneeId: 1
        });
        requirements.push(requirement);
      }

      // Create use cases
      const useCases = [];
      for (let i = 0; i < (analysisResult.useCases || []).length; i++) {
        const uc = analysisResult.useCases[i];
        const requirementId = requirements[i % requirements.length]?.id || requirements[0]?.id;
        
        if (requirementId) {
          const useCase = await storage.createUseCase({
            title: uc.title,
            description: uc.description,
            actor: uc.actor || "System User",
            preconditions: uc.preconditions || null,
            steps: uc.steps || [],
            postconditions: uc.postconditions || null,
            requirementId: requirementId,
            isAiGenerated: true
          });
          useCases.push(useCase);
        }
      }

      // Log AI activity
      await storage.createAiActivity({
        type: "project_generation",
        description: `Generated project "${project.name}" from web article analysis`,
        projectId: project.id,
        userId: 1,
        metadata: { 
          sourceUrl: url, 
          requirementsCount: requirements.length,
          useCasesCount: useCases.length
        }
      });

      res.json({
        project,
        requirements,
        useCases,
        message: `Successfully created project "${project.name}" with ${requirements.length} requirements and ${useCases.length} use cases`
      });

    } catch (error) {
      console.error("URL analysis error details:", {
        message: error.message,
        code: error.code,
        stack: error.stack,
        name: error.name
      });
      
      if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
        res.status(400).json({ error: "Unable to access the provided URL" });
      } else if (error.message?.includes('timeout')) {
        res.status(408).json({ error: "Request timeout - URL took too long to respond" });
      } else if (error.name === 'ValidationException' || error.message?.includes('bedrock')) {
        res.status(500).json({ error: "AI analysis service error", details: error.message });
      } else {
        res.status(500).json({ error: "Failed to analyze URL content", details: error.message });
      }
    }
  });

  // WebSocket handling for real-time chat
  io.on("connection", (socket) => {
    console.log("User connected to chat:", socket.id);

    socket.on("join-project", (projectId) => {
      socket.join(`project-${projectId}`);
      console.log(`User joined project ${projectId}`);
    });

    socket.on("send-message", async (data) => {
      try {
        const { content, projectId, userId } = data;
        
        // Save user message
        const userMessage = await storage.createChatMessage({
          content,
          role: "user",
          projectId: parseInt(projectId),
          userId: userId || 1,
          metadata: {},
        });

        // Emit user message to project room
        io.to(`project-${projectId}`).emit("new-message", userMessage);

        // Check if message contains URL and user wants to create a project
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        const urls = content.match(urlRegex);
        const isProjectCreationRequest = content.toLowerCase().includes('create') && 
                                       content.toLowerCase().includes('project') && 
                                       urls && urls.length > 0;

        console.log("Message analysis:", {
          content: content.substring(0, 100),
          hasCreate: content.toLowerCase().includes('create'),
          hasProject: content.toLowerCase().includes('project'),
          urls: urls,
          isProjectCreationRequest
        });

        if (isProjectCreationRequest) {
          // Handle URL-based project creation
          const url = urls[0];
          console.log("Starting project creation from URL:", url);
          
          try {
            // Scrape web content
            console.log("Fetching web content...");
            const response = await axios.get(url, {
              headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
              },
              timeout: 10000
            });
            console.log("Web content fetched successfully, length:", response.data.length);

            const $ = cheerio.load(response.data);
            
            // Remove unwanted elements
            $('script, style, nav, header, footer, .sidebar, .advertisement, .ads, .social-share, .comments').remove();
            
            // Extract title with fallbacks
            const title = $('title').text().trim() || 
                         $('h1').first().text().trim() || 
                         $('meta[property="og:title"]').attr('content') || 
                         'Untitled Article';
            
            // Try multiple content selectors in order of preference
            let webContent = '';
            const contentSelectors = [
              'article .content, article .post-content, article .entry-content',
              'main .content, main .post-content, main .entry-content', 
              '.content, .post-content, .entry-content, .article-content',
              'article, main, .main-content, .page-content',
              'body'
            ];
            
            for (const selector of contentSelectors) {
              const content = $(selector).text().trim();
              if (content && content.length > 200) {
                webContent = content;
                break;
              }
            }
            
            // Also extract any paragraph text as fallback
            if (!webContent || webContent.length < 200) {
              webContent = $('p').map((i, el) => $(el).text()).get().join(' ');
            }
            
            const cleanContent = webContent
              .replace(/\s+/g, ' ')
              .replace(/\n+/g, '\n')
              .trim()
              .substring(0, 12000); // Increased limit for better content

            console.log("Extracted content preview:", {
              title: title.substring(0, 100),
              contentLength: cleanContent.length,
              contentPreview: cleanContent.substring(0, 200)
            });

            // Generate project analysis using AWS Bedrock
            const analysisPrompt = `
You are a business analyst. Read this article carefully and create a software project that implements the EXACT systems, features, or solutions described in the article.

IMPORTANT: Base your project ONLY on what is actually described in this article. Do not create generic projects about blockchain, trading, or other topics unless they are specifically mentioned in the article content.

SOURCE ARTICLE:
Title: ${title}
Content: ${cleanContent}

TASK: Create a project that implements what is described in this article. If the article discusses specific technologies, business processes, or systems, create a project that builds or implements those exact things.

Return a JSON response with this structure:
{
  "project": {
    "name": "Project name that directly reflects the article's main topic",
    "description": "Description based on the article's specific content and requirements",
    "phase": "design",
    "progress": 25
  },
  "requirements": [
    {
      "title": "Requirement directly from article content",
      "description": "Detailed requirement based on article specifics",
      "priority": "high",
      "status": "planning"
    }
  ],
  "useCases": [
    {
      "title": "Use case for features mentioned in article",
      "description": "Functionality described in the article",
      "actor": "User type mentioned in article",
      "preconditions": "Prerequisites from article context",
      "steps": ["Specific steps based on article workflow"],
      "postconditions": "Results described in article"
    }
  ]
}

CRITICAL: If the article doesn't contain technical system requirements, create a project that would support or implement the business processes or solutions described. Do NOT create unrelated blockchain, trading, or generic projects.`;

            const command = new InvokeModelCommand({
              modelId: "anthropic.claude-3-haiku-20240307-v1:0",
              contentType: "application/json",
              accept: "application/json",
              body: JSON.stringify({
                anthropic_version: "bedrock-2023-05-31",
                max_tokens: 4000,
                temperature: 0.3,
                messages: [
                  {
                    role: "user",
                    content: analysisPrompt
                  }
                ]
              }),
            });

            const bedrockResponse = await bedrockClient.send(command);
            const responseBody = JSON.parse(new TextDecoder().decode(bedrockResponse.body));
            const aiContent = responseBody.content[0].text.trim();

            // Parse AI response
            let analysisResult;
            try {
              const jsonMatch = aiContent.match(/\{[\s\S]*\}/);
              if (jsonMatch) {
                analysisResult = JSON.parse(jsonMatch[0]);
              } else {
                throw new Error("No JSON found in AI response");
              }
            } catch (parseError) {
              throw new Error("Failed to parse AI analysis");
            }

            // Create project
            const project = await storage.createProject({
              name: analysisResult.project.name,
              description: analysisResult.project.description,
              phase: analysisResult.project.phase || "design",
              progress: analysisResult.project.progress || 25,
              ownerId: 1
            });

            // Create requirements
            const requirements = [];
            for (const req of analysisResult.requirements || []) {
              const requirement = await storage.createRequirement({
                title: req.title,
                description: req.description,
                priority: req.priority || "medium",
                status: req.status || "planning",
                projectId: project.id,
                assigneeId: 1
              });
              requirements.push(requirement);
            }

            // Create use cases
            const useCases = [];
            for (let i = 0; i < (analysisResult.useCases || []).length; i++) {
              const uc = analysisResult.useCases[i];
              const requirementId = requirements[i % requirements.length]?.id || requirements[0]?.id;
              
              if (requirementId) {
                const useCase = await storage.createUseCase({
                  title: uc.title,
                  description: uc.description,
                  actor: uc.actor || "System User",
                  preconditions: uc.preconditions || null,
                  steps: uc.steps || [],
                  postconditions: uc.postconditions || null,
                  requirementId: requirementId,
                  isAiGenerated: true
                });
                useCases.push(useCase);
              }
            }

            // Log AI activity
            await storage.createAiActivity({
              type: "project_generation",
              description: `Generated project "${project.name}" from web article analysis`,
              projectId: project.id,
              userId: 1,
              metadata: { 
                sourceUrl: url, 
                requirementsCount: requirements.length,
                useCasesCount: useCases.length
              }
            });

            // Send success response
            const successMessage = await storage.createChatMessage({
              content: `✅ Successfully created project "${project.name}" with ${requirements.length} requirements and ${useCases.length} use cases from the article analysis.\n\nProject Details:\n${project.description}\n\nThe project has been added to your dashboard. Click on it to view all generated use cases and requirements.`,
              role: "assistant",
              projectId: parseInt(projectId),
              userId: null,
              metadata: { 
                type: "project_creation",
                projectId: project.id,
                sourceUrl: url
              },
            });

            io.to(`project-${projectId}`).emit("new-message", successMessage);
            io.emit("project-created", { project, requirements, useCases });

          } catch (urlError) {
            console.error("URL processing error:", urlError);
            const errorMessage = await storage.createChatMessage({
              content: `❌ I encountered an issue analyzing the URL "${url}". Please ensure the URL is accessible and contains technical content that can be converted into project requirements. \n\nError: ${urlError.message || 'Unable to process the webpage content'}`,
              role: "assistant",
              projectId: parseInt(projectId),
              userId: null,
              metadata: { type: "error", sourceUrl: url },
            });
            io.to(`project-${projectId}`).emit("new-message", errorMessage);
          }
        } else {
          // Generate regular AI response
          const prompt = `You are an AI assistant specializing in software development lifecycle (SDLC) management. 
          
User message: ${content}

Provide a helpful response related to:
- Requirements analysis and documentation
- Use case generation and validation
- SDLC best practices
- Project management guidance
- Technical recommendations

If the user provides a URL and asks to create a project, explain that I can analyze web articles and automatically generate projects with requirements and use cases. They should say something like "Create a project from this URL: [link]".

Keep responses concise but informative.`;

        const command = new InvokeModelCommand({
          modelId: "anthropic.claude-3-haiku-20240307-v1:0",
          contentType: "application/json",
          accept: "application/json",
          body: JSON.stringify({
            anthropic_version: "bedrock-2023-05-31",
            max_tokens: 1000,
            temperature: 0.7,
            messages: [
              {
                role: "user",
                content: prompt
              }
            ]
          }),
        });

        const response = await bedrockClient.send(command);
        const responseBody = JSON.parse(new TextDecoder().decode(response.body));

        // Save AI response
        const aiMessage = await storage.createChatMessage({
          content: responseBody.content[0].text.trim(),
          role: "assistant",
          projectId: parseInt(projectId),
          userId: null,
          metadata: { model: "anthropic.claude-3-sonnet" },
        });

          // Emit AI response to project room
          io.to(`project-${projectId}`).emit("new-message", aiMessage);
        }

      } catch (error) {
        console.error("Chat error:", error);
        socket.emit("chat-error", { message: "Failed to process message" });
      }
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });

  return httpServer;
}
