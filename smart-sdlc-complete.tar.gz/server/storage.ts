import { 
  users, projects, requirements, useCases, chatMessages, aiActivities,
  type User, type InsertUser,
  type Project, type InsertProject,
  type Requirement, type InsertRequirement,
  type UseCase, type InsertUseCase,
  type ChatMessage, type InsertChatMessage,
  type AiActivity, type InsertAiActivity
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Projects
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByUser(userId: number): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, updates: Partial<Project>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;

  // Requirements
  getRequirement(id: number): Promise<Requirement | undefined>;
  getRequirementsByProject(projectId: number): Promise<Requirement[]>;
  createRequirement(requirement: InsertRequirement): Promise<Requirement>;
  updateRequirement(id: number, updates: Partial<Requirement>): Promise<Requirement | undefined>;

  // Use Cases
  getUseCase(id: number): Promise<UseCase | undefined>;
  getUseCasesByRequirement(requirementId: number): Promise<UseCase[]>;
  getUseCasesByProject(projectId: number): Promise<UseCase[]>;
  createUseCase(useCase: InsertUseCase): Promise<UseCase>;

  // Chat Messages
  getChatMessagesByProject(projectId: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;

  // AI Activities
  getAiActivitiesByProject(projectId: number): Promise<AiActivity[]>;
  createAiActivity(activity: InsertAiActivity): Promise<AiActivity>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private projects: Map<number, Project> = new Map();
  private requirements: Map<number, Requirement> = new Map();
  private useCases: Map<number, UseCase> = new Map();
  private chatMessages: Map<number, ChatMessage> = new Map();
  private aiActivities: Map<number, AiActivity> = new Map();
  
  private currentUserId = 1;
  private currentProjectId = 1;
  private currentRequirementId = 1;
  private currentUseCaseId = 1;
  private currentChatMessageId = 1;
  private currentAiActivityId = 1;

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Create a default user
    const defaultUser: User = {
      id: 1,
      username: "sarah.mitchell",
      email: "sarah.mitchell@company.com",
      password: "password",
      role: "business_analyst",
      initials: "SM",
      servicenowGroup: "Investment Banking Operations",
      department: "Digital Transformation",
      profileImage: null,
      createdAt: new Date(),
    };
    this.users.set(1, defaultUser);
    this.currentUserId = 2;

    // Create investment banking projects with specific statuses
    const projects: Project[] = [
      {
        id: 1,
        name: "Trade Settlement System",
        description: "Automated trade settlement and clearing system for equity and fixed income securities",
        phase: "development",
        progress: 75,
        ownerId: 1,
        assignedGroup: "Capital Markets IT",
        submittedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
        createdAt: new Date(),
      },
      {
        id: 2,
        name: "Risk Management Platform",
        description: "Real-time risk assessment and portfolio monitoring for institutional clients",
        phase: "draft",
        progress: 15,
        ownerId: 1,
        assignedGroup: null,
        submittedAt: null,
        createdAt: new Date(),
      },
      {
        id: 3,
        name: "Client Onboarding Portal",
        description: "Digital onboarding system for corporate and institutional clients with KYC/AML compliance",
        phase: "completed",
        progress: 100,
        ownerId: 1,
        assignedGroup: "Compliance Technology",
        submittedAt: new Date(Date.now() - 13 * 24 * 60 * 60 * 1000),
        createdAt: new Date(),
      },
      {
        id: 4,
        name: "Derivatives Trading Platform",
        description: "High-frequency derivatives trading system with real-time pricing and risk management",
        phase: "pending review",
        progress: 85,
        ownerId: 1,
        assignedGroup: "Risk Technology",
        submittedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
        createdAt: new Date(),
      }
    ];
    
    projects.forEach(project => this.projects.set(project.id, project));
    this.currentProjectId = 5;

    // Create sample requirements for the 4 investment banking projects
    const sampleRequirements: Requirement[] = [
      {
        id: 1,
        title: "Trade Order Matching Engine",
        description: "High-performance matching engine for equity and bond trades with sub-millisecond latency requirements",
        priority: "high",
        status: "in_progress",
        projectId: 1,
        assigneeId: 1,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      },
      {
        id: 2,
        title: "Settlement Risk Calculator",
        description: "Real-time settlement risk calculation system with counterparty exposure limits",
        priority: "high",
        status: "open",
        projectId: 1,
        assigneeId: 1,
        createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
      },
      {
        id: 3,
        title: "Portfolio Risk Analytics",
        description: "Advanced risk metrics calculation including VaR, stress testing, and scenario analysis",
        priority: "high",
        status: "in_progress",
        projectId: 2,
        assigneeId: 1,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      },
      {
        id: 4,
        title: "KYC Compliance Module",
        description: "Automated Know Your Customer verification system with document validation",
        priority: "high",
        status: "completed",
        projectId: 3,
        assigneeId: 1,
        createdAt: new Date(Date.now() - 72 * 60 * 60 * 1000), // 3 days ago
      },
      {
        id: 5,
        title: "Real-time Market Data Feed",
        description: "High-frequency market data processing for derivatives pricing",
        priority: "critical",
        status: "pending review",
        projectId: 4,
        assigneeId: 1,
        createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000), // 12 hours ago
      },
    ];

    sampleRequirements.forEach(req => this.requirements.set(req.id, req));
    this.currentRequirementId = 6;

    // Create sample AI activities for investment banking context
    const sampleActivities: AiActivity[] = [
      {
        id: 1,
        type: "use_case_generation",
        description: "Generated 4 use cases for trade settlement system requirements",
        projectId: 1,
        userId: 1,
        metadata: { requirementId: 1, useCasesCount: 4 },
        createdAt: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
      },
      {
        id: 2,
        type: "requirement_analysis",
        description: "Analyzed risk management requirements for regulatory compliance",
        projectId: 2,
        userId: 1,
        metadata: { requirementsAnalyzed: 3 },
        createdAt: new Date(Date.now() - 60 * 60 * 1000), // 1 hour ago
      },
      {
        id: 3,
        type: "documentation",
        description: "Created technical specifications document",
        projectId: 1,
        userId: 1,
        metadata: { documentType: "technical_spec" },
        createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
      },
    ];

    sampleActivities.forEach(activity => this.aiActivities.set(activity.id, activity));
    this.currentAiActivityId = 4;

    // Create sample use cases with functional and non-functional requirements
    const sampleUseCases: UseCase[] = [
      // Functional use cases for Trade Settlement System
      {
        id: 1,
        title: "Execute Trade Settlement",
        requirementId: 1,
        description: "System processes trade settlement for equity and bond transactions",
        actor: "Settlement Manager",
        preconditions: "Trade order is validated and matched",
        steps: [
          "Receive settlement instruction from trading system",
          "Validate counterparty details and settlement date",
          "Calculate settlement amount including fees and taxes",
          "Initiate funds transfer between counterparties",
          "Update trade status to settled",
          "Generate settlement confirmation"
        ],
        postconditions: "Trade is marked as settled and confirmation sent to all parties",
        isAiGenerated: true,
        createdAt: new Date(),
      },
      {
        id: 2,
        title: "Handle Settlement Failure",
        requirementId: 1,
        description: "System manages failed settlement scenarios with automatic retry mechanisms",
        actor: "Settlement System",
        preconditions: "Settlement attempt has failed",
        steps: [
          "Identify failure reason (insufficient funds, invalid account, etc.)",
          "Log failure details in audit trail",
          "Notify relevant parties of settlement failure",
          "Schedule automatic retry based on failure type",
          "Escalate to operations team if retry limit exceeded"
        ],
        postconditions: "Failed settlement is properly handled and tracked",
        isAiGenerated: true,
        createdAt: new Date(),
      },
      // Non-functional use cases for Trade Settlement System
      {
        id: 3,
        title: "Process High Volume Settlements",
        requirementId: 2,
        description: "System handles peak settlement volumes with sub-millisecond response times",
        actor: "Settlement System",
        preconditions: "System is under high load conditions",
        steps: [
          "Monitor incoming settlement requests",
          "Process requests in parallel using thread pool",
          "Maintain response time under 500 microseconds",
          "Scale processing capacity automatically",
          "Generate performance metrics"
        ],
        postconditions: "All settlements processed within SLA requirements",
        isAiGenerated: true,
        createdAt: new Date(),
      },
      // Functional use cases for Risk Management Platform
      {
        id: 4,
        title: "Calculate Portfolio VaR",
        requirementId: 3,
        description: "System calculates Value at Risk for institutional client portfolios",
        actor: "Risk Analyst",
        preconditions: "Portfolio data is available and markets are open",
        steps: [
          "Retrieve current portfolio positions",
          "Fetch latest market data and volatilities",
          "Apply risk calculation models (Monte Carlo, Historical)",
          "Calculate VaR at 95% and 99% confidence levels",
          "Generate risk reports with scenario analysis",
          "Alert on limit breaches"
        ],
        postconditions: "Risk metrics are calculated and available for analysis",
        isAiGenerated: true,
        createdAt: new Date(),
      },
      // Functional use cases for Client Onboarding
      {
        id: 5,
        title: "Verify Client Identity",
        requirementId: 4,
        description: "System performs automated KYC verification for new institutional clients",
        actor: "Compliance Officer",
        preconditions: "Client has submitted required documentation",
        steps: [
          "Scan and extract data from identity documents",
          "Verify documents against government databases",
          "Perform sanctions screening (OFAC, EU, UN lists)",
          "Check ultimate beneficial ownership structure",
          "Generate compliance risk score",
          "Create client profile in CRM system"
        ],
        postconditions: "Client identity is verified and compliance status determined",
        isAiGenerated: true,
        createdAt: new Date(),
      },
      // Non-functional use case for security
      {
        id: 6,
        title: "Ensure Data Encryption",
        requirementId: 4,
        description: "System maintains end-to-end encryption for all client data",
        actor: "Security System",
        preconditions: "Client data is being processed or stored",
        steps: [
          "Encrypt data using AES-256 encryption",
          "Implement TLS 1.3 for data in transit",
          "Store encryption keys in hardware security modules",
          "Rotate encryption keys quarterly",
          "Audit encryption compliance regularly"
        ],
        postconditions: "All client data is encrypted according to regulatory standards",
        isAiGenerated: true,
        createdAt: new Date(),
      }
    ];
    
    sampleUseCases.forEach(useCase => this.useCases.set(useCase.id, useCase));
    this.currentUseCaseId = 7;
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      role: insertUser.role || "business_analyst",
      department: insertUser.department || null,
      profileImage: insertUser.profileImage || null,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  // Projects
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjectsByUser(userId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(project => project.ownerId === userId);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const project: Project = { ...insertProject, id, createdAt: new Date() };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, updates: Partial<Project>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject = { ...project, ...updates };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: number): Promise<boolean> {
    const project = this.projects.get(id);
    if (!project) return false;
    
    // Only allow deletion of draft projects
    if (project.phase !== 'draft') return false;
    
    // Delete the project and all related data
    this.projects.delete(id);
    
    // Delete related requirements
    const requirements = Array.from(this.requirements.values()).filter(req => req.projectId === id);
    requirements.forEach(req => this.requirements.delete(req.id));
    
    // Delete related use cases
    const useCases = Array.from(this.useCases.values()).filter(uc => 
      requirements.some(req => req.id === uc.requirementId)
    );
    useCases.forEach(uc => this.useCases.delete(uc.id));
    
    // Delete related chat messages
    const chatMessages = Array.from(this.chatMessages.values()).filter(msg => msg.projectId === id);
    chatMessages.forEach(msg => this.chatMessages.delete(msg.id));
    
    // Delete related AI activities
    const aiActivities = Array.from(this.aiActivities.values()).filter(activity => activity.projectId === id);
    aiActivities.forEach(activity => this.aiActivities.delete(activity.id));
    
    return true;
  }

  // Requirements
  async getRequirement(id: number): Promise<Requirement | undefined> {
    return this.requirements.get(id);
  }

  async getRequirementsByProject(projectId: number): Promise<Requirement[]> {
    return Array.from(this.requirements.values())
      .filter(req => req.projectId === projectId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createRequirement(insertRequirement: InsertRequirement): Promise<Requirement> {
    const id = this.currentRequirementId++;
    const requirement: Requirement = { ...insertRequirement, id, createdAt: new Date() };
    this.requirements.set(id, requirement);
    return requirement;
  }

  async updateRequirement(id: number, updates: Partial<Requirement>): Promise<Requirement | undefined> {
    const requirement = this.requirements.get(id);
    if (!requirement) return undefined;
    
    const updatedRequirement = { ...requirement, ...updates };
    this.requirements.set(id, updatedRequirement);
    return updatedRequirement;
  }

  // Use Cases
  async getUseCase(id: number): Promise<UseCase | undefined> {
    return this.useCases.get(id);
  }

  async getUseCasesByRequirement(requirementId: number): Promise<UseCase[]> {
    return Array.from(this.useCases.values())
      .filter(useCase => useCase.requirementId === requirementId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getUseCasesByProject(projectId: number): Promise<UseCase[]> {
    const projectRequirements = await this.getRequirementsByProject(projectId);
    const requirementIds = projectRequirements.map(req => req.id);
    
    return Array.from(this.useCases.values())
      .filter(useCase => requirementIds.includes(useCase.requirementId))
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createUseCase(insertUseCase: InsertUseCase): Promise<UseCase> {
    const id = this.currentUseCaseId++;
    const useCase: UseCase = { ...insertUseCase, id, createdAt: new Date() };
    this.useCases.set(id, useCase);
    return useCase;
  }

  // Chat Messages
  async getChatMessagesByProject(projectId: number): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(msg => msg.projectId === projectId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentChatMessageId++;
    const message: ChatMessage = { ...insertMessage, id, createdAt: new Date() };
    this.chatMessages.set(id, message);
    return message;
  }

  // AI Activities
  async getAiActivitiesByProject(projectId: number): Promise<AiActivity[]> {
    return Array.from(this.aiActivities.values())
      .filter(activity => activity.projectId === projectId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createAiActivity(insertActivity: InsertAiActivity): Promise<AiActivity> {
    const id = this.currentAiActivityId++;
    const activity: AiActivity = { ...insertActivity, id, createdAt: new Date() };
    this.aiActivities.set(id, activity);
    return activity;
  }
}

export const storage = new MemStorage();
