import fs from 'fs/promises';
import path from 'path';
import type { 
  User, 
  Project, 
  Requirement, 
  UseCase, 
  ChatMessage, 
  AiActivity,
  InsertUser,
  InsertProject,
  InsertRequirement,
  InsertUseCase,
  InsertChatMessage,
  InsertAiActivity
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Projects
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByUser(userId: number): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, updates: Partial<Project>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;

  // Requirements
  getRequirement(id: number): Promise<Requirement | undefined>;
  getRequirementsByProject(projectId: number): Promise<Requirement[]>;
  createRequirement(requirement: InsertRequirement): Promise<Requirement>;
  updateRequirement(id: number, updates: Partial<Requirement>): Promise<Requirement | undefined>;

  // Use Cases
  getUseCase(id: number): Promise<UseCase | undefined>;
  getUseCasesByRequirement(requirementId: number): Promise<UseCase[]>;
  getUseCasesByProject(projectId: number): Promise<UseCase[]>;
  createUseCase(useCase: InsertUseCase): Promise<UseCase>;

  // Chat Messages
  getChatMessagesByProject(projectId: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;

  // AI Activities
  getAiActivitiesByProject(projectId: number): Promise<AiActivity[]>;
  createAiActivity(activity: InsertAiActivity): Promise<AiActivity>;
}

interface FileData {
  users: User[];
  projects: Project[];
  requirements: Requirement[];
  useCases: UseCase[];
  chatMessages: ChatMessage[];
  aiActivities: AiActivity[];
  counters: {
    userId: number;
    projectId: number;
    requirementId: number;
    useCaseId: number;
    chatMessageId: number;
    aiActivityId: number;
  };
}

export class FileStorage implements IStorage {
  private dataPath: string;
  private data: FileData;

  constructor() {
    this.dataPath = path.join(process.cwd(), 'data.json');
    this.data = {
      users: [],
      projects: [],
      requirements: [],
      useCases: [],
      chatMessages: [],
      aiActivities: [],
      counters: {
        userId: 1,
        projectId: 1,
        requirementId: 1,
        useCaseId: 1,
        chatMessageId: 1,
        aiActivityId: 1,
      }
    };
    this.initializeData();
  }

  private async initializeData() {
    try {
      const fileContent = await fs.readFile(this.dataPath, 'utf8');
      this.data = JSON.parse(fileContent);
      
      // Convert date strings back to Date objects
      this.data.users.forEach(user => {
        user.createdAt = new Date(user.createdAt);
      });
      this.data.projects.forEach(project => {
        project.createdAt = new Date(project.createdAt);
        if (project.submittedAt) project.submittedAt = new Date(project.submittedAt);
      });
      this.data.requirements.forEach(req => {
        req.createdAt = new Date(req.createdAt);
      });
      this.data.useCases.forEach(uc => {
        uc.createdAt = new Date(uc.createdAt);
      });
      this.data.chatMessages.forEach(msg => {
        msg.createdAt = new Date(msg.createdAt);
      });
      this.data.aiActivities.forEach(activity => {
        activity.createdAt = new Date(activity.createdAt);
      });
    } catch (error) {
      // File doesn't exist, create with default data
      await this.seedDefaultData();
      await this.saveData();
    }
  }

  private async saveData() {
    await fs.writeFile(this.dataPath, JSON.stringify(this.data, null, 2));
  }

  private async seedDefaultData() {
    // Create default user
    const defaultUser: User = {
      id: 1,
      username: "sarah.mitchell",
      email: "sarah.mitchell@company.com",
      password: "password",
      role: "business_analyst",
      initials: "SM",
      servicenowGroup: "Investment Banking Operations",
      department: "Digital Transformation",
      profileImage: null,
      createdAt: new Date(),
    };
    this.data.users.push(defaultUser);

    // Create sample projects
    const projects: Project[] = [
      {
        id: 1,
        name: "Trade Settlement System",
        description: "Automated trade settlement and clearing system for equity and fixed income securities",
        phase: "development",
        progress: 75,
        ownerId: 1,
        assignedGroup: "Capital Markets IT",
        submittedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
        createdAt: new Date(),
      },
      {
        id: 2,
        name: "Risk Management Platform",
        description: "Real-time risk assessment and portfolio monitoring for institutional clients",
        phase: "draft",
        progress: 15,
        ownerId: 1,
        assignedGroup: null,
        submittedAt: null,
        createdAt: new Date(),
      },
      {
        id: 3,
        name: "Client Onboarding Portal",
        description: "Digital onboarding system for corporate and institutional clients with KYC/AML compliance",
        phase: "completed",
        progress: 100,
        ownerId: 1,
        assignedGroup: "Compliance Technology",
        submittedAt: new Date(Date.now() - 13 * 24 * 60 * 60 * 1000),
        createdAt: new Date(),
      },
      {
        id: 4,
        name: "Derivatives Trading Platform",
        description: "High-frequency derivatives trading system with real-time pricing and risk management",
        phase: "pending review",
        progress: 85,
        ownerId: 1,
        assignedGroup: "Risk Technology",
        submittedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
        createdAt: new Date(),
      }
    ];
    this.data.projects.push(...projects);

    // Update counters
    this.data.counters.userId = 2;
    this.data.counters.projectId = 5;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.data.users.find(user => user.id === id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return this.data.users.find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.data.counters.userId++;
    const user: User = {
      ...insertUser,
      id,
      role: insertUser.role || "business_analyst",
      department: insertUser.department || null,
      profileImage: insertUser.profileImage || null,
      createdAt: new Date()
    };
    this.data.users.push(user);
    await this.saveData();
    return user;
  }

  // Project methods
  async getProject(id: number): Promise<Project | undefined> {
    return this.data.projects.find(project => project.id === id);
  }

  async getProjectsByUser(userId: number): Promise<Project[]> {
    return this.data.projects.filter(project => project.ownerId === userId);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.data.counters.projectId++;
    const project: Project = {
      ...insertProject,
      id,
      ownerId: insertProject.ownerId || 1, // Ensure ownerId is always set
      description: insertProject.description || null,
      phase: insertProject.phase || "draft",
      progress: insertProject.progress || 0,
      assignedGroup: null,
      submittedAt: null,
      createdAt: new Date()
    };
    this.data.projects.push(project);
    await this.saveData();
    return project;
  }

  async updateProject(id: number, updates: Partial<Project>): Promise<Project | undefined> {
    const projectIndex = this.data.projects.findIndex(p => p.id === id);
    if (projectIndex === -1) return undefined;

    this.data.projects[projectIndex] = { ...this.data.projects[projectIndex], ...updates };
    await this.saveData();
    return this.data.projects[projectIndex];
  }

  async deleteProject(id: number): Promise<boolean> {
    const project = this.data.projects.find(p => p.id === id);
    if (!project || project.phase !== "draft") return false;

    this.data.projects = this.data.projects.filter(p => p.id !== id);
    this.data.requirements = this.data.requirements.filter(r => r.projectId !== id);
    this.data.useCases = this.data.useCases.filter(uc => {
      const requirement = this.data.requirements.find(r => r.id === uc.requirementId);
      return requirement?.projectId !== id;
    });
    this.data.chatMessages = this.data.chatMessages.filter(msg => msg.projectId !== id);
    this.data.aiActivities = this.data.aiActivities.filter(activity => activity.projectId !== id);
    
    await this.saveData();
    return true;
  }

  // Requirement methods
  async getRequirement(id: number): Promise<Requirement | undefined> {
    return this.data.requirements.find(req => req.id === id);
  }

  async getRequirementsByProject(projectId: number): Promise<Requirement[]> {
    return this.data.requirements.filter(req => req.projectId === projectId);
  }

  async createRequirement(insertRequirement: InsertRequirement): Promise<Requirement> {
    const id = this.data.counters.requirementId++;
    const requirement: Requirement = {
      ...insertRequirement,
      id,
      priority: insertRequirement.priority || "medium",
      status: insertRequirement.status || "open",
      assigneeId: insertRequirement.assigneeId || null,
      createdAt: new Date()
    };
    this.data.requirements.push(requirement);
    await this.saveData();
    return requirement;
  }

  async updateRequirement(id: number, updates: Partial<Requirement>): Promise<Requirement | undefined> {
    const reqIndex = this.data.requirements.findIndex(r => r.id === id);
    if (reqIndex === -1) return undefined;

    this.data.requirements[reqIndex] = { ...this.data.requirements[reqIndex], ...updates };
    await this.saveData();
    return this.data.requirements[reqIndex];
  }

  // Use Case methods
  async getUseCase(id: number): Promise<UseCase | undefined> {
    return this.data.useCases.find(uc => uc.id === id);
  }

  async getUseCasesByRequirement(requirementId: number): Promise<UseCase[]> {
    return this.data.useCases.filter(uc => uc.requirementId === requirementId);
  }

  async getUseCasesByProject(projectId: number): Promise<UseCase[]> {
    const requirements = this.data.requirements.filter(r => r.projectId === projectId);
    const requirementIds = requirements.map(r => r.id);
    return this.data.useCases.filter(uc => requirementIds.includes(uc.requirementId));
  }

  async createUseCase(insertUseCase: InsertUseCase): Promise<UseCase> {
    const id = this.data.counters.useCaseId++;
    const useCase: UseCase = {
      ...insertUseCase,
      id,
      preconditions: insertUseCase.preconditions || null,
      postconditions: insertUseCase.postconditions || null,
      isAiGenerated: insertUseCase.isAiGenerated || false,
      createdAt: new Date()
    };
    this.data.useCases.push(useCase);
    await this.saveData();
    return useCase;
  }

  // Chat Message methods
  async getChatMessagesByProject(projectId: number): Promise<ChatMessage[]> {
    return this.data.chatMessages.filter(msg => msg.projectId === projectId);
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.data.counters.chatMessageId++;
    const message: ChatMessage = {
      ...insertMessage,
      id,
      userId: insertMessage.userId || null,
      metadata: insertMessage.metadata || null,
      createdAt: new Date()
    };
    this.data.chatMessages.push(message);
    await this.saveData();
    return message;
  }

  // AI Activity methods
  async getAiActivitiesByProject(projectId: number): Promise<AiActivity[]> {
    return this.data.aiActivities.filter(activity => activity.projectId === projectId);
  }

  async createAiActivity(insertActivity: InsertAiActivity): Promise<AiActivity> {
    const id = this.data.counters.aiActivityId++;
    const activity: AiActivity = {
      ...insertActivity,
      id,
      userId: insertActivity.userId || null,
      metadata: insertActivity.metadata || null,
      createdAt: new Date()
    };
    this.data.aiActivities.push(activity);
    await this.saveData();
    return activity;
  }
}

export const storage = new FileStorage();