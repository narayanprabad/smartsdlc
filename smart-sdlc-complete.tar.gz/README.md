# Smart SDLC - AI-Driven Software Development Lifecycle Platform

An AI-powered SDLC management platform designed for corporate investment banking workflows, featuring AWS Bedrock integration, real-time collaboration, and ServiceNow integration.

## Features

- **AI-Powered Project Generation**: Create projects from web articles using AWS Bedrock
- **Real-time Collaboration**: Socket.io-based chat system with persistent history
- **ServiceNow Integration**: Project submission workflow with group assignment
- **Investment Banking Focus**: Specialized for corporate banking projects
- **Professional UI**: Clean, modern interface with Smart SDLC branding
- **File-Based Storage**: No database required - uses JSON file storage

## Prerequisites

- Node.js 18+ installed
- AWS Account with Bedrock access
- Git

## Installation & Setup

### 1. Clone and Install Dependencies

```bash
git clone <your-repo-url>
cd smart-sdlc
npm install
```

### 2. Environment Variables

Create a `.env` file in the root directory:

```env
# AWS Bedrock Configuration (REQUIRED)
AWS_ACCESS_KEY_ID=your_aws_access_key_here
AWS_SECRET_ACCESS_KEY=your_aws_secret_key_here
AWS_REGION=us-east-1
```

### 3. AWS Bedrock Setup

**IMPORTANT**: You need AWS credentials with Bedrock access.

1. **Get AWS Credentials**:
   - Log into AWS Console
   - Go to IAM → Users → Your User → Security Credentials
   - Create Access Key if you don't have one
   - Copy the Access Key ID and Secret Access Key

2. **Enable Bedrock Models**:
   - Go to AWS Bedrock Console
   - Navigate to "Model access" in the left sidebar
   - Request access to "Claude 3 Sonnet" model
   - Wait for approval (usually instant for existing AWS accounts)

3. **Add Credentials to .env**:
   ```env
   AWS_ACCESS_KEY_ID=AKIA... (your actual key)
   AWS_SECRET_ACCESS_KEY=... (your actual secret)
   AWS_REGION=us-east-1
   ```

### 4. Start the Application

```bash
npm run dev
```

The application will be available at: `http://localhost:5000`

**Note**: The application uses file-based JSON storage. A `data.json` file will be automatically created in the root directory to store all data.

## Project Structure

```
smart-sdlc/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/         # Application pages
│   │   ├── hooks/         # Custom React hooks
│   │   └── lib/           # Utilities and API client
├── server/                # Express backend
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   ├── file-storage.ts   # File-based data storage
│   └── vite.ts           # Vite development server
├── shared/               # Shared types and schemas
│   └── schema.ts        # Data types and validation
├── data.json            # Auto-generated data storage
└── package.json         # Dependencies and scripts
```

## Usage

### Default User
- **Username**: sarah.mitchell
- **Role**: Business Analyst
- **ServiceNow Group**: Investment Banking Operations
- **Department**: Digital Transformation

### Key Features

1. **Project Management**: View and manage investment banking projects
2. **AI Assistant**: Generate use cases and requirements using AWS Bedrock
3. **Real-time Chat**: Collaborate with AI assistant in real-time
4. **Project Submission**: Submit draft projects to ServiceNow groups
5. **URL Analysis**: Create projects by analyzing web articles

### Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
```

## Troubleshooting

### Common Issues

1. **AWS Bedrock Access Denied**:
   - Verify AWS credentials are correct
   - Check Bedrock model access in AWS Console
   - Ensure proper IAM permissions

2. **Port Already in Use**:
   - Kill existing processes: `lsof -ti:5000 | xargs kill -9`
   - Or change port in vite.config.ts

3. **Module Not Found Errors**:
   - Clear node_modules: `rm -rf node_modules package-lock.json`
   - Reinstall: `npm install`

4. **Data File Issues**:
   - Delete `data.json` to reset all data
   - The file will be recreated with default data on restart

### Getting AWS Credentials

1. AWS Console → IAM → Users
2. Select your user → Security credentials
3. Create access key → Application running outside AWS
4. Copy Access Key ID and Secret Access Key
5. Add to `.env` file

### Bedrock Model Access

1. AWS Console → Bedrock → Model access
2. Request access to "Anthropic Claude 3 Sonnet"
3. Wait for approval (usually instant)

## Environment Variables Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `AWS_ACCESS_KEY_ID` | AWS Access Key | `AKIA...` |
| `AWS_SECRET_ACCESS_KEY` | AWS Secret Key | `...` |
| `AWS_REGION` | AWS Region | `us-east-1` |

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Verify all environment variables are set correctly
3. Ensure AWS Bedrock access is properly configured
4. Check server logs for specific error messages

## Deployment

### Option 1: Replit Deployment (Recommended)

1. **Deploy on Replit**:
   - Click the "Deploy" button in your Replit environment
   - Configure environment variables in Replit Secrets:
     - `AWS_ACCESS_KEY_ID`: Your AWS access key
     - `AWS_SECRET_ACCESS_KEY`: Your AWS secret key  
     - `AWS_REGION`: us-east-1
   - Replit will automatically handle the build and deployment

2. **Domain**: Your app will be available at `https://your-repl-name.your-username.replit.app`

### Option 2: Manual ZIP Deployment (Standalone)

1. **Build the Application**:
   ```bash
   # Install dependencies
   npm install
   
   # Build frontend and backend
   npm run build
   
   # Create deployment package
   mkdir smart-sdlc-deploy
   cp -r dist/ smart-sdlc-deploy/
   cp package.json smart-sdlc-deploy/
   cp -r node_modules/ smart-sdlc-deploy/
   
   # Create ZIP file
   zip -r smart-sdlc-production.zip smart-sdlc-deploy/
   ```

2. **Deploy on Your Server**:
   ```bash
   # Upload and extract the ZIP file on your server
   unzip smart-sdlc-production.zip
   cd smart-sdlc-deploy
   
   # Create environment file
   nano .env
   ```

3. **Environment File (.env)**:
   ```env
   AWS_ACCESS_KEY_ID=your_aws_access_key_here
   AWS_SECRET_ACCESS_KEY=your_aws_secret_key_here
   AWS_REGION=us-east-1
   NODE_ENV=production
   PORT=5000
   ```

4. **Start the Application**:
   ```bash
   # Run the production server
   npm start
   
   # Or use PM2 for production process management
   npm install -g pm2
   pm2 start "npm start" --name "smart-sdlc"
   pm2 save
   pm2 startup
   ```

5. **Server Requirements**:
   - Node.js 18+ installed
   - Port 5000 available (or configure custom port)
   - Write permissions for data.json file
   - SSL certificate (recommended for production)

### Option 3: Docker Deployment

1. **Create Dockerfile** (in project root):
   ```dockerfile
   FROM node:18-alpine
   WORKDIR /app
   COPY package*.json ./
   RUN npm install
   COPY . .
   RUN npm run build
   EXPOSE 5000
   CMD ["npm", "start"]
   ```

2. **Build and Run**:
   ```bash
   docker build -t smart-sdlc .
   docker run -p 5000:5000 --env-file .env smart-sdlc
   ```

### Environment Variables for Production

Ensure these are set in your deployment environment:

```env
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_REGION=us-east-1
NODE_ENV=production
PORT=5000
```

### Pre-Deployment Checklist

- [ ] AWS Bedrock access configured and tested
- [ ] Environment variables set correctly
- [ ] Application builds without errors (`npm run build`)
- [ ] All features tested in development
- [ ] Data.json file permissions configured
- [ ] SSL certificate configured (for production)

## Technology Stack

- **Frontend**: React, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Node.js, Express, TypeScript
- **Storage**: File-based JSON storage (data.json)
- **AI**: AWS Bedrock (Claude 3 Sonnet)
- **Real-time**: Socket.io
- **Build**: Vite